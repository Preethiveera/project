using System;
using System.Collections.Generic;
using System.Text;

namespace CoilTracking.Data.Models
{
  public class PLCAzureAd
  {
    public string Instance { get; set; }
    public string ClientId { get; set; }
    public string TenantId { get; set; }
    public string Audience { get; set; }
    public string ScopeUrl { get; set; }
    public string SecretName { get; set; }
  }
}
