using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  //[Index(nameof(PlantName), IsUnique = true)]
  public class Plant
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }
    [Required]
    [MaxLength(200)]

    public string PlantName { get; set; }
    [Required]
    [ForeignKey("TimeZone_Id")]
    public PlantTimeZone TimeZone { get; set; }

    public string NAMCCode { get; set; }
  }
}
