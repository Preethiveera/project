﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  class CoilWeightLookup
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }
    [Required]
    public CoilType CoilType { get; set; }
    [Required]
    public float Thickness { get; set; }
    [Required]
    public float Weight { get; set; }
  }
}
