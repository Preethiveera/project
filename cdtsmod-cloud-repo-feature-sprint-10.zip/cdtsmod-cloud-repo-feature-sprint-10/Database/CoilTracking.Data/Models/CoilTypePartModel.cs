namespace CoilTracking.Data.Models
{
  public class CoilTypePartModel
  {
    public int CoilTypeId { get; set; }
    public string PartNumber { get; set; }

    public string Models { get; set; }

    public Part Parts { get; set; }
  }
}
