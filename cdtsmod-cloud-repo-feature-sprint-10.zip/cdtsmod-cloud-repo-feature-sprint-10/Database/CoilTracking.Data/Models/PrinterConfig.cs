﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  public class PrinterConfig
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }

    [Required, StringLength(15)]
    public string IPAddress { get; set; }

    [Required]
    public int PortNumber { get; set; }

    [Required]
    public string PrinterName { get; set; }

    [Required]
    public string Line { get; set; }

    [Required]
    public string NAMCCode { get; set; }

    [Required]
    public bool Disabled { get; set; }
  }
}
