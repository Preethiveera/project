﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  public class Line
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }
    [Required]
    [ForeignKey("Plant_Id")]
    public Plant Plant { get; set; }
    public int Plant_Id { get; set; }
    [Required]
    [MaxLength(200)]
    public string LineName { get; set; }
    [Required]
    [ForeignKey("OPCServer_Id")]
    public OPCConfig OPCServer { get; set; }
    public int OPCServer_Id { get; set; }
    [Required]
    [MaxLength(512)]
    public string LinePath { get; set; }
    [Required]
    [MaxLength(512)]
    public string Tags { get; set; }
    public bool Subscribed { get; set; }
    public bool Disabled { get; set; }
  }
}
