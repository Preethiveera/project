using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;

namespace CoilTracking.Data.Models
{
  //[Index(nameof(PartNumber), IsUnique = true)]
  public class Part
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }
    [Required]
    [MaxLength(25)]
    public string PartNumber { get; set; }
    [Required]
    [MaxLength(255)]
    public string PartName { get; set; }
    public bool Disabled { get; set; }

    public int StrokeCount { get; set; }

    public int Plant_Id { get; set; }
  }
}
