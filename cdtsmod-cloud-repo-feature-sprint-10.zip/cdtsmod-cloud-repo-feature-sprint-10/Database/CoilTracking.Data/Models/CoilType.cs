using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  //[Index(nameof(Name),IsUnique =true)]
  public class CoilType
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }

    /// <summary>
    /// The name of the coil Type (Such as 1-1-A, 1-5-Y, 2-3-D). Also referred to as "Coil Location" by stamping
    /// </summary>
    [Required]
    [MaxLength(25)]
    public string Name { get; set; }

    /// <summary>
    /// The Theoretical Width of the coil type (measured in mm)
    /// </summary>
    [Required]
    public int Width { get; set; }

    /// <summary>
    /// The Theoretical Thickness of the coil type (measured in mm)
    /// </summary>
    [Required]
    public decimal Thickness { get; set; }

    /// <summary>
    /// From the BUS list, defines the coil metallurgy
    /// </summary>
    [Required, MaxLength(25)]
    public string Spec { get; set; }

    /// <summary>
    /// The zone this CoilType will be placed in.
    /// </summary>
    /// 
    [ForeignKey("CoilFieldZone_Id")]
    public CoilFieldZone CoilFieldZone { get; set; }

    /// <summary>
    /// The desired number of coils of this type that should be in the zone at a time + a partial. Not a hard max, more could be placed there.
    /// </summary>
    [Required]
    public int NumCoils { get; set; }

    public bool Disabled { get; set; }

    public decimal Yield { get; set; }

    /// <summary>
    /// The min thickness allowed for the tolerance
    /// </summary>
    public decimal MinThickness { get; set; }

    /// <summary>
    /// The max thickness allowed for the tolerance
    /// </summary>
    public decimal MaxThickness { get; set; }

    /// <summary>
    /// The min width allowed for the tolerance
    /// </summary>
    public decimal MinWidth { get; set; }

    /// <summary>
    /// The max width allowed for the tolerance
    /// </summary>
    public decimal MaxWidth { get; set; }

    /// <summary>
    /// The list of Y #'s associated with this Coil Type
    /// </summary>
    public virtual List<CoilTypeYNA> CoilTypeYNAs { get; set; }


    public int Plant_Id { get; set; }

  }
}
