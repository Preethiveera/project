using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  public class PartModel
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }
    [Key, Column(Order = 0)]
    [Required]
    [ForeignKey("Part_Id")]
    public Part Part { get; set; }
    [Key, Column(Order = 1)]
    [Required]
    [ForeignKey("Model_Id")]
    public Model Model { get; set; }

    public int Plant_Id { get; set; }
  }
}
