using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  // [Index(nameof(DataNumber), nameof(Line_Id),Name = "IX_LineDataNum", IsUnique = true)]
  public class BlankInfo
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }

    [Required]
   // [Index("IX_LineDataNum", 1, IsUnique = true)]
    public int DataNumber { get; set; }

    [Required]
    [ForeignKey("Line_Id")]
    public virtual Line Line { get; set; }

   // [Index("IX_LineDataNum", 2, IsUnique = true)]
    public int Line_Id { get; set; }

    [Required]
    [ForeignKey("Part_Id")]
    public Part Part { get; set; }

    [Required]
    [ForeignKey("CoilType_Id")]
    public CoilType CoilType { get; set; }

    [Required]
    public decimal Pitch { get; set; }

    [Required]
    public int Width { get; set; }

    public decimal Weight { get; set; }

    public int DieNo { get; set; }

    public int StackSize { get; set; }

    public bool Disabled { get; set; }

    /// <summary>
    /// The min pitch allowed for the tolerance
    /// </summary>
    public decimal MinPitch { get; set; }

    /// <summary>
    /// The max pitch allowed for the tolerance
    /// </summary>
    public decimal MaxPitch { get; set; }

    /// <summary>
    /// The min width allowed for the tolerance
    /// </summary>
    public decimal MinWidth { get; set; }

    /// <summary>
    /// The max width allowed for the tolerance
    /// </summary>
    public decimal MaxWidth { get; set; }

    /// <summary>
    /// The Press related to this Data#/BlankInfo (Not Required currently, could be null)
    /// </summary>
    /// 
    [ForeignKey("Press_Id")]
    public virtual Press Press { get; set; }
    public decimal RewindWeight { get; set; }

    [ForeignKey("Plant_Id")]
    public Plant Plant { get; set; }
    public int Plant_Id { get; set; }
  }
}
