namespace CoilTracking.Data.Models
{
  public class BlockingDiagramConfiguration
  {
    public AWSS3Configuration AWSS3 { get; set; }
  }
  public class AWSS3Configuration
  {
    public int MaxUploadFile { get; set; }
    public string BucketName { get; set; }
  }
}
