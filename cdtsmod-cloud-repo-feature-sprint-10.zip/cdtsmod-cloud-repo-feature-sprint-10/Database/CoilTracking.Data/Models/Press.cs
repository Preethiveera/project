using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  // [Index(nameof(Name), IsUnique = true)]
  public class Press
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }

    /// <summary>
    /// The Press's Name
    /// </summary>
    [Required, MaxLength(10),]
    public string Name { get; set; }

    public bool Disabled { get; set; }
    public int Plant_Id { get; set; }
  }
}
