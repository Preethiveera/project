using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  public class RunOrderList
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }
    [Required]
    [Column(TypeName = "Date")]
    public DateTime Date { get; set; }
    [Required]
    [ForeignKey("Line_Id")]
    public Line Line { get; set; }
    [Required]
    [ForeignKey("Shift_Id")]
    public Shift Shift { get; set; }

    [MaxLength(1)]
    public string PatternLetter { get; set; }

    /// <summary>
    /// This will be the quantities for each part/model in the pattern... This is still pending feedback from Melinda
    /// </summary>
    public virtual List<RunOrderListQuantity> Quantities { get; set; }

    [ForeignKey("Plant_Id")]
    public Plant Plant { get; set; }
    public int Plant_Id { get; set; }
  }
}
