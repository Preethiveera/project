using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  //[Index(nameof(Year), nameof(Month), nameof(Part),Name = "IX_YearMonthPart", IsUnique = true)]
  public class PartLotSize
  {
    [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }
    [Required]
    public int Year { get; set; }
    [Required]
    public int Month { get; set; }

    //TODO
    [Required]
    [ForeignKey("Part_Id")]
    public int Part { get; set; }

    [Required]

    public int LotSize { get; set; }

    public int Plant_Id { get; set; }
  }
}
