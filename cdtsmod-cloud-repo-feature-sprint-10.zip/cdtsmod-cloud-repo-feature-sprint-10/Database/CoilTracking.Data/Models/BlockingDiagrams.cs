﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  public class BlockingDiagrams
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }

    [Required]
    [Index(IsUnique = true)]
    public int DataNumber { get; set; }

    [DisplayName("Upload Image")]
    public string ImagePath { get; set; }

  }
}
