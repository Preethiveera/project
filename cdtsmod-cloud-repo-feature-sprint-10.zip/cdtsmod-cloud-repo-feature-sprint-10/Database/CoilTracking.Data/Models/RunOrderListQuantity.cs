using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  /// <summary>
  /// Rough draft of the class, waiting for feedback from Melinda
  /// </summary>
  public class RunOrderListQuantity
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }
    [Required]
    public int SortOrder { get; set; }
    [Required]
    [ForeignKey("Part_Id")]
    public Part Part { get; set; }
    [Required]
    [ForeignKey("BlankInfo_Id")]
    public BlankInfo BlankInfo { get; set; }
    [Required]
    public int Quantity { get; set; }
    /// <summary>
    /// Store the override quantity entered by the team leader
    /// </summary>
    public int OverrideQty { get; set; }

    [Required]
    [ForeignKey("RunOrderList_Id")]
    public RunOrderList RunOrderList { get; set; }

    /// <summary>
    /// Flag (not stored in database) to tell if it is incomplete
    /// </summary>
    [NotMapped]
    public bool Incomplete { get; set; }

    [ForeignKey("Plant_Id")]
    public Plant Plant { get; set; }
    public int Plant_Id { get; set; }
  }

  public class RunOrderItemComparer : IComparer<RunOrderListQuantity>
  {
    public int Compare(RunOrderListQuantity x, RunOrderListQuantity y)
    {
      if (x == null)
      {
        if (y == null)
        {
          return 0;
        }
        else
        {
          return -1;
        }
      }
      else
      {
        if (y == null)
        {
          return 1;
        }
        else
        {
          int retval = x.SortOrder.CompareTo(y.SortOrder);

          if (retval != 0)
          {
            return retval;
          }
          else
          {
            return x.SortOrder.CompareTo(y.SortOrder);
          }
        }
      }
    }
  }
}
