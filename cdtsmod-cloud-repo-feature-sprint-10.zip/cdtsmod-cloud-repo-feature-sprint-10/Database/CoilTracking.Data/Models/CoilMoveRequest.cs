using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  /// <summary>
  /// The type of coil movement requested
  /// </summary>
  public enum CoilMoveRequestType
  {
    CoilRequest = 1,
    CoilReturn = 2,
    CoilReject = 3
  }

  /// <summary>
  /// The database model for a Coil Move Request (Of type Request or Return)
  /// </summary>
  public class CoilMoveRequest
  {
    /// <summary>
    /// The Id of the request
    /// </summary>
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }

    /// <summary>
    /// The type of Request this is
    /// </summary>
    [Required]
    [ForeignKey("Requesttype")]
    public CoilMoveRequestType RequestType { get; set; }

    /// <summary>
    /// The Line the Coil move is for
    /// </summary>
    [Required]
    [ForeignKey("Line_Id")]
    public Line Line { get; set; }

    /// <summary>
    /// The Coil requested to be moved by the line
    /// </summary>
    [Required]
    [ForeignKey("Coil_Id")]
    public Coil Coil { get; set; }

    /// <summary>
    /// The date/time the move was requested
    /// </summary>
    [Required]
    public DateTime Requested { get; set; }

    /// <summary>
    /// The date/time it was Fulfilled, null means it is an open request
    /// </summary>
    public DateTime? Fulfilled { get; set; }

    /// <summary>
    /// Flag to say if this move request has been cancelled
    /// </summary>
    public bool IsCancelled { get; set; }

    public int Plant_Id { get; set; }
  }
}
