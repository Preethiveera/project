using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  public class CoilFieldZone
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }

    /// <summary>
    /// The name of the zone. 1,2,3,4,5
    /// </summary>
    [Required]
    [StringLength(25)]
    public string Name { get; set; }

    /// <summary>
    /// The color of the zone, used as background color on Andon and maybe other places
    /// </summary>
    [StringLength(10)]
    public string Color { get; set; }

    /// <summary>
    /// The color to use for text inside the zone
    /// </summary>
    [StringLength(10)]
    public string TextColor { get; set; }

    /// <summary>
    /// The CoilField this Zone is a part of. TMMK has just 1 field, but others may have multiple zones
    /// </summary>
    [Required]
    [ForeignKey("CoilField_Id")]
    public virtual CoilField CoilField { get; set; }

    /// <summary>
    /// The list of locations in the zone. A1, A2, B1, B2, etc....
    /// </summary>
    public List<CoilFieldLocation> Locations { get; set; }
    public bool Disabled { get; set; }

    public int Plant_Id { get; set; }
  }
}
