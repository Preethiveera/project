using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  //[Index(nameof(Part), IsUnique = true)]
  public class ProdPlan
  {
    [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }
    [Required]
    [ForeignKey("Part_Id")]
    public Part Part { get; set; }
    [Required]
    public int LotSize { get; set; }

    public int Plant_Id { get; set; }
  }
}
