using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  /// <summary>
  /// A listing of Y #s for the Coil Type
  /// </summary>

  //[Index(nameof(YNA),IsUnique =true)]
  public class CoilTypeYNA
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }

    /// <summary>
    /// The CoilType this is the YNA entry for
    /// </summary>
    ///
    [Required]
    [ForeignKey("CoilType_Id")]
    public CoilType CoilType { get; set; }

    public int CoilType_Id { get; set; }

    /// <summary>
    /// The YNA # for the coil type (Such as YNA0144774)
    /// </summary>
    [Required]
    [StringLength(25)]
    public string YNA { get; set; }

    /// <summary>
    /// The date this YNA was added to the CoilType
    /// </summary>
    public DateTime DateAdded { get; set; }

    /// <summary>
    /// Rather this YNA is disabled for the coil type or not
    /// </summary>
    public bool Disabled { get; set; }

    /// <summary>
    /// The MaterialType for the YNA
    /// </summary>
    ///
    [Required]
    [ForeignKey("MaterialType_Id")]
    [DefaultValue("1")]
    public MaterialType MaterialType { get; set; }

    public int Plant_Id { get; set; }
  }
}
