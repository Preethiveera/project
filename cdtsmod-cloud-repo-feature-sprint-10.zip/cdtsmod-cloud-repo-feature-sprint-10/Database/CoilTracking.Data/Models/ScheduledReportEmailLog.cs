﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  public class ScheduledReportEmailLog
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }
    public string MailInfo { get; set; }
    public bool IsSccess { get; set; }
    public string ExceptionMessage { get; set; }
    public DateTime LogTimestamp { get; set; }
  }
}
