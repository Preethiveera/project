using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  public class CoilStatus
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }

    /// <summary>
    /// The name of the status such as - New, Partial, Partial Needs Weighed, Completely Used, Rejected On Hand, Rejected Returned, Returned
    /// </summary>
    [Required, StringLength(25)]
    public string Name { get; set; }

    /// <summary>
    /// The color of the status, used as background color on Andon and maybe other places
    /// </summary>
    [StringLength(10)]
    public string Color { get; set; }

    /// <summary>
    /// The color to use for text
    /// </summary>
    [StringLength(10)]
    public string TextColor { get; set; }

    /// <summary>
    /// A simple boolean field to determine if a coil in this status is usable
    /// </summary>
    public bool IsUsable { get; set; }

    public int Plant_Id { get; set; }

    /// <summary>
    /// A simple boolean field to determine if a coil in this status is counted as 'in inventory'
    /// </summary>
    public bool InInventory { get; set; }

    [NotMapped]
    public bool IsReject
    {
      get
      {
        if (!string.IsNullOrWhiteSpace(this.Name) && this.Name.Contains("Reject"))
        {
          return true;
        }
        return false;
      }
    }
  }

  public enum CoilStatusNames
  {
    New = 1,
    Partial = 2,
    PartialNeedsWeighed = 3,
    CompletelyUsed = 4,
    RejectedOnHand = 5,
    RejectedReturned = 6,
    Returned = 7,
    LoadedatLine = 8,
    TryoutCoils = 9,
  }
}
