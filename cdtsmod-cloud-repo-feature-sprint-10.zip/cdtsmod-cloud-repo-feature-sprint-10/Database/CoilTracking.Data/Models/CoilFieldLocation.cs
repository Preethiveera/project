using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  public class CoilFieldLocation
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }
    [Required]
    [StringLength(25)]
    public string Name { get; set; }
    [Required]
    [ForeignKey("Zone_Id")]
    public CoilFieldZone Zone { get; set; }
    [Required]
    public bool IsEmpty { get; set; }
    [Required]
    public int Row { get; set; }
    [Required]
    public int Column { get; set; }
    public bool Disabled { get; set; }

    public int Plant_Id { get; set; }


    public virtual Coil Coil { get; set; }

  }
}
