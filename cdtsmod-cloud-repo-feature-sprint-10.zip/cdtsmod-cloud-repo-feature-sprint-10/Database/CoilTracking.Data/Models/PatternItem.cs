using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  public class PatternItem
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }
    [Required]
    public int SortOrder { get; set; }
    [Required]
    [StringLength(50)]
    public string PartNumber { get; set; }
    [Required]
    [StringLength(200)]
    public string ModelNumber { get; set; }
    [StringLength(250)]
    public string PartName { get; set; }
    public string DataNumber { get; set; }

    [ForeignKey("Plant_Id")]
    public Plant Plant { get; set; }
    public int Plant_Id { get; set; }
  }
}
