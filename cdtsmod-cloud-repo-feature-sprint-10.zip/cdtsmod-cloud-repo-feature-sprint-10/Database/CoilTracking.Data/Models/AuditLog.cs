﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  public enum AuditActionType
  {
    Checkin = 1,
    FulFillRequest = 2,
    CoilMove = 3,
    CoilRequest = 4,
    CoilReturn = 5,
    CoilReject = 6,
    EnableDisable = 7,
    CreateEntity = 8,
    ModifyEntity = 9,
    ModifyPattern = 10,
    ModifyPatternCalendar = 11,
    ModifyRunOrderList = 12,
    CreateRunOrderListByOperator = 13,
    CoilMoveRequest = 14,
    DeleteCoilMoveRequest = 15,
    CancelCoilMoveRequest = 16
  }
  //CCDTS-15 : Added new option 'CancelCoilMoveRequest' to track coil cancel requests

  //[Index(nameof(ActionTime))]
  public class AuditLog
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }

    [Required]
    [MaxLength(40)]
    public string UserName { get; set; }

    [Required]
    public AuditActionType ActionType { get; set; }

    [Required]
    public DateTime ActionTime { get; set; }

    [Required]
    public string Log { get; set; }
  }
}
