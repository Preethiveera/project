using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace CoilTracking.Data.Models
{
  public class CoilField
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }
    [Required]
    [StringLength(25)]
    public string Name { get; set; }
    public List<CoilFieldZone> Zones { get; set; }
    public bool Disabled { get; set; }

    [ForeignKey("Plant_Id")]
    public Plant Plant { get; set; }
    public int Plant_Id { get; set; }
  }
}
