using System;
using System.Collections.Generic;
using System.Text;

namespace CoilTracking.Data.Models
{
  public class PLCIntegrationURLS
  {
    public Dictionary<string,string> PlantUrl { get; set; }
    public string SubscribeLineData { get; set; }
    public string UnSubscribeLineData { get; set; }
    public string PrintTag { get; set; }

  }
  public class PlantUrl
  {
    public Dictionary<string, string> Urls
    {
      get;
      set;
    }
  }

}
