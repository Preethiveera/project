using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  public enum RunOrderItemStatus
  {
    New = 1,
    Completed = 2,
    Incomplete = 3,
    CarriedOver = 4,
    RunStarted = 5,
    Removed = 6
  }

  public class IncompleteRunOrderItem
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }

    [Required]
    [ForeignKey("Line_Id")]
    public Line Line { get; set; }

    [Required]
    [ForeignKey("RunOrderList_Id")]
    public RunOrderList RunOrderList { get; set; }

    [Required]
    [ForeignKey("RunOrderItem_Id")]
    public RunOrderListQuantity RunOrderItem { get; set; }

    [Required]
    [ForeignKey("Part_Id")]
    public Part Part { get; set; }

    [Required]
    public int DataNumber { get; set; }

    [Required]
    public int SortOrder { get; set; }

    [Required]
    public int Quantity { get; set; }

    [Required]
    [ForeignKey("Status")]
    public RunOrderItemStatus Status { get; set; }

    [Required]
    [Column(TypeName = "Date")]
    public DateTime Date { get; set; }

    /// <summary>
    /// The RunOrder the incomplete item was carried over to.
    /// </summary>
    ///
    [ForeignKey("CarriedOverToRunOrder_Id")]
    public RunOrderList CarriedOverToRunOrder { get; set; }

    public int Plant_Id { get; set; }
  }
}
