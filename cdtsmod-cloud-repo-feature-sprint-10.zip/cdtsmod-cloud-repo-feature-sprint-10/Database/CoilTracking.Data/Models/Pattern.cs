using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  public class Pattern
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }
    [Required]
    public DateTime CreateDate { get; set; }

    /// <summary>
    /// The Line this pattern is for (BL1, BL2, BL3, BL4)
    /// </summary>
    [Required]
    [ForeignKey("Line_Id")]
    public Line Line { get; set; }

    /// <summary>
    /// This is the pattern letter (A, B, C, D)
    /// </summary>
    [Required]
    [StringLength(1)]
    public string Name { get; set; }
    [ForeignKey("Pattern_Id")]
    public List<PatternItem> PatternItems { get; set; }

    [ForeignKey("Plant_Id")]
    public Plant Plant { get; set; }
    public int Plant_Id { get; set; }
  }
}
