﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CoilTracking.Data.Models
{
  public class PalletTag
  {
    [Key, Required]
    public int TagID { get; set; }

    [Required, StringLength(15)]
    public string PalletID { get; set; }

    [Required, StringLength(50)]
    public string SerialNumber { get; set; }

    [Required]
    public int BlanksQuantity { get; set; }

    public int PalletSequence { get; set; }

    public string PartNumber { get; set; }

    public string FTZ { get; set; }

    public Int32? RunOrderItemId { get; set; }

    public string LineName { get; set; }

    public string NAMCCode { get; set; }

    public DateTime Created { get; set; }
  }
}
