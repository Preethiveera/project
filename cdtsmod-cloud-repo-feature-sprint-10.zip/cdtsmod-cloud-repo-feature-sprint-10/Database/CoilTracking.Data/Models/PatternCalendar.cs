using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  public class PatternCalendar //this class may not be required
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }
    [Required]
    [Column(TypeName = "Date")]
    public DateTime Date { get; set; }
    [Required]
    [ForeignKey("Shift_Id")]
    public Shift Shift { get; set; }
    [Required]
    [StringLength(1)]
    public string PatternLetter { get; set; }
    [ForeignKey("Line_Id")]
    public Line Line { get; set; }
    [ForeignKey("Plant_Id")]
    public int Plant_Id { get; set; }
  }
}
