using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  /// <summary>
  /// User event such as login/logout
  /// </summary>
  //[Index(nameof(EventDate))]
  public class UserEvent
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }

    /// <summary>
    /// The User's Name
    /// </summary>
    [Required, MaxLength(150)]
    public string UserName { get; set; }

    /// <summary>
    /// The date/time when the event occurred
    /// </summary>
    [Required]
    public DateTime EventDate { get; set; }

    /// <summary>
    /// The type of event
    /// </summary>
    [Required]
    public UserEventType EventType { get; set; }

    public int Plant_Id { get; set; }
  }

  /// <summary>
  /// The type of event
  /// </summary>
  public enum UserEventType
  {
    Login = 1,
    Logout = 2,
  }
}
