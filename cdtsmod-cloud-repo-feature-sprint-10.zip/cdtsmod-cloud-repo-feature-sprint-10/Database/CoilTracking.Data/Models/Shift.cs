using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace CoilTracking.Data.Models
{
  public class Shift
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }
    [Required]
    [StringLength(25)]
    public string Name { get; set; }
    public TimeSpan Start { get; set; }
    public TimeSpan Finish { get; set; }
    public bool Disabled { get; set; }
    [StringLength(10)]
    public string BackgroundColor { get; set; } //for calendar display
    [StringLength(10)]
    public string TextColor { get; set; } // for calendar display

    public int Plant_Id { get; set; }
  }
}
