using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  //[Index(nameof(LineId), IsUnique = true)]
  public class LineData
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }
    [Required]

    public int LineId { get; set; }
    [Required]
    public string DataUpdate { get; set; }
    [Required]
    public DateTime UpdateTime { get; set; }

    public int Plant_Id { get; set; }
  }
}
