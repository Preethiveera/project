using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  public class MaterialType
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }
    [Required]
    [MaxLength(2)]
    [Index(IsUnique = true)]
    public string Name { get; set; }
    public string Description { get; set; }

  }
}
