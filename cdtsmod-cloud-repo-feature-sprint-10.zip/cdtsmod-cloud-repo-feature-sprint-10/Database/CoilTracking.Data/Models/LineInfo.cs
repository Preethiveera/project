using System;
using System.Collections.Generic;
using System.Text;

namespace CoilTracking.Data.Models
{
  public class LineInfo
  {
    public int lineId { get; set; }
    public string kepHostName { get; set; }
    public string kepServerInstance { get; set; }
    public string linePath { get; set; }
    public string[] plcTags { get; set; }
    public string responseUrl { get; set; }
  }
}
