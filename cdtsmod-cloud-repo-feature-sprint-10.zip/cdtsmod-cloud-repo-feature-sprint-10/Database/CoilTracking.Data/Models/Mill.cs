using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  //[Index(nameof(Name), IsUnique = true)]
  public class Mill
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }

    /// <summary>
    /// The Mill's Name
    /// </summary>
    [Required, MaxLength(40), Index(IsUnique = true)]
    public string Name { get; set; }

    public bool Disabled { get; set; }
    public int  Plant_Id { get; set; }
  }
}
