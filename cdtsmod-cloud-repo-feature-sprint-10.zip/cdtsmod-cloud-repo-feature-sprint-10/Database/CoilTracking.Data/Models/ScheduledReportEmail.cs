﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  public class ScheduledReportEmail
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }
    [Required]
    [EmailAddress]
    [MaxLength(100)]
    [Index(IsUnique = true)]
    public string Email { get; set; }
    [DefaultValue("0")]
    public bool CoilReport { get; set; }
    [DefaultValue("0")]
    public bool ScrapReport { get; set; }
    [DefaultValue("0")]
    public bool RunReport { get; set; }
  }
}
