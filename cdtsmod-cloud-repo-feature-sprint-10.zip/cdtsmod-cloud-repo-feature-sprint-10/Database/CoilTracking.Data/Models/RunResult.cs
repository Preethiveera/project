using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  public class RunResult
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }
    [Required]
    [ForeignKey("RunOrderList_Id")]
    public RunOrderList RunOrderList { get; set; }
    [Required]
    public DateTime RunStarted { get; set; }
    [Required]
    public int DataNumber { get; set; }
    [Required]
    [MaxLength(25)]
    public string PartNumber { get; set; }
    [Required]
    public int BlanksRequested { get; set; }
    [Required]
    [ForeignKey("Coil_Id")]
    public Coil Coil { get; set; }
    [Required]
    public decimal MeasuredThickness { get; set; }
    [Required]
    public int MeasuredWidth { get; set; }
    [Required]
    public int MeasuredPitch { get; set; }
    public int PressCount { get; set; }
    public int BlanksProduced { get; set; }
    public int DownTime { get; set; }
    [MaxLength(512)]
    public string Comments { get; set; }
    public decimal WeightUsed { get; set; }
    public DateTime RunFinished { get; set; }

    public decimal BlankWeight { get; set; }
    public decimal BlankPitch { get; set; }
    public decimal BlankWidth { get; set; }
    public decimal BlankStackSize { get; set; }
    public decimal BlankDieNo { get; set; }
    [MaxLength(25)]
    public string BlankCoilTypeName { get; set; }
    public decimal CoilWeightBefore { get; set; }

    public int AdcDt { get; set; }
    public int MaintDt { get; set; }
    public int ToolDieDt { get; set; }
    public int ProdDt { get; set; }
    public int KanbanDt { get; set; }
    public int TryoutDt { get; set; }
    public int SchdDt { get; set; }
    [MaxLength(100)]
    public string ModifiedBy { get; set; }

    [ForeignKey("Plant_Id")]
    public Plant Plant { get; set; }
    public int Plant_Id { get; set; }

  }
}
