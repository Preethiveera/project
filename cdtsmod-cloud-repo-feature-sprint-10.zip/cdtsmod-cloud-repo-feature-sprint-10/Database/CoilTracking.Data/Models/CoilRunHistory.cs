using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  /// <summary>
  /// Keeps track of the history of a coil. When a coil is used on a RunOrderList, mark the weight used by adding a new CoilRunHistory object to Coil.CoilRunHistory
  /// </summary>
  public class CoilRunHistory
  {
    public int Id { get; set; }

    /// <summary>
    /// The Coil this history is for
    /// </summary>
    /// 

    [ForeignKey("Coil_Id")]
    public Coil Coil { get; set; }

    /// <summary>
    /// The RunOrderList it was used in
    /// </summary>
    ///    
    [ForeignKey("RunOrderList_Id")]
    public RunOrderList RunOrderList { get; set; }

    /// <summary>
    /// The weight used for the Run
    /// </summary>
    public int WeightUsed { get; set; }

  
    public int Plant_Id { get; set; }
  }
}
