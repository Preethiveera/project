using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;

namespace CoilTracking.Data.Models
{
  //[Index(nameof(FTZ), IsUnique = true)]
  //[Index(nameof(CheckInDate))]
  public class Coil
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]

    public int Id { get; set; }

    /// <summary>
    /// The status of the coil
    /// </summary>
    [Required]
    [ForeignKey("CoilStatus_Id")]
    public CoilStatus CoilStatus { get; set; }

    /// <summary>
    /// The Order # the coil is for (Also called a PO #)
    /// </summary>
    [Required]
    public int OrderNo { get; set; }

    /// <summary>
    /// The type of coil, based on YNA
    /// </summary>
    [Required]
 
    [ForeignKey("CoilType_Id")]
    public CoilType CoilType { get; set; }

    /// <summary>
    /// The Mill the coil is from
    /// </summary>
    [Required]
    [ForeignKey("Mill_Id")]
    public Mill Mill { get; set; }
    /// <summary>
    /// The serial # of the original coil. A larger coil may be cut down into multiple, each showing the same original Serial #.
    /// </summary>
    [MaxLength(25)]
    public string SerialNum { get; set; }

    /// <summary>
    /// The original Actual Weight of the coil (measured in KG)
    /// </summary>
    [Required]
    public int OriginalWeight { get; set; }

    /// <summary>
    /// The FTZ (Foreign Trade Zone) number of the coil (from Toyota Tsusho) This number should be unique per each physical coil we receive.
    /// </summary>
    [MaxLength(15)]
    public string FTZ { get; set; }

    /// <summary>
    /// The date and time the coil was originally checked in, used for the FIFO process
    /// </summary>
    public DateTime CheckInDate { get; set; }

    /// <summary>
    /// The date and time the coil was returned to the coilfield/zone/location. Indicating the coil is partially used
    /// </summary>
    public DateTime? ReturnedToField { get; set; }

    /// <summary>
    /// The current location of the coil. A null location means it is either loaded into a blanking line, or possibly it is used up?
    /// </summary>
    
    [ForeignKey("CoilFieldLocation_Id")]
    public CoilFieldLocation CoilFieldLocation { get; set; }

    public int? CoilFieldLocation_Id { get; set; }
    /// <summary>
    /// The history of runs this coil has been used in
    /// </summary>
    public List<CoilRunHistory> CoilRunHistory { get; set; }

    /// <summary>
    /// A coil has a specific Coil Type, but a Coil Type can have multiple Y#'s. This is the specific Y# for this coil.
    /// </summary>
    [StringLength(25)]
    public string YNA { get; set; }

    /// <summary>
    /// The original Actual Weight of the coil (measured in kg)
    /// Sums up all CoilRunHistory for this coil, could be slower than expected
    /// </summary>
    [NotMapped]
    public int CurrentWeight
    {
      get
      {
        int weightUsed = 0;
        if (CoilRunHistory != null)
        {
          weightUsed = CoilRunHistory.Sum(item => item.WeightUsed);
        }
        return OriginalWeight - (weightUsed + UnAccountedWeight);
      }
    }

    /// <summary>
    /// Any 'extra' used/unaccounted weight not part of the Run History
    /// </summary>
    public int UnAccountedWeight { get; set; }

    /// <summary>
    /// Flag to say if this coil should be used before all others (disregard FIFO logic, use Priority coils first) 
    /// If multiple Priority Coils exist, use FIFO among priority coils.
    /// </summary>
    public bool IsPriority { get; set; }

    public DateTime? BornOnDate { get; set; }
    public int Plant_Id { get; set; }
  }
}
