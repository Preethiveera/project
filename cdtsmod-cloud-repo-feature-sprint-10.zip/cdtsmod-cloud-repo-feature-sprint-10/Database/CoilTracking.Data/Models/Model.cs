using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  //[Index(nameof(ModelNumber), IsUnique = true)]
  public class Model
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }
    [Required, MaxLength(25)]
    public string ModelNumber { get; set; }
    [MaxLength(255)]
    public string Name { get; set; }
    public bool Disabled { get; set; }
    public int Plant_Id { get; set; }
  }
}
