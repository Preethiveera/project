﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoilTracking.Data.Models
{
  public class OPCConfig
  {
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }
    [Required]
    [MaxLength(200)]
    public string ServerName { get; set; }
    [Required]
    [MaxLength(200)]
    public string InstanceName { get; set; }
    public bool Disabled { get; set; }
  }
}
