using CoilTracking.Data.Mapping;
using CoilTracking.Data.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using CoilTracking.Common;
using Newtonsoft.Json.Linq;
using CoilTracking.Common.Constants;
using CoilTracking.Common.UsersHelperUtility;
using Microsoft.AspNetCore.Http;
using CoilTracking.Common.Exception;

namespace CoilTracking.Data
{
  public class CoilTrackingContext : DbContext
  {
    public readonly DbContextOptions<CoilTrackingContext> _options;
    private readonly IHttpContextAccessor httpContextAccessor;
    private readonly IUserHelper userHelper;

    public CoilTrackingContext(DbContextOptions<CoilTrackingContext> options, IHttpContextAccessor httpContextAccessor, IUserHelper userHelper) : base(options)
    {
      _options = options;
      this.httpContextAccessor = httpContextAccessor;
      this.userHelper = userHelper;
    }
    public DbSet<Coil> Coils { get; set; }
    public DbSet<CoilField> CoilFields { get; set; }
    public DbSet<CoilFieldLocation> CoilFieldLocations { get; set; }
    public DbSet<CoilFieldZone> CoilFieldZones { get; set; }
    public DbSet<CoilType> CoilTypes { get; set; }
    public DbSet<BlankInfo> BlankInfoes { get; set; }
    public DbSet<Line> Lines { get; set; }
    public DbSet<Model> Models { get; set; }
    public DbSet<OPCConfig> OPCConfigs { get; set; }
    public DbSet<Part> Parts { get; set; }
    public DbSet<PartModel> PartModels { get; set; }
    public DbSet<Pattern> Patterns { get; set; }
    public DbSet<PatternItem> PatternItems { get; set; }
    public DbSet<PatternCalendar> PatternCalendars { get; set; }
    public DbSet<Plant> Plants { get; set; }
    public DbSet<PlantTimeZone> PlantTimeZones { get; set; }
    public DbSet<RunOrderList> RunOrderLists { get; set; }
    public DbSet<RunOrderListQuantity> RunOrderListQuantities { get; set; }
    public DbSet<Shift> Shifts { get; set; }
    public DbSet<CoilRunHistory> CoilRunHistories { get; set; }
    public DbSet<Mill> Mills { get; set; }
    public DbSet<CoilMoveRequest> CoilMoveRequests { get; set; }
    public DbSet<LineData> LineDatas { get; set; }
    public DbSet<RunResult> RunResults { get; set; }
    public DbSet<PartLotSize> PartLotSize { get; set; }
    public DbSet<CoilStatus> CoilStatus { get; set; }
    public DbSet<ProdPlan> ProdPlans { get; set; }
    public DbSet<CoilTypeYNA> CoilTypeYNAs { get; set; }
    public DbSet<UserEvent> UserEvents { get; set; }
    public DbSet<AuditLog> AuditLogs { get; set; }
    public DbSet<Press> Presses { get; set; }
    public DbSet<IncompleteRunOrderItem> IncompleteRunOrderItems { get; set; }

    public DateTime Datetime { get; set; }
    public DbSet<MaterialType> MaterialTypes { get; set; }
    public DbSet<ScheduledReportEmail> ScheduledReportEmails { get; set; }
    public DbSet<ScheduledReportEmailLog> ScheduledReportEmailLog { get; set; }
    public DbSet<PalletTag> PalletTags { get; set; }
    public DbSet<PrinterConfig> PrinterConfigs { get; set; }
    public DbSet<BlockingDiagrams> BlockingDiagrams { get; set; }
    public DbSet<PatternLetter> PatternLetters { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
      foreach (var property in modelBuilder.Model.GetEntityTypes().SelectMany(t => t.GetProperties()).Where(p => p.ClrType == typeof(decimal) || p.ClrType == typeof(decimal?)))
      {
        // EF Core 3
        property.SetColumnType("decimal(18, 6)");
      }

      modelBuilder.ApplyConfiguration(new BlockingDiagramMap());
      modelBuilder.ApplyConfiguration(new MillMap());

      modelBuilder.Entity<CoilFieldLocation>()
       .HasOne(p => p.Coil)
       .WithOne(a => a.CoilFieldLocation)
       .HasForeignKey<Coil>(a => a.CoilFieldLocation_Id);

      modelBuilder.Entity<BlankInfo>().Property(b => b.Weight).HasColumnType("decimal(18,4)").IsRequired(true);
      modelBuilder.Entity<CoilField>().HasMany(a => a.Zones).WithOne(c => c.CoilField).OnDelete(DeleteBehavior.Cascade);

      //Default to user NAMC
      SetDefaultValues(modelBuilder);

      //Filter based on logged in user NAMC
      ApplyGlobalFilters(modelBuilder);


    }
    //Filter the entities based on NAMC
    public void ApplyGlobalFilters(ModelBuilder modelBuilder)
    {
      modelBuilder.Entity<Mill>().HasQueryFilter(b => EF.Property<int>(b, Constant.PlantId) == userHelper.GetUsernamcCode());
      modelBuilder.Entity<Coil>().HasQueryFilter(b => EF.Property<int>(b, Constant.PlantId) == userHelper.GetUsernamcCode());


      modelBuilder.Entity<CoilRunHistory>().HasQueryFilter(b => EF.Property<int>(b, Constant.PlantId) == userHelper.GetUsernamcCode());
      modelBuilder.Entity<CoilType>().HasQueryFilter(b => EF.Property<int>(b, Constant.PlantId) == userHelper.GetUsernamcCode());
      modelBuilder.Entity<CoilField>().HasQueryFilter(b => EF.Property<int>(b, Constant.PlantId) == userHelper.GetUsernamcCode());
      modelBuilder.Entity<Pattern>().HasQueryFilter(b => EF.Property<int>(b, Constant.PlantId) == userHelper.GetUsernamcCode());
      modelBuilder.Entity<RunResult>().HasQueryFilter(b => EF.Property<int>(b, Constant.PlantId) == userHelper.GetUsernamcCode());
      modelBuilder.Entity<RunOrderList>().HasQueryFilter(b => EF.Property<int>(b, Constant.PlantId) == userHelper.GetUsernamcCode());
      modelBuilder.Entity<PatternLetter>().HasQueryFilter(b => EF.Property<int>(b, Constant.PlantId) == userHelper.GetUsernamcCode());
      modelBuilder.Entity<PatternItem>().HasQueryFilter(b => EF.Property<int>(b, Constant.PlantId) == userHelper.GetUsernamcCode());
      modelBuilder.Entity<PatternCalendar>().HasQueryFilter(b => EF.Property<int>(b, Constant.PlantId) == userHelper.GetUsernamcCode());

      modelBuilder.Entity<RunOrderListQuantity>().HasQueryFilter(b => EF.Property<int>(b, Constant.PlantId) == userHelper.GetUsernamcCode());

      modelBuilder.Entity<Part>().HasQueryFilter(b => EF.Property<int>(b, Constant.PlantId) == userHelper.GetUsernamcCode());

      modelBuilder.Entity<BlankInfo>().HasQueryFilter(b => EF.Property<int>(b, Constant.PlantId) == userHelper.GetUsernamcCode());

      modelBuilder.Entity<CoilFieldLocation>().HasQueryFilter(b => EF.Property<int>(b, Constant.PlantId) == userHelper.GetUsernamcCode());

      modelBuilder.Entity<CoilMoveRequest>().HasQueryFilter(b => EF.Property<int>(b, Constant.PlantId) == userHelper.GetUsernamcCode());

      modelBuilder.Entity<PartModel>().HasQueryFilter(b => EF.Property<int>(b, Constant.PlantId) == userHelper.GetUsernamcCode());
      modelBuilder.Entity<LineData>().HasQueryFilter(b => EF.Property<int>(b, Constant.PlantId) == userHelper.GetUsernamcCode());
      modelBuilder.Entity<IncompleteRunOrderItem>().HasQueryFilter(b => EF.Property<int>(b, Constant.PlantId) == userHelper.GetUsernamcCode());
      modelBuilder.Entity<UserEvent>().HasQueryFilter(b => EF.Property<int>(b, Constant.PlantId) == userHelper.GetUsernamcCode());
      modelBuilder.Entity<Press>().HasQueryFilter(b => EF.Property<int>(b, Constant.PlantId) == userHelper.GetUsernamcCode());
      modelBuilder.Entity<ProdPlan>().HasQueryFilter(b => EF.Property<int>(b, Constant.PlantId) == userHelper.GetUsernamcCode());

      modelBuilder.Entity<Shift>().HasQueryFilter(b => EF.Property<int>(b, Constant.PlantId) == userHelper.GetUsernamcCode());
      modelBuilder.Entity<Model>().HasQueryFilter(b => EF.Property<int>(b, Constant.PlantId) == userHelper.GetUsernamcCode());
      modelBuilder.Entity<PartLotSize>().HasQueryFilter(b => EF.Property<int>(b, Constant.PlantId) == userHelper.GetUsernamcCode());

      modelBuilder.Entity<CoilFieldZone>().HasQueryFilter(b => EF.Property<int>(b, Constant.PlantId) == userHelper.GetUsernamcCode());


      modelBuilder.Entity<CoilTypeYNA>().HasQueryFilter(e =>
      this.Set<CoilType>().Any(ei => ei.Plant_Id == userHelper.GetUsernamcCode()));

      modelBuilder.Entity<CoilMoveRequest>().HasQueryFilter(e =>
      this.Set<Coil>().Any(ei => ei.Plant_Id == userHelper.GetUsernamcCode()));



    }

    //Update with NAMC id
    public void SetDefaultValues(ModelBuilder modelBuilder)
    {

      modelBuilder.Entity<Mill>()
      .Property(b => b.Plant_Id)
      .HasDefaultValue(userHelper.GetUsernamcCode());

      modelBuilder.Entity<Coil>()
      .Property(b => b.Plant_Id)
      .HasDefaultValue(userHelper.GetUsernamcCode());

      modelBuilder.Entity<CoilFieldLocation>()
      .Property(b => b.Plant_Id)
      .HasDefaultValue(userHelper.GetUsernamcCode());

      modelBuilder.Entity<CoilTypeYNA>()
      .Property(b => b.Plant_Id)
      .HasDefaultValue(userHelper.GetUsernamcCode());

      modelBuilder.Entity<Shift>()
      .Property(b => b.Plant_Id)
      .HasDefaultValue(userHelper.GetUsernamcCode());


      modelBuilder.Entity<Model>()
      .Property(b => b.Plant_Id)
      .HasDefaultValue(userHelper.GetUsernamcCode());

      modelBuilder.Entity<CoilMoveRequest>()
      .Property(b => b.Plant_Id)
      .HasDefaultValue(userHelper.GetUsernamcCode());

      modelBuilder.Entity<LineData>()
     .Property(b => b.Plant_Id)
     .HasDefaultValue(userHelper.GetUsernamcCode());

      modelBuilder.Entity<PartModel>()
     .Property(b => b.Plant_Id)
     .HasDefaultValue(userHelper.GetUsernamcCode());

      modelBuilder.Entity<Press>()
      .Property(b => b.Plant_Id)
      .HasDefaultValue(userHelper.GetUsernamcCode());

      modelBuilder.Entity<IncompleteRunOrderItem>()
      .Property(b => b.Plant_Id)
      .HasDefaultValue(userHelper.GetUsernamcCode());

      modelBuilder.Entity<ProdPlan>()
      .Property(b => b.Plant_Id)
      .HasDefaultValue(userHelper.GetUsernamcCode());

      modelBuilder.Entity<UserEvent>()
      .Property(b => b.Plant_Id)
      .HasDefaultValue(userHelper.GetUsernamcCode());

      modelBuilder.Entity<PartLotSize>()
       .Property(b => b.Plant_Id)
      .HasDefaultValue(userHelper.GetUsernamcCode());

      modelBuilder.Entity<CoilFieldZone>()
    .Property(b => b.Plant_Id)
   .HasDefaultValue(userHelper.GetUsernamcCode());

      modelBuilder.Entity<CoilType>()
          .Property(c => c.Plant_Id)
          .HasDefaultValueSql("userHelper.GetUsernamcCode()");

      modelBuilder.Entity<CoilField>()
          .Property(c => c.Plant_Id)
          .HasDefaultValueSql("userHelper.GetUsernamcCode()");

      modelBuilder.Entity<Pattern>()
           .Property(b => b.Plant_Id)
           .HasDefaultValueSql("userHelper.GetUsernamcCode()");

      modelBuilder.Entity<RunResult>()
          .Property(b => b.Plant_Id)
          .HasDefaultValueSql("userHelper.GetUsernamcCode()");

      modelBuilder.Entity<RunOrderList>()
         .Property(b => b.Plant_Id)
         .HasDefaultValueSql("userHelper.GetUsernamcCode()");

      modelBuilder.Entity<Pattern>()
         .Property(b => b.Plant_Id)
         .HasDefaultValueSql("userHelper.GetUsernamcCode()");

      modelBuilder.Entity<PatternCalendar>()
         .Property(b => b.Plant_Id)
         .HasDefaultValueSql("userHelper.GetUsernamcCode()");

      modelBuilder.Entity<PatternItem>()
         .Property(b => b.Plant_Id)
         .HasDefaultValueSql("userHelper.GetUsernamcCode()");

      modelBuilder.Entity<PatternLetter>()
         .Property(b => b.Plant_Id)
         .HasDefaultValueSql("userHelper.GetUsernamcCode()");

      modelBuilder.Entity<RunOrderListQuantity>()
         .Property(b => b.Plant_Id)
         .HasDefaultValueSql("userHelper.GetUsernamcCode()");


      modelBuilder.Entity<CoilRunHistory>()
       .Property(b => b.Plant_Id)
       .HasDefaultValueSql("userHelper.GetUsernamcCode()");


      modelBuilder.Entity<Part>()
     .Property(b => b.Plant_Id)
     .HasDefaultValue(userHelper.GetUsernamcCode());

      modelBuilder.Entity<BlankInfo>()
     .Property(b => b.Plant_Id)
     .HasDefaultValueSql("userHelper.GetUsernamcCode()");
    }

    //Fetching the user NAMC
    protected void OnContextCreated()
    {
      // TO DO
    }

    /// <summary>
    /// The SaveChanges call passing in the user and action tpe for the Audit log
    /// </summary>
    /// <param name="user"></param>
    /// <param name="actionType"></param>
    /// <returns></returns>
    public Task<int> SaveChangesAsync(string user, AuditActionType actionType)
    {
      WriteChangesToAuditLog(user, actionType);
      try
      {
        //TODO
        ValidateInput();

        return base.SaveChangesAsync();
      }
      catch (DbUpdateException ex)
      {
        if (ex.InnerException != null)
        {
          if (ex.InnerException.InnerException != null)
          {
            throw ex.InnerException.InnerException;
          }
          else
          {
            throw ex.InnerException;
          }
        }
        else
        {
          throw; //throw original exception
        }
      }

    }

    /// <summary>
    /// The SaveChanges call passing in the user and action tpe for the Audit log
    /// </summary>
    /// <param name="user"></param>
    /// <param name="actionType"></param>
    /// <returns></returns>
    public int SaveChanges(string user, AuditActionType actionType)
    {
      WriteChangesToAuditLog(user, actionType);

      try
      {
        ValidateInput();
        return base.SaveChanges();
      }
      catch (DbUpdateException ex)
      {
        if (ex.InnerException != null)
        {
          if (ex.InnerException.InnerException != null)
          {
            throw ex.InnerException.InnerException;
          }
          else
          {
            throw ex.InnerException;
          }
        }
        else
        {
          throw; //throw original exception
        }
      }
      catch (Exception)
      {
        throw;
      }
    }

    /// <summary>
    /// Detect and write changes to the AuditLog
    /// </summary>
    /// <param name="user"></param>
    /// <param name="actionType"></param>
    private void WriteChangesToAuditLog(string user, AuditActionType actionType)
    {
      this.ChangeTracker.DetectChanges();
      var changes = from e in ChangeTracker.Entries()
                    where e.State == EntityState.Added
                        || e.State == EntityState.Modified
                        || e.State == EntityState.Deleted
                    select e;

      //TODO
      if (user != "Seeding" && user != "OPCClient")
      {

        bool previousLazyLoadEnabled = this.ChangeTracker.LazyLoadingEnabled;//this.Configuration.LazyLoadingEnabled; //keep track of what lazy load setting was before this method
        this.ChangeTracker.LazyLoadingEnabled = false; //Disable lazy loading so our serialization doesnt pull even more data from the database that we didn't modify
        foreach (EntityEntry stateEntryEntity in changes.ToList())
        {
          if (stateEntryEntity.Entity != null && !(stateEntryEntity.Entity is AuditLog) && !(stateEntryEntity.Entity is UserEvent))
          {
            string beforeStr = null;
            string afterStr = null;
            SetstateEntryEntity(actionType, stateEntryEntity, beforeStr, afterStr, user);
          }

        }

        this.ChangeTracker.LazyLoadingEnabled = previousLazyLoadEnabled; //Reset lazy load back to the original value
      }
    }

    /// <summary>
    /// Audit Log
    /// </summary>
    /// <param name="actionType"></param>
    /// <param name="stateEntryEntity"></param>
    /// <param name="beforeStr"></param>
    /// <param name="afterStr"></param>
    /// <param name="user"></param>
    public void SetstateEntryEntity(AuditActionType actionType, EntityEntry stateEntryEntity, string beforeStr, string afterStr, string user)
    {
      string afterStr1 = null;
      if (stateEntryEntity.State == EntityState.Added)
      {
        afterStr1 = JsonConvert.SerializeObject(stateEntryEntity.Entity, Formatting.None, new JsonSerializerSettings() { ReferenceLoopHandling = ReferenceLoopHandling.Ignore });

        var objAfterTest = new Dictionary<string, object>();

        SetValueForAddedEntity(afterStr1, objAfterTest);
        afterStr = JsonConvert.SerializeObject(objAfterTest);

      }
      else if (stateEntryEntity.State == EntityState.Deleted)
      {
        beforeStr = JsonConvert.SerializeObject(stateEntryEntity.Entity, Formatting.None, new JsonSerializerSettings() { ReferenceLoopHandling = ReferenceLoopHandling.Ignore });
      }
      else if (stateEntryEntity.State == EntityState.Modified)
      {
        var objBefore = new Dictionary<string, object>();
        var objAfter = new Dictionary<string, object>();

        ChangeTracker.DetectChanges();
        foreach (var entry in ChangeTracker.Entries())
        {
          CheckValueForModifiedEntity(objBefore, objAfter, entry);

        }

        setAuditActionType(actionType, stateEntryEntity, objBefore);
        beforeStr = JsonConvert.SerializeObject(objBefore);
        afterStr = JsonConvert.SerializeObject(objAfter);
      }
      CreateLog(GetClassName(stateEntryEntity.Entity.GetType()), beforeStr, afterStr, user, actionType);
    }
    public void CheckValueForModifiedEntity(Dictionary<string, object> objBefore, Dictionary<string, object> objAfter, EntityEntry entry)
    {
      foreach (var property in entry.Properties)
      {
        string propertyName = property.Metadata.Name;
        if (property.Metadata.IsPrimaryKey())
        {
          continue;
        }
        if (property.IsModified)
        {
          SetBeforeValueForModifiedRecord(objBefore, propertyName, property, entry);
          SetobjAfterValueForModifiedRecord(objAfter, propertyName, property, entry);
        }

      }
    }
    public void SetValueForAddedEntity(string afterStr1, Dictionary<string, object> objAfterTest)
    {
      dynamic deserializedObject = JsonConvert.DeserializeObject(afterStr1);

      foreach (var values in deserializedObject)
      {
        var getValue = values;


        var valueType = getValue.Value.GetType();
        SetAduditLogForAddedEntity(valueType, getValue, objAfterTest);


      }

    }
    public void SetAduditLogForAddedEntity(dynamic valueType, dynamic getValue, Dictionary<string, object> objAfterTest)
    {
      int count = 0;
      if (valueType.Name == "JObject")
      {
        foreach (var val in getValue.Value)
        {
          var type = val.Value.GetType();

          if (val.Value != null && type.Name != "JObject" && type.Name != "JArray")
          {
            count++;
          }

          if (count == 2 && type.Name != "JObject")
          {
            var keyVal = getValue.Name + "-" + val.Name;
            var pairVal = val.Value;
            objAfterTest.Add(keyVal, pairVal);
            break;
          }

        }

      }
      else if (valueType.Name == "JValue")
      {
        objAfterTest.Add(getValue.Name, getValue.Value);
      }
    }
    public void SetBeforeValueForModifiedRecord(Dictionary<string, object> objBefore, string propertyName, PropertyEntry property, EntityEntry entry)
    {
      if (!objBefore.ContainsKey(propertyName) && entry.GetDatabaseValues().GetValue<object>(property.Metadata.Name) != null)
      {

        var valueForOriginal = entry.GetDatabaseValues().GetValue<object>(property.Metadata.Name);
        objBefore.Add(propertyName, valueForOriginal);

      }
    }
    public void SetobjAfterValueForModifiedRecord(Dictionary<string, object> objAfter, string propertyName, PropertyEntry property, EntityEntry entry)
    {
      if (!objAfter.ContainsKey(propertyName) && entry.GetDatabaseValues().GetValue<object>(property.Metadata.Name) != null)
      {
        var valueForOriginal = entry.GetDatabaseValues().GetValue<object>(property.Metadata.Name);

        if (property.CurrentValue != null && !(valueForOriginal.ToString().Equals(property.CurrentValue.ToString())))
        {
          objAfter.Add(propertyName, property.CurrentValue);
        }

      }
    }
    /// <summary>
    /// Set AuditActionType
    /// </summary>
    /// <param name="actionType"></param>
    /// <param name="stateEntryEntity"></param>
    /// <param name="objBefore"></param>
    public void setAuditActionType(AuditActionType actionType, EntityEntry stateEntryEntity, Dictionary<string, object> objBefore)
    {
      if (actionType == AuditActionType.CancelCoilMoveRequest || actionType == AuditActionType.FulFillRequest)
      {
        if (stateEntryEntity.Entity is CoilMoveRequest)
        {
          objBefore.Add("Coil FTZ", (stateEntryEntity.Entity as CoilMoveRequest).Coil.FTZ);
        }
      }
    }

    /// <summary>
    /// Get the class name without the namespace, and without the EF dynamic proxy
    /// </summary>
    /// <param name="entityType"></param>
    /// <returns></returns>
    private string GetClassName(Type entityType)
    {
      if (entityType.BaseType != null && entityType.Namespace == "System.Data.Entity.DynamicProxies")
      {
        entityType = entityType.BaseType;
      }
      return entityType.Name;
    }

    /// <summary>
    /// Create an AuditLog entry
    /// </summary>
    /// <param name="classStr"></param>
    /// <param name="beforeStr"></param>
    /// <param name="afterStr"></param>
    /// <param name="user"></param>
    /// <param name="actionType"></param>
    private void CreateLog(string classStr, string beforeStr, string afterStr, string user, AuditActionType actionType)
    {
      var logObj = new
      {
        ClassName = classStr,
        Before = beforeStr,
        After = afterStr
      };

      string logStr = JsonConvert.SerializeObject(logObj);
      AuditLog log = new AuditLog
      {
        ActionTime = DateTime.Now,
        ActionType = actionType,
        Log = logStr,
        UserName = user
      };

      this.AuditLogs.Add(log);
    }

    /// <summary>
    /// Validate Input
    /// </summary>
    private void ValidateInput()
    {
      var entities = from e in ChangeTracker.Entries()
                     where e.State == EntityState.Added
                         || e.State == EntityState.Modified
                     select e.Entity;
      List<string> errorMessages = new List<string>();
      foreach (var entity in entities)
      {
        var validationContext = new ValidationContext(entity);

        List<ValidationResult> valResults = new List<ValidationResult>();

        Validator.TryValidateObject(
       entity,
       validationContext, valResults,
       validateAllProperties: true);

        if (valResults.Count > 0)
        {
          errorMessages.AddRange(valResults.Select(s => s.ErrorMessage));
        }

      }

      if (errorMessages.Count > 0)
      {
        //    Join the list to a single string.
        var fullErrorMessage = string.Join("; ", errorMessages);

        //    Combine the original exception message with the new one.
        var exceptionMessage = string.Concat("Validation failed for one or more entities. The validation errors are: ", fullErrorMessage);

        //    Throw a new DbEntityValidationException with the improved exception message.
        throw new CoilTrackingException { ErrorMessage = exceptionMessage, HttpStatusCode = "BadRequest" };
      }
    }
  }
}
