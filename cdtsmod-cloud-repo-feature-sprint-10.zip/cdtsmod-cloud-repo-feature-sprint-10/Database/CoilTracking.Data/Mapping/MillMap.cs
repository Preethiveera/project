using CoilTracking.Data.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CoilTracking.Data.Mapping
{
  public class MillMap : IEntityTypeConfiguration<Mill>
  {
    public void Configure(EntityTypeBuilder<Mill> builder)
    {
      builder.HasIndex(c => c.Name).IsUnique();
    }
  }
}
