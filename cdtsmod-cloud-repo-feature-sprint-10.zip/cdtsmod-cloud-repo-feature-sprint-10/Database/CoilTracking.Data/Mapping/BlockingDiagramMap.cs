using CoilTracking.Data.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CoilTracking.Data.Mapping
{
  public class BlockingDiagramMap : IEntityTypeConfiguration<BlockingDiagrams>
  {
    public void Configure(EntityTypeBuilder<BlockingDiagrams> builder)
    {
      builder.HasIndex(c => c.DataNumber).IsUnique();
    }
  }
}
