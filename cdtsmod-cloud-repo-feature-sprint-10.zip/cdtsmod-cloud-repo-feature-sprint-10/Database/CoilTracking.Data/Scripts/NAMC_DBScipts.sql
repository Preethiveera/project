ALTER TABLE [dbo].[CoilTypes] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[CoilTypes]  WITH CHECK ADD  CONSTRAINT [FK_dbo.CoilTypes_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO

ALTER TABLE [dbo].[Coils] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[Coils]  WITH CHECK ADD  CONSTRAINT [FK_dbo.Coils_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO

ALTER TABLE [dbo].[CoilFields] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[CoilFields]  WITH CHECK ADD  CONSTRAINT [FK_dbo.CoilFields_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO

ALTER TABLE [dbo].[Mills] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[Mills]  WITH CHECK ADD  CONSTRAINT [FK_dbo.Mills_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO

ALTER TABLE [dbo].[BlockingDiagrams] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[BlockingDiagrams]  WITH CHECK ADD  CONSTRAINT [FK_dbo.BlockingDiagrams_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO

ALTER TABLE [dbo].[Patterns] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[Patterns]  WITH CHECK ADD  CONSTRAINT [FK_dbo.Patterns_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO

ALTER TABLE [dbo].[RunOrderLists] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[RunOrderLists]  WITH CHECK ADD  CONSTRAINT [FK_dbo.RunOrderLists_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO

ALTER TABLE [dbo].[RunResults] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[RunResults]  WITH CHECK ADD  CONSTRAINT [FK_dbo.RunResults_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO

ALTER TABLE [dbo].[PatternItems] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[PatternItems]  WITH CHECK ADD  CONSTRAINT [FK_dbo.PatternItems_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO

ALTER TABLE [dbo].[PatternCalendars] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[PatternCalendars]  WITH CHECK ADD  CONSTRAINT [FK_dbo.PatternCalendars_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO

ALTER TABLE [dbo].[PatternLetters] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[PatternLetters]  WITH CHECK ADD  CONSTRAINT [FK_dbo.PatternLetters_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO

ALTER TABLE [dbo].[RunOrderListQuantities] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[RunOrderListQuantities]  WITH CHECK ADD  CONSTRAINT [FK_dbo.RunOrderListQuantities_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO

ALTER TABLE [dbo].[BlankInfoes] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[BlankInfoes]  WITH CHECK ADD  CONSTRAINT [FK_dbo.BlankInfoes_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO

ALTER TABLE [dbo].[Parts] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[Parts]  WITH CHECK ADD  CONSTRAINT [FK_dbo.Parts_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO


ALTER TABLE [dbo].[CoilStatus] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[CoilStatus]  WITH CHECK ADD  CONSTRAINT [FK_dbo.CoilStatus_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO


ALTER TABLE [dbo].[CoilFieldLocations] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[CoilFieldLocations]  WITH CHECK ADD  CONSTRAINT [FK_dbo.CoilFieldLocations_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO

ALTER TABLE [dbo].[CoilTypeYNAs] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[CoilTypeYNAs]  WITH CHECK ADD  CONSTRAINT [FK_dbo.CoilTypeYNAs_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO


ALTER TABLE [dbo].[CoilRunHistories] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[CoilRunHistories]  WITH CHECK ADD  CONSTRAINT [FK_dbo.CoilRunHistories_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO

ALTER TABLE [dbo].[Shifts] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[Shifts]  WITH CHECK ADD  CONSTRAINT [FK_dbo.Shifts_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO

ALTER TABLE [dbo].[Models] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[Models]  WITH CHECK ADD  CONSTRAINT [FK_dbo.Models_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO

ALTER TABLE [dbo].[LineDatas] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[LineDatas]  WITH CHECK ADD  CONSTRAINT [FK_dbo.LineDatas_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO

ALTER TABLE [dbo].[CoilMoveRequests] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[CoilMoveRequests]  WITH CHECK ADD  CONSTRAINT [FK_dbo.CoilMoveRequests_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO
ALTER TABLE [dbo].[IncompleteRunOrderItems] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[IncompleteRunOrderItems]  WITH CHECK ADD  CONSTRAINT [FK_dbo.IncompleteRunOrderItems_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO


ALTER TABLE [dbo].[PartModels] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[PartModels]  WITH CHECK ADD  CONSTRAINT [FK_dbo.PartModels_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO

ALTER TABLE [dbo].[PartLotSizes] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[PartLotSizes]  WITH CHECK ADD  CONSTRAINT [FK_dbo.PartLotSizes_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO

ALTER TABLE [dbo].[Presses] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[Presses]  WITH CHECK ADD  CONSTRAINT [FK_dbo.Presses_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO

ALTER TABLE [dbo].[ProdPlans] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[ProdPlans]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ProdPlans_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO

ALTER TABLE [dbo].[UserEvents] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[UserEvents]  WITH CHECK ADD  CONSTRAINT [FK_dbo.UserEvents_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO


ALTER TABLE [dbo].[CoilFieldZones] ADD [Plant_Id] INT NOT NULL Default 1
GO
ALTER TABLE [dbo].[CoilFieldZones]  WITH CHECK ADD  CONSTRAINT [FK_dbo.CoilFieldZones_dbo.Plants_Plant_Id] FOREIGN KEY([Plant_Id])
REFERENCES [dbo].[Plants] ([Id])
GO

CREATE UNIQUE NONCLUSTERED INDEX [IX_Name] ON [dbo].[Mills]
(
	[Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX [IX_ModelNumber] ON [dbo].[Models]
(
	[ModelNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
