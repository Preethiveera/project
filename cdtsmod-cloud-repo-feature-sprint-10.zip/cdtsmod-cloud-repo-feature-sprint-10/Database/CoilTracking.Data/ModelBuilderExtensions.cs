namespace CoilTracking.Data
{
  public static class ModelBuilderExtensions
  {
    //public static PropertyBuilder<decimal?> HasPrecision(this PropertyBuilder<decimal?> builder, int precision, int scale)
    //{
    //    return builder.HasPrecision($"decimal({precision},{scale})");
    //}

    //public static Microsoft.EntityFrameworkCore.Metadata.Builders.PropertyBuilder<decimal?> HasPrecision(this PropertyBuilder<decimal?> builder,int precision, int scale)
    //{
    //    var a = builder.HasColumnType($"decimal(18,4)");
    //    return a;
    //    //return builder.HasPrecision($"decimal({precision},{scale})");
    //}

    //public static Microsoft.EntityFrameworkCore.Metadata.Builders.PropertyBuilder<TProperty> HasColumnType<TProperty>(this Microsoft.EntityFrameworkCore.Metadata.Builders.PropertyBuilder<TProperty> propertyBuilder, string typeName);

    //public static PropertyBuilder<decimal?> HasPrecision(this PropertyBuilder<decimal?> builder, int precision, int scale)
    //{
    //    return builder.HasPrecision($"decimal({precision},{scale})");
    //}
    //public static int? HasPrecision(this Microsoft.EntityFrameworkCore.Metadata.IProperty property);

    //public static PropertyBuilder<decimal> HasPrecision(this PropertyBuilder<decimal> builder, int precision, int scale)
    //{
    //    return builder.HasColumnType($"decimal({precision},{scale})");
    //}
  }
}
