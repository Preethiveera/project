using CoilTracking.Data.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface ICoilTypeYNARepository
  {
    List<CoilTypeYNA> GetCoilTypeYNAsByYNA(List<CoilTypeYNA> coilTypeYNA);
    CoilType GetCoilTypeByRecordNumber(string yNumber);
    CoilTypeYNA GetCoilTypeYNAByNumberWithcoilTypeName(string coilTypeName, string yNumber);
    CoilTypeYNA GetcoilTypeYNAAlreadyExistsDiffCoilType(string coilTypeName, string yNumber);
    Task<string> GetMaterialTypeByYNA(string yna);
    CoilTypeYNA GetcoilTypeYNAsByYNANo(string YNANo);
    bool IscoilTypeYNAsByYNANo(string YNANo);
  }
}
