using CoilTracking.Data.Models;
using CoilTracking.DTO;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface ICoilTypeRepository
  {
    /// <summary>
    /// Get list of CoilTypes
    /// </summary>
    /// <param name="dbZoneId"></param>
    /// <returns></returns>
    List<CoilType> GetdbCoilTypes(List<CoilFieldZone> coilField);
    /// <summary>
    /// Get CoilTypesName
    /// </summary>
    /// <param name="coilTypeName"></param>
    /// <returns></returns>

    List<CoilType> GetCoilTypes();

    CoilType GetCoilTypeById(int id);
    Task<CoilType> GetMaterialCoilTypeById(int id);
    public CoilType GetCoilTypeByName(string name);
    CoilType GetoriginalCoilTypeById(CoilTypeDto coilType);
    Task<IQueryable<CoilType>> GetMaterialCoilTypes();
    void DeleteCoilType(CoilType coilType);

    void RemoveCoilType(CoilType coilType);
    void ModifyCoilType(CoilType coilType);


    Task<int> ModifyCoilTypes(CoilType coilType);
    void UnchangedCoilType(CoilType coilType);

    void DeleteCoilTypeYNA(CoilTypeYNA removedYNA);

    void InsertCoilType(CoilType coilType);

    Task<int> SaveChangesAsync();

    void AddCoilType(CoilType coilType);
    bool IsCoilTypeByName(string coilTypeName);
    public Task<List<CoilType>> GetAssociatedItemsByCoilFieldZone(int zoneId);

    public int GetCountIfCoilTypes();
    List<CoilTypePartModel> GetCoilTypesWithAllPartNums();
  }
}
