using CoilTracking.Data.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface IPartModelsRepository
  {
    Task<PartModel> GetPartModel(int id);
    Task<List<PartModel>> GetPartModelByPartIdsAndModelId(int[] partIds, int modelId);
    Task<List<PartModel>> GetPartModels();
    Task<List<Part>> GetPartsRelatedToModels(int modelId);
    bool UpdatePartModel(PartModel partModel);
    bool RemovePartModel(PartModel partModel);
    bool UnchangedPartModel(PartModel partModel);
    Task<bool> UpdatePartModelSaveAsync(PartModel partModel);

    Task<List<PartModel>> GetPartmodelsByPartnumber(string partNumber);
    Task<List<PartModel>> GetPartmodelsByPartId(int id);

    Task<List<PartModel>> GetPartmodelsByPartIdwithOut(int id);

    List<Model> GetPartModelByPartId(int Id);
    Task<int> InsertPartModelsSavechanges(List<PartModel> partModels);

    Task<int> PartModelsSavechanges();

    Task<PartModel> GetPartModelById(int id);

    Task<List<PartModel>> GetPartModelsAsync();

    Task SaveChanges(AuditActionType auditActionType);

    Task UpdatePartModelAsync(PartModel partModel);

    Task<PartModel> AddPartModelAsync(PartModel partModel);

    Task DeletePartModelAsync(PartModel partModel);

    string GetModelList(string partNumber);
  }
}
