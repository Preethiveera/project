using CoilTracking.Data.Models;
using CoilTracking.DTO;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface ICoilFieldLocationRepository
  {

    /// <summary>
    /// 
    /// </summary>
    /// <param name="coilsInField"></param>
    /// <param name="dbZone"></param>
    /// <returns></returns>
    List<Coil> CoilFieldLocations(List<Data.Models.Coil> coilsInField, List<CoilFieldLocation> fieldLocations);

    public int GetCountOfCoilFieldLocation();

    IQueryable<CoilFieldLocation> GetAllCoilFieldLocations();

    CoilFieldLocation GetCoilFieldLocationById(int id);

    CoilFieldLocation GetCoilFieldLocationWithZone(int id);

    List<CoilFieldLocation> GetCoilFieldLocationByZoneId(int zoneId);

    void UpdateCoilFieldLocation(int id, CoilFieldLocation coilFieldLocation);

    Task<CoilFieldLocation> AddCoilFieldLocation(CoilFieldLocation coilFieldLocation);

    void DeleteCoilFieldLocation(CoilFieldLocation coilFieldLocation);

    void SaveChanges(AuditActionType auditAction);
    Task<int> SaveChangesAync(AuditActionType auditAction);

    List<CoilFieldLocation> GetFreeLocations();

    Task<CoilFieldLocation> GetCoilFieldLocationByName(string zone, string locationName);

    public void DeleteCoilFieldLocationEntry(CoilFieldLocation coilFieldLocation);
    void CoilFieldLocationZoneEntityStateModified(CoilFieldLocation newLocation);

    void CoilFieldLocationOldLocationEntity(CoilFieldLocation oldLocation);

    Task<List<string>> CheckEdit(int id, CoilFieldLocationDto dto);
  }
}
