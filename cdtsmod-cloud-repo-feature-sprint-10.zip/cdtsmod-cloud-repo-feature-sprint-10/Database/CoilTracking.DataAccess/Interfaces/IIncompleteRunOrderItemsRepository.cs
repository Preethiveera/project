using CoilTracking.Data.Models;
using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface IIncompleteRunOrderItemsRepository
  {
    Task<List<IncompleteRunOrderItem>> GetIncompleteRunOrderItemsByStatus(RunOrderItemStatus status);

    Task<List<IncompleteRunOrderItem>> GetIncompleteRunOrderItemsById(int id);

    Task<List<IncompleteRunOrderItem>> GetCompletedRunOrderItemsByIdAndStatus(List<int> lastRuns, RunOrderItemStatus status);

    Task<List<string>> GetFTZAsync(int id);

    Task<PrinterConfig> GetPrinterConfigAsync(string lineName);

    IQueryable<PrinterConfigDto> GetPrinterConfigDto(string strNAMC, string PrinterName);

    Task<bool> IsTagsPrintedfromAutoPrint(int runOrderItemId);

    PalletTag GetMaxBkankPalet();

    string GetSerialNumbers(string namcCode, string line, string customerPartNumber);

    Task AddPallet(PalletTag pallettag);

    Task<bool> IncompleteRunOrderItemsExists(int id);
  }
}
