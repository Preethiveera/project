using CoilTracking.Data.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface IPatternsRepository
  {
    Task<Pattern> GetPatternsByLineIdPatternLetterAndDate(int lineId, string calendarEntry, DateTime date);
    public Task<List<Pattern>> GetPatternByMonthAndYear(int month, int year);
    public Task<List<Pattern>> GetPatterns();
    public Task<Pattern> GetPatternByLineId_PatternLetter_Year_Month(int lineId, string patternLetter, int year, int month);
    public Task<List<PatternItem>> GetPatternsItems(int id);
    public Task<Pattern> GetPatternById(int id);
    public bool UpdatePattern(Pattern pattern);
    public Task<Pattern> AddPattern(Pattern pattern);
    public Task<bool> RemovePattern(Pattern pattern);
    Pattern GetPatternsWithPlantOPCServer(int lineId, string patternLetter, DateTime date);
    Task SaveChangesAsync(AuditActionType auditAction);

    Task<bool> PatternExists(int lineId);

    Task<List<Pattern>> GetPatternByLineId(int lineId);
  }
}
