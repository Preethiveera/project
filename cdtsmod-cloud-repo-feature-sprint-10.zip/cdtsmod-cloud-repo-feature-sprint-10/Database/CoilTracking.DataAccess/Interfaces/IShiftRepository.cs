using CoilTracking.Data.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface IShiftRepository
  {
    public int GetCountofShifts();

    Task<Shift> GetShiftByIdAsync(int id);

    Task<List<Shift>> GetShifts();
    public Task<List<Shift>> GetAllShifts();

    Task<Shift> GetCurrentShift(TimeSpan currentTime);

    Task<Shift> GetLateNightShift();

    Task<Shift> GetOrderedCurrentShift(TimeSpan currentTime);

    Task<Shift> GetNextShiftByCurrentTime(TimeSpan currentTime);

    Task<Shift> GetNextShift();

    Task SaveChanges(AuditActionType auditActionType);

    Task UpdateShift(Shift shift, AuditActionType auditActionType);

    Task<Shift> AddShift(Shift shift);

    Task DeleteShift(Shift shift);

    Task<bool> CheckEdit(int id, Shift shift);
  }
}
