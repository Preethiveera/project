using CoilTracking.Data.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface IOPCConfigRepository
  {
    public int GetCountOfOPCConfigs();

    Task<OPCConfig> GetOPCConfigById(int id);

    Task<List<OPCConfig>> GetOPCConfigsAsync();

    public void UpdateOPCConfig(OPCConfig oPCConfig);

    public OPCConfig OPCConfigExistsbyId(int id);

    public Task DisableOPCConfig(int id, bool disable);

    public  Task<OPCConfig> InsertOPCConfig(OPCConfig oPCConfig);
    public  Task<OPCConfig> DeleteOPCConfig(int id);
  }
}
