using CoilTracking.Data.Models;
using System.Threading.Tasks;
namespace CoilTracking.DataAccess.Interfaces
{
  public interface IPlantsRepository
  {
    /// <summary>
    /// Get plants Name
    /// </summary>
    /// <returns></returns>
    string GetPlantName();
    Task<string> GetPlantNAMCCode();

    Plant GetPlant();

    Task<Plant> GetPlantByNAMCCode(string NAMCCode);
    string GetPlantName(string plantname);
    Task<Plant> GetPlantByPlantName(string plantname);

  }
}
