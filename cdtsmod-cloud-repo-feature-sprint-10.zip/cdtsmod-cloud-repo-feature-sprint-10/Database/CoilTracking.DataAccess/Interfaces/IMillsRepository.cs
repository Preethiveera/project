using CoilTracking.Data.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface IMillsRepository
  {
    public int GetCountOfMills();
    public List<Mill> GetMills();
    public Mill GetMillById(int id);
    bool CheckIfEdited(int id, Mill mill);
    public void DisableMill(int id, bool disable);
    public void InsertMill(Mill mill);
    public Mill DeleteMill(int id);
    public bool UpdateMill(Mill mill);
    Task<Mill> GetMillByName(string coilCheckInMill);
  }
}
