using CoilTracking.Data.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface ICoilMoveRequestsRepository
  {
    List<CoilMoveRequest> GetCoilMoveRequestById(int id);

    Task<List<CoilMoveRequest>> GetAllCoilMoveRequest();

    Task<List<CoilMoveRequest>> GetPendingRequestByLine(int lineId, DateTime? startTime = null, DateTime? endTime = null);

    Task<List<CoilMoveRequest>> GetUnfulfilledCoilMoveRequests();

    Task<CoilMoveRequest> GetMoveRequestById(int id);

    Task SaveChanges(AuditActionType auditAction);

    Task<List<int>> GetUnfulfilledCoilIds();

    Task AddCoilMoveRequest(CoilMoveRequest coilMoveRequest);

    Task<CoilMoveRequest> GetCoilMoveRequestWithCoilData(int id);

    Task<CoilMoveRequest> FindCoilMoveRequestAsync(int id);

    Task<bool> DeleteCoilMoveRequest(CoilMoveRequest coilMoveRequest);

    Task<List<Coil>> GetCoilsLoadedByCoilStatusName(string statusName);

    Task<List<CoilMoveRequest>> GetReturnRequests();

    Task<int> GetUnfulfilledCoilMoveRequestsCount();
  }
}
