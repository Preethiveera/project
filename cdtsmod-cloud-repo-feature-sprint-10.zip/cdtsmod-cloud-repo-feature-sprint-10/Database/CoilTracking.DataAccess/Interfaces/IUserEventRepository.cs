using CoilTracking.Data.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface IUserEventRepository
  {
    public Task<List<UserEvent>> GetUserEvents();
    public Task<List<UserEvent>> GetUserEventsBetween(DateTime? startTime = null, DateTime? endTime = null, string username = null);

    public Task<UserEvent> GetUserEventById(int id);
    public UserEvent UpdateUserEvent(int id, UserEvent userEvent);
    public  Task<UserEvent> InsertUserEvent(UserEvent userEvent);
    public Task<UserEvent> DeleteUserEvent(int id);
  }
}
