using CoilTracking.Data.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface IBlankInfoesRepository
  {
    /// <summary>
    /// 
    /// </summary>
    /// <param name="CoilTypeId"></param>
    /// <returns></returns>
    List<int> GetdieNo(List<CoilFieldLocation> coilFieldLocation);

    /// <summary>
    /// 
    /// </summary>
    /// <param name="CoilTypeId"></param>
    /// <returns></returns>
    List<BlankInfo> GetdieNos(List<Coil> coil);



    /// <summary>
    /// Get CurrentStackSize
    /// </summary>
    /// <returns></returns>
    BlankInfo GetCurrentStackSize(int dataNum);
    public int GetCountOfBlankInfoes();

    public IQueryable<BlankInfo> GetAllBlankInfo();

    public BlankInfo GetBlankInfoById(int id);

    public BlankInfo GetBlankInforByDataNumAndLineId(int dataNum, int lineId);

    public List<IncompleteRunOrderItem> GetDependencyForBlankInfo(int id);
    void AddNewBlankInfo(BlankInfo blankInfo);
    void UpdateBlankInfo(BlankInfo blankInfo);

    void DisableBlankInfo(int id, bool disable);
    void DeleteBlankInfo(int id);

    List<BlankInfo> GetBlankInfoByDataNumber(int dataNum);
    void RemoveBlankInfo(BlankInfo blank);


    public List<BlankInfo> GetListByPartnumberLineIds(List<string> partNumber, int lineId);
    List<BlankInfo> GetBlankInfoByPartnumberLineIds(string partNumber, int lineId);
    public List<BlankInfo> GetBlankInfoByListOfDataNumAndLineId(List<int> dataNum, int lineId);

    public List<BlankInfo> GetListWithPlantsAndTimeZones(List<int> dataNum, int lineId);

    public Task<IQueryable<BlankInfo>> GetListWithPlantTimeZonePart(List<string> partNum, int lineId);

    public List<BlankInfo> GetBlanksByDataIdList(List<int> dataIdList);

    Task<List<BlankInfo>> GetBlankInfoByLineIdAndPartNumber(int lineId, List<string> partNumbers);
    Task<List<BlankInfo>> GetBlankInfoByPartId(int id);

    Task<List<BlankInfo>> GetBlankInfoByDataNumbers(List<int> dataNumber);
  }
}
