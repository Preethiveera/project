using CoilTracking.Data.Models;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface IScheduleReportRepository
  {
    IQueryable<ScheduledReportEmail> Get();
    ScheduledReportEmail GetScheduleReportByID(int id);
    Task<int> PostScheduleReport(ScheduledReportEmail scheduledReportEmail);
    bool PutScheduleReport(int id, ScheduledReportEmail scheduledReportEmail);
    bool DeleteScheduleReport(int id);
    ScheduledReportEmail GetScheduleReportByEmail(string email);
    bool ScheduleReportExists(int id);

    Task AddScheduleReportEmailLog(string exception, string mailInfo, bool isSuccess);
  }
}
