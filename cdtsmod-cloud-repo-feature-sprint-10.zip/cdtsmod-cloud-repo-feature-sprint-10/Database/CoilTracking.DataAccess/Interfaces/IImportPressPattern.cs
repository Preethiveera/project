using System.IO;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface IImportPressPattern
  {
    void Import(string filename, string userName);

    Task<int> Import(MemoryStream ms, string userName);
  }
}
