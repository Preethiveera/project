using CoilTracking.Data.Models;
using System.Collections.Generic;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface ICoilFieldRepository
  {

    public int GetCountOfCoilField();
    public List<CoilField> GetCoilFields();
    public CoilField GetCoilFieldById(int id);
    public CoilField GetCoilFieldWithZonesById(int id);
    public bool DisableCoilField(int id, bool disable);
    public bool UpdateCoilField(int id, CoilField coilField);
    public bool SaveCoilField(CoilField coilField);

    public CoilField DeleteCoilField(int id);
  }
}
