using CoilTracking.Data.Models;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface ICoilRunHistoryRepository
  {
    /// <summary>
    /// Save CoilRunHistories
    /// </summary>
    /// <param name="runHistory"></param>
    /// <returns></returns>
    bool SaveCoilRunHistories(CoilRunHistory runHistory);
    Task<CoilRunHistory> GetCoilRunHistoryByRunOrderListId(int id);
  }
}
