using CoilTracking.Data.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface ILineRepository
  {
    /// <summary>
    /// Get Lines
    /// </summary>
    /// <returns></returns>
    IEnumerable<Line> GetLines();
    IEnumerable<Line> GetAllLines();
    /// <summary>
    /// GetLine ByLineID
    /// </summary>
    /// <param name="lineId"></param>
    /// <returns></returns>
    Line GetLineByLineID(int lineId);
    public int GetCountOfLines();

    Task<Line> GetLineWithPlantDetails(int lineId);


    public Task<Line> GetLineByLineIDAsync(int lineId);
    Task<Line> GetLineWithTimeZoneOpcServer(int id);

    Task<List<Line>> GetLinesAsync();

    Task<Line> GetLineByIdAsync(int id);

    Task UpdateLineSubscription(Line line);

    Task SaveChanges(AuditActionType actionType, string user = null);

    Task<List<Line>> GetSubscribedLines(string namcCode);

    void DisableLine(Line line);

    Task PutLine(Line line);

    Task<Line> AddLine(Line line);

    void AddPlantAndOPCServerData(Line line);

    Task<LineData> GetLineDataByLineId(LineData lineData);

    void UpdateLineData(LineData lineData);

    Task AddLineData(LineData lineData);

    Task DeleteLine(Line line);

    Task<int> CheckEdit(int id);

    Task<List<IncompleteRunOrderItem>> GetIncompleteRunOrderItem(int id);

    Task<List<Line>> GetLinesByOPcConfigId(int id);

    public List<Line> GetIncompleteRunLinesByLineList(List<Line> lines);
    public Task<LineData> GetLinesData(int lineId);
  }
}
