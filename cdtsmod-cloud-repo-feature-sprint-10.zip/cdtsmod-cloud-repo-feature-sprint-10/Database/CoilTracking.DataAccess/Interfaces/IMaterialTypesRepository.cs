using CoilTracking.Data.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface IMaterialTypesRepository
  {
    Task<List<MaterialType>> GetCoilsMaterialTypes();

    MaterialType GetMaterialTypesById(int id);
  }
}
