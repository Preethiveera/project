using CoilTracking.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface IRunResultsRepository
  {
    /// <summary>
    /// Get Run Results
    /// </summary>
    /// <returns></returns>
    Task<List<RunResult>> GetRunResults();
    List<RunResult> GetRunOrderRunResultById(int id);
    /// <summary>
    /// Get details By  Search 
    /// </summary>
    /// <param name="startTime"></param>
    /// <param name="endTime"></param>
    /// <param name="partNum"></param>
    /// <param name="dataNum"></param>
    /// <param name="coilType"></param>
    /// <param name="lineId"></param>
    /// <param name="shiftId"></param>
    /// <param name="ftz"></param>
    /// <returns></returns>
    List<RunResult> GetRunResultsSearch(DateTime? startTime = null, DateTime? endTime = null, string partNum = null, int? dataNum = null, string coilType = null, int? lineId = null, int? shiftId = null, string ftz = null);


    /// <summary>
    /// Get Db Coils To Be Weighed
    /// </summary>
    /// <param name="Id"></param>
    /// <returns></returns>
    List<RunResult> GetCoilsToBeWeighed();
    /// <summary>
    /// Get RunResult Return Weight
    /// </summary>
    /// <param name="RunResultId"></param>
    /// <returns></returns>
    List<RunResult> GetRunResultIds(List<int> ids);
    /// <summary>
    /// Run Result Modified
    /// </summary>
    /// <param name="runResult"></param>
    bool ModifyRunResult(RunResult runResult);
    /// <summary>
    /// Get Weight partials Based on Id
    /// </summary>
    /// <param name="partialsId"></param>
    /// <returns></returns>
    RunResult GetRunResultId(int id);

    Task<RunResult> GetRunResultsId(int id);
    /// <summary>
    /// RunResult Unchanged Status
    /// </summary>
    /// <param name="runResult"></param>
    /// <returns></returns>
    Task<bool> RunResultSaveChanges(RunResult runResult);
    Task<bool> UpdateRunResultSaveChanges(RunResult runResult);

    /// <summary>
    /// Verfiy RunResult Exists
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    bool IsRunResultExists(int id);
    /// <summary>
    /// Delete RunResult Based on Id
    /// </summary>
    /// <param name="runResult"></param>
    /// <returns></returns>
    Task<int> DeleteRunResult(RunResult runResult);
    /// <summary>
    /// Get Coil and RunOrderList Based on Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    Task<RunResult> GetRunResultsById(int Id);

    Task<RunResult> GetNewestRunResultForCoil(int coilId);

    Task<RunResult> GetRunResultByRunOrderListId(int id);

    Task<List<RunResult>> GetRunResultsByDate(DateTime startDate, DateTime endDate);

    IQueryable<int> GetRunResultForIncompleteOrderItem();



  }
}
