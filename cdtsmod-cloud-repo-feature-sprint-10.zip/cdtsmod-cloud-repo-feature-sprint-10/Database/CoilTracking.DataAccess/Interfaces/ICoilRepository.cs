using CoilTracking.Common.Constants;
using CoilTracking.Data.Models;
using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface ICoilRepository
  {


    /// <summary>
    /// Get CoilsFeildsByZoneId
    /// </summary>
    /// <param name="zoneId"></param>
    /// <returns></returns>
    List<Coil> GetCoilsFeildsByZoneId(int? zoneId);
    /// <summary>
    ///Get Coil FieldLocation
    /// </summary>
    /// <param name="dbLocationId"></param>
    /// <param name="coilsInField"></param>
    /// <returns></returns>
    Coil CoilFieldLocation(CoilFieldLocation dbLocationId, List<Coil> coilsInField);
    /// <summary>
    /// Get list of Andon CoilTypeLocation 
    /// </summary>
    /// <param name="dbLocationId"></param>
    /// <param name="coilsOnHand"></param>
    /// <param name="dbCoilTypeId"></param>
    /// <returns></returns>
    List<AndonCoilTypeLocation> GetCoilLocationsInOrder(CoilFieldZone dbLocationId, List<Coil> coilsOnHand);
    /// <summary>
    /// Get CoilData based on coilid
    /// </summary>
    /// <param name="kanCoilId"></param>
    /// <returns></returns>
    List<Coil> GetKanCoils();

    List<Coil> GetCoilsList(List<int> coilTypesList);
    List<Coil> GetCoilTypeByBlanks(List<BlankInfo> blanks);

    /// <summary>
    /// Get Partials Coils
    /// </summary>
    /// <returns></returns>
    IQueryable<Coil> GetPartialsCoils();
    /// <summary>
    /// Get CoilRunHistory By Ids
    /// </summary>
    /// <param name="Id"></param>
    /// <returns></returns>
    List<Coil> GetCoilRunHistoryByIds(List<int> ids);

    /// <summary>
    /// Get Count Of Coils
    /// </summary>
    /// <returns></returns>
    public int GetCountOfCoils();
    /// <summary>
    /// Get CurrentWeightCoils By CoilId
    /// </summary>
    /// <param name="CoilId"></param>
    /// <returns></returns>
    Coil GetCoilsWithAllInfo(int CoilId);
    /// <summary>
    /// Get Coils By  CoilId
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    Task<Coil> GetCoilId(int id);
    List<Coil> GetCoilsByMillId(int id);
    List<Coil> GetLoadedCoilsById(int id);

    public bool IsmillIdPresentInCoilMoveRequest(int id);

    public List<Coil> GetCoilsByCoilField(int id);
    Task<List<Coil>> GetCoilsByCoilTypeId(int id);

    Task<List<Coil>> GetCoilsLoadedById(int id);

    Coil GetCoilWithCoilField(int id);

    List<Coil> GetCoilByLocationId(int locationId);


    Task<List<Coil>> GetCoilsToMove(int coilTypeId, List<int> unfulfilledCoilIds);

    Task<Coil> GetCoilToMoveByCoilId(int coilId);

    Task<IQueryable<Coil>> GetCoils();
    Task<List<Coil>> GetCoilsForSearch(DateTime? startTime = null, DateTime? endTime = null, string coilType = null,
      int? coilStatusId = null, int? zoneId = null, string FilterByBornOnDate = Constant.zero);

    Task<List<Coil>> GetCoilsByInInventory();

    Task<Coil> GetCoilsByIdWithTypeRunHistory(int id);


    Task<Coil> GetCoilsByFTZ(string ftz);
    Task<Coil> GetCoilsByPrefixFtz(string sPrefixFtz, string tPrefixFtz);

    Task<List<Coil>> GetRunResultCoilsByPrefixFtz(string sPrefixFtz, string tPrefixFtz);
    Task<List<Coil>> GetRunResultCoilsByFtz(string ftz);

    Task<Coil> GetCoilsByLocationId(int id);

    Task<Coil> GetCoilsById(int id);

    Task<Coil> GetCoilsIds(int id);

    Task<List<Coil>> GetCoilsByCoilStatusName(string Name);

    Task<List<Coil>> CoilsInventoryBYTypeId(int coilTypeId);

    public Task<List<Coil>> GetCoilsByZoneId(int zoneId);

    Task<int> InsertCoil(Coil coil);
    Task<int> DeleteCoil(Coil coil);

    Task<int> ModifyCoil(Coil coil);

    Task<Coil> GetCoilStatusByCoilId(int id);

    Task<int> UpdateCoilStatus(Coil coil);

    Task<int> UpdateCoils(Coil coil);


    Task<int> UpdateCoilForRunHistory(Coil coilUpdated);
    Task<int> CoilSaveChanges(Coil coil);

  }
}
