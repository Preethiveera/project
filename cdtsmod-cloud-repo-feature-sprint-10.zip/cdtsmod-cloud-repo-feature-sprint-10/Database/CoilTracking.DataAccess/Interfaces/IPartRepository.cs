using CoilTracking.Data.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface IPartRepository
  {
    /// <summary>
    /// Get Model List
    /// </summary>
    /// <returns></returns>
    public string GetModelList(string partNumber);

    public List<PartModel> GetPartModelsByPartNumberList(List<string> partnumberList);
    /// <summary>
    /// Set Models
    /// </summary>
    /// <param name="models"></param>
    /// <param name="userName"></param>
    public int GetCountOfparts();

    public Part GetPartById(int id);
    public Part GetPartByName(string name);

    public Task<Part> GetPartByNameAync(string name);
    public List<Part> GetPartsListByPartNumberList(List<string> partNumbers);

    Task<List<Part>> GetPartsAsync();
    Task<Part> GetPartByIdAsync(int id);

    Task<int> UpdatePartSaveChanges(Part part);
    Task<int> DisablePartSaveChanges(Part part);
    Task<int> InsertParts(Part part);
    Task<int> DeletePart(Part part);

    Task<Part> InsertPart(Part part);

    void RemovePart(Part part);
    bool UnchangedPart(Part part);

    Task<string> GetPartName(string partNumber);

    Task<int> PartSavechanges();
  }
}
