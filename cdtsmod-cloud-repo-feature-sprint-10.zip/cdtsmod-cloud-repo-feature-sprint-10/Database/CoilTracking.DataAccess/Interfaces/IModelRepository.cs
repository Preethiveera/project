using CoilTracking.Data.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface IModelRepository
  {
    Task<bool> AddModel(Model model);
    Task<bool> DeleteModel(Model model);
    int GetCountOfModels();
    Task<Model> GetModelById(int id);
    Task<List<Model>> GetModelByModelNo(string modelNo);
    List<Model> GetAllModelByModelNo(List<string> modelNo);
    Task<List<Model>> GetModels();
    Task<bool> UpdateModel(Model model, AuditActionType auditActionType = AuditActionType.ModifyEntity);
    bool UnchangedModel(Model model);
    void RemoveModel(Model model);
    Task<bool> SaveChangesModel(Model model);
  }
}
