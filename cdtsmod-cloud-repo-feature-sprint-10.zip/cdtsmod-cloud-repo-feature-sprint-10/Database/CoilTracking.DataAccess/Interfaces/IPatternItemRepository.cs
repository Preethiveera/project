using CoilTracking.Data.Models;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface IPatternItemRepository
  {
    public bool RemovePatternItem(PatternItem patternItem);
  }
}
