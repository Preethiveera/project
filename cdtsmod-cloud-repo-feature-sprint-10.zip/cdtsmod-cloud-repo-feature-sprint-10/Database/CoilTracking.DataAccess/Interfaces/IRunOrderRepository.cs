using CoilTracking.Data.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface IRunOrderRepository
  {
    /// <summary>
    /// Getting RunOrderList By Ids
    /// </summary>
    /// <param name="Id"></param>
    /// <returns></returns>
    List<RunOrderList> GetRunOrderListByPartialIds(List<int> partials);
    /// <summary>
    /// Getting RunOrderList By Id
    /// </summary>
    /// <param name="Id"></param>
    /// <returns></returns>
    RunOrderList GetRunOrderListId(int partialId);
    Task<List<RunOrderList>> GetRunOrderListsAsync();

    Task<RunOrderList> GetRunOrderListByIdAsync(int id);
    bool IsScheduledOnRunOrder(int blankinfoId);
    bool RunOrderListExists(int id);
    List<IncompleteRunOrderItem> GetIncompleteRunOrderItemsByLineId(int lineId);
    public List<IncompleteRunOrderItem> GetIncompleteItemsWithShiftLinePart(int lineId);

    public Task MarkRunOrderItemsIncomplete(List<IncompleteRunOrderItem> incompleteItems);
    Task MarkRunOrderItemStatus(int runOrderItemId, RunOrderItemStatus status);
    public void CreateIncompleteRunOrderItemEntries(RunOrderList runOrderList);
    public Task<RunOrderList> GetListByDateLineIdAndShift(DateTime date, int lineId, int shiftId);
    public Task<RunOrderList> GetListWithQuantitiesAndShifts(DateTime date, int lineId, int shiftId);
    public void AddNewRunOrderList(RunOrderList runOrderList);

    public Task<RunOrderList> GetListByIdWithLineQuantity(int id);

    public void DeleteRunOrderList(int id, RunOrderList runOrderList);
    public void SaveNewRunOrderList(RunOrderList runOrderListToSave);
    public List<IncompleteRunOrderItem> GetIncompleteItemByStatusAndPart(List<string> partList, int lineId);
    public void ModifyIncompleteRunOrderRecordState(List<IncompleteRunOrderItem> item);
    public void ModifyIncompleteRunStateToDeleted(IncompleteRunOrderItem item);
    public void AddIncompleteRunOrderRecordList(List<IncompleteRunOrderItem> item);
    public List<IncompleteRunOrderItem> GetIncompleteRunItemByLineId(int lineId);

    public void ChangeEntityState(RunOrderList runOrderListOriginal, DateTime date);

    public Task<List<IncompleteRunOrderItem>> GetIncompleteItemListByRunOrderId(List<int> runOrderId);

    public Pattern GetPatternByLineInShiftId(DateTime date, int lineId, int shiftId);
    public string GetPatternLetterByLineId(DateTime date, int lineId, int shiftId);

    Task<List<RunOrderList>> GetRunOrderListsByShiftId(int id);
  }
}
