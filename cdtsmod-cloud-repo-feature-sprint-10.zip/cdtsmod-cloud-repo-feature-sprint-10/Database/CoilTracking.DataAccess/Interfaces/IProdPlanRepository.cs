using CoilTracking.Data.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface IProdPlanRepository
  {
    List<ProdPlan> GetProdPlanByPartnumberList(List<string> partnumList);

    List<ProdPlan> GetProdPlanByPartnumber(string PartNumber);

    Task<ProdPlan> GetProdPlanByPartBynumber(string PartNumber);

    Task<List<ProdPlan>> GetProdPlans();

    Task<ProdPlan> GetProdPlanById(int id);

    Task PutProdPlan(ProdPlan prodPlan);

    Task SaveChanges(AuditActionType auditActionType);

    Task<ProdPlan> AddProdPlan(ProdPlan prodPlan);

    Task<List<ProdPlan>> GetProdPlanEntry(List<string> partNumber);

    Task AddProdPlantEntry(ProdPlan prodPlantEntry);

    void RemoveProdPlantEntry(ProdPlan prodPlantEntry);

    Task UpdateProdPlantEntry(ProdPlan prodPlantEntry);

    void UpdateProdPlantState(ProdPlan prodPlantEntry);

    Task RemoveProdPlan(ProdPlan prodPlan);
  }
}
