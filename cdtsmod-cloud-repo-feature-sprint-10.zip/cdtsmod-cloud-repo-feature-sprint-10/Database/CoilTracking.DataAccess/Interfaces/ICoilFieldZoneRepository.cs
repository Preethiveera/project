using CoilTracking.Data.Models;
using CoilTracking.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface ICoilFieldZoneRepository
  {
    /// <summary>
    /// 
    /// </summary>
    /// <param name="zoneId"></param>
    /// <returns></returns>
    ///     
    List<CoilFieldZone> GetCoilFieldZones(int? zoneId);

    public Task<List<CoilFieldZone>> GetCoilFieldZones();

    public int GetCountOfCoilFieldZones();

    CoilFieldZone GetCoilTypeCoilFieldZoneById(CoilTypeDto coilType);

    public Task<CoilFieldZone> GetCoilFieldZoneById(int id);
    public List<CoilFieldZone> GetCoilFieldZoneByIds(List<int> id);

    public List<CoilFieldZone> GetCoilFieldsZoneByCoilFieldId(int id);

    CoilFieldZone GetCoilFieldZoneByName(string zone);

    public Task<bool> UpdateCoilFieldZone(CoilFieldZone coilFieldZone);
    public Task<bool> DisableCoilFieldZone(int zoneId, bool disable);

    public Task<CoilFieldZone> AddCoilFieldZone(CoilFieldZone coilFieldZone);

    public Task<bool> DeleteCoilFieldZone(int zoneId);

    Task<CoilFieldZone> GetCoilFieldZoneByNameWithLocation(string zoneName);

    public Task SaveChangesAsync(AuditActionType auditAction);
  }
}
