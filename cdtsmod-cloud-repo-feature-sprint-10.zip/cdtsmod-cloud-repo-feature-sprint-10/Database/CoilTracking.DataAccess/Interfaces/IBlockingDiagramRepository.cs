using CoilTracking.Data.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface IBlockingDiagramRepository
  {
    public Task<List<BlockingDiagrams>> GetBlockingDiagrams();
    public Task InsertBlockingDiagram(BlockingDiagrams blockingDiagram);
    public Task InsertBlockingDiagramList(List<BlockingDiagrams> blockingDiagram);
    public Task UpdateBlockingDiagram(BlockingDiagrams blockingDiagram);
    public Task<BlockingDiagrams> GetBlockingDiagramByDataNum(int dataNum);
    public Task<BlockingDiagrams> GetBlockingDiagramById(int id);
    public Task DeleteBlockingDiagram(int id);
  }
}
