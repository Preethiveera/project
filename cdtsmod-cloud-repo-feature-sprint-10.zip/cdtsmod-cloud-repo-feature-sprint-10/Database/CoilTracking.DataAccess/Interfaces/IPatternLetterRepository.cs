using CoilTracking.Data.Models;
using System.Linq;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface IPatternLetterRepository
  {
    IQueryable<PatternLetter> GetPatternLetter();
    PatternLetter GetPatternLetterById(int id);
    PatternLetter PostPatternLetter(PatternLetter patternLetter);
    bool PutPatternLetter(int id, PatternLetter patternLetter);
    bool DeletePatternLetter(int id);
    bool DisablePatternLetter(int id, bool disable);
    bool PatternLetterExists(int id);
    PatternLetter CheckEdit(int id);
    PatternLetter GetPatternLetterByName(string name);
  }
}
