using CoilTracking.Data.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface IPatternCalendarRepository
  {
    bool GetPatternLetterAssociation(PatternLetter patternLetter);
    Task<PatternCalendar> GetPatternCalendarByDateLineIdAndShiftId(DateTime date, int lineId, int shiftId);
    Task<List<PatternCalendar>> GetPatternCalendarByMonthAndYear(int month, int year);
    public Task<PatternCalendar> GetPatternCalendarById(int id);
    public Task<bool> UpdatePatternCalendar(PatternCalendar patternCalendar);    
    public Task<bool> RemovePatternCalendar(PatternCalendar patternCalendar);
    public Task<List<PatternCalendar>> GetPatternCalendarByMonthYearShiftIdLineId(int month, int year, int shiftId, int lineId);
    public Task<PatternCalendar> AddPatternCalendar(PatternCalendar patternCalendar);
    public Task AddPatternCalendar(List<PatternCalendar> patternCalendars);

    Task<bool> PatternCalenderExistsByLineId(int lineId);

    Task RemovePatternCalenderByLineId(int lineId);

    Task<List<PatternCalendar>> GetPatternCalendarsByLineIdAndShiftIdAsync(int lineId, int shiftId, DateTime minDate, DateTime maxDate);

    Task AddPatternCalenderAsync(PatternCalendar patternCalendar);
  }
}
