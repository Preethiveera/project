﻿using CoilTracking.Data.Models;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface IPressRepository
  {
    Press GetPressByName(string name);

    void AddNewPress(Press press);
  }
}
