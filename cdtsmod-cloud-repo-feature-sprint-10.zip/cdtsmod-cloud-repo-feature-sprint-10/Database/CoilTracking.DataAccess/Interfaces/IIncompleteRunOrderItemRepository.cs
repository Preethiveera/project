using CoilTracking.Data.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface IIncompleteRunOrderItemRepository
  {
    public Task<List<Part>> GetIncompleteRunOrderItemsByStatus(params RunOrderItemStatus[] runOrderItemStatuses);

    Task<List<IncompleteRunOrderItem>> GetIncompleteRunOrderItems();
  }
}
