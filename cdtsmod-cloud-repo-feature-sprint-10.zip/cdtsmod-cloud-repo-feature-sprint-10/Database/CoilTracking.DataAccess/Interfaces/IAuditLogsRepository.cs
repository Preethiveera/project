using CoilTracking.Data.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface IAuditLogsRepository
  {

    AuditLog AuditLogExist(int Id);

    public List<AuditLog> GetAuditLogs();

    public List<string> GetUserNameAudits();
    public List<AuditLog> Search(DateTime? startTime = null, DateTime? endTime = null, string username = null, int? actionType = null, string className = null);
  }
}
