using CoilTracking.Data.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface IRunOrderListQuantityRepository
  {
    /// <summary>
    /// GetRunOrderListQuantities
    /// </summary>
    /// <returns></returns>
    Task<List<RunOrderListQuantity>> GetRunOrderListQuantities();
    /// <summary>
    /// IsRunOrderListQuantityExists
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    RunOrderListQuantity GetRunOrderListQuantityById(int id);
    /// <summary>
    /// IsRunOrderListQuantityExists
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    bool IsRunOrderListQuantityExists(int id);
    /// <summary>
    /// ModifyRunOrderListQuantity
    /// </summary>
    /// <param name="runOrderListQuantity"></param>
    /// <returns></returns>
    void ModifyRunOrderListQuantity(RunOrderListQuantity runOrderListQuantity);
    /// <summary>
    /// InsertRunOrderListQuantity
    /// </summary>
    /// <param name="runOrderListQuantity"></param>
    void InsertRunOrderListQuantity(RunOrderListQuantity runOrderListQuantity);
    /// <summary>
    /// DeleteRunOrderListQuantityById
    /// </summary>
    /// <param name="runOrderListQuantity"></param>
    /// <returns></returns>
    void DeleteRunOrderListQuantityById(RunOrderListQuantity runOrderListQuantity);
    bool RunOrderListQuantitySaveChanges();
    void RemoveRunOrderQtyList(List<RunOrderListQuantity> qty);

    public List<RunOrderListQuantity> GetRunOrderListQuantityByQtyIdList(List<int> ids);

    List<RunOrderListQuantity> GetRunOrderListQuantityByListBlankInfo(List<BlankInfo> blankInfo);
  }
}
