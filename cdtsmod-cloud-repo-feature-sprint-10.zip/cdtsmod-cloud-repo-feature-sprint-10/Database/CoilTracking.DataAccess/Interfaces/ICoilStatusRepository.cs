using CoilTracking.Data.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Interfaces
{
  public interface ICoilStatusRepository
  {
    Task<List<CoilStatus>> GetCoilStatusByName(string name);

    CoilStatus GetCoilStatusName(string name);
    public Task<List<CoilStatus>> GetCoilStatuses();
    public Task<CoilStatus> GetCoilStatusByIdAsync(int id);
    public CoilStatus GetCoilStatusById(int id);
    public void InsertCoilStatus(CoilStatus coilStatus);
    public void UpdateCoilStatus(CoilStatus coilStatus);
    public CoilStatus DeleteCoilStatus(int id);
  }
}
