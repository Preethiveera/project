using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class MaterialTypesRepository : IMaterialTypesRepository
  {

    private readonly CoilTrackingContext coilTrackingContext;

    public MaterialTypesRepository(CoilTrackingContext coilTrackingContext)
    {
      this.coilTrackingContext = coilTrackingContext;
    }
    /// <summary>
    /// Get  MaterialTypes
    /// </summary>
    /// <returns></returns>
    public async Task<List<MaterialType>> GetCoilsMaterialTypes()
    {
      var materialTypes = await coilTrackingContext.MaterialTypes.ToListAsync();
      return materialTypes;
    }


    /// <summary>
    /// Get MaterialTypes Based on Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public MaterialType GetMaterialTypesById(int id)
    {
      var materialTypes = coilTrackingContext.MaterialTypes.Find(id);
      return materialTypes;
    }
  }
}
