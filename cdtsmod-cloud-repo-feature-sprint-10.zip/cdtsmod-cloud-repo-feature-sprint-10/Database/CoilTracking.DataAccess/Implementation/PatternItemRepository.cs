using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class PatternItemRepository : IPatternItemRepository
  {
    private readonly CoilTrackingContext coilTrackingContext;
    public PatternItemRepository(CoilTrackingContext coilTrackingContext)
    {
      this.coilTrackingContext = coilTrackingContext;
    }

    public bool RemovePatternItem(PatternItem patternItem)
    {
      coilTrackingContext.PatternItems.Remove(patternItem);
      return true;
    }
  }
}
