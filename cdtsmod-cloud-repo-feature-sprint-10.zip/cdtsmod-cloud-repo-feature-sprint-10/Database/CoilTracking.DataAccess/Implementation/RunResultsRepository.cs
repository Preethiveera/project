using CoilTracking.Common;
using CoilTracking.Common.Constant;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class RunResultsRepository : IRunResultsRepository
  {
    private readonly CoilTrackingContext coilTrackingContext;
    private readonly IUserHelper usersHelper;
    public RunResultsRepository(CoilTrackingContext coilTrackingContext, IUserHelper usersHelper)
    {
      this.coilTrackingContext = coilTrackingContext;
      this.usersHelper = usersHelper;
    }

    /// <summary>
    /// Get Run Results
    /// </summary>
    /// <returns></returns>
    public async Task<List<RunResult>> GetRunResults()
    {
      var results = await coilTrackingContext.RunResults
           .Include(r => r.Coil)
           .Include(r => r.Coil.CoilType)
           .Include(r => r.RunOrderList)
           .Include(r => r.RunOrderList.Line)
           .Include(r => r.RunOrderList.Shift).ToListAsync();

      return results;
    }

    /// <summary>
    /// Get RunOrder RunResult By Id
    /// </summary>
    /// <returns></returns>
    public List<RunResult> GetRunOrderRunResultById(int id)
    {
      var results = coilTrackingContext.RunResults.Include(v => v.RunOrderList).Include(x => x.Coil).ThenInclude(y => y.CoilType).Where(rr => rr.RunOrderList.Id == id).ToList();
      return results;
    }

    /// <summary>
    /// Get Details By Search
    /// </summary>
    /// <param name="startTime"></param>
    /// <param name="endTime"></param>
    /// <param name="partNum"></param>
    /// <param name="dataNum"></param>
    /// <param name="coilType"></param>
    /// <param name="lineId"></param>
    /// <param name="shiftId"></param>
    /// <param name="ftz"></param>
    /// <returns></returns>
    public List<RunResult> GetRunResultsSearch(DateTime? startTime = null, DateTime? endTime = null, string partNum = null, int? dataNum = null, string coilType = null, int? lineId = null, int? shiftId = null, string ftz = null)
    {
      var results = coilTrackingContext.RunResults.Where(rr => (!startTime.HasValue || rr.RunStarted >= startTime)
                                     && (!endTime.HasValue || rr.RunStarted <= endTime)
                                     && (partNum == null || rr.PartNumber.Contains(partNum))
                                     && (dataNum == null || rr.DataNumber == dataNum)
                                     && (coilType == null || rr.BlankCoilTypeName.Contains(coilType))
                                     && (lineId == null || rr.RunOrderList.Line.Id == lineId)
                                     && (shiftId == null || rr.RunOrderList.Shift.Id == shiftId)
                                     && (ftz == null || rr.Coil.FTZ.Contains(ftz))
                                 )
                         .Include(r => r.Coil.CoilRunHistory)
                         .Include(r => r.Coil.CoilType)
                         .Include(r => r.RunOrderList)
                         .Include(r => r.Coil)
                         .Include(r => r.RunOrderList.Line)
                         .Include(r => r.RunOrderList.Shift)
                         .OrderBy(rr => rr.RunStarted).ToList();
      return results;
    }

    /// <summary>
    /// Get Coils To Be Weighed
    /// </summary>
    /// <returns></returns>
    public List<RunResult> GetCoilsToBeWeighed()
    {
      List<RunResult> runResultsWithPartials = coilTrackingContext.RunResults
                                                 .Include(r => r.RunOrderList)
                                                 .Include(r => r.Coil)
                                                 .Include(r => r.Coil.CoilRunHistory)
                                                 .Include(r => r.Coil.CoilType)
                                                 .Include(r => r.Coil.CoilFieldLocation)
                                                 .Include(r => r.Coil.CoilFieldLocation.Zone)
                                                 .Where(r => r.Coil.CoilStatus.Name == CoilStatusName.PartialNeedsWeighed
                                                             && r.WeightUsed == 0)
                                                 .OrderByDescending(r => r.RunStarted)
                                                 .ToList();
      return runResultsWithPartials;
    }

    /// <summary>
    /// Get the Run Result Based on Partial Ids
    /// </summary>
    /// <param name="Id"></param>
    /// <returns></returns>
    public List<RunResult> GetRunResultIds(List<int> ids)
    {

      var runResult = coilTrackingContext.RunResults.Where(x => ids.Contains(x.Id)).ToList();
      return runResult;
    }

    /// <summary>
    /// Entry Run Result Modified
    /// </summary>
    /// <param name="runResult"></param>
    public bool ModifyRunResult(RunResult runResult)
    {
      coilTrackingContext.Entry(runResult).State = EntityState.Modified;
      return true;
    }

    /// <summary>
    /// Get Weight partials Based on Id
    /// </summary>
    /// <param name="partialsId"></param>
    /// <returns></returns>
    public RunResult GetRunResultId(int id)
    {
      RunResult runResult = coilTrackingContext.RunResults.Find(id);
      return runResult;
    }

    /// <summary>
    /// Get Weight partials Based on Id
    /// </summary>
    /// <param name="partialsId"></param>
    /// <returns></returns>
    public async Task<RunResult>  GetRunResultsId(int id)
    {
      RunResult runResult = await coilTrackingContext.RunResults.AsNoTracking().Where(x=>x.Id==id).FirstOrDefaultAsync();
      return runResult;
    }

    /// <summary>
    /// Deletion of RunResult Based on RunResult Info
    /// </summary>
    /// <param name="runResult"></param>
    /// <returns></returns>
    public async Task<int> DeleteRunResult(RunResult runResult)
    {
       coilTrackingContext.RunResults.Remove(runResult);
      var result =   await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
     
      return result;
    }

    /// <summary>
    /// RunResult SaveChanges
    /// </summary>
    /// <param name="runResult"></param>
    /// <returns></returns>
    public async Task<bool> RunResultSaveChanges(RunResult runResult)
    {
      try
      {
        coilTrackingContext.Entry(runResult.RunOrderList).State = EntityState.Unchanged;
        coilTrackingContext.Entry(runResult.Coil).State = EntityState.Unchanged;
        coilTrackingContext.RunResults.Add(runResult);
       await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.CreateEntity);
        return true;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }
    /// <summary>
    /// Validate RunResult 
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public bool IsRunResultExists(int id)
    {
      return coilTrackingContext.RunResults.Count(e => e.Id == id) > 0;
    }

    /// <summary>
    /// Get RunResults By RunResultDtoId
    /// </summary>
    /// <param name="Id"></param>
    /// <returns></returns>
    public async Task<RunResult> GetRunResultsById(int Id)
    {
      var results = await coilTrackingContext.RunResults.AsNoTracking()
           .Include(r => r.RunOrderList)
          .Include(r => r.Coil).Where(r => r.Id == Id)
            .FirstOrDefaultAsync();

      return results;
    }

    /// <summary>
    /// Update RunResult SaveChanges
    /// </summary>
    /// <param name="runResult"></param>
    /// <returns></returns>
    public async Task<bool> UpdateRunResultSaveChanges(RunResult runResult)
    {    
        coilTrackingContext.Entry(runResult.RunOrderList).State = EntityState.Unchanged;
        coilTrackingContext.Entry(runResult.Coil).State = EntityState.Unchanged;
        coilTrackingContext.Entry(runResult).State = EntityState.Modified;
        coilTrackingContext.RunResults.Update(runResult);
       await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.CreateEntity);     
      return true;
    }

    public async Task<RunResult> GetNewestRunResultForCoil(int coilId)
    {
      var runResult = await coilTrackingContext.RunResults
                                         .Where(rr => rr.Coil.Id == coilId)
                                         .Include(rr => rr.RunOrderList)
                                         .OrderByDescending(rr => rr.RunStarted)
                                         .FirstOrDefaultAsync();

      return runResult;
    }
    /// <summary>
    /// Get run result by run order result id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>run result</returns>
    public async Task<RunResult> GetRunResultByRunOrderListId(int id)
    {
      return await coilTrackingContext.RunResults.Where(x => x.RunOrderList.Id == id).FirstOrDefaultAsync();
    }

    /// <summary>
    /// Get run result by Date
    /// </summary>
    /// <returns>run result</returns>
    public async Task<List<RunResult>> GetRunResultsByDate(DateTime startDate, DateTime endDate)
    {
      return await coilTrackingContext.RunResults.Where(rr => (rr.RunStarted >= startDate)
                                         && (rr.RunStarted < endDate))
                             .Include(r => r.Coil)
                             .Include(r => r.Coil.CoilRunHistory)
                             .Include(r => r.Coil.CoilType)
                             .Include(r => r.RunOrderList)
                             .Include(r => r.RunOrderList.Line)
                             .Include(r => r.RunOrderList.Shift)
                             .OrderBy(rr => rr.RunStarted)
                             .ToListAsync();

    }

    /// <summary>
    /// Get run result by for incomplete order item
    /// </summary>
    /// <returns>run result</returns>
    public IQueryable<int> GetRunResultForIncompleteOrderItem()
    {
      var runResult = coilTrackingContext.RunResults
        .Include(x => x.RunOrderList)
        .ToList()
        .GroupBy(x => x.RunOrderList.Line)
        .Select(x => x.OrderBy(r => r.RunFinished).Select(r => r.RunOrderList.Id).FirstOrDefault())
        .AsQueryable();

      return runResult;
    }
  }
}
