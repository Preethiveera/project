using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class CoilFieldLocationRepository : ICoilFieldLocationRepository
  {
    private readonly CoilTrackingContext coilTrackingContext;
    private readonly IUserHelper usersHelper;
    public CoilFieldLocationRepository(CoilTrackingContext coilTrackingContext, IUserHelper usersHelper)
    {
      this.coilTrackingContext = coilTrackingContext;
      this.usersHelper = usersHelper;
    }


    /// <summary>
    /// Get the list of coilat location based on CoilId,CoilFieldLocationId
    /// </summary>
    /// <param name="dbLocationId"></param>
    /// <param name="coilsInField"></param>
    /// <returns></returns> ks
    public List<Coil> CoilFieldLocations(List<Data.Models.Coil> coilsInField, List<CoilFieldLocation> fieldLocations)
    {
      var fieldLocation = fieldLocations.Select(k => k.Id).ToList();
      var coilsInFields = coilsInField.Where(m => fieldLocation.Contains(m.CoilFieldLocation.Id)).ToList();
      return coilsInFields;
    }

    /// <summary>
    /// To get count of all the coil Field Location
    /// </summary>

    public int GetCountOfCoilFieldLocation()
    {
      return coilTrackingContext.CoilFieldLocations.Count();
    }

    /// <summary>
    /// To get  all the coil Field Location
    /// </summary>

    public IQueryable<CoilFieldLocation> GetAllCoilFieldLocations()
    {
      var coilFieldLocations = coilTrackingContext.CoilFieldLocations.Include(l => l.Zone).OrderBy(cfl => cfl.Zone.Id).ThenBy(cfl => cfl.Name);
      return coilFieldLocations;
    }


    /// <summary>
    /// To get the coil Field Location by id
    /// </summary>

    public CoilFieldLocation GetCoilFieldLocationById(int id)
    {
      var coilFieldLocation = coilTrackingContext.CoilFieldLocations.Include(c=>c.Zone).Where(x=>x.Id == id).FirstOrDefault();
      return coilFieldLocation;
    }

    /// <summary>
    /// To get the coil Field Location by id including zone
    /// </summary>

    public CoilFieldLocation GetCoilFieldLocationWithZone(int id)
    {
      var coilFieldLocation = coilTrackingContext.CoilFieldLocations.AsNoTracking().Include(l => l.Zone).Where(l => l.Id == id).FirstOrDefault();
      return coilFieldLocation;
    }

    /// <summary>
    /// To get the coil Field Location by zoneId
    /// </summary>

    public List<CoilFieldLocation> GetCoilFieldLocationByZoneId(int zoneId)
    {
      var coilFieldLocation = coilTrackingContext.CoilFieldLocations.Include(l => l.Zone).Where(l => l.Zone.Id == zoneId).ToList();
      return coilFieldLocation;
    }

    /// <summary>
    /// To update the coil Field Location
    /// </summary>

    public void UpdateCoilFieldLocation(int id, CoilFieldLocation coilFieldLocation)
    {
      coilTrackingContext.Entry(coilFieldLocation).State = EntityState.Modified;
      SaveChanges(AuditActionType.ModifyEntity);
    }

    /// <summary>
    /// To add the coil Field Location
    /// </summary>

    public async Task<CoilFieldLocation>  AddCoilFieldLocation(CoilFieldLocation coilFieldLocation)
    {
    await coilTrackingContext.CoilFieldLocations.AddAsync(coilFieldLocation);
     await SaveChangesAync(AuditActionType.CreateEntity);
      return coilFieldLocation;
    }

    /// <summary>
    /// To delete the coil Field Location
    /// </summary>

    public void DeleteCoilFieldLocation(CoilFieldLocation coilFieldLocation)
    {
      coilTrackingContext.CoilFieldLocations.Remove(coilFieldLocation);
      SaveChanges(AuditActionType.ModifyEntity);
    }

    /// <summary>
    /// To delete the coil Field Location
    /// </summary>

    public void DeleteCoilFieldLocationEntry(CoilFieldLocation coilFieldLocation)
    {
      coilTrackingContext.Entry(coilFieldLocation).State = EntityState.Deleted;
    }

    /// <summary>
    /// To save changes in the database
    /// </summary>

    public void SaveChanges(AuditActionType auditAction)
    {
      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), auditAction);
    }
    public async Task<int> SaveChangesAync(AuditActionType auditAction)
    {
   var res =  await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), auditAction);
      return res;
    }
    /// <summary>
    /// To Get this list of free/empty coil Field Location
    /// </summary>

    public List<CoilFieldLocation> GetFreeLocations()
    {
      return coilTrackingContext.CoilFieldLocations.Include(l => l.Zone).Where(l => l.IsEmpty == true).ToList();
    }
    public async Task<CoilFieldLocation> GetCoilFieldLocationByName(string zone, string locationName)
    {
      CoilFieldLocation location = await coilTrackingContext.CoilFieldLocations.Where(l => l.Zone.Name == zone && l.Name == locationName).Include(l => l.Zone).FirstOrDefaultAsync();
      return location;
    }

    /// <summary>
    ///CoilFieldLocation Zone EntityState Unchanged
    /// </summary>
    /// <param name="coil"></param>
    public void CoilFieldLocationZoneEntityStateModified(CoilFieldLocation newLocation)
    {

      coilTrackingContext.Entry(newLocation).State = EntityState.Modified;
      coilTrackingContext.Entry(newLocation.Zone).State = EntityState.Unchanged;
      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
    }

    /// <summary>
    ///CoilFieldLocation Zone EntityState Unchanged
    /// </summary>
    /// <param name="coil"></param>
    public void CoilFieldLocationOldLocationEntity(CoilFieldLocation oldLocation)
    {

      coilTrackingContext.Entry(oldLocation).State = EntityState.Modified;
      coilTrackingContext.Entry(oldLocation.Zone).State = EntityState.Unchanged;
      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
    }

    public async Task<List<string>> CheckEdit(int id, CoilFieldLocationDto dto)
    {
      List<string> coilTypeAssociation = new List<string>();
      if (dto.Id != await coilTrackingContext.CoilFieldLocations.Where(x => x.Id == id).Select(y => y.Id).FirstOrDefaultAsync()
              || dto.Name != coilTrackingContext.CoilFieldLocations.Where(x => x.Id == id).Select(y => y.Name).FirstOrDefault()
              || dto.Column != coilTrackingContext.CoilFieldLocations.Where(x => x.Id == id).Select(y => y.Column).FirstOrDefault()
              || dto.Row != coilTrackingContext.CoilFieldLocations.Where(x => x.Id == id).Select(y => y.Row).FirstOrDefault()
              || dto.ZoneId != coilTrackingContext.CoilFieldLocations.Where(x => x.Id == id).Select(y => y.Zone.Id).FirstOrDefault()
              || dto.IsEmpty != coilTrackingContext.CoilFieldLocations.Where(x => x.Id == id).Select(y => y.IsEmpty).FirstOrDefault()
          )
      {
        coilTypeAssociation.Add("editing");
      }

      return coilTypeAssociation;
    }
  }
}
