using CoilTracking.Common;
using CoilTracking.Common.Exception;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class RunOrderRepository : IRunOrderRepository
  {
    private readonly CoilTrackingContext coilTrackingContext;
    private readonly IUserHelper usersHelper;
    public RunOrderRepository(CoilTrackingContext coilTrackingContext, IUserHelper usersHelper)
    {
      this.coilTrackingContext = coilTrackingContext;
      this.usersHelper = usersHelper;
    }

    /// <summary>
    /// Getting RunOrderList By Ids
    /// </summary>
    /// <param name="RunResultId"></param>
    /// <returns></returns>
    public List<RunOrderList> GetRunOrderListByPartialIds(List<int> partials)
    {
      var coilRunHistory = coilTrackingContext.RunOrderLists.Where(x => partials.Contains(x.Id)).ToList();
      return coilRunHistory;
    }
    /// <summary>
    /// Getting RunOrderList By Id
    /// </summary>
    /// <param name="partialId"></param>
    /// <returns></returns>
    public RunOrderList GetRunOrderListId(int partialId)
    {
      var coilRunHistory = coilTrackingContext.RunOrderLists.Find(partialId);
      return coilRunHistory;
    }
    /// <summary>
    /// To check if run order is scheduled for BlankInfo
    /// </summary>
    /// <param name="blankinfoId"></param>
    /// <returns></returns>
    public bool IsScheduledOnRunOrder(int blankinfoId)
    {
      var check = coilTrackingContext.RunOrderLists.Any(rol => rol.Date >= DateTime.Today && rol.Quantities.Any(q => q.BlankInfo.Id == blankinfoId));

      return check;

    }

    /// <summary>
    /// Get list of runOrderLists
    /// </summary>
    /// <returns>RunOrderList</returns>
    public async Task<List<RunOrderList>> GetRunOrderListsAsync()
    {
      return await coilTrackingContext.RunOrderLists.Include(x => x.Line).Include(c => c.Shift).Include(cc => cc.Quantities).ToListAsync();
    }

    /// <summary>
    /// Get RunOrderList by Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>runorderList</returns>
    public async Task<RunOrderList> GetRunOrderListByIdAsync(int id)
    {
      return await coilTrackingContext.RunOrderLists.Include(x => x.Line).Where(x => x.Id == id).FirstOrDefaultAsync();
    }
    /// <summary>
    /// To check if RunOrderList exists
    /// </summary>
    /// <param name="id"></param>
    /// <returns>bool</returns>
    public bool RunOrderListExists(int id)
    {
      return coilTrackingContext.RunOrderLists.Count(e => e.Id == id) > 0;
    }

    /// <summary>
    /// Get list of IncompleteRunOrderItems which includes Part, Line,RunOrder
    /// </summary>
    /// <param name="lineId"></param>
    /// <returns>list</returns>
    public List<IncompleteRunOrderItem> GetIncompleteRunOrderItemsByLineId(int lineId)
    {
      return coilTrackingContext.IncompleteRunOrderItems
            .Include(i => i.RunOrderList)
            .Include(i => i.Part)
            .Include(i => i.Line)
            .Where(i => i.Line.Id == lineId && (i.Status == RunOrderItemStatus.New ||
                                                i.Status == RunOrderItemStatus.RunStarted ||
                                                i.Status == RunOrderItemStatus.Incomplete))
            .OrderBy(i => i.SortOrder)
            .ToList();

    }

    /// <summary>
    /// Get list of IncompleteRunOrderItems which includes Part, Line,RunOrderList, Quantities,Shifts
    /// </summary>
    /// <param name="lineId"></param>
    /// <returns>list</returns>
    public List<IncompleteRunOrderItem> GetIncompleteItemsWithShiftLinePart(int lineId)
    {
      return coilTrackingContext.IncompleteRunOrderItems
              .Include("RunOrderList")
              .Include("RunOrderList.Shift")
              .Include("RunOrderList.Line")
              .Include("RunOrderList.Quantities")
              .Include("RunOrderList.Quantities.Part")
              .Include("Part")
              .AsNoTracking()
              .Where(i => i.Line.Id == lineId && (i.Status == RunOrderItemStatus.New ||
                                                  i.Status == RunOrderItemStatus.RunStarted ||
                                                  i.Status == RunOrderItemStatus.Incomplete))
              .OrderBy(i => i.SortOrder)
              .ToList();

    }

    /// <summary>
    /// Mark RunOrderItem as Incomplete
    /// </summary>
    /// <param name="incompleteItems"></param>
    public async Task MarkRunOrderItemsIncomplete(List<IncompleteRunOrderItem> incompleteItems)
    {
      // mark each item in list as incomplete
      foreach (IncompleteRunOrderItem dto in incompleteItems)
      {
        IncompleteRunOrderItem incompleteItem =
            await coilTrackingContext.IncompleteRunOrderItems
                .Include(i => i.Line)
                .Include(i => i.RunOrderList)
                .Include(i => i.RunOrderItem)
                .Include(i => i.Part)
                .Where(i => i.RunOrderItem.Id == dto.Id).FirstOrDefaultAsync();
        if (incompleteItem != null)
        {
          incompleteItem.Status = RunOrderItemStatus.Incomplete;
        }
      }

      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.CreateEntity);

    }



    /// <summary>
    /// Create IncompleteRunOrder item entries for table
    /// </summary>
    /// <param name="runOrderList"></param>
    public void CreateIncompleteRunOrderItemEntries(RunOrderList runOrderList)
    {
      try
      {
        foreach (RunOrderListQuantity runOrderItem in runOrderList.Quantities)
        {
          if (runOrderItem.Incomplete)
          {
            IncompleteRunOrderItem incompleteItem =
                coilTrackingContext.IncompleteRunOrderItems
                .Include("Line")
                .Include("RunOrderList")
                .Include("RunOrderItem")
                .Include("Part")
                .Where(i => i.Line.Id == runOrderList.Line.Id &&
                                                    i.Part.Id == runOrderItem.Part.Id &&
                                                    (i.Status == RunOrderItemStatus.New ||
                                                    i.Status == RunOrderItemStatus.RunStarted ||
                                                    i.Status == RunOrderItemStatus.Incomplete)).FirstOrDefault();

            var local = coilTrackingContext.Set<IncompleteRunOrderItem>()
            .Local
            .FirstOrDefault(entry => entry.Id.Equals(incompleteItem.Id));
            if (local == null) // checking if it is already tracked, if no then only track, if already tracked ignore
            {
              incompleteItem.Status = RunOrderItemStatus.CarriedOver;
              incompleteItem.CarriedOverToRunOrder = runOrderList;
              coilTrackingContext.Entry(incompleteItem).State = EntityState.Modified;
            }

            IncompleteRunOrderItem item = new IncompleteRunOrderItem()
            {
              Line = runOrderList.Line,
              RunOrderList = runOrderList,
              RunOrderItem = runOrderItem,
              Part = runOrderItem.Part,
              DataNumber = runOrderItem.BlankInfo.DataNumber,
              SortOrder = runOrderItem.SortOrder,
              Quantity = runOrderItem.OverrideQty,
              Status = RunOrderItemStatus.New,
              Date = DateTime.Now
            };

            coilTrackingContext.IncompleteRunOrderItems.Add(item);

            coilTrackingContext.Entry(item.Line).State = EntityState.Unchanged;
            coilTrackingContext.Entry(item.RunOrderList).State = EntityState.Unchanged;
            coilTrackingContext.Entry(item.RunOrderItem).State = EntityState.Unchanged;
            coilTrackingContext.Entry(item.Part).State = EntityState.Unchanged;

          }
        }
        coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.CreateEntity);
      }
      catch (Exception e)
      {
        throw new CoilTrackingException { ErrorMessage = e.Message + e.InnerException.ToString() };

      }
    }

    /// <summary>
    /// Get runorderlist by date, shift and line id
    /// </summary>
    /// <param name="date"></param>
    /// <param name="lineId"></param>
    /// <param name="shiftId"></param>
    /// <returns>runOrderList</returns>
    public async Task<RunOrderList> GetListByDateLineIdAndShift(DateTime date, int lineId, int shiftId)
    {
      var runOrderList = await coilTrackingContext.RunOrderLists.Include(rol => rol.Quantities)
                                                   .Include("Quantities.Part")
                                                   .Include("Quantities.BlankInfo")
                                                   .Include("Quantities.BlankInfo.CoilType")
                                                   .Include(rol => rol.Line)
                                                   .Where(r => r.Date == date &&
                                                       r.Line.Id == lineId && r.Shift.Id == shiftId).FirstOrDefaultAsync();


      return runOrderList;


    }

    /// <summary>
    /// Get runorderlist by date, shift and line id which includes Shift and Quantities
    /// </summary>
    /// <param name="date"></param>
    /// <param name="lineId"></param>
    /// <param name="shiftId"></param>
    /// <returns>runOrderList</returns>
    public async Task<RunOrderList> GetListWithQuantitiesAndShifts(DateTime date, int lineId, int shiftId)
    {
      var runOrderList = await coilTrackingContext.RunOrderLists.Include(rol => rol.Line)
                                                 .Include(rol => rol.Shift)
                                                 .Include(rol => rol.Quantities)
                                                 .Include("Quantities.Part")
                                                 .Include("Quantities.BlankInfo")
                                                 .Include("Quantities.BlankInfo.Part")
                                                 .Include("Quantities.BlankInfo.CoilType")
                                                 .Include("Quantities.BlankInfo.CoilType.CoilFieldZone")
                                                 .Include("Quantities.BlankInfo.CoilType.CoilTypeYNAs")
                                                 .AsNoTracking()
                                                 .Where(r => r.Date == date &&
                                                     r.Line.Id == lineId &&
                                                     r.Shift.Id == shiftId)
                                                 .FirstOrDefaultAsync();
      return runOrderList;

    }

    /// <summary>
    /// Add new runOrderList
    /// </summary>
    /// <param name="runOrderList"></param>
    public void AddNewRunOrderList(RunOrderList runOrderList)
    {
      coilTrackingContext.Entry(runOrderList.Shift).State = EntityState.Unchanged;
      coilTrackingContext.Entry(runOrderList.Line).State = EntityState.Unchanged;

      foreach (var item in runOrderList.Quantities)
      {
        var part = item.Part;
        var local = coilTrackingContext.Set<Part>()
        .Local
        .FirstOrDefault(entry => entry.Id.Equals(part.Id));

        if (local == null)
        {
          coilTrackingContext.Entry(part).State = EntityState.Unchanged;
        }
        else
        {
          item.Part = null;
          item.Part = local;
        }

        var blank = item.BlankInfo;
        var localBlank = coilTrackingContext.Set<BlankInfo>()
        .Local
        .FirstOrDefault(entry => entry.Id.Equals(blank.Id));

        if (localBlank == null)
        {
          coilTrackingContext.Entry(blank).State = EntityState.Unchanged;
        }
        else
        {
          item.BlankInfo = null;
          item.BlankInfo = localBlank;
        }

      }

      coilTrackingContext.RunOrderLists.AddRange(runOrderList);

      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.CreateRunOrderListByOperator);
    }

    /// <summary>
    /// To change run order status
    /// </summary>
    /// <param name="runOrderItemId"></param>
    /// <param name="status"></param>
    /// <returns></returns>
    public async Task MarkRunOrderItemStatus(int runOrderItemId, RunOrderItemStatus status)
    {
      IncompleteRunOrderItem startedItem =
         await coilTrackingContext.IncompleteRunOrderItems
              .Include(i => i.Line)
              .Include(i => i.RunOrderList)
              .Include(i => i.RunOrderItem)
              .Include(i => i.Part)
              .Where(i => i.RunOrderItem.Id == runOrderItemId).FirstOrDefaultAsync();
      if (startedItem != null)
      {

        startedItem.Status = status;

        await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.ModifyEntity);

      }
    }

    /// <summary>
    /// Get runorderlist by id includes lines and Quantities
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<RunOrderList> GetListByIdWithLineQuantity(int id)
    {
      RunOrderList runOrderList = await coilTrackingContext.RunOrderLists.Include(rol => rol.Line)
                                                  .Include(rol => rol.Quantities)
                                                  .Where(rol => rol.Id == id).FirstOrDefaultAsync();
      return runOrderList;
    }

    /// <summary>
    /// Delete run Order List
    /// </summary>
    /// <param name="id"></param>
    /// <param name="runOrderList"></param>
    /// <returns></returns>
    public void DeleteRunOrderList(int id, RunOrderList runOrderList)
    {
      var unCarryoverItems = coilTrackingContext.IncompleteRunOrderItems
          .Include(iroi => iroi.RunOrderList)
          .Include(iroi => iroi.RunOrderItem)
          .Include(iroi => iroi.Part)
          .Where(iroi => iroi.CarriedOverToRunOrder.Id == id);
      foreach (var item in unCarryoverItems)
      {
        item.CarriedOverToRunOrder = null;
        item.Status = RunOrderItemStatus.Incomplete;
      }

      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyEntity);

      coilTrackingContext.RunOrderListQuantities.RemoveRange(runOrderList.Quantities);
      var incompleteItems = coilTrackingContext.IncompleteRunOrderItems.Where(iroi => iroi.RunOrderList.Id == id);
      coilTrackingContext.IncompleteRunOrderItems.RemoveRange(incompleteItems);

      coilTrackingContext.RunOrderLists.Remove(runOrderList);
      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyRunOrderList);
    }
    /// <summary>
    /// Save new run order list with shift unchanged
    /// </summary>
    /// <param name="runOrderListToSave"></param>
    public void SaveNewRunOrderList(RunOrderList runOrderListToSave)
    {
      coilTrackingContext.Entry(runOrderListToSave.Shift).State = EntityState.Unchanged;
      coilTrackingContext.RunOrderLists.Add(runOrderListToSave);
      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyRunOrderList);
    }

    /// <summary>
    /// Get list of incomplete runorder items by partList and status
    /// </summary>
    /// <param name="partList"></param>
    /// <param name="lineId"></param>
    /// <returns>incompleterunitems</returns>
    public List<IncompleteRunOrderItem> GetIncompleteItemByStatusAndPart(List<string> partList, int lineId)
    {
      var items =
             coilTrackingContext.IncompleteRunOrderItems
            .Include(i => i.RunOrderList)
            .Include(i => i.RunOrderItem)
            .Include(i => i.Part)
            .Where(i => i.Line.Id == lineId
                    && partList.Contains(i.Part.PartNumber)
                    && i.Status != RunOrderItemStatus.CarriedOver
                    && i.Status != RunOrderItemStatus.Completed
                    && i.Status != RunOrderItemStatus.Removed)
            .ToList();
      return items;
    }

    /// <summary>
    /// Get incomplete run items by line Id
    /// </summary>
    /// <param name="lineId"></param>
    /// <returns></returns>
    public List<IncompleteRunOrderItem> GetIncompleteRunItemByLineId(int lineId)
    {
      return coilTrackingContext.IncompleteRunOrderItems.Include(i => i.RunOrderList)
                                                      .Include(i => i.RunOrderItem)
                                                      .Include(i => i.Part)
                                                      .Where(i => i.Line.Id == lineId
                                                              && i.Status != RunOrderItemStatus.CarriedOver
                                                              && i.Status != RunOrderItemStatus.Completed
                                                              && i.Status != RunOrderItemStatus.Removed)
                                                      .ToList();
    }
    /// <summary>
    /// Modify  incomplete run order items state to modified
    /// </summary>
    /// <param name="item"></param>
    public void ModifyIncompleteRunOrderRecordState(List<IncompleteRunOrderItem> item)
    {
      foreach (var data in item)
      {
        coilTrackingContext.Entry(data).State = EntityState.Modified;
      }

      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyRunOrderList);


    }
    /// <summary>
    /// Modify  incomplete run order items state to deleted
    /// </summary>
    /// <param name="item"></param>
    public void ModifyIncompleteRunStateToDeleted(IncompleteRunOrderItem item)
    {
      coilTrackingContext.Entry(item).State = EntityState.Deleted;

      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyRunOrderList);

    }


    /// <summary>
    /// Add list of Incomplete RunOrderRecord List
    /// </summary>
    /// <param name="item"></param>
    public void AddIncompleteRunOrderRecordList(List<IncompleteRunOrderItem> item)
    {
      coilTrackingContext.IncompleteRunOrderItems.AddRange(item);

      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.CreateEntity);
    }

    /// <summary>
    /// Change entity state for runOrderList
    /// </summary>
    /// <param name="runOrderListOriginal"></param>
    public void ChangeEntityState(RunOrderList runOrderListOriginal, DateTime date)
    {
      coilTrackingContext.Entry(runOrderListOriginal.Shift).State = EntityState.Unchanged;
      runOrderListOriginal.Date = date;
      coilTrackingContext.Entry(runOrderListOriginal).State = EntityState.Modified;
      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
    }

    public async Task<List<IncompleteRunOrderItem>> GetIncompleteItemListByRunOrderId(List<int> runOrderId)
    {
      return await coilTrackingContext.IncompleteRunOrderItems.Where(i => runOrderId.Contains(i.RunOrderItem.Id)).ToListAsync();
    }

    public Pattern GetPatternByLineInShiftId(DateTime date, int lineId, int shiftId)
    {
      Pattern pattern = new Pattern();
      PatternCalendar calendarEntry = coilTrackingContext.PatternCalendars.Where(c => c.Date == date && c.Line.Id == lineId
                            && c.Shift.Id == shiftId).FirstOrDefault();
      if (calendarEntry != null)
      {
        pattern = coilTrackingContext.Patterns
                .Include("PatternItems")
                .Include("Line")
                .Include("Line.Plant")
                .Include("Line.Plant.TimeZone")
                .Include("Line.OPCServer")
                .Where(p => p.Line.Id == lineId &&
                    p.Name == calendarEntry.PatternLetter &&
                    p.CreateDate.Year == date.Year &&
                    p.CreateDate.Month == date.Month).FirstOrDefault();
      }
      return pattern;
    }
    public string GetPatternLetterByLineId(DateTime date, int lineId, int shiftId)
    {
      string patternLetter = string.Empty;
      PatternCalendar calendarEntry = coilTrackingContext.PatternCalendars.Where(c => c.Date == date && c.Line.Id == lineId
                            && c.Shift.Id == shiftId).FirstOrDefault();
      if (calendarEntry != null)
      {
        patternLetter = calendarEntry.PatternLetter;

      }
      return patternLetter;
    }

    public async Task<List<RunOrderList>> GetRunOrderListsByShiftId(int id)
    {
      var list = await coilTrackingContext.RunOrderLists
        .Where(c => c.Shift.Id == id)
        .ToListAsync();

      return list;
    }
  }
}
