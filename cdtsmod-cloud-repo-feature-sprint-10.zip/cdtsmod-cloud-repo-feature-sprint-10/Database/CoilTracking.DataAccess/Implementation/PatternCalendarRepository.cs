using CoilTracking.Common;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class PatternCalendarRepository : IPatternCalendarRepository
  {
    private readonly CoilTrackingContext coilTrackingContext;
    private readonly IUserHelper usersHelper;
    public PatternCalendarRepository(CoilTrackingContext coilTrackingContext, IUserHelper usersHelper)
    {
      this.coilTrackingContext = coilTrackingContext;
      this.usersHelper = usersHelper;
    }

    public bool GetPatternLetterAssociation(PatternLetter patternLetter)
    {
      var associatedItems = coilTrackingContext.PatternCalendars.Where(p => p.PatternLetter.Equals(patternLetter.Name)).ToList();

      if (associatedItems.Count != 0)
      {
        return true;
      }
      return false;
    }

    /// <summary>
    /// Get Pattern Calendar by date, shift and lineId
    /// </summary>
    /// <param name="date"></param>
    /// <param name="lineId"></param>
    /// <param name="shiftId"></param>
    /// <returns>patternCalendar</returns>
    public async Task<PatternCalendar> GetPatternCalendarByDateLineIdAndShiftId(DateTime date, int lineId, int shiftId)
    {
      var patternCalendar = await coilTrackingContext.PatternCalendars.Where(c => c.Date == date &&
                                                                 c.Line.Id == lineId &&
                                                                 c.Shift.Id == shiftId).FirstOrDefaultAsync();
      return patternCalendar;
    }

    /// <summary>
    /// Get pattern calendar by month and year
    /// </summary>
    /// <param name="month"></param>
    /// <param name="year"></param>
    /// <returns>List of paatern calendar</returns>
    public async Task<List<PatternCalendar>> GetPatternCalendarByMonthAndYear(int month, int year)
    {
      return await coilTrackingContext.PatternCalendars.Include(x => x.Line).Include(x => x.Shift).Where(p => p.Date.Month == month && p.Date.Year == year).ToListAsync();
    }

    /// <summary>
    /// Get pattern calendar by month year shiftId and lineId
    /// </summary>
    /// <param name="month"></param>
    /// <param name="year"></param>
    /// <param name="shiftId"></param>
    /// <param name="lineId"></param>
    /// <returns>List of pattern calendar</returns>
    public async Task<List<PatternCalendar>> GetPatternCalendarByMonthYearShiftIdLineId(int month, int year, int shiftId, int lineId)
    {
      return await coilTrackingContext.PatternCalendars.AsNoTracking()
        .Include(pc => pc.Line)
        .Include(pc => pc.Shift)
        .Where(p => p.Shift.Id == shiftId
        && p.Date.Month == month && p.Date.Year == year && p.Line.Id == lineId).ToListAsync();
    }

    /// <summary>
    /// Get pattern calendar by id.
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<PatternCalendar> GetPatternCalendarById(int id)
    {
      return await coilTrackingContext.PatternCalendars
        .Include(pc => pc.Line)
        .Include(pc => pc.Shift)
        .FirstAsync(p => p.Id == id);
    }

    /// <summary>
    /// Update pattern calendar.
    /// </summary>
    /// <param name="patternCalendar"></param>
    /// <returns>bool</returns>
    public async Task<bool> UpdatePatternCalendar(PatternCalendar patternCalendar)
    {
      coilTrackingContext.PatternCalendars.Update(patternCalendar);
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.ModifyPatternCalendar);
      return true;
    }

    /// <summary>
    /// Add pattern calendar range
    /// </summary>
    /// <param name="patternCalendars"></param>
    /// <returns></returns>
    public async Task AddPatternCalendar(List<PatternCalendar> patternCalendars)
    {
      foreach (var p in patternCalendars)
      {
        coilTrackingContext.Entry(p.Line).State = EntityState.Unchanged;
        coilTrackingContext.Entry(p.Shift).State = EntityState.Unchanged;
      }
      await coilTrackingContext.PatternCalendars.AddRangeAsync(patternCalendars.OrderBy(p => p.Date));
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.CreateEntity);
    }

    /// <summary>
    /// Add pattern calendar
    /// </summary>
    /// <param name="patternCalendar"></param>
    /// <returns>PatternCalendar</returns>
    public async Task<PatternCalendar> AddPatternCalendar(PatternCalendar patternCalendar)
    {
      await coilTrackingContext.PatternCalendars.AddAsync(patternCalendar);
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.CreateEntity);
      return patternCalendar;
    }

    /// <summary>
    /// remove pattern calendar
    /// </summary>
    /// <param name="patternCalendar"></param>
    /// <returns>bool</returns>
    public async Task<bool> RemovePatternCalendar(PatternCalendar patternCalendar)
    {
      coilTrackingContext.PatternCalendars.Remove(patternCalendar);
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
      return true;
    }

    /// <summary>
    /// Check if pattern calendar exists
    /// </summary>
    /// <param name="lineId"></param>
    public async Task<bool> PatternCalenderExistsByLineId(int lineId)
    {
      return await coilTrackingContext.PatternCalendars.AnyAsync(x => x.Line.Id == lineId);
    }

    /// <summary>
    /// Remove pattern calendar for line
    /// </summary>
    /// <param name="lineId"></param>
    public async Task RemovePatternCalenderByLineId(int lineId)
    {
      var list = await coilTrackingContext.PatternCalendars.Where(x => x.Line.Id == lineId).ToListAsync();
      coilTrackingContext.PatternCalendars.RemoveRange(list);
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
    }

    public async Task<List<PatternCalendar>> GetPatternCalendarsByLineIdAndShiftIdAsync(int lineId, int shiftId, DateTime minDate, DateTime maxDate)
    {
      return await coilTrackingContext.PatternCalendars
        .Where(p => p.Line.Id == lineId && p.Shift.Id == shiftId && p.Date >= minDate && p.Date <= maxDate)
        .ToListAsync();
    }

    public async Task AddPatternCalenderAsync(PatternCalendar patternCalendar)
    {
      await coilTrackingContext.PatternCalendars.AddAsync(patternCalendar);
    }
  }
}
