using CoilTracking.Common;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess
{
  public class LineRepository : ILineRepository
  {
    private readonly CoilTrackingContext coilTrackingContext;
    private readonly IUserHelper usersHelper;
    public LineRepository(CoilTrackingContext coilTrackingContext, IUserHelper usersHelper)
    {
      this.coilTrackingContext = coilTrackingContext;
      this.usersHelper = usersHelper;
    }
    /// <summary>
    /// Get the list of Line details by lineId
    /// </summary>
    /// <param name="lineId"></param>
    /// <returns></returns>
    public Line GetLineByLineID(int lineId)
    {
      return coilTrackingContext.Lines.Where(l => l.Id == lineId).SingleOrDefault();
    }

    /// <summary>
    /// Get async the list of Line details by lineId
    /// </summary>
    /// <param name="lineId"></param>
    /// <returns></returns>
    public async Task<Line> GetLineByLineIDAsync(int lineId)
    {
      return await coilTrackingContext.Lines.AsNoTracking().Where(x=>x.Id == lineId).FirstOrDefaultAsync();
    }

    /// <summary>
    /// Get list of Lines
    /// </summary>
    /// <returns></returns>
    public IEnumerable<Line> GetLines()
    {
      return coilTrackingContext.Lines.Include(x=>x.Plant).Where(l => !l.Disabled).OrderBy(l => l.LineName);
    }
    public int GetCountOfLines()
    {
      return coilTrackingContext.Lines.Count();
    }

    /// <summary>
    /// Get Line with plant details
    /// </summary>
    /// <returns></returns>
    public async Task<Line> GetLineWithPlantDetails(int lineId)
    {
      var line = await coilTrackingContext.Lines
        .Include(l => l.Plant)
        .Include(l => l.Plant.TimeZone)
        .Where(l => l.Id == lineId)
        .FirstOrDefaultAsync();
      return line;
    }

    /// <summary>
    /// Get lines with time zones and opc server details
    /// </summary>
    /// <param name="id"></param>
    /// <returns>lines</returns>
    public async Task<Line> GetLineWithTimeZoneOpcServer(int id)
    {
      var lines = await coilTrackingContext.Lines
                                       .Include(l => l.Plant.TimeZone)
                                       .Include(l => l.OPCServer)
                                       .Where(l => l.Id == id).FirstOrDefaultAsync();
      return lines;
    }

    /// <summary>
    /// Get list of Lines
    /// </summary>
    /// <returns></returns>
    public async Task<List<Line>> GetLinesAsync()
    {
      var lines = await coilTrackingContext.Lines.AsNoTracking()
        .Include(l => l.OPCServer).AsNoTracking()
        .Include(l => l.Plant.TimeZone).AsNoTracking()
        .ToListAsync();

      return lines;
    }

    /// <summary>
    /// Get line by Id
    /// </summary>
    /// <returns></returns>
    public async Task<Line> GetLineByIdAsync(int id)
    {
      var line = await coilTrackingContext.Lines.Where(l => l.Id == id)
                      .Include(l => l.OPCServer)
                      .Include(l => l.Plant)
                      .Include(l => l.Plant.TimeZone)
                      .FirstOrDefaultAsync();

      return line;
    }

    /// <summary>
    /// Update line subscription
    /// </summary>
    /// <returns></returns>
    public async Task UpdateLineSubscription(Line line)
    {
      coilTrackingContext.Entry(line.OPCServer).State = EntityState.Unchanged;
      coilTrackingContext.Entry(line.Plant).State = EntityState.Unchanged;
      coilTrackingContext.Entry(line).State = EntityState.Modified;
      await SaveChanges(AuditActionType.ModifyEntity);
    }

    /// <summary>
    /// Save the changes to database
    /// </summary>
    /// <returns></returns>
    public async Task SaveChanges(AuditActionType actionType, string user = null)
    {
      if (user != null)
      {
        await coilTrackingContext.SaveChangesAsync(user, actionType);
      }
      else
      {
        await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), actionType);
      }
    }

    /// <summary>
    /// Get list of subscribed lines
    /// </summary>
    /// <returns></returns>
    public async Task<List<Line>> GetSubscribedLines(string namcCode)
    {
      //TODO
      //get line details by namc code
      var subscribedLines = await coilTrackingContext.Lines
        .Include(l => l.OPCServer)
        .Where(l => l.Subscribed)
        .ToListAsync();

      return subscribedLines;
    }

    /// <summary>
    /// Disable a line
    /// </summary>
    /// <returns></returns>
    public void DisableLine(Line line)
    {
      coilTrackingContext.Entry(line).State = EntityState.Modified;
    }

    /// <summary>
    /// Update a line
    /// </summary>
    /// <returns></returns>
    public async Task PutLine(Line line)
    {
      coilTrackingContext.Entry(line).State = EntityState.Modified;
      await SaveChanges(AuditActionType.ModifyEntity);
    }

    /// <summary>
    /// Add a line
    /// </summary>
    /// <returns></returns>
    public async Task<Line> AddLine(Line line)
    {
      await coilTrackingContext.Lines.AddAsync(line);
      await SaveChanges(AuditActionType.CreateEntity);
      return line;
    }

    /// <summary>
    /// Add Plant and OPCServer Data to line
    /// </summary>
    /// <returns></returns>
    public void AddPlantAndOPCServerData(Line line)
    {
      coilTrackingContext.Entry(line.Plant).State = EntityState.Unchanged;
      coilTrackingContext.Entry(line.OPCServer).State = EntityState.Unchanged;
    }

    /// <summary>
    /// Find a line by Id
    /// </summary>
    /// <returns></returns>
    public async Task<LineData> GetLineDataByLineId(LineData lineData)
    {
      var lineDatas = await coilTrackingContext.LineDatas.Where(ld => ld.LineId == lineData.LineId &&
                                        System.Data.Entity.DbFunctions.TruncateTime(ld.UpdateTime)
                                            == System.Data.Entity.DbFunctions.TruncateTime(lineData.UpdateTime))
                                        .OrderByDescending(ld => ld.UpdateTime).FirstAsync();
      return lineDatas;
    }

    /// <summary>
    /// Update a line
    /// </summary>
    /// <returns></returns>
    public void UpdateLineData(LineData lineData)
    {
      coilTrackingContext.Entry(lineData).State = EntityState.Modified;
    }

    /// <summary>
    /// Add line Data for a line
    /// </summary>
    /// <returns></returns>
    public async Task AddLineData(LineData lineData)
    {
      await coilTrackingContext.LineDatas.AddAsync(lineData);
    }

    /// <summary>
    /// Delete a line
    /// </summary>
    /// <returns></returns>
    public async Task DeleteLine(Line line)
    {
      coilTrackingContext.Lines.Remove(line);
      await SaveChanges(AuditActionType.ModifyEntity);
    }

    /// <summary>
    /// Check edit a line
    /// </summary>
    /// <returns></returns>
    public async Task<int> CheckEdit(int id)
    {
      return await coilTrackingContext.Lines
        .Where(x => x.Id == id)
        .Select(y => y.Id)
        .FirstOrDefaultAsync();
    }

    /// <summary>
    /// GetIncompleteRunOrderItem for a line
    /// </summary>
    /// <returns></returns>
    public async Task<List<IncompleteRunOrderItem>> GetIncompleteRunOrderItem(int id)
    {
      return await coilTrackingContext.IncompleteRunOrderItems
        .Where(x => x.RunOrderList.Line.Id == id && (x.Status == RunOrderItemStatus.New || x.Status == RunOrderItemStatus.RunStarted || x.Status == RunOrderItemStatus.Incomplete || x.Status == RunOrderItemStatus.CarriedOver))
        .ToListAsync();
    }

    /// <summary>
    /// get list of lines by opc config id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>list of lines</returns>
   public async Task<List<Line>> GetLinesByOPcConfigId(int id)
    {
      return await coilTrackingContext.Lines.Where(c => c.OPCServer.Id == id).ToListAsync();

    }

    public List<Line> GetIncompleteRunLinesByLineList(List<Line> lines)
    {
      var lineIds = lines.Select(c => c.Id).ToList();
      var linesinRunOrder =  coilTrackingContext.IncompleteRunOrderItems
        .Where(c => lineIds.Contains(c.Line.Id))
        .Where(x=>x.Status == RunOrderItemStatus.New ||
        x.Status == RunOrderItemStatus.RunStarted ||
        x.Status == RunOrderItemStatus.Incomplete).Select(cc=>cc.Line).Distinct().ToList();
      return linesinRunOrder;
    }


    public IEnumerable<Line> GetAllLines()
    {
      return coilTrackingContext.Lines;
    }

    public async  Task<LineData> GetLinesData(int lineId)
    {
      var lineData = await coilTrackingContext.LineDatas.Where(ld => ld.LineId == lineId).OrderByDescending(ld => ld.UpdateTime).FirstAsync();
      return lineData;
    }
  }
}
