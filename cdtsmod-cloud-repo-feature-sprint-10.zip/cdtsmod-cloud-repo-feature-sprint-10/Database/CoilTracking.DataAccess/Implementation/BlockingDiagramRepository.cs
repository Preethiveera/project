using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class BlockingDiagramRepository : IBlockingDiagramRepository
  {
    private readonly CoilTrackingContext coilTrackingContext;
    private readonly IUserHelper usersHelper;
    public BlockingDiagramRepository(CoilTrackingContext coilTrackingContext, IUserHelper usersHelper)
    {
      this.coilTrackingContext = coilTrackingContext;
      this.usersHelper = usersHelper;
    }

    /// <summary>
    /// Get blocking diagrams
    /// </summary>
    /// <returns>blockingDiagrams</returns>
    public async Task<List<BlockingDiagrams>> GetBlockingDiagrams()
    {
      return await coilTrackingContext.BlockingDiagrams.ToListAsync();
    }
    /// <summary>
    /// Get Blocking diagram by dataNum
    /// </summary>
    /// <param name="dataNum"></param>
    /// <returns></returns>
    public async Task<BlockingDiagrams> GetBlockingDiagramByDataNum(int dataNum)
    {
      return await coilTrackingContext.BlockingDiagrams.Where(b => b.DataNumber == dataNum).FirstOrDefaultAsync();

    }

    /// <summary>
    /// Save new Blocking diagram details to database
    /// </summary>
    /// <param name="blockingDiagram"></param>
    public async Task InsertBlockingDiagram(BlockingDiagrams blockingDiagram)
    {
      await coilTrackingContext.BlockingDiagrams.AddAsync(blockingDiagram);
      await coilTrackingContext.SaveChangesAsync();
    }

    /// <summary>
    /// Get blocking diagrams by Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>blockingDiagram</returns>
    public async Task<BlockingDiagrams> GetBlockingDiagramById(int id)
    {
      return await coilTrackingContext.BlockingDiagrams.Where(i => i.Id == id).AsNoTracking().FirstOrDefaultAsync();
    }
    /// <summary>
    /// Delete blocking diagram by Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task DeleteBlockingDiagram(int id)
    {
      var blockingDiagram = await coilTrackingContext.BlockingDiagrams.FindAsync(id);
      coilTrackingContext.BlockingDiagrams.Remove(blockingDiagram);
      await coilTrackingContext.SaveChangesAsync();
    }

    /// <summary>
    /// To update blocking diagram details
    /// </summary>
    /// <param name="blockingDiagram"></param>
    /// <returns></returns>
    public async Task UpdateBlockingDiagram(BlockingDiagrams blockingDiagram)
    {
      var diagram = await coilTrackingContext.BlockingDiagrams.FindAsync(blockingDiagram.Id);
      diagram.DataNumber = blockingDiagram.DataNumber;
      diagram.ImagePath = blockingDiagram.ImagePath;
      coilTrackingContext.Entry(diagram).State = EntityState.Modified;
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.ModifyEntity);

    }

    /// <summary>
    /// Insert list of blocking diagrams
    /// </summary>
    /// <param name="blockingDiagram"></param>
    /// <returns></returns>
    public async Task InsertBlockingDiagramList(List<BlockingDiagrams> blockingDiagram)
    {
      await coilTrackingContext.BlockingDiagrams.AddRangeAsync(blockingDiagram);
      await coilTrackingContext.SaveChangesAsync();
    }

  }
}
