using CoilTracking.Common;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class BlankInfoesRepository : IBlankInfoesRepository
  {
    private readonly CoilTrackingContext coilTrackingContext;
    private readonly IUserHelper usersHelper;
    public BlankInfoesRepository(CoilTrackingContext coilTrackingContext, IUserHelper usersHelper)
    {
      this.coilTrackingContext = coilTrackingContext;
      this.usersHelper = usersHelper;
    }
    /// <summary>
    /// Get dieno based on CoilFieldLocation
    /// </summary>
    /// <param name="CoilTypeId"></param>
    /// <returns></returns>
    public List<int> GetdieNo(List<CoilFieldLocation> coilFieldLocation)
    {
      var CoilFieldLocations = coilFieldLocation.Select(k => k.Id).ToList();
      var dieNo = coilTrackingContext.BlankInfoes.Where(m => CoilFieldLocations.Contains(m.Id)).Select(d => d.DieNo).ToList();
      return dieNo;


    }

   
    /// <summary>
    /// Get dieno based on coil
    /// </summary>
    /// <param name="CoilTypeId"></param>
    /// <returns></returns>
    public List<BlankInfo> GetdieNos(List<Coil> coil)
    {
      var coils = coil.Select(k => k.CoilType.Id).ToList();
      var dieNo = coilTrackingContext.BlankInfoes.Where(m => coils.Contains(m.CoilType.Id)).ToList();
      return dieNo;
    }
    /// <summary>
    /// Get CurrentStack Size Based on Data Number
    /// </summary>
    /// <param name="dataNum"></param>
    /// <returns></returns>
    public BlankInfo GetCurrentStackSize(int dataNum)
    {
      var blankInfo = coilTrackingContext.BlankInfoes
          .Include(b => b.CoilType)
          .Include(b => b.Part)
          .Where(b => b.DataNumber == dataNum)
          .FirstOrDefault();

      return blankInfo;
    }
    /// <summary>
    /// Get the Count of blankinfoes
    /// </summary>
    /// <returns></returns>
    public int GetCountOfBlankInfoes()
    {
      return coilTrackingContext.BlankInfoes.Count();
    }

    /// <summary>
    /// Get List of BlankInfoes
    /// </summary>
    /// <returns></returns>
    public IQueryable<BlankInfo> GetAllBlankInfo()
    {
      return coilTrackingContext.BlankInfoes.
       Include(d => d.Line).
       Include(d => d.Line.Plant).
       Include(d => d.Line.Plant.TimeZone).
       Include(d => d.Line.OPCServer).
       Include(d => d.Part)
      .Include(d => d.CoilType);
    }

    /// <summary>
    /// Get BlankInfo By Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public BlankInfo GetBlankInfoById(int id)
    {
      return coilTrackingContext.BlankInfoes.AsNoTracking().
                              Include(d => d.Line).
                              Include(d => d.Line.Plant).
                              Include(d => d.Line.Plant.TimeZone).
                              Include(d => d.Line.OPCServer).
                              Include(d => d.Part).
                              Include(d => d.CoilType).
                              Where(d => d.Id == id).
                              FirstOrDefault();
    }

    /// <summary>
    /// Get blank info by DataNum and lineId
    /// </summary>
    /// <param name="dataNum"></param>
    /// <param name="lineId"></param>
    /// <returns></returns>
    public BlankInfo GetBlankInforByDataNumAndLineId(int dataNum, int lineId)
    {
      return coilTrackingContext.BlankInfoes
          .Include(b => b.CoilType)
          .Include(b => b.Part)
          .Where(b => b.DataNumber == dataNum && b.Line.Id == lineId)
          .FirstOrDefault();


    }

    /// <summary>
    /// Get Blanks info and include Plant, CoilType,Line, TimeZone
    /// </summary>
    /// <param name="dataNum"></param>
    /// <param name="lineId"></param>
    /// <returns>blankInfo</returns>
    public List<BlankInfo> GetListWithPlantsAndTimeZones(List<int> dataNum, int lineId)
    {
      coilTrackingContext.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
      return coilTrackingContext.BlankInfoes
            .Include(b => b.Line)
            .Include(b => b.Line.Plant)
            .Include(b => b.Line.Plant.TimeZone)
            .Include(b => b.Line.OPCServer)
            .Include(b => b.Part)
            .Include(b => b.CoilType)
            .Include(b => b.CoilType.CoilTypeYNAs)
            .AsNoTracking()
            .Where(b => dataNum.Contains(b.DataNumber) && b.Line.Id == lineId)
            .ToList();
    }

    /// <summary>
    /// Get dependent element for blank info
    /// </summary>
    /// <param name="id"></param>
    /// <returns>bool</returns>
    public List<IncompleteRunOrderItem> GetDependencyForBlankInfo(int id)
    {

      var dependentItems = (coilTrackingContext.IncompleteRunOrderItems
         .Where(i => i.Status != RunOrderItemStatus.Completed
         || i.Status != RunOrderItemStatus.Removed))
         .Where(i => i.RunOrderItem.BlankInfo.Id == id).ToList();

      return dependentItems;
    }

    /// <summary>
    /// Add new blank info
    /// </summary>
    /// <param name="blankInfo"></param>
    public void AddNewBlankInfo(BlankInfo blankInfo)
    {
      coilTrackingContext.Entry(blankInfo.CoilType).State = EntityState.Unchanged;
      coilTrackingContext.Entry(blankInfo.Line).State = EntityState.Unchanged;
      coilTrackingContext.Entry(blankInfo.Part).State = EntityState.Unchanged;

      coilTrackingContext.BlankInfoes.Add(blankInfo);
      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.CreateEntity);
    }


    /// <summary>
    /// Update blank info
    /// </summary>
    /// <param name="blankInfo"></param>
    public void UpdateBlankInfo(BlankInfo blankInfo)
    {
      
      coilTrackingContext.Entry(blankInfo).State = EntityState.Modified;

      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyEntity);

    }

    /// <summary>
    /// Disable BlankInfo
    /// </summary>
    /// <param name="id"></param>
    /// <param name="disable"></param>
    public void DisableBlankInfo(int id, bool disable)
    {

      var blank = coilTrackingContext.BlankInfoes
         .Include(b => b.CoilType)
         .Include(b => b.Part)
         .Include(b => b.Line)
         .Where(b => b.Id == id)
         .FirstOrDefault();


      blank.Disabled = disable;
      coilTrackingContext.Entry(blank).State = EntityState.Modified;
      coilTrackingContext.Entry(blank.Line).State = EntityState.Unchanged;
      coilTrackingContext.Entry(blank.Part).State = EntityState.Unchanged;
      coilTrackingContext.Entry(blank.CoilType).State = EntityState.Unchanged;

      coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.EnableDisable);

    }

    /// <summary>
    /// Delete blankInfo
    /// </summary>
    /// <param name="id"></param>
    public void DeleteBlankInfo(int id)
    {
      BlankInfo blankInfo = coilTrackingContext.BlankInfoes.Find(id);
      List<RunOrderListQuantity> runQuantity = coilTrackingContext.RunOrderListQuantities.Select(c => c).Where(c => c.BlankInfo.Id == id).ToList();
      List<IncompleteRunOrderItem> incompleteRunOrderList = new List<IncompleteRunOrderItem>();
      if (runQuantity.Count != 0)
      {
        foreach (var k in runQuantity)
        {
          incompleteRunOrderList = coilTrackingContext.IncompleteRunOrderItems.Select(x => x).Where(x => x.RunOrderItem.Id == k.Id).ToList();
        }
      }

      if (incompleteRunOrderList.Count != 0)
      {
        coilTrackingContext.IncompleteRunOrderItems.RemoveRange(incompleteRunOrderList);
        coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
      }
      if (runQuantity.Count != 0)
      {
        coilTrackingContext.RunOrderListQuantities.RemoveRange(runQuantity);
        coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
      }



      coilTrackingContext.BlankInfoes.Remove(blankInfo);
      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
    }

    /// <summary>
    /// Get  BlankInfo By Datanum
    /// </summary>
    /// <param name="dataNum"></param>
    /// <returns></returns>
    public List<BlankInfo> GetBlankInfoByDataNumber(int dataNum)
    {
      return coilTrackingContext.BlankInfoes.Where(c => c.DataNumber == dataNum).ToList();
    }

    /// <summary>
    /// Remove BlankInfor for importing to excel
    /// </summary>
    /// <param name="blank"></param>
    public void RemoveBlankInfo(BlankInfo blank)
    {
      coilTrackingContext.Remove(blank);
    }

    /// <summary>
    /// Get  BlankInfo By Datanum
    /// </summary>
    /// <param name="dataNum"></param>
    /// <returns></returns>
    public List<BlankInfo> GetBlankInfoByPartnumberLineIds(string partNumber, int lineId)
    {
      return coilTrackingContext.BlankInfoes.Include(b => b.CoilType)
                                  .Where(b => b.Part.PartNumber == partNumber && b.Line.Id == lineId)
                                  .ToList();

    }
    /// <summary>
    /// Get  BlankInfo By Datanum list and lineId
    /// </summary>
    /// <param name="dataNum"></param>
    /// <returns></returns>
    public List<BlankInfo> GetListByPartnumberLineIds(List<string> partNumber, int lineId)
    {
      return coilTrackingContext.BlankInfoes.Include(b => b.CoilType).Include(c=>c.Part).Include(c=>c.Line)
                                  .Where(b => partNumber.Contains(b.Part.PartNumber) && b.Line.Id == lineId)
                                  .ToList();

    }


    /// <summary>
    /// Get list of blanks by dataNum and LineId
    /// </summary>
    /// <param name="dataNum"></param>
    /// <param name="lineId"></param>
    /// <returns></returns>

    public List<BlankInfo> GetBlankInfoByListOfDataNumAndLineId(List<int> dataNum, int lineId)
    {
      var blank = coilTrackingContext.BlankInfoes.Include(b => b.CoilType).Include(c=>c.Line).Where(x => dataNum.Contains(x.DataNumber) && lineId == x.Line.Id).ToList();
      return blank;
    }

    /// <summary>
    /// Get blank infoes by part no and lineId which includes plant, lines, Zones,OPCServers
    /// </summary>
    /// <param name="partNum"></param>
    /// <param name="lineId"></param>
    /// <returns>blankInfoes</returns>
    public async Task<IQueryable<BlankInfo>> GetListWithPlantTimeZonePart(List<string> partNum, int lineId)
    {
      var blanks = await coilTrackingContext.BlankInfoes
                                    .Include(b => b.Line)
                                    .Include(b => b.Line.Plant)
                                    .Include(b => b.Line.Plant.TimeZone)
                                    .Include(b => b.Line.OPCServer)
                                    .Include(b => b.Part)
                                    .Include(b => b.CoilType)
                                    .ThenInclude(b => b.CoilTypeYNAs)
                                    .AsNoTracking()
                                    .Where(b => partNum.Contains(b.Part.PartNumber) && b.Line.Id == lineId).ToListAsync();
      return blanks.AsQueryable();
    }

    /// <summary>
    /// Get blanks by list of dataIds
    /// </summary>
    /// <param name="dataIdList"></param>
    /// <returns></returns>
    public List<BlankInfo> GetBlanksByDataIdList(List<int> dataIdList)
    {
      return coilTrackingContext.BlankInfoes.Where(x => dataIdList.Contains(x.Id)).ToList();
    }

    /// <summary>
    /// Get BlankInfo By LineId And PartNumber
    /// </summary>
    /// <param name="partNumber"></param>
    /// <param name="lineId"></param>
    /// <returns></returns>
    public async Task<List<BlankInfo>> GetBlankInfoByLineIdAndPartNumber(int lineId, List<string> partNumbers)
    {
      return await coilTrackingContext.BlankInfoes
        .Include(x => x.Part)
        .Where(x => x.Line_Id == lineId && partNumbers.Contains(x.Part.PartNumber))
        .ToListAsync();
    }
    /// <summary>
    /// Get BlankInfo By PartId
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<List<BlankInfo>> GetBlankInfoByPartId(int id)
    {
      return await coilTrackingContext.BlankInfoes.Include(x=>x.CoilType).Include(x=>x.Part).Include(y=>y.Line).Select(d => d).Where(d => d.Part.Id == id).Distinct().ToListAsync();
    }

    /// <summary>
    /// Get BlankInfo By Data Number and Line Id
    /// </summary>
    /// <returns></returns>
    public async Task<List<BlankInfo>> GetBlankInfoByDataNumbers(List<int> dataNumber)
    {
      var blankInfo = await coilTrackingContext.BlankInfoes
        .Where(b => dataNumber.Contains(b.DataNumber))
        .ToListAsync();
      return blankInfo;
    }
  }
}
