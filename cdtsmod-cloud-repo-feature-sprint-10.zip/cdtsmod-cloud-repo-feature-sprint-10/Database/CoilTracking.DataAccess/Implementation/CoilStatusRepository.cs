using CoilTracking.Common;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class CoilStatusRepository : ICoilStatusRepository
  {
    private readonly CoilTrackingContext coilTrackingContext;
    private readonly IUserHelper usersHelper;
    public CoilStatusRepository(CoilTrackingContext coilTrackingContext, IUserHelper usersHelper)
    {
      this.coilTrackingContext = coilTrackingContext;
      this.usersHelper = usersHelper;
    }

    public async Task<List<CoilStatus>> GetCoilStatusByName(string name)
    {
      var statuses = await coilTrackingContext.CoilStatus.Where(cs => cs.Name == name).ToListAsync();
      return statuses;
    }

    public CoilStatus GetCoilStatusName(string name)
    {
      var statuses = coilTrackingContext.CoilStatus.Where(cs => cs.Name == name).FirstOrDefault();
      return statuses;
    }

    /// <summary>
    /// Get list of coil status
    /// </summary>
    /// <returns>coil status</returns>
    public async Task<List<CoilStatus>> GetCoilStatuses()
    {
      return await coilTrackingContext.CoilStatus.ToListAsync();
    }

    /// <summary>
    /// Get coil status by Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>CoilStatus</returns>
    public async Task<CoilStatus> GetCoilStatusByIdAsync(int id)
    {
      return await coilTrackingContext.CoilStatus.FindAsync(id);

    }
    public CoilStatus GetCoilStatusById(int id)
    {
      return coilTrackingContext.CoilStatus.Where(i => i.Id == id).AsNoTracking().FirstOrDefault();

    }
    /// <summary>
    /// Save new CoilStatus
    /// </summary>
    /// <param name="coilStatus"></param>
    public void InsertCoilStatus(CoilStatus coilStatus)
    {
      coilTrackingContext.CoilStatus.Add(coilStatus);
      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.CreateEntity);

    }
    /// <summary>
    /// Update  CoilStatus
    /// </summary>
    /// <param name="coilStatus"></param>
    public void UpdateCoilStatus(CoilStatus coilStatus)
    {
      coilTrackingContext.Entry(coilStatus).State = EntityState.Modified;
      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
    }

    /// <summary>
    /// Delete coilstatus by Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>Coil Status</returns>
    public CoilStatus DeleteCoilStatus(int id)
    {
      CoilStatus coilStatus = coilTrackingContext.CoilStatus.Find(id);
      coilTrackingContext.CoilStatus.Remove(coilStatus);
      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
      return coilStatus;
    }
  }
}
