using CoilTracking.Common;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class CoilFieldZoneRepository : ICoilFieldZoneRepository
  {
    private readonly CoilTrackingContext coilTrackingContext;
    private readonly IUserHelper usersHelper;
    public CoilFieldZoneRepository(CoilTrackingContext coilTrackingContext, IUserHelper usersHelper)
    {
      this.coilTrackingContext = coilTrackingContext;
      this.usersHelper = usersHelper;
    }

    /// <summary>
    /// Get coil field zone by coilField Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>coilfieldzone</returns>
    public List<CoilFieldZone> GetCoilFieldsZoneByCoilFieldId(int id)
    {
      var coilFieldZones = coilTrackingContext.CoilFieldZones.Where(x => x.CoilField.Id == id).ToList();

      return coilFieldZones;
    }

    /// <summary>
    /// Get the list of DB zones
    /// </summary>
    /// <param name="zoneId"></param>
    /// <returns></returns>
    public List<CoilFieldZone> GetCoilFieldZones(int? zoneId)
    {
      return coilTrackingContext.CoilFieldZones.Include(z => z.Locations).Include(z => z.CoilField).ThenInclude(x=>x.Zones).Where(z => (zoneId.HasValue && z.Id == zoneId.Value) || !zoneId.HasValue && !z.Disabled).ToList();
    }

    /// <summary>
    ///   Get the list of coil field zones.
    /// </summary>
    /// <returns>returns list of CoilFieldZone.></returns>
    public async Task<List<CoilFieldZone>> GetCoilFieldZones()
    {
      return await coilTrackingContext.CoilFieldZones.AsNoTracking().Include(z => z.CoilField).ToListAsync();
    }


    public int GetCountOfCoilFieldZones()
    {
      return coilTrackingContext.CoilFieldZones.Count();
    }


    /// <summary>
    /// Get CoilType CoilFieldZone Based on Id
    /// </summary>
    /// <param name="coilType"></param>
    /// <returns></returns>
    public async Task<CoilFieldZone> GetCoilFieldZoneById(int id)
    {
      var coilFieldZone = await coilTrackingContext.CoilFieldZones.Include(x => x.CoilField).Include(x => x.Locations).FirstOrDefaultAsync(x => x.Id == id);
      return coilFieldZone;
    }
    public List<CoilFieldZone> GetCoilFieldZoneByIds(List<int> id)
    {
      var zones = coilTrackingContext.CoilFieldZones.Where(c => id.Contains(c.Id)).ToList();
      return zones;
    }

    /// <summary>
    /// Get CoilFieldZone By Name
    /// </summary>
    /// <param name="zone"></param>
    /// <returns></returns>
    public CoilFieldZone GetCoilFieldZoneByName(string zone)
    {
      return coilTrackingContext.CoilFieldZones.Where(z => z.Name == zone).FirstOrDefault();
    }

    public CoilFieldZone GetCoilTypeCoilFieldZoneById(CoilTypeDto coilType)
    {
      return coilTrackingContext.CoilFieldZones.Where(cfz => cfz.Id == coilType.CoilFieldZoneId).FirstOrDefault();
    }

    /// <summary>
    /// Update the coil field zone.
    /// </summary>
    /// <param name="coilFieldZone"></param>
    /// <returns>bool</returns>
    public async Task<bool> UpdateCoilFieldZone(CoilFieldZone coilFieldZone)
    {
      if (coilFieldZone == null)
      {
        return false;
      }
      coilTrackingContext.Entry(coilFieldZone).State = EntityState.Modified;
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
      return true;
    }

    /// <summary>
    /// Disable the coil field zone.
    /// </summary>
    /// <param name="zoneId"></param>
    /// <param name="disable"></param>
    /// <returns>bool</returns>
    public async Task<bool> DisableCoilFieldZone(int zoneId, bool disable)
    {
      var coilFieldZone = await coilTrackingContext.CoilFieldZones.FindAsync(zoneId);
      coilFieldZone.Disabled = disable;
      coilTrackingContext.Entry(coilFieldZone).State = EntityState.Modified;
      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
      return true;
    }

    /// <summary>
    /// Add the coil filed zone.
    /// </summary>
    /// <param name="coilFieldZone"></param>
    /// <returns>CoilFieldZone</returns>
    public async Task<CoilFieldZone> AddCoilFieldZone(CoilFieldZone coilFieldZone)
    {
      await coilTrackingContext.CoilFieldZones.AddAsync(coilFieldZone);
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.CreateEntity);
      return coilFieldZone;
    }

    /// <summary>
    /// Delete hte coil field zone
    /// </summary>
    /// <param name="zoneId"></param>
    /// <returns>bool</returns>
    public async Task<bool> DeleteCoilFieldZone(int zoneId)
    {
      var coilFieldZone = await coilTrackingContext.CoilFieldZones.FindAsync(zoneId);
      coilTrackingContext.CoilFieldZones.Remove(coilFieldZone);
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
      return true;
    }

    /// <summary>
    ///  Get the list of coil field zone with location details.
    /// </summary>
    /// <returns>returns CoilFieldZone.></returns>
    public async Task<CoilFieldZone> GetCoilFieldZoneByNameWithLocation(string zoneName)
    {
      var zone = await coilTrackingContext.CoilFieldZones
        .Where(z => z.Name == zoneName)
        .Include(z => z.Locations).FirstOrDefaultAsync();

      return zone;
    }

    /// <summary>
    /// SaveChangesAsync.
    /// </summary>
    /// <param name="auditAction"></param>
    /// <returns></returns>
    public async Task SaveChangesAsync(AuditActionType auditAction)
    {
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), auditAction);
    }
  }
}
