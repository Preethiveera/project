using CoilTracking.Common;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class OPCConfigRepository : IOPCConfigRepository
  {
    private readonly CoilTrackingContext coilTrackingContext;
    private readonly IUserHelper usersHelper;
    public OPCConfigRepository(CoilTrackingContext coilTrackingContext, IUserHelper usersHelper)
    {
      this.coilTrackingContext = coilTrackingContext;
      this.usersHelper = usersHelper;
    }

    public int GetCountOfOPCConfigs()
    {
      return coilTrackingContext.OPCConfigs.Count();
    }
    /// <summary>
    /// get opcconfig by Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<OPCConfig> GetOPCConfigById(int id)
    {
      var oPCConfig = await coilTrackingContext.OPCConfigs.FindAsync(id);
      return oPCConfig;
    }

    /// <summary>
    /// Get list of opc configs
    /// </summary>
    /// <returns></returns>
    public async Task<List<OPCConfig>> GetOPCConfigsAsync()
    {
      return await coilTrackingContext.OPCConfigs
        .ToListAsync();
    }

    /// <summary>
    /// Get opcconfig by id to check if opcconfig exists
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public  OPCConfig OPCConfigExistsbyId(int id)
    {
      return  coilTrackingContext.OPCConfigs.Where(i => i.Id == id).AsNoTracking().FirstOrDefault();
    }

    /// <summary>
    /// To update an existing opcconfig
    /// </summary>
    /// <param name="oPCConfig"></param>
    /// <returns></returns>
    public void  UpdateOPCConfig(OPCConfig oPCConfig)
    {
        coilTrackingContext.Entry(oPCConfig).State = EntityState.Modified;
        coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
     
    }
    /// <summary>
    /// To disable an opcconfig
    /// </summary>
    /// <param name="id"></param>
    /// <param name="disable"></param>
    /// <returns></returns>
    public async Task DisableOPCConfig(int id, bool disable)
    {
      OPCConfig config = coilTrackingContext.OPCConfigs.Find(id);
      config.Disabled = disable;
      coilTrackingContext.Entry(config).State = EntityState.Modified;
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.EnableDisable);
     

    }

    /// <summary>
    /// Add new opcconfig
    /// </summary>
    /// <param name="oPCConfig"></param>
    /// <returns></returns>
    public async Task<OPCConfig> InsertOPCConfig(OPCConfig oPCConfig)
    {
      await coilTrackingContext.OPCConfigs.AddAsync(oPCConfig);
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.CreateEntity);
      return oPCConfig;
    }
    /// <summary>
    /// To delete opcconfig by id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<OPCConfig> DeleteOPCConfig(int id)
    {
      OPCConfig oPCConfig = await coilTrackingContext.OPCConfigs.FindAsync(id);
        if (oPCConfig != null)
        {
          coilTrackingContext.OPCConfigs.Remove(oPCConfig);
           coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
        }
      return oPCConfig;
    }
  }
}
