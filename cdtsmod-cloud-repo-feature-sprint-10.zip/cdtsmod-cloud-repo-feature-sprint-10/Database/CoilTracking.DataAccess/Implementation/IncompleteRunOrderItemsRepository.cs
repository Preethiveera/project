using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class IncompleteRunOrderItemsRepository : IIncompleteRunOrderItemsRepository
  {
    private readonly CoilTrackingContext coilTrackingContext;

    public IncompleteRunOrderItemsRepository(CoilTrackingContext coilTrackingContext)
    {
      this.coilTrackingContext = coilTrackingContext;
    }

    /// <summary>
    /// Get Incomplete run order items by status
    /// </summary>
    /// <returns></returns>
    public async Task<List<IncompleteRunOrderItem>> GetIncompleteRunOrderItemsByStatus(RunOrderItemStatus status)
    {
      var incompleteItems = await coilTrackingContext.IncompleteRunOrderItems
               .Include("RunOrderList")
               .Include("RunOrderList.Line")
               .Include("RunOrderList.Quantities")
               .Include("RunOrderList.Quantities.Part")
               .Include("Part")
               .Where(i => i.Status == status)
               .ToListAsync();

      return incompleteItems;
    }

    /// <summary>
    /// Get Incomplete run order items by Id
    /// </summary>
    /// <returns></returns>
    public async Task<List<IncompleteRunOrderItem>> GetIncompleteRunOrderItemsById(int id)
    {
      var incompleteItems = await coilTrackingContext.IncompleteRunOrderItems
                       .Include("RunOrderList")
                       .Include("RunOrderList.Line")
                       .Include("RunOrderList.Quantities")
                       .Include("RunOrderList.Quantities.Part")
                       .Include("Part")
                       .Where(i => i.RunOrderItem.Id == id)
                       .ToListAsync();

      return incompleteItems;
    }

    /// <summary>
    /// Get Complete run order items by id and status
    /// </summary>
    /// <returns></returns>
    public async Task<List<IncompleteRunOrderItem>> GetCompletedRunOrderItemsByIdAndStatus(List<int> lastRuns, RunOrderItemStatus status)
    {
      var completedItems = await coilTrackingContext.IncompleteRunOrderItems.Include("RunOrderList")
          .Include("RunOrderList.Line")
          .Include("RunOrderList.Quantities")
          .Include("RunOrderList.Quantities.Part")
          .Include("Part")
          .Where(i => lastRuns.Contains(i.RunOrderList.Id) && i.Status == status)
          .ToListAsync();

      return completedItems;
    }

    /// <summary>
    /// Get FTZ Async
    /// </summary>
    /// <returns></returns>
    public async Task<List<string>> GetFTZAsync(int id)
    {
      var ftz = await coilTrackingContext.PalletTags
        .Where(x => x.RunOrderItemId == id && x.FTZ != null)
        .Select(r => r.FTZ)
        .Distinct()
        .ToListAsync();

      return ftz;
    }

    /// <summary>
    /// Get printer config async
    /// </summary>
    /// <returns></returns>
    public async Task<PrinterConfig> GetPrinterConfigAsync(string lineName)
    {
      return await coilTrackingContext.PrinterConfigs
        .FirstOrDefaultAsync(x => x.Line.Equals(lineName));
    }

    /// <summary>
    /// Get Printer config dto
    /// </summary>
    /// <returns></returns>
    public IQueryable<PrinterConfigDto> GetPrinterConfigDto(string strNAMC, string PrinterName)
    {
      var configs = from print in coilTrackingContext.PrinterConfigs
      where (print.NAMCCode == strNAMC) && (print.PrinterName == PrinterName)
      select new PrinterConfigDto
      {
        NAMCCode = print.NAMCCode,
        IPAddress = print.IPAddress,
        PortNumber = print.PortNumber,
        PrinterName = print.PrinterName
      };

      return configs;
    }

    /// <summary>
    /// Check if tags are printed from auto print
    /// </summary>
    /// <returns></returns>
    public async Task<bool> IsTagsPrintedfromAutoPrint(int runOrderItemId)
    {
      return await coilTrackingContext.PalletTags
        .Where(p => p.RunOrderItemId == runOrderItemId)
        .AnyAsync();
    }

    /// <summary>
    /// Get Maximum blank palet
    /// </summary>
    /// <returns></returns>
    public PalletTag GetMaxBkankPalet()
    {
      return coilTrackingContext.PalletTags
        .AsEnumerable()
        .LastOrDefault();
    }

    /// <summary>
    /// Get serial number
    /// </summary>
    /// <returns></returns>
    public string GetSerialNumbers(string namcCode, string line, string customerPartNumber)
    {
      var palletList = (from fg in coilTrackingContext.PalletTags //need to create column for seq number in db
                        where fg.NAMCCode == namcCode && fg.LineName == line && fg.PartNumber == customerPartNumber && fg.SerialNumber != null
                        orderby fg.TagID descending
                        select fg.SerialNumber).FirstOrDefault();
      return palletList;
    }

    /// <summary>
    /// Add palet to database
    /// </summary>
    /// <returns></returns>
    public async Task AddPallet(PalletTag pallettag)
    {
      coilTrackingContext.PalletTags.Add(pallettag);
      await coilTrackingContext.SaveChangesAsync();
    }

    public async Task<bool> IncompleteRunOrderItemsExists(int id)
    {
      return await coilTrackingContext.IncompleteRunOrderItems
        .AnyAsync(c => c.RunOrderList.Id == id);
    }
  }
}
