using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class PlantsRepository : IPlantsRepository
  {
    public readonly CoilTrackingContext coilTrackingContext;

    public PlantsRepository(CoilTrackingContext coilTrackingContext)
    {
      this.coilTrackingContext = coilTrackingContext;
    }
    /// <summary>
    /// Get Plant
    /// </summary>
    /// <returns></returns>
    public Plant GetPlant()
    {
      return coilTrackingContext.Plants.FirstOrDefault();
    }

    /// <summary>
    /// Get plants NAMC 
    /// </summary>
    /// <returns></returns>
    public string GetPlantName()
    {
      string NAMC = coilTrackingContext.Plants.Select(p => p.PlantName).FirstOrDefault();
      return NAMC;

    }
    /// <summary>
    /// Get Plant NAMCCode
    /// </summary>
    /// <returns></returns>
    public async Task<string> GetPlantNAMCCode()
    {
      string NAMCCode = await coilTrackingContext.Plants.Select(p => p.NAMCCode).FirstOrDefaultAsync();
      return NAMCCode;

    }
    /// <summary>
    /// Get Plant By NAMCCode
    /// </summary>
    /// <param name="NAMCCode"></param>
    /// <returns></returns>
    public async Task<Plant> GetPlantByNAMCCode(string NAMCCode)
    {
      var plant = await coilTrackingContext.Plants.Where(p => p.NAMCCode == NAMCCode).FirstOrDefaultAsync();
      return plant;

    }

    /// <summary>
    /// Get plants NAMC 
    /// </summary>
    /// <returns></returns>
    public string GetPlantName(string plantname)
    {
      var NAMC = coilTrackingContext.Plants.Where(p => p.PlantName == plantname).Select(x=>x.NAMCCode).FirstOrDefault();
      return NAMC;

    }

    public async Task<Plant> GetPlantByPlantName(string plantname)
    {
      var plant = await coilTrackingContext.Plants.Where(p => p.PlantName.Equals(plantname)).Include(c => c.TimeZone).FirstOrDefaultAsync();
      return plant;
    }
  }
}
