using CoilTracking.Common;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class PartRepository : IPartRepository
  {
    private readonly CoilTrackingContext coilTrackingContext;
    private readonly IUserHelper usersHelper;   
    public PartRepository(CoilTrackingContext coilTrackingContext, IUserHelper usersHelper)
    {
      this.coilTrackingContext = coilTrackingContext;
      this.usersHelper = usersHelper;
    }
    /// <summary>
    /// Get modelList based on partnumber
    /// </summary>
    /// <param name="partNumber"></param>
    /// <returns></returns>
    public string GetModelList(string partNumber)
    {
      List<string> partModels = coilTrackingContext.PartModels.Where(p => p.Part.PartNumber == partNumber).Select(p => p.Model.ModelNumber).OrderBy(modelNum => modelNum).ToList();
      string modelList = string.Join("/", partModels);
      return modelList;
    }

    /// <summary>
    /// Get Part Models By PartNumbers
    /// </summary>
    /// <returns></returns>
    public List<PartModel> GetPartModelsByPartNumberList(List<string> partnumberList)
    {
      List<PartModel> partmodels = coilTrackingContext.PartModels.Include(x => x.Part).Include(y => y.Model).Where(y => partnumberList.Contains(y.Part.PartNumber)).ToList();

      return partmodels;
    }
    public int GetCountOfparts()
    {
      return coilTrackingContext.Parts.Count();
    }

    public Part GetPartById(int id)
    {
      return coilTrackingContext.Parts.Find(id);
    }

    /// <summary>
    /// Get part by name
    /// </summary>
    /// <param name="name"></param>
    /// <returns></returns>
    public Part GetPartByName(string name)
    {
      return coilTrackingContext.Parts.AsNoTracking().Where(x => x.PartNumber == name).FirstOrDefault();
    }


    /// <summary>
    /// Get part by name
    /// </summary>
    /// <param name="name"></param>
    /// <returns></returns>
    public async Task<Part> GetPartByNameAync(string name)
    {
      var part = await coilTrackingContext.Parts.AsNoTracking().Where(x => x.PartNumber == name).FirstOrDefaultAsync();
      return part;
    }

    /// <summary>
    /// Get List of Parts by list of partNumbers
    /// </summary>
    /// <returns></returns>
    public List<Part> GetPartsListByPartNumberList(List<string> partNumbers)
    {
      return coilTrackingContext.Parts.Where(c => partNumbers.Contains(c.PartNumber)).ToList();
    }
    /// <summary>
    /// GetPartsAsync
    /// </summary>
    /// <returns></returns>
    public async Task<List<Part>> GetPartsAsync()
    {
      return await coilTrackingContext.Parts.AsNoTracking().ToListAsync();
    }
    /// <summary>
    /// GetPartByIdAsync
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<Part> GetPartByIdAsync(int id)
    {
      var part = await coilTrackingContext.Parts.AsNoTracking().Where(x => x.Id == id).FirstOrDefaultAsync();
      return part;
    }
    /// <summary>
    /// UpdatePartSaveChanges
    /// </summary>
    /// <param name="part"></param>
    /// <returns></returns>
    public async Task<int> UpdatePartSaveChanges(Part part)
    {
        coilTrackingContext.Entry(part).State = EntityState.Modified;
        var result = await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
        return result;
    
    }
    /// <summary>
    /// DisablePartSaveChanges
    /// </summary>
    /// <param name="part"></param>
    /// <returns></returns>
    public async Task<int> DisablePartSaveChanges(Part part)
    {
      coilTrackingContext.Entry(part).State = EntityState.Modified;
      var result = await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.EnableDisable);
      return result;
    }

    /// <summary>
    /// InsertParts
    /// </summary>
    /// <param name="part"></param>
    /// <returns></returns>
    public async Task<int> InsertParts(Part part)
    {
        coilTrackingContext.Parts.Add(part);
        var result = await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.CreateEntity);
        return result;
    }


    /// <summary>
    /// InsertParts
    /// </summary>
    /// <param name="part"></param>
    /// <returns></returns>
    public async Task<Part> InsertPart(Part part)
    {
      coilTrackingContext.Parts.Add(part);
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.CreateEntity);
      return part;
    }

    /// <summary>
    /// DeletePart
    /// </summary>
    /// <param name="part"></param>
    /// <returns></returns>
    public async Task<int> DeletePart(Part part)
    {
      coilTrackingContext.Parts.Remove(part);
      var result = await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
      return result;
    }
    /// <summary>
    /// Remove Part
    /// </summary>
    /// <param name="part"></param>
    public void RemovePart(Part part)
    {
      coilTrackingContext.Parts.Remove(part);
    }
    /// <summary>
    /// Unchanged Part
    /// </summary>
    /// <param name="part"></param>
    /// <returns></returns>
    public bool UnchangedPart(Part part)
    {
      coilTrackingContext.Entry(part).State = EntityState.Unchanged;
      return true;
    }


    public async Task<int> PartSavechanges()
    {
      var result = await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
      return result;
    }

    public async Task<string> GetPartName(string partNumber)
    {
      return await coilTrackingContext.Parts
        .Where(p => p.PartNumber == partNumber)
        .Select(p => p.PartName)
        .FirstOrDefaultAsync();
    }
  }
}
