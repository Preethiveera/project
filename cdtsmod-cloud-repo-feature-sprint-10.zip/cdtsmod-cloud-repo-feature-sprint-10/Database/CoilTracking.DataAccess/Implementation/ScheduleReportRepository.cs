using CoilTracking.Common;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class ScheduleReportRepository : IScheduleReportRepository
  {
    private readonly CoilTrackingContext coilTrackingContext;
    private readonly IUserHelper usersHelper;
    public ScheduleReportRepository(CoilTrackingContext coilTrackingContext, IUserHelper usersHelper)
    {
      this.coilTrackingContext = coilTrackingContext;
      this.usersHelper = usersHelper;
    }

    // Get the list of Sheculdule reprots
    public IQueryable<ScheduledReportEmail> Get()
    {
      return coilTrackingContext.ScheduledReportEmails;
    }

    // Get by ID
    public ScheduledReportEmail GetScheduleReportByID(int id)
    {
      return coilTrackingContext.ScheduledReportEmails.Find(id);
    }

    //Add Report Mail
    public async Task<int> PostScheduleReport(ScheduledReportEmail scheduledReportEmail)
    {
      await coilTrackingContext.ScheduledReportEmails.AddAsync(scheduledReportEmail);
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.CreateEntity);

      return scheduledReportEmail.Id;

    }

    // Edit Report mail
    public bool PutScheduleReport(int id, ScheduledReportEmail scheduledReportEmail)
    {
      coilTrackingContext.Entry(scheduledReportEmail).State = EntityState.Modified;
      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.CreateEntity);

      return true;
    }

    public bool ScheduleReportExists(int id)
    {
      return coilTrackingContext.ScheduledReportEmails.Count(e => e.Id == id) > 0;
    }

    public ScheduledReportEmail GetScheduleReportByEmail(string email)
    {
      return coilTrackingContext.ScheduledReportEmails.Where(x => x.Email == email).FirstOrDefault();
    }

    public bool DeleteScheduleReport(int id)
    {
      ScheduledReportEmail scheduledReportEmail = coilTrackingContext.ScheduledReportEmails.Find(id);

      coilTrackingContext.ScheduledReportEmails.Remove(scheduledReportEmail);
      coilTrackingContext.SaveChanges();
      return true;
    }

    /// <summary>
    /// Add Scheduled Report Email logs
    /// </summary>
    /// <returns></returns>
    public async Task AddScheduleReportEmailLog(string exception, string mailInfo, bool isSuccess)
    {
      await coilTrackingContext.ScheduledReportEmailLog.AddAsync(new ScheduledReportEmailLog()
      {
        ExceptionMessage = exception,
        MailInfo = mailInfo,
        IsSccess = isSuccess,
        LogTimestamp = DateTime.Now
      }
      );
      await coilTrackingContext.SaveChangesAsync();
    }
  }
}
