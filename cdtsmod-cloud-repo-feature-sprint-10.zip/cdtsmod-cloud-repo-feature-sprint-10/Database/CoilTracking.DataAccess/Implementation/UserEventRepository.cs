using CoilTracking.Common;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
 public  class UserEventRepository : IUserEventRepository
  {
    private readonly CoilTrackingContext coilTrackingContext;
    private readonly IUserHelper usersHelper;

    public UserEventRepository(CoilTrackingContext coilTrackingContext, IUserHelper usersHelper)
    {
      this.coilTrackingContext = coilTrackingContext;
      this.usersHelper = usersHelper;
    }

    /// <summary>
    /// Get list of user events
    /// </summary>
    /// <returns></returns>
    public async  Task<List<UserEvent>> GetUserEvents()
    {
      
      return await coilTrackingContext.UserEvents.ToListAsync();
    }

    /// <summary>
    /// to get list of Userevents by time and username
    /// </summary>
    /// <param name="startTime"></param>
    /// <param name="endTime"></param>
    /// <param name="username"></param>
    /// <returns></returns>
    public async  Task<List<UserEvent>> GetUserEventsBetween(DateTime? startTime = null, DateTime? endTime = null, string username = null)
    {
      return await coilTrackingContext.UserEvents.Where(ue => (!startTime.HasValue || ue.EventDate >= startTime) && (!endTime.HasValue || ue.EventDate <= endTime) && (username == null || ue.UserName.Contains(username))).OrderBy(ue => ue.EventDate).ToListAsync();

    }
    /// <summary>
    /// Get user events by id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async  Task<UserEvent> GetUserEventById(int id)
    {
      return await coilTrackingContext.UserEvents.FindAsync(id);
    }
    /// <summary>
    /// To update  userevents
    /// </summary>
    /// <param name="id"></param>
    /// <param name="userEvent"></param>
    /// <returns></returns>
    public  UserEvent UpdateUserEvent(int id, UserEvent userEvent)
    {
      coilTrackingContext.Entry(userEvent).State = EntityState.Modified;

      coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
      return userEvent;
     }

    /// <summary>
    /// to add new user events
    /// </summary>
    /// <param name="userEvent"></param>
    /// <returns></returns>
    public async Task<UserEvent> InsertUserEvent(UserEvent userEvent)
    {
      coilTrackingContext.UserEvents.Add(userEvent);
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
      return userEvent;
    }

    /// <summary>
    /// to delete user event
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async  Task<UserEvent> DeleteUserEvent(int id)
    {
      var userEvent = await coilTrackingContext.UserEvents.Where(i => i.Id == id).AsNoTracking().FirstOrDefaultAsync();
      coilTrackingContext.UserEvents.Remove(userEvent);
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
      return userEvent;
    }
  }
}
