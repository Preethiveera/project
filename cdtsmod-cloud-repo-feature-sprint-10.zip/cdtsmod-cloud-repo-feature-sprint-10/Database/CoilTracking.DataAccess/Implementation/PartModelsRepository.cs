using CoilTracking.Common;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class PartModelsRepository : IPartModelsRepository
  {
    private readonly CoilTrackingContext coilTrackingContext;
    private readonly IUserHelper usersHelper;
    public PartModelsRepository(CoilTrackingContext coilTrackingContext, IUserHelper usersHelper)
    {
      this.coilTrackingContext = coilTrackingContext;
      this.usersHelper = usersHelper;
    }

    public async Task<List<PartModel>> GetPartModels()
    {
      List<PartModel> partmodels = await coilTrackingContext.PartModels.Include(x => x.Part).Include(y => y.Model).ToListAsync();

      return partmodels;
    }

    /// <summary>
    /// Get part model.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>PartModel</returns>
    public async Task<PartModel> GetPartModel(int id)
    {
      return await coilTrackingContext.PartModels.AsNoTracking().Include(x => x.Part).Include(y => y.Model).FirstOrDefaultAsync(x => x.Id == id);
    }

    /// <summary>
    /// Get parts related to models.
    /// </summary>
    /// <param name="modelId"></param>
    /// <returns>list of part</returns>
    public async Task<List<Part>> GetPartsRelatedToModels(int modelId)
    {
      var parts = await coilTrackingContext.PartModels.Include(x => x.Part).Where(x => x.Model.Id == modelId)
        .Select(x => x.Part).Distinct().ToListAsync();
      return parts;
    }

    /// <summary>
    /// Get part model by partIds and modelId
    /// </summary>
    /// <param name="partIds"></param>
    /// <param name="modelId"></param>
    /// <returns>list of PartModel</returns>
    public async Task<List<PartModel>> GetPartModelByPartIdsAndModelId(int[] partIds, int modelId)
    {
      return await coilTrackingContext.PartModels.Include(x => x.Part).Include(x => x.Model)
        .Where(x => x.Model.Id == modelId && partIds.Contains(x.Part.Id)).Distinct().ToListAsync();
    }

    /// <summary>
    /// Update PartModel.
    /// </summary>
    /// <param name="partModel"></param>
    /// <returns>bool</returns>
    public bool UpdatePartModel(PartModel partModel)
    {
      coilTrackingContext.Entry(partModel).State = EntityState.Modified;    
      return true;
    }
    /// <summary>
    /// Unchanged PartModel
    /// </summary>
    /// <param name="partModel"></param>
    /// <returns></returns>
    public bool UnchangedPartModel(PartModel partModel)
    {
      coilTrackingContext.Entry(partModel).State = EntityState.Unchanged;
      return true;
    }
    /// <summary>
    /// Remove PartModel
    /// </summary>
    /// <param name="partModel"></param>
    /// <returns></returns>
    public bool RemovePartModel(PartModel partModel)
    {
      coilTrackingContext.PartModels.Remove(partModel);
      return true;
    }


    /// <summary>
    /// Update PartModel.
    /// </summary>
    /// <param name="partModel"></param>
    /// <returns>bool</returns>
    public async Task<bool> UpdatePartModelSaveAsync(PartModel partModel)
    {
      coilTrackingContext.Entry(partModel).State = EntityState.Modified;
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
      return true;
    }

    public async Task<List<PartModel>> GetPartmodelsByPartnumber(string partNumber)
    {
    var partmodels = await   coilTrackingContext.PartModels.Include(x=>x.Model).Include(y=>y.Part).Where(pm => pm.Part.PartNumber.StartsWith(partNumber) && !pm.Part.Disabled).ToListAsync();
      return partmodels;
    }

    public async Task<List<PartModel>> GetPartmodelsByPartId(int  id)
    {
      List<PartModel> partModels = await coilTrackingContext.PartModels.AsNoTracking().Include(x => x.Model).AsNoTracking().Include(y=>y.Part).Where(x => x.Part.Id == id).ToListAsync();

      return partModels;
    }


    public async Task<List<PartModel>> GetPartmodelsByPartIdwithOut(int id)
    {
      List<PartModel> partModels = await coilTrackingContext.PartModels.AsNoTracking().Include(x => x.Model).Where(x => x.Part.Id == id).ToListAsync();

      return partModels;
    }

    /// <summary>
    /// Get models List
    /// </summary>
    /// <param name="Id"></param>
    /// <returns></returns>
    /// GetPartModelByPartId
    public List<Model> GetPartModelByPartId(int Id)
    {
      var partModels =  coilTrackingContext.PartModels.AsNoTracking().Include(x => x.Model).Where(x => x.Part.Id == Id).Select(x => x.Model).ToList();
      return partModels;
    }

    public async Task<int> InsertPartModelsSavechanges(List<PartModel> partModels)
    {
        foreach (var part in partModels)
        {
          coilTrackingContext.Entry(part.Model).State = EntityState.Unchanged;
          coilTrackingContext.Entry(part.Part).State = EntityState.Unchanged;
        }
        await coilTrackingContext.PartModels.AddRangeAsync(partModels);
        var save = await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
        return save;   
    }

    public async Task<int> PartModelsSavechanges()
    {
      var save = await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
      return save;
    }

    /// <summary>
    /// Get PartModel By Id.
    /// </summary>
    /// <returns></returns>
    public async Task<PartModel> GetPartModelById(int id)
    {
      return await coilTrackingContext.PartModels.AsNoTracking().Where(x=>x.Id == id).FirstOrDefaultAsync();
    }

    /// <summary>
    /// Get list of PartModel.
    /// </summary>
    /// <returns></returns>
    public async Task<List<PartModel>> GetPartModelsAsync()
    {
      return await coilTrackingContext.PartModels.ToListAsync();
    }

    /// <summary>
    /// Save changes to database.
    /// </summary>
    /// <returns></returns>
    public async Task SaveChanges(AuditActionType auditActionType)
    {
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), auditActionType);
    }

    /// <summary>
    /// Update PartModel.
    /// </summary>
    /// <returns></returns>
    public async Task UpdatePartModelAsync(PartModel partModel)
    {
      coilTrackingContext.Entry(partModel).State = EntityState.Modified;
      await SaveChanges(AuditActionType.ModifyEntity);
    }

    /// <summary>
    /// Add PartModel.
    /// </summary>
    /// <returns></returns>
    public async Task<PartModel> AddPartModelAsync(PartModel partModel)
    {
      await coilTrackingContext.PartModels.AddAsync(partModel);
      coilTrackingContext.Entry(partModel.Model).State = EntityState.Unchanged;
      coilTrackingContext.Entry(partModel.Part).State = EntityState.Unchanged;
      await SaveChanges(AuditActionType.ModifyEntity);

      return partModel;
    }

    /// <summary>
    /// Delete PartModel.
    /// </summary>
    /// <returns></returns>
    public async Task DeletePartModelAsync(PartModel partModel)
    {
      coilTrackingContext.PartModels.Remove(partModel);
      await SaveChanges(AuditActionType.ModifyEntity);
    }

    public string GetModelList(string partNumber)
    {
      List<string> partModels = coilTrackingContext.PartModels.Where(p => p.Part.PartNumber == partNumber)
      .Select(p => p.Model.ModelNumber)
      .OrderBy(modelNum => modelNum).ToList();

      string modelList = string.Join("/", partModels);
      return modelList;
    }
  }
}
