using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class IncompleteRunOrderItemRepository : IIncompleteRunOrderItemRepository
  {
    public readonly CoilTrackingContext coilTrackingContext;

    public IncompleteRunOrderItemRepository(CoilTrackingContext coilTrackingContext)
    {
      this.coilTrackingContext = coilTrackingContext;
    }

    /// <summary>
    /// Get incomplete run order items by status.
    /// </summary>
    /// <param name="runOrderItemStatuses"></param>
    /// <returns>list of part</returns>
    public async Task<List<Part>> GetIncompleteRunOrderItemsByStatus(params RunOrderItemStatus[] runOrderItemStatuses)
    {
      return await coilTrackingContext.IncompleteRunOrderItems.Where(y => runOrderItemStatuses.Contains(y.Status)).Select(x => x.Part).ToListAsync();
    }

    public async Task<List<IncompleteRunOrderItem>> GetIncompleteRunOrderItems()
    {
      return await coilTrackingContext.IncompleteRunOrderItems.ToListAsync();
    }
  }
}
