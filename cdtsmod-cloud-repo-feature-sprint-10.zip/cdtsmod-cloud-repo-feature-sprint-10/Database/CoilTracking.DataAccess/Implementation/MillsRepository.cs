using CoilTracking.Common;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class MillsRepository : IMillsRepository
  {
    private readonly CoilTrackingContext coilTrackingContext;
    private readonly IUserHelper usersHelper;
    public MillsRepository(CoilTrackingContext coilTrackingContext, IUserHelper usersHelper)
    {
      this.coilTrackingContext = coilTrackingContext;
      this.usersHelper = usersHelper;
    }
    /// <summary>
    /// Get total no of mills
    /// </summary>
    /// <returns>count</returns>
    public int GetCountOfMills()
    {
      return coilTrackingContext.Mills.Count();
    }

    /// <summary>
    /// Get mills By Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>Mill</returns>
    public Mill GetMillById(int id)
    {
      return coilTrackingContext.Mills.AsNoTracking().Where(x => x.Id == id).FirstOrDefault();
    }

    /// <summary>
    /// Get Mills from DB
    /// </summary>
    /// <returns>mills</returns>
    public List<Mill> GetMills()
    {
      return coilTrackingContext.Mills.ToList();
    }


    /// <summary>
    /// Check if entity is edited while deletion
    /// </summary>
    /// <param name="id"></param>
    /// <param name="mill"></param>
    /// <returns>string</returns>
    public bool CheckIfEdited(int id, Mill mill)
    {
      var millById = coilTrackingContext.Mills.Find(id);
      if (mill.Name != millById.Name
           || mill.Disabled != millById.Disabled)
      {
        return true;
      }
      return false;
    }

    /// <summary>
    /// Disable a mill by id
    /// </summary>
    /// <param name="id"></param>
    /// <param name="disable"></param>
    /// <returns>void</returns>
    public void DisableMill(int id, bool disable)
    {
      Mill mill = coilTrackingContext.Mills.Find(id);

      mill.Disabled = disable;

      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.EnableDisable);
      coilTrackingContext.Entry(mill).State = EntityState.Modified;


    }

    /// <summary>
    /// Add new Mill
    /// </summary>
    /// <param name="mill"></param>
    /// <returns>mill</returns>
    public void InsertMill(Mill mill)
    {
      coilTrackingContext.Mills.Add(mill);
      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.CreateEntity);


    }

    /// <summary>
    /// Delete a Mill
    /// </summary>
    /// <param name="id"></param>
    /// <returns>mill</returns>
    public Mill DeleteMill(int id)
    {
      var mill = coilTrackingContext.Mills.Find(id);
      if (mill != null)
      {
        coilTrackingContext.Mills.Remove(mill);
        coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyEntity);

      }
      return mill;
    }

    /// <summary>
    /// Update a Mill
    /// </summary>
    /// <param name="mill"></param>
    /// <returns>bool</returns>
    public bool UpdateMill(Mill mill)
    {
      coilTrackingContext.Entry(mill).State = EntityState.Modified;
      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyEntity);

      return true;
    }
    /// <summary>
    /// Get MillByName
    /// </summary>
    /// <param name="coilCheckInMill"></param>
    /// <returns></returns>
    public async Task<Mill> GetMillByName(string coilCheckInMill)
    {
      var mills = await coilTrackingContext.Mills.Where(m => m.Name == coilCheckInMill).AsNoTracking().FirstOrDefaultAsync();
      return mills;

    }

  }
}
