using CoilTracking.Common;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class ShiftRepository : IShiftRepository
  {
    private readonly CoilTrackingContext coilTrackingContext;
    private readonly IUserHelper usersHelper;
    public ShiftRepository(CoilTrackingContext coilTrackingContext, IUserHelper usersHelper)
    {
      this.coilTrackingContext = coilTrackingContext;
      this.usersHelper = usersHelper;
    }

    public int GetCountofShifts()
    {

      return coilTrackingContext.Shifts.Count();
    }

    /// <summary>
    /// Get Shift by Id 
    /// </summary>
    /// <param name="id"></param>
    /// <returns>Shift</returns>
    public async Task<Shift> GetShiftByIdAsync(int id)
    {
      return await coilTrackingContext.Shifts.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
    }

    /// <summary>
    /// Get Shifts
    /// </summary>
    /// <param></param>
    /// <returns>Shift</returns>
    public async Task<List<Shift>> GetShifts()
    {
      var shifts = await coilTrackingContext.Shifts.AsNoTracking().Where(s => !s.Disabled).ToListAsync();
      return shifts;
    }
    public async Task<List<Shift>> GetAllShifts()
    {
      var shifts = await coilTrackingContext.Shifts.AsNoTracking().ToListAsync();
      return shifts;
    }

    /// <summary>
    /// Get Current Shift
    /// </summary>
    /// <param></param>
    /// <returns>Shift</returns>
    public async Task<Shift> GetCurrentShift(TimeSpan currentTime)
    {
      var shift = await coilTrackingContext.Shifts
        .Where(s => s.Start < currentTime && s.Finish > currentTime && !s.Disabled)
        .FirstOrDefaultAsync();
      return shift;
    }

    /// <summary>
    /// Get Late night Shift
    /// </summary>
    /// <param></param>
    /// <returns>Shift</returns>
    public async Task<Shift> GetLateNightShift()
    {
      var shift = await coilTrackingContext.Shifts
        .Where(s => s.Start > s.Finish && !s.Disabled)
        .FirstOrDefaultAsync();
      return shift;
    }

    /// <summary>
    /// Get Ordered current night Shift
    /// </summary>
    /// <param></param>
    /// <returns>Shift</returns>
    public async Task<Shift> GetOrderedCurrentShift(TimeSpan currentTime)
    {
      var shift = await coilTrackingContext.Shifts
        .Where(s => s.Start > currentTime)
        .OrderBy(t => t.Start)
        .FirstAsync();
      return shift;
    }

    /// <summary>
    /// Get next shift by current time
    /// </summary>
    /// <param></param>
    /// <returns>Shift</returns>
    public async Task<Shift> GetNextShiftByCurrentTime(TimeSpan currentTime)
    {
      var shift = await coilTrackingContext.Shifts
        .Where(s => s.Start > currentTime && !s.Disabled)
        .FirstOrDefaultAsync();
      return shift;
    }

    /// <summary>
    /// Get next Shift
    /// </summary>
    /// <param></param>
    /// <returns>Shift</returns>
    public async Task<Shift> GetNextShift()
    {
      var shift = await coilTrackingContext.Shifts
        .OrderBy(s => s.Start)
        .FirstOrDefaultAsync();
      return shift;
    }

    /// <summary>
    /// Save changes to database
    /// </summary>
    /// <param></param>
    /// <returns>Shift</returns>
    public async Task SaveChanges(AuditActionType auditActionType)
    {
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), auditActionType);
    }

    /// <summary>
    /// Update shift
    /// </summary>
    /// <param></param>
    /// <returns>Shift</returns>
    public async Task UpdateShift(Shift shift, AuditActionType auditActionType)
    {
      coilTrackingContext.Entry(shift).State = EntityState.Modified;
      await SaveChanges(auditActionType);
    }

    /// <summary>
    /// Add shift
    /// </summary>
    /// <param></param>
    /// <returns>Shift</returns>
    public async Task<Shift> AddShift(Shift shift)
    {
      await coilTrackingContext.Shifts.AddAsync(shift);
      await SaveChanges(AuditActionType.CreateEntity);
      return shift;
    }

    /// <summary>
    /// Delete shift
    /// </summary>
    /// <param></param>
    /// <returns>Shift</returns>
    public async Task DeleteShift(Shift shift)
    {
      coilTrackingContext.Shifts.Remove(shift);
      await SaveChanges(AuditActionType.ModifyEntity);
    }

    /// <summary>
    /// Check Edit for shift.
    /// </summary>
    /// <returns></returns>
    public async Task<bool> CheckEdit(int id, Shift shift)
    {
      if (shift.Name != await coilTrackingContext.Shifts.Where(x => x.Id == id).Select(y => y.Name).FirstOrDefaultAsync()
              || shift.Start != coilTrackingContext.Shifts.Where(x => x.Id == id).Select(y => y.Start).FirstOrDefault()
              || shift.TextColor != coilTrackingContext.Shifts.Where(x => x.Id == id).Select(y => y.TextColor).FirstOrDefault()
              || shift.Finish != coilTrackingContext.Shifts.Where(x => x.Id == id).Select(y => y.Finish).FirstOrDefault()
              || shift.BackgroundColor != coilTrackingContext.Shifts.Where(x => x.Id == id).Select(y => y.BackgroundColor).FirstOrDefault()
              || shift.Disabled != coilTrackingContext.Shifts.Where(x => x.Id == id).Select(y => y.Disabled).FirstOrDefault())
      {
        return true;
      }
      return false;
    }
  }
}
