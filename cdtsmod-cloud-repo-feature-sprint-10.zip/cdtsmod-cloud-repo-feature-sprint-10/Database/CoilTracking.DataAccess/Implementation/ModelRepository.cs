using CoilTracking.Common;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class ModelRepository : IModelRepository
  {
    private readonly CoilTrackingContext coilTrackingContext;
    private readonly IUserHelper usersHelper;
    public ModelRepository(CoilTrackingContext coilTrackingContext, IUserHelper usersHelper)
    {
      this.coilTrackingContext = coilTrackingContext;
      this.usersHelper = usersHelper;
    }
    /// <summary>
    /// GetCount Of Models
    /// </summary>
    /// <returns></returns>
    public int GetCountOfModels()
    {
      return coilTrackingContext.Models.Count();
    }

    /// <summary>
    /// Get the list of models.
    /// </summary>
    /// <returns>List of model</returns>
    public async Task<List<Model>> GetModels()
    {
      return await coilTrackingContext.Models.ToListAsync();
    }

    /// <summary>
    /// Get model by id.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>Model</returns>
    public async Task<Model> GetModelById(int id)
    {
      return await coilTrackingContext.Models.AsNoTracking().FirstOrDefaultAsync(x=>x.Id == id);
    }

    /// <summary>
    /// Update the model.
    /// </summary>
    /// <param name="model"></param>
    /// <param name="auditActionType"></param>
    /// <returns>bool</returns>
    public async Task<bool> UpdateModel(Model model, AuditActionType auditActionType = AuditActionType.ModifyEntity)
    {
      coilTrackingContext.Entry(model).State = EntityState.Modified;
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), auditActionType);
      return true;
    }
    /// <summary>
    /// Remove Model
    /// </summary>
    /// <param name="model"></param>
    public void RemoveModel(Model model)
    {
      coilTrackingContext.Models.Remove(model);
    }

    /// <summary>
    /// Add model.
    /// </summary>
    /// <param name="model"></param>
    /// <returns>bool</returns>
    public async Task<bool> AddModel(Model model)
    {
      await coilTrackingContext.AddAsync(model);
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.CreateEntity);
      return true;
    }

    /// <summary>
    /// Add model.
    /// </summary>
    /// <param name="model"></param>
    /// <returns>bool</returns>
    public async Task<bool> SaveChangesModel(Model model)
    {
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.CreateEntity);
      return true;
    }

    /// <summary>
    /// Get model by model number.
    /// </summary>
    /// <param name="modelNo"></param>
    /// <returns>list of model</returns>
    public async Task<List<Model>> GetModelByModelNo(string modelNo)
    {
      var mod =  await coilTrackingContext.Models.Where(x => x.ModelNumber == modelNo).ToListAsync();
      return mod;
    }
    /// <summary>
    /// Get ALL  Model By ModelNo
    /// </summary>
    /// <param name="modelNo"></param>
    /// <returns></returns>
    public  List<Model> GetAllModelByModelNo(List<string> modelNo)
    {
      var models = modelNo.Select(b => b);
      var mod = coilTrackingContext.Models.Where(x => models.Contains(x.ModelNumber)).ToList();
      return mod;
    }


   

    /// <summary>
    /// Delete model by id.
    /// </summary>
    /// <param name="model"></param>
    /// <returns>bool</returns>
    public async Task<bool> DeleteModel(Model model)
    {
      coilTrackingContext.Models.Remove(model);
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
      return true;
    }
    /// <summary>
    /// UnchangedModel
    /// </summary>
    /// <param name="model"></param>
    /// <returns></returns>
    public bool UnchangedModel(Model model)
    {
      coilTrackingContext.Entry(model).State = EntityState.Unchanged;
      return true;
    }
  }
}
