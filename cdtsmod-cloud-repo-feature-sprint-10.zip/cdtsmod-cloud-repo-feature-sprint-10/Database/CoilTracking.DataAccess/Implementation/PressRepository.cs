using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using System.Linq;

namespace CoilTracking.DataAccess.Implementation
{
  public class PressRepository : IPressRepository
  {

    private readonly CoilTrackingContext coilTrackingContext;

    public PressRepository(CoilTrackingContext coilTrackingContext)
    {
      this.coilTrackingContext = coilTrackingContext;
    }

    /// <summary>
    /// Add new Press
    /// </summary>
    /// <param name="press"></param>
    public void AddNewPress(Press press)
    {
      coilTrackingContext.Presses.Add(press); ;

    }

    /// <summary>
    /// Get Press By name
    /// </summary>
    /// <param name="name"></param>
    /// <returns></returns>
    public Press GetPressByName(string name)
    {
      return coilTrackingContext.Presses.Where(x => x.Name.Equals(name)).FirstOrDefault();
    }
  }
}
