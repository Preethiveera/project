using CoilTracking.Common;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class CoilMoveRequestsRepository : ICoilMoveRequestsRepository
  {
    private readonly CoilTrackingContext coilTrackingContext;
    private readonly IUserHelper usersHelper;
    public CoilMoveRequestsRepository(CoilTrackingContext coilTrackingContext, IUserHelper usersHelper)
    {
      this.coilTrackingContext = coilTrackingContext;
      this.usersHelper = usersHelper;
    }
    /// <summary>
    /// Get CoilMoveRequest Based on Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public List<CoilMoveRequest> GetCoilMoveRequestById(int id)
    {
      var moveRequest = coilTrackingContext.CoilMoveRequests
        .Where(c => c.Coil.Id == id && c.RequestType == CoilMoveRequestType.CoilRequest && (c.Fulfilled == null && c.IsCancelled != true))
        .ToList();

      return moveRequest;
    }

    /// <summary>
    /// To Get all the coil move requests.
    /// </summary>

    public async Task<List<CoilMoveRequest>> GetAllCoilMoveRequest()
    {
      var requests = coilTrackingContext.CoilMoveRequests
        .Include(cmr => cmr.Coil.CoilType)
        .Include(cmr => cmr.Coil.CoilFieldLocation.Zone)
        .Include(cmr => cmr.Line).ToListAsync();

      return await requests;
    }

    /// <summary>
    /// To Get all the pending coil move requests by lineId.
    /// </summary>

    public async Task<List<CoilMoveRequest>> GetPendingRequestByLine(int lineId, DateTime? startTime = null, DateTime? endTime = null)
    {
      var requests = await coilTrackingContext.CoilMoveRequests
          .Include(cmr => cmr.Coil.CoilType)
          .Include(cmr => cmr.Coil.CoilFieldLocation.Zone)
          .Include(cmr => cmr.Line)
          .Where(cmr => cmr.Line.Id == lineId &&
                  cmr.Fulfilled == null &&
                  ((cmr.IsCancelled == false) ||
                      ((startTime.HasValue && endTime.HasValue) && (cmr.Requested > startTime) && (cmr.Requested < endTime)))).ToListAsync();

      return requests;
    }

    /// <summary>
    /// To Get all the unfulfilled coil move requests.
    /// </summary>

    public async Task<List<CoilMoveRequest>> GetUnfulfilledCoilMoveRequests()
    {
      var requests = await coilTrackingContext.CoilMoveRequests.Where(cmr => cmr.Fulfilled == null && !cmr.IsCancelled)
                                .Include(cmr => cmr.Coil.CoilType.CoilFieldZone)
                                .Include(cmr => cmr.Coil.CoilFieldLocation.Zone)
                                .Include(cmr => cmr.Line)
                                .OrderBy(cmr => cmr.Requested).ToListAsync();

      return requests;
    }

    public async Task<int> GetUnfulfilledCoilMoveRequestsCount()
    {
      return await coilTrackingContext.CoilMoveRequests.Where(cmr => cmr.Fulfilled == null && !cmr.IsCancelled).CountAsync();
    }

    /// <summary>
    /// To Get coil move requests by id.
    /// </summary>

    public async Task<CoilMoveRequest> GetMoveRequestById(int id)
    {
      var request = await coilTrackingContext.CoilMoveRequests
          .Include(cmr => cmr.Coil.CoilType)
          .Include(cmr => cmr.Coil.CoilFieldLocation.Zone)
          .Include(cmr => cmr.Line)
          .Include(cmr => cmr.Coil.CoilStatus)
          .Include(cmr => cmr.Coil.Mill)
          .Where(cmr => cmr.Id == id).FirstOrDefaultAsync();

      return request;
    }

    /// <summary>
    /// To save changes to database.
    /// </summary>

    public async Task SaveChanges(AuditActionType auditAction)
    {
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), auditAction);
    }

    /// <summary>
    /// To Get all coilIds of  unfulfilled coil move requests.
    /// </summary>

    public async Task<List<int>> GetUnfulfilledCoilIds()
    {
      var unfulfilledIds = await coilTrackingContext.CoilMoveRequests.Include(cmr => cmr.Coil)
                                                        .Where(cmr => cmr.Fulfilled == null && !cmr.IsCancelled)
                                                        .Select(cmr => cmr.Coil.Id)
                                                        .Distinct().ToListAsync();

      return unfulfilledIds;
    }

    /// <summary>
    /// To Add a new coil move requests.
    /// </summary>

    public async Task AddCoilMoveRequest(CoilMoveRequest coilMoveRequest)
    {
      await coilTrackingContext.CoilMoveRequests.AddAsync(coilMoveRequest);
    }

    /// <summary>
    /// To Get the coil move requests with CoilData by id.
    /// </summary>

    public async Task<CoilMoveRequest> GetCoilMoveRequestWithCoilData(int id)
    {
      var coilMoveRequest = await coilTrackingContext.CoilMoveRequests
                                          .Where(cmr => cmr.Id == id)
                                          .Include(cmr => cmr.Line)
                                          .Include(cmr => cmr.Coil.CoilType)
                                          .Include(cmr => cmr.Coil.CoilStatus)
                                          .Include(cmr => cmr.Coil.CoilRunHistory)
                                          .Include(cmr => cmr.Coil.Mill)
                                          .Include(cmr => cmr.Coil.CoilFieldLocation.Zone)
                                          .FirstOrDefaultAsync();

      return coilMoveRequest;
    }

    /// <summary>
    /// To find a coil move requests.
    /// </summary>

    public async Task<CoilMoveRequest> FindCoilMoveRequestAsync(int id)
    {
      var coilMoveRequest = await coilTrackingContext.CoilMoveRequests.FindAsync(id);
      return coilMoveRequest;
    }

    /// <summary>
    /// To delete a coil move requests.
    /// </summary>

    public async Task<bool> DeleteCoilMoveRequest(CoilMoveRequest coilMoveRequest)
    {
      coilTrackingContext.CoilMoveRequests.Remove(coilMoveRequest);
      await SaveChanges(AuditActionType.DeleteCoilMoveRequest);
      return true;
    }

    /// <summary>
    /// To Get all the Loaded Coils in a coil move requests.
    /// </summary>

    public async Task<List<Coil>> GetCoilsLoadedByCoilStatusName(string statusName)
    {
      var coilsLoaded = await coilTrackingContext.CoilMoveRequests
          .Include(c => c.Coil)
          .Include(c => c.Coil.CoilRunHistory)
          .Include(c => c.Coil.CoilFieldLocation)
          .Include(c => c.Coil.CoilFieldLocation.Zone)
          .Include(c => c.Coil.CoilStatus)
          .Include(c => c.Coil.CoilType)
          .Include(c => c.Coil.Mill)
          .Where(c => c.Coil.CoilStatus.Name == statusName)
          .Select(cm => cm.Coil)
          .ToListAsync();

      return coilsLoaded;
    }

    /// <summary>
    /// To Get all the return coil move requests.
    /// </summary>

    public async Task<List<CoilMoveRequest>> GetReturnRequests()
    {
      var returnRequests = await coilTrackingContext.CoilMoveRequests
          .Include(cm => cm.Coil)
          .Where(cm => cm.Fulfilled == null &&
              (cm.RequestType == CoilMoveRequestType.CoilReject || cm.RequestType == CoilMoveRequestType.CoilReturn))
          .ToListAsync();

      return returnRequests;
    }
  }
}
