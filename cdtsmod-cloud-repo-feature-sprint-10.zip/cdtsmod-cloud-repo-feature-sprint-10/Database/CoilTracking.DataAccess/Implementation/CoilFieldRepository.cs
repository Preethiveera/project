using CoilTracking.Common;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace CoilTracking.DataAccess.Implementation
{
  public class CoilFieldRepository : ICoilFieldRepository
  {

    private readonly CoilTrackingContext coilTrackingContext;
    private readonly IUserHelper usersHelper;
    public CoilFieldRepository(CoilTrackingContext coilTrackingContext, IUserHelper usersHelper)
    {
      this.coilTrackingContext = coilTrackingContext;
      this.usersHelper = usersHelper;
    }



    /// <summary>
    /// Get the count of coil fields
    /// </summary>
    /// <returns>integer</returns>
    public int GetCountOfCoilField()
    {
      return coilTrackingContext.CoilFields.Count();
    }


    /// <summary>
    /// To get the List of CoilFields by Id.Includes both zones and locations with the coil fields
    /// </summary>
    /// <param name="id"></param>
    /// <returns>coilField</returns>
    public CoilField GetCoilFieldById(int id)
    {
      return coilTrackingContext.CoilFields.Find(id);

    }

    /// <summary>
    /// To get the List of CoilFields.Includes both zones and locations with the coil fields
    /// </summary>
    /// <returns>coilFields</returns>
    public List<CoilField> GetCoilFields()
    {
      var coilFields = coilTrackingContext.CoilFields.Include(cf => cf.Zones).ThenInclude(cc => cc.Locations).Include(cp=>cp.Plant).ToList();

      return coilFields;

    }



    /// <summary>
    /// Disable coil field
    /// </summary>
    /// <param name="id"></param>
    /// <param name="disable"></param>
    /// <returns>bool</returns>
    public bool DisableCoilField(int id, bool disable)
    {
      CoilField coilField = coilTrackingContext.CoilFields.Find(id);
      coilField.Disabled = disable;
      coilTrackingContext.Entry(coilField).State = EntityState.Modified;
      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.EnableDisable);
      return true;
    }

    /// <summary>
    /// To update an existing Coil Field
    /// </summary>
    /// <param name="id"></param>
    /// <param name="coilField"></param>
    /// <returns>bool</returns>
    public bool UpdateCoilField(int id, CoilField coilField)
    {
      CoilField coilFieldFromDb = coilTrackingContext.CoilFields.Where(c => c.Id == id).FirstOrDefault();
      coilFieldFromDb.Name = coilField.Name;
      coilFieldFromDb.Disabled = coilField.Disabled;
      coilField.Plant_Id = coilFieldFromDb.Plant_Id;
      if (coilField.Zones != null)
      {
        foreach (var zone in coilField.Zones)
        {
          coilFieldFromDb.Zones.RemoveAll(z => !zone.Id.Equals(z.Id));
        }
      }
      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
      return true;
    }

    /// <summary>
    /// To add new coil field
    /// </summary>
    /// <param name="coilField"></param>
    /// <returns>bool</returns>
    public bool SaveCoilField(CoilField coilField)
    {
      var zoineIds = coilField.Zones.Select(c => c.Id).ToList();
      CoilField coilFieldToDb = new CoilField
      {
        Name = coilField.Name
      };
      coilField.Zones = coilTrackingContext.CoilFieldZones.Where(z => zoineIds.Contains(z.Id)).ToList();
      coilTrackingContext.CoilFields.Add(coilField);
      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.CreateEntity);
      return true;
    }

    /// <summary>
    /// Delete a coil field
    /// </summary>
    /// <param name="id"></param>
    /// <returns>coilfield</returns>
    public CoilField DeleteCoilField(int id)
    {
      var coilField = coilTrackingContext.CoilFields.Find(id);
      coilTrackingContext.CoilFields.Remove(coilField);
      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
      return coilField;
    }
    /// <summary>
    /// Get CoilField With Zones Based on Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public CoilField GetCoilFieldWithZonesById(int id)
    {
      return coilTrackingContext.CoilFields.Include(cf => cf.Zones).AsNoTracking().Where(x => x.Id == id).FirstOrDefault();
    }
  }
}
