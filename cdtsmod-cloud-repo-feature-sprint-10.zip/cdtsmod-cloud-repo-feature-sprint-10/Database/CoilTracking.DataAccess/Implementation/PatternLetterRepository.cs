using CoilTracking.Common.Constants;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace CoilTracking.DataAccess.Implementation
{
  public class PatternLetterRepository : IPatternLetterRepository
  {
    private readonly CoilTrackingContext coilTrackingContext;

    public PatternLetterRepository(CoilTrackingContext coilTrackingContext)
    {
      this.coilTrackingContext = coilTrackingContext;
    }


    /// <summary>
    /// Get the list of PatternLetters from Database
    /// </summary>
    /// <returns></returns>
    public IQueryable<PatternLetter> GetPatternLetter()
    {

      return coilTrackingContext.PatternLetters.Include(x=>x.Plant).Where(p => p.Name.Equals(Constant.defaultPatternLetter) == false);

    }

    /// <summary>
    /// Get the list of PatternLetters from Database by Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public PatternLetter GetPatternLetterById(int id)
    {
      return coilTrackingContext.PatternLetters.AsNoTracking().Where(x=>x.Id == id).FirstOrDefault();
    }

    public PatternLetter PostPatternLetter(PatternLetter patternLetter)
    {
      patternLetter.Name = patternLetter.Name.ToUpper();
      coilTrackingContext.PatternLetters.Add(patternLetter);
      coilTrackingContext.SaveChanges();

      return patternLetter;

    }

    public bool PutPatternLetter(int id, PatternLetter patternLetter)
    {
      coilTrackingContext.Entry(patternLetter).State = EntityState.Modified;

      coilTrackingContext.SaveChanges();

      return true;
    }

    /// <summary>
    /// To delete a Pattern Letter
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>

    public bool DeletePatternLetter(int id)
    {
      PatternLetter patternLetter = coilTrackingContext.PatternLetters.Find(id);

      coilTrackingContext.PatternLetters.Remove(patternLetter);
      coilTrackingContext.SaveChanges();
      return true;
    }

    /// <summary>
    /// To disable PatternLetter
    /// </summary>
    /// <param name="id"></param>
    /// <param name="disable"></param>
    /// <returns></returns>
    public bool DisablePatternLetter(int id, bool disable)
    {
      PatternLetter patternLetter = coilTrackingContext.PatternLetters.Find(id);
      patternLetter.Disabled = disable;
      coilTrackingContext.Entry(patternLetter).State = EntityState.Modified;

      coilTrackingContext.SaveChanges();
      return true;
    }

    /// <summary>
    /// To check if Pattern Letter exists
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public bool PatternLetterExists(int id)
    {
      return coilTrackingContext.PatternLetters.Count(e => e.Id == id) > 0;
    }

    /// <summary>
    /// To check if the model is modified while performing delete operation
    /// </summary>
    /// <param name="id"></param>
    /// <param name="patternLetterDto"></param>
    /// <returns></returns>
    public PatternLetter CheckEdit(int id)
    {
      PatternLetter patternLetter = coilTrackingContext.PatternLetters.Where(x => x.Id == id).FirstOrDefault();

      return patternLetter;
    }

    public PatternLetter GetPatternLetterByName(string name)
    {
      return coilTrackingContext.PatternLetters.Where(x => x.Name == name).FirstOrDefault();
    }
  }
}
