using CoilTracking.Common;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class CoilRunHistoryRepository : ICoilRunHistoryRepository
  {

    private readonly CoilTrackingContext coilTrackingContext;
    private readonly IUserHelper usersHelper;
    public CoilRunHistoryRepository(CoilTrackingContext coilTrackingContext, IUserHelper usersHelper)
    {
      this.coilTrackingContext = coilTrackingContext;
      this.usersHelper = usersHelper;
    }

    /// <summary>
    /// to get coil run history by run order list id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>coil run history</returns>
    public async Task<CoilRunHistory> GetCoilRunHistoryByRunOrderListId(int id)
    {
      return await coilTrackingContext.CoilRunHistories.Where(crh => crh.RunOrderList.Id == id).FirstOrDefaultAsync();
    }

    /// <summary>
    /// Save Coil Run Histories 
    /// </summary>
    /// <param name="runHistory"></param>
    public bool SaveCoilRunHistories(CoilRunHistory runHistory)
    {
      coilTrackingContext.CoilRunHistories.Add(runHistory);
      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.CreateEntity);
      return true;
    }
  }
}
