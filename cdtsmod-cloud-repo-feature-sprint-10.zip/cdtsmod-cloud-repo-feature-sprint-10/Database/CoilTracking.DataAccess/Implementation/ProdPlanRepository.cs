using CoilTracking.Common;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class ProdPlanRepository : IProdPlanRepository
  {
    private readonly CoilTrackingContext coilTrackingContext;
    private readonly IUserHelper usersHelper;
    public ProdPlanRepository(CoilTrackingContext coilTrackingContext, IUserHelper usersHelper)
    {
      this.coilTrackingContext = coilTrackingContext;
      this.usersHelper = usersHelper;
    }
    /// <summary>
    /// Get ProdPlan Based on Partnumber
    /// </summary>
    /// <param name="partNumber"></param>
    /// <returns></returns>
    public List<ProdPlan> GetProdPlanByPartnumberList(List<string> partnumList)
    {
      var RequestQuantity = coilTrackingContext.ProdPlans.Where(c => partnumList.Contains(c.Part.PartNumber)).Include(c=>c.Part).ToList();
      return RequestQuantity;
    }

    public List<ProdPlan> GetProdPlanByPartnumber(string PartNumber)
    {
      var RequestQuantity = coilTrackingContext.ProdPlans.Where(c => c.Part.PartNumber == PartNumber).ToList();
      return RequestQuantity;
    }

    public async Task<ProdPlan> GetProdPlanByPartBynumber(string PartNumber)
    {
      var RequestQuantity = await coilTrackingContext.ProdPlans.Include(x=>x.Part).Where(p => p.Part.PartNumber == PartNumber).FirstOrDefaultAsync();
      return RequestQuantity;
    }

    /// <summary>
    /// Get list of ProdPlan.
    /// </summary>
    /// <returns></returns>
    public async Task<List<ProdPlan>> GetProdPlans()
    {
      return await coilTrackingContext.ProdPlans
        .Include(x => x.Part)
        .ToListAsync();
    }

    /// <summary>
    /// Get ProdPlan by Id.
    /// </summary>
    /// <returns></returns>
    public async Task<ProdPlan> GetProdPlanById(int id)
    {
      return await coilTrackingContext.ProdPlans.FindAsync(id);
    }

    /// <summary>
    /// Update ProdPlan.
    /// </summary>
    /// <returns></returns>
    public async Task PutProdPlan(ProdPlan prodPlan)
    {
      coilTrackingContext.Entry(prodPlan).State = EntityState.Modified;
      await SaveChanges(AuditActionType.ModifyEntity);
    }

    /// <summary>
    /// Save changes to Database
    /// </summary>
    /// <returns></returns>
    public async Task SaveChanges(AuditActionType auditActionType)
    {
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), auditActionType);
    }

    /// <summary>
    /// Add ProdPlan.
    /// </summary>
    /// <returns></returns>
    public async Task<ProdPlan> AddProdPlan(ProdPlan prodPlan)
    {
      await coilTrackingContext.ProdPlans.AddAsync(prodPlan);
      await SaveChanges(AuditActionType.ModifyEntity);
      return prodPlan;
    }

    /// <summary>
    /// Get ProdPlanEntry by part number.
    /// </summary>
    /// <returns></returns>
    public async Task<List<ProdPlan>> GetProdPlanEntry(List<string> partNumber)
    {
      var prodPlan = await coilTrackingContext.ProdPlans
        .Include("Part")
        .Where(p => partNumber.Contains(p.Part.PartNumber))
        .ToListAsync();

      return prodPlan;
    }

    /// <summary>
    /// Add ProdPlanEntry.
    /// </summary>
    /// <returns></returns>
    public async Task AddProdPlantEntry(ProdPlan prodPlantEntry)
    {
      coilTrackingContext.Entry(prodPlantEntry.Part).State = EntityState.Unchanged;
      await coilTrackingContext.ProdPlans.AddAsync(prodPlantEntry);
      await SaveChanges(AuditActionType.CreateEntity);
    }

    /// <summary>
    /// Remove ProdPlanEntry.
    /// </summary>
    /// <returns></returns>
    public void RemoveProdPlantEntry(ProdPlan prodPlantEntry)
    {
      coilTrackingContext.ProdPlans.Remove(prodPlantEntry);
    }

    /// <summary>
    /// Update ProdPlanEntry.
    /// </summary>
    /// <returns></returns>
    public async Task UpdateProdPlantEntry(ProdPlan prodPlantEntry)
    {
      coilTrackingContext.Entry(prodPlantEntry.Part).State = EntityState.Unchanged;
      coilTrackingContext.Entry(prodPlantEntry).State = EntityState.Modified;
      await SaveChanges(AuditActionType.ModifyEntity);
    }

    /// <summary>
    /// Update ProdPlanState.
    /// </summary>
    /// <returns></returns>
    public void UpdateProdPlantState(ProdPlan prodPlantEntry)
    {
      coilTrackingContext.Entry(prodPlantEntry).State = EntityState.Unchanged;
    }

    /// <summary>
    /// Remove ProdPlan
    /// </summary>
    /// <returns></returns>
    public async Task RemoveProdPlan(ProdPlan prodPlan)
    {
      coilTrackingContext.ProdPlans.Remove(prodPlan);
      await SaveChanges(AuditActionType.ModifyEntity);
    }
  }
}
