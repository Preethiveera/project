using CoilTracking.Common;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class PatternsRepository : IPatternsRepository
  {
    private readonly CoilTrackingContext coilTrackingContext;
    private readonly IUserHelper usersHelper;
    public PatternsRepository(CoilTrackingContext coilTrackingContext, IUserHelper usersHelper)
    {
      this.coilTrackingContext = coilTrackingContext;
      this.usersHelper = usersHelper;
    }

    /// <summary>
    /// Get Patterns by pattern letter, date and line Id
    /// </summary>
    /// <param name="lineId"></param>
    /// <param name="calendarEntry"></param>
    /// <param name="date"></param>
    /// <returns>Pattern</returns>
    public async Task<Pattern> GetPatternsByLineIdPatternLetterAndDate(int lineId, string calendarEntry, DateTime date)
    {

      var pattern = await coilTrackingContext.Patterns
                           .Include(cc => cc.PatternItems)
                           .Where(p => p.Line.Id == lineId &&
                               p.Name == calendarEntry &&
                               p.CreateDate.Year == date.Year &&
                               p.CreateDate.Month == date.Month).FirstOrDefaultAsync();
      return pattern;

    }
    public Pattern GetPatternsWithPlantOPCServer(int lineId, string patternLetter, DateTime date)
    {
      var patterns = coilTrackingContext.Patterns
               .Include("PatternItems")
                             .Include("Line")
                             .Include("Line.Plant")
                             .Include("Line.Plant.TimeZone")
                             .Include("Line.OPCServer")
                             .AsNoTracking()
                             .Where(p => p.Line.Id == lineId &&
                                 p.Name == patternLetter &&
                                 p.CreateDate.Year == date.Year &&
                                 p.CreateDate.Month == date.Month).FirstOrDefault();

      return patterns;

    }


    /// <summary>
    /// Get pattern by month and year
    /// </summary>
    /// <param name="month"></param>
    /// <param name="year"></param>
    /// <returns>List of pattern</returns>
    public async Task<List<Pattern>> GetPatternByMonthAndYear(int month, int year)
    {
      return await coilTrackingContext.Patterns.Include(p => p.Line).Include(p => p.PatternItems).Where(p => p.CreateDate.Month == month && p.CreateDate.Year == year).ToListAsync();
    }

    /// <summary>
    /// Get patterns
    /// </summary>
    /// <returns>List of pattern</returns>
    public async Task<List<Pattern>> GetPatterns()
    {
      return await coilTrackingContext.Patterns.Include(x=>x.Plant).Include(x => x.Line).ToListAsync();
    }

    /// <summary>
    /// Get pattern by id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>pattern</returns>
    public async Task<Pattern> GetPatternById(int id)
    {
      return await coilTrackingContext.Patterns.Include(x => x.Line).Include(x => x.PatternItems).FirstOrDefaultAsync(p => p.Id == id);
    }

    /// <summary>
    /// Get pattern by lineId ,patternLetter, year and month
    /// </summary>
    /// <param name="lineId"></param>
    /// <param name="patternLetter"></param>
    /// <param name="year"></param>
    /// <param name="month"></param>
    /// <returns>Pattern</returns>
    public async Task<Pattern> GetPatternByLineId_PatternLetter_Year_Month(int lineId, string patternLetter, int year, int month)// Change method name
    {
      return await coilTrackingContext.Patterns
                                   .Where(p => p.Line.Id == lineId &&
                                               p.Name == patternLetter &&
                                               p.CreateDate.Year == year &&
                                               p.CreateDate.Month == month)
                                   .Include(p => p.PatternItems)
                                   .Include(p => p.Line.Plant.TimeZone)
                                   .Include(p => p.Line.OPCServer)
                                   .FirstOrDefaultAsync();
    }

    /// <summary>
    /// Get pattern items by pattern id.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>List of pattern item</returns>
    public async Task<List<PatternItem>> GetPatternsItems(int id)
    {
      var result = await coilTrackingContext.Patterns.FindAsync(id);

      return result.PatternItems;
    }


    /// <summary>
    /// Update pattern items.
    /// </summary>
    /// <param name="pattern"></param>
    /// <returns>bool</returns>
    public bool UpdatePattern(Pattern pattern)
    {
      coilTrackingContext.Entry(pattern.Line).State = EntityState.Unchanged;
      coilTrackingContext.Patterns.Update(pattern);
      return true;
    }

    /// <summary>
    /// Add pattern
    /// </summary>
    /// <param name="pattern"></param>
    /// <returns>Pattern</returns>
    public async Task<Pattern> AddPattern(Pattern pattern)
    {
      coilTrackingContext.Entry(pattern.Line.OPCServer).State = EntityState.Unchanged;
      coilTrackingContext.Entry(pattern.Line.Plant.TimeZone).State = EntityState.Unchanged;
      coilTrackingContext.Entry(pattern.Line.Plant).State = EntityState.Unchanged;
      coilTrackingContext.Entry(pattern.Line).State = EntityState.Unchanged;
      coilTrackingContext.Entry(pattern.Plant).State = EntityState.Unchanged;
      await coilTrackingContext.Patterns.AddAsync(pattern);
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.ModifyPattern);
      return pattern;
    }

    /// <summary>
    /// Remove pattern
    /// </summary>
    /// <param name="pattern"></param>
    /// <returns>bool</returns>
    public async Task<bool> RemovePattern(Pattern pattern)
    {
      coilTrackingContext.Patterns.Remove(pattern);
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
      return true;
    }

    /// <summary>
    /// SaveChangesAsync
    /// </summary>
    /// <param name="auditAction"></param>
    /// <returns></returns>
    public async Task SaveChangesAsync(AuditActionType auditAction)
    {
      await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), auditAction);
    }

    /// <summary>
    /// Check is pattern exists
    /// </summary>
    /// <param name="lineId"></param>
    public async Task<bool> PatternExists(int lineId)
    {
      return await coilTrackingContext.Patterns.AnyAsync(x => x.Line.Id == lineId);
    }

    /// <summary>
    /// Get patterns by Line Id
    /// </summary>
    /// <param name="lineId"></param>
    public async Task<List<Pattern>> GetPatternByLineId(int lineId)
    {
      return await coilTrackingContext.Patterns
        .Include(y => y.PatternItems)
        .Where(x => x.Line.Id == lineId)
        .ToListAsync();
    }
  }
}
