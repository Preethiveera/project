using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class AuditLogsRepository : IAuditLogsRepository
  {
    private readonly CoilTrackingContext coilTrackingContext;

    public AuditLogsRepository(CoilTrackingContext coilTrackingContext)
    {
      this.coilTrackingContext = coilTrackingContext;
    }

    public AuditLog AuditLogExist(int Id)
    {
      return coilTrackingContext.AuditLogs.Where(l => l.Id == Id).SingleOrDefault();
    }
    /// <summary>
    /// Get the records of events and changes
    /// </summary>
    /// <returns>audit logs</returns>
    public List<AuditLog> GetAuditLogs()
    {
      return coilTrackingContext.AuditLogs.ToList();
    }
    /// <summary>
    /// Get UserNameAudits
    /// </summary>
    /// <returns></returns>
    public  List<string> GetUserNameAudits()
    {
      var name =  coilTrackingContext.AuditLogs.Select(x=>x.UserName).Distinct().ToList();
      return name;
    }

    /// <summary>
    /// Search for a record of events and changes
    /// </summary>
    /// <param name="startTime"></param>
    /// <param name="endTime"></param>
    /// <param name="username"></param>
    /// <param name="actionType"></param>
    /// <param name="className"></param>
    /// <returns> audit Logs</returns>
    public List<AuditLog> Search(DateTime? startTime = null, DateTime? endTime = null, string username = null, int? actionType = null, string className = null)
    {
      List<AuditLog> logs ;
      if (username == null && actionType == null)
      {
        logs = coilTrackingContext.AuditLogs.Where(al => (!startTime.HasValue || al.ActionTime >= startTime)
                                   && (!endTime.HasValue || al.ActionTime <= endTime)
                                   && (username == null || al.UserName.Contains(username))
                                   && (actionType == null || al.ActionType == (AuditActionType)actionType.Value)
                                   && (className == null || al.Log.StartsWith(className)))
                      .OrderBy(al => al.ActionTime).Take(500).ToList();

      }
      else
      {
        logs = coilTrackingContext.AuditLogs.Where(al => (!startTime.HasValue || al.ActionTime >= startTime)
                                    && (!endTime.HasValue || al.ActionTime <= endTime)
                                    && (username == null || al.UserName.Contains(username))
                                    && (actionType == null || al.ActionType == (AuditActionType)actionType.Value)
                                    && (className == null || al.Log.StartsWith(className)))
                        .OrderBy(al => al.ActionTime).ToList();
      }
      return logs;
    }
  }
}
