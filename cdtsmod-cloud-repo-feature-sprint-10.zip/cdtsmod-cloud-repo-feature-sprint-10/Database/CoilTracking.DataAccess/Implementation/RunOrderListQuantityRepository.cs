using CoilTracking.Common;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class RunOrderListQuantityRepository : IRunOrderListQuantityRepository
  {
    private readonly CoilTrackingContext coilTrackingContext;
    private readonly IUserHelper usersHelper;
    public RunOrderListQuantityRepository(CoilTrackingContext coilTrackingContext, IUserHelper usersHelper)
    {
      this.coilTrackingContext = coilTrackingContext;
      this.usersHelper = usersHelper;
    }
    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public async Task<List<RunOrderListQuantity>> GetRunOrderListQuantities()
    {
      var rr = await coilTrackingContext.RunOrderListQuantities.ToListAsync();
      return rr;
    }

    /// <summary>
    /// Get RunOrderListQuantity Based on ID
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public RunOrderListQuantity GetRunOrderListQuantityById(int id)
    {
      var runOrderListQuantity = coilTrackingContext.RunOrderListQuantities.Find(id);
      return runOrderListQuantity;
    }

    /// <summary>
    /// Get run order list quantities by quantity ids
    /// </summary>
    /// <param name="ids"></param>
    /// <returns></returns>
    public List<RunOrderListQuantity> GetRunOrderListQuantityByQtyIdList(List<int> ids)
    {
      return coilTrackingContext.RunOrderListQuantities.Where(x => ids.Contains(x.Id)).ToList();
    }

    public List<RunOrderListQuantity> GetRunOrderListQuantityByListBlankInfo(List<BlankInfo> blankInfo)
    {
      var blanks = blankInfo.Select(k => k.Id).ToList();
      return coilTrackingContext.RunOrderListQuantities.Include(x=>x.BlankInfo).Where(ct => blanks.Contains(ct.Id)).ToList();
    }
    /// <summary>
    /// validation RunOrderListQuantity 
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>

    public bool IsRunOrderListQuantityExists(int id)
    {
      return coilTrackingContext.RunOrderListQuantities.Count(e => e.Id == id) > 0;
    }
    /// <summary>
    /// Modify RunOrderListQuantity Record
    /// </summary>
    /// <param name="runOrderListQuantity"></param>
    public void ModifyRunOrderListQuantity(RunOrderListQuantity runOrderListQuantity)
    {
      coilTrackingContext.Entry(runOrderListQuantity).State = EntityState.Modified;
    }

    /// <summary>
    ///   RunOrderListQuantity Save Change
    /// </summary>
    /// <param name="runOrderListQuantity"></param>
    /// <returns></returns>
    public bool RunOrderListQuantitySaveChanges()
    {
      try
      {
        coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyEntity);

      }
      catch (Exception)
      {
        throw;
      }
      return true;
    }
    /// <summary>
    /// Insert New Record RunOrderListQuantity
    /// </summary>
    /// <param name="runOrderListQuantity"></param>
    public void InsertRunOrderListQuantity(RunOrderListQuantity runOrderListQuantity)
    {
      coilTrackingContext.RunOrderListQuantities.Add(runOrderListQuantity);
      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
    }

    /// <summary>
    /// Deletion of RunOrderListQuantity 
    /// </summary>
    /// <param name="runOrderListQuantity"></param>
    public void DeleteRunOrderListQuantityById(RunOrderListQuantity runOrderListQuantity)
    {
      coilTrackingContext.RunOrderListQuantities.Remove(runOrderListQuantity);
      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
    }

    /// <summary>
    /// Remove list of runOrderList quantities
    /// </summary>
    /// <param name="qty"></param>
    public void RemoveRunOrderQtyList(List<RunOrderListQuantity> qty)
    {
      coilTrackingContext.RunOrderListQuantities.RemoveRange(qty);
      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
    }
  }
}
