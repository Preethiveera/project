using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class CoilTypeYNARepository : ICoilTypeYNARepository
  {
    private readonly CoilTrackingContext coilTrackingContext;

    public CoilTypeYNARepository(CoilTrackingContext coilTrackingContext)
    {
      this.coilTrackingContext = coilTrackingContext;
    }

    /// <summary>
    /// Get CoilTypeYNAs By YNA
    /// </summary>
    /// <param name="coilTypeYNA"></param>
    /// <returns></returns>
    public List<CoilTypeYNA> GetCoilTypeYNAsByYNA(List<CoilTypeYNA> coilTypeYNA)
    {
      var coilTypeYNAs = coilTypeYNA.Select(k => k.Id).ToList();
      return coilTrackingContext.CoilTypeYNAs.Where(ct => coilTypeYNAs.Contains(ct.Id)).ToList();
    }
    /// <summary>
    /// Get CoilType By RecordyNumber
    /// </summary>
    /// <param name="yNumber"></param>
    /// <returns></returns>
    public CoilType GetCoilTypeByRecordNumber(string yNumber)
    {

      var coils = coilTrackingContext.CoilTypeYNAs
                            .Include(cty => cty.CoilType.CoilFieldZone)
                             .Where(cty => cty.YNA == yNumber)
                             .Select(cty => cty.CoilType)
                             .FirstOrDefault();
      return coils;
    }
    /// <summary>
    /// Get CoilTypeYNAs By yNumber and coilTypeName
    /// </summary>
    /// <param name="coilTypeName"></param>
    /// <param name="yNumber"></param>
    /// <returns></returns>
    public CoilTypeYNA GetCoilTypeYNAByNumberWithcoilTypeName(string coilTypeName, string yNumber)
    {
      return coilTrackingContext.CoilTypeYNAs.Where(cty => cty.CoilType.Name == coilTypeName && cty.YNA == yNumber).Include(cty => cty.CoilType).FirstOrDefault();

    }
    /// <summary>
    /// Get coilTypeYNAs AlreadyExists Diff CoilType
    /// </summary>
    /// <param name="coilTypeName"></param>
    /// <param name="yNumber"></param>
    /// <returns></returns>
    public CoilTypeYNA GetcoilTypeYNAAlreadyExistsDiffCoilType(string coilTypeName, string yNumber)
    {
      return coilTrackingContext.CoilTypeYNAs.Include(cty => cty.CoilType).Where(cty => cty.YNA == yNumber && !cty.Disabled && cty.CoilType.Name != coilTypeName).FirstOrDefault();
    }
    /// <summary>
    /// Get Coils  MaterialType Based on  YNA
    /// </summary>
    /// <param name="yna"></param>
    /// <returns></returns>
    public async Task<string> GetMaterialTypeByYNA(string yna)
    {
      var materialType = await coilTrackingContext.CoilTypeYNAs.Where(y => y.YNA == yna).Select(y => y.MaterialType.Id.ToString()).FirstOrDefaultAsync();

      return materialType;
    }
    /// <summary>
    /// Get coilTypeYNA By YNANo
    /// </summary>
    /// <param name="YNANo"></param>
    /// <returns></returns>
    public CoilTypeYNA GetcoilTypeYNAsByYNANo(string YNANo)
    {
      CoilTypeYNA ynaNos = null;
      try
      {
         ynaNos = coilTrackingContext.CoilTypeYNAs.Where(cty => cty.YNA == YNANo && !cty.Disabled).Include(cty => cty.CoilType).FirstOrDefault();
        return ynaNos;
      }
      catch (Exception)
      {
        throw;
      }
     
    }
    public bool IscoilTypeYNAsByYNANo(string YNANo)
    {
      return coilTrackingContext.CoilTypeYNAs.Any(cty => cty.YNA == YNANo && cty.Disabled);
    }
  }
}
