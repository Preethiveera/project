using CoilTracking.Common;
using CoilTracking.Common.Constant;
using CoilTracking.Common.Constants;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class CoilRepository : ICoilRepository
  {
    private readonly CoilTrackingContext coilTrackingContext;
    private readonly IUserHelper usersHelper;
    public CoilRepository(CoilTrackingContext coilTrackingContext, IUserHelper usersHelper)
    {
      this.coilTrackingContext = coilTrackingContext;
      this.usersHelper = usersHelper;
    }

    /// <summary>
    /// Getting the list of coils which is present in various location based on zoneid
    /// </summary>
    /// <param name="zoneId"></param>
    /// <returns></returns>
    public List<Coil> GetCoilsFeildsByZoneId(int? zoneId)
    {
      //Get the list of all coils that are placed in a location to avoid querying the DB many times in the loops below
      List<Data.Models.Coil> coilsInField = coilTrackingContext.Coils.Include(c => c.CoilFieldLocation).ThenInclude(x=>x.Zone)
                                                    .Include(c => c.CoilType)
                                                    .Include(c => c.CoilStatus)
                                                    .Where(c => c.CoilFieldLocation != null &&  (c.CoilFieldLocation_Id !=null) && (!zoneId.HasValue || c.CoilFieldLocation.Zone.Id == zoneId.Value)).ToList();

      var coils = coilsInField.Where(c => c.CoilFieldLocation != null).ToList();
      return coils;
    }

    /// <summary>
    /// Get list of coils in inventory
    /// </summary>
    /// <param name="coilTypesList"></param>
    /// <returns>coils/returns>
    public List<Coil> GetCoilsList(List<int> coilTypesList)
    {
      return coilTrackingContext.Coils.Include(c => c.CoilStatus).Include(c => c.CoilType).Include(c => c.CoilRunHistory)
        .Where(c => coilTypesList.Contains(c.CoilType.Id) && !c.CoilStatus.Name.Contains(Constant.rejected)
          && c.CoilStatus.InInventory).ToList();

    }

    /// <summary>
    /// Get the list of coil deatils based on CoilFieldLocation
    /// </summary>
    /// <param name="dbLocationId"></param>
    /// <param name="coilsInField"></param>
    /// <returns></returns>
    public Coil CoilFieldLocation(CoilFieldLocation dbLocationId, List<Coil> coilsInField)
    {

      return coilsInField.FirstOrDefault(c => c.CoilFieldLocation.Id == dbLocationId.Id);

    }

    /// <summary>
    /// Get the list of AndonCoilTypeLocation based on CoilFieldZone,Coil and CoilTypeID
    /// </summary>
    /// <param name="dbLocationId"></param>
    /// <param name="coilsOnHand"></param>
    /// <param name="dbCoilTypeId"></param>
    /// <returns></returns>
    public List<AndonCoilTypeLocation> GetCoilLocationsInOrder(CoilFieldZone dbLocationId, List<Data.Models.Coil> coilsOnHand)
    {

      var CoilTypeId = coilsOnHand.Select(k => k.CoilType.Id).ToList();
      var AndonCoilType = coilsOnHand.Where(c => CoilTypeId.Contains(c.CoilType.Id)
                                            && (c.CoilFieldLocation != null
                                            && c.CoilFieldLocation.Zone.Id == dbLocationId.Id)
                                           )
          .OrderBy(c => c.IsPriority)
          .ThenByDescending(c => c.CheckInDate).Select(c => new AndonCoilTypeLocation()
          {
            Name = c.CoilFieldLocation.Name,
            CoilId = c.Id,
            BackgroundColor = c.CoilStatus.Color,
            TextColor = c.CoilStatus.TextColor
          }).ToList();
      //Andon logic is backwards, we want newest first to the left, oldest to the right
      return AndonCoilType;
    }
    /// <summary>
    /// Get the list of coils details based on kancoilid 
    /// </summary>
    /// <param name="kanCoilId"></param>
    /// <returns></returns>
    public List<Coil> GetKanCoils()
    {
      return coilTrackingContext.Coils.Include(c => c.CoilStatus).ToList();
    }
    /// <summary>
    /// Get CoilType Based on Blankinfo
    /// </summary>
    /// <param name="blanks"></param>
    /// <returns></returns>
    public List<Coil> GetCoilTypeByBlanks(List<BlankInfo> blanks)
    {
      var CoilTypes = blanks.Select(k => k.CoilType.Id).Distinct().ToList();
      var coil = coilTrackingContext.Coils.Include(x=>x.CoilType).Include(y=>y.CoilRunHistory).Include(v=>v.CoilStatus).Where(ct => CoilTypes.Contains(ct.CoilType.Id)).ToList();

      return coil;
    }
    /// <summary>
    /// Getting Partials Coils
    /// </summary>
    /// <returns></returns>
    public IQueryable<Coil> GetPartialsCoils()
    {
      //Add all partial coils that are not partials from Runs
      var partials = coilTrackingContext.Coils
          .Include(c => c.CoilType)
          .Include(c => c.CoilRunHistory)
          .Include(c => c.CoilFieldLocation)
          .Include(c => c.CoilFieldLocation.Zone);
      return partials;



    }
    /// <summary>
    /// Getting Coil RunHistory Based on Ids
    /// </summary>
    /// <param name="partials"></param>
    /// <returns></returns>
    public List<Coil> GetCoilRunHistoryByIds(List<int> ids)
    {
      var coilRunHistory = coilTrackingContext.Coils.Where(x => ids.Contains(x.Id)).ToList();
      return coilRunHistory;
    }
    /// <summary>
    /// Find Coils By Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<Coil> GetCoilId(int id)
    {
      var CoilId = await coilTrackingContext.Coils.AsNoTracking().Include(x=>x.CoilStatus).Include(y=>y.CoilType).Where(x => x.Id == id).FirstOrDefaultAsync();
      return CoilId;
    }

    /// <summary>
    /// Getting the Count of coils 
    /// </summary>
    /// <returns></returns>
    public int GetCountOfCoils()
    {
      return coilTrackingContext.Coils.Count();
    }
    /// <summary>
    /// Getting Coils Current Weight Based on Id
    /// </summary>
    /// <param name="CoilId"></param>
    /// <returns></returns>
    /// //GetCoilswithAllInfo
    public Coil GetCoilsWithAllInfo(int CoilId)
    {
      //Add all partial coils that are not partials from Runs
      Coil CurrentWeightCoils = coilTrackingContext.Coils
               .Include(c => c.CoilRunHistory)
               .Include(c => c.CoilType)
               .Include(c => c.CoilStatus)
               .Include(c => c.Mill)
               .Include(c => c.CoilFieldLocation)
               .Where(c => c.Id == CoilId)
               .FirstOrDefault();
      return CurrentWeightCoils;

    }

    /// <summary>
    /// Get Associated coils for a   Mill
    /// </summary>
    /// <param name="id"></param>
    /// <returns>coils</returns>
    public List<Coil> GetCoilsByMillId(int id)
    {
      List<Coil> coils = coilTrackingContext.Coils.Select(x => x)
        .Include(x => x.Mill)
        .Include(x => x.CoilStatus)
        .Include(x => x.CoilFieldLocation)
        .Include(x => x.CoilType)
        .Where(x => x.Mill.Id == id).ToList();
      return coils;
    }

    /// <summary>
    /// Get coils with status Loaded at line
    /// </summary>
    /// <param name="id"></param>
    /// <returns>coils</returns>
    public List<Coil> GetLoadedCoilsById(int id)
    {

      return coilTrackingContext.Coils
        .Include(x => x.Mill)
        .Include(x => x.CoilStatus)
        .Include(x => x.CoilFieldLocation)
        .Include(x => x.CoilType)
        .Where(c => c.Mill.Id == id && (c.CoilStatus.Name == CoilStatusName.LoadedAtLine || c.CoilStatus.Id == Convert.ToInt32(CoilStatusNames.LoadedatLine))).ToList();

    }

    /// <summary>
    /// Check if mill id is present in CoilMoveRequest
    /// </summary>
    /// <param name="id"></param>
    /// <returns>bool</returns>
    public bool IsmillIdPresentInCoilMoveRequest(int id)

    {
      if (coilTrackingContext.CoilMoveRequests.Any(c => c.Coil.Mill.Id == id && c.RequestType == CoilMoveRequestType.CoilRequest && c.Fulfilled == null))
      {
        return true;
      }
      return false;
    }

    /// <summary>
    /// Get the coils by coil field Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>coils</returns>
    public List<Coil> GetCoilsByCoilField(int id)
    {
      var coils = coilTrackingContext.Coils.Where(c => c.CoilFieldLocation.Zone.CoilField.Id == id).ToList();
      return coils;
    }
    /// <summary>
    /// Get Associated CoilType Based On Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>//changes 
    public async Task<List<Coil>> GetCoilsByCoilTypeId(int id)
    {
      var coils = await coilTrackingContext.Coils.Include(y=>y.CoilType).Include(c=>c.CoilRunHistory).Select(x => x).Distinct().Where(x => x.CoilType.Id == id).ToListAsync();
      return coils;
    }
    /// <summary>
    /// Get Coils Loaded For CoilType Based on Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<List<Coil>> GetCoilsLoadedById(int id)
    {
      var coils = await coilTrackingContext.Coils.Where(c => c.CoilType.Id == id && (c.CoilStatus.Name == Constant.loadedatLine || c.CoilStatus.Id == 8)).ToListAsync();
      return coils;
    }
    /// <summary>
    /// Get Coil With CoilField
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public Coil GetCoilWithCoilField(int id)
    {
      return coilTrackingContext.Coils.AsNoTracking().Include(c => c.CoilFieldLocation).Where(c => c.Id == id).FirstOrDefault();
    }

    /// <summary>
    /// GetCoil By LocationId
    /// </summary>
    /// <param name="locationId"></param>
    /// <returns></returns>
    public List<Coil> GetCoilByLocationId(int locationId)
    {
      return coilTrackingContext.Coils.Include(c => c.CoilFieldLocation).Where(c => c.CoilFieldLocation.Id == locationId).ToList();
    }
    /// <summary>
    /// Get Coils
    /// </summary>
    /// <returns></returns>
    public async Task<IQueryable<Coil>> GetCoils()
    {
      //Get coils
      var coils = await coilTrackingContext.Coils
           .Include(c => c.Mill)
                .Include(c => c.CoilType).Include(x => x.CoilType.CoilTypeYNAs)
                .Include(c => c.CoilStatus)
                .Include(c => c.CoilFieldLocation.Zone)
                .Include(c => c.CoilRunHistory).ToListAsync();
      return coils.AsQueryable();
    }

    /// <summary>
    /// GetCoils To Move
    /// </summary>
    /// <param name="coilTypeId"></param>
    /// <param name="unfulfilledCoilIds"></param>
    /// <returns></returns>
    public async Task<List<Coil>> GetCoilsToMove(int coilTypeId, List<int> unfulfilledCoilIds)
    {
      var coilsToMove = await coilTrackingContext.Coils.Include(c => c.CoilStatus)
                       .Where(c => c.CoilType.Id == coilTypeId //Get coils matching coilType,
                                && !unfulfilledCoilIds.Contains(c.Id) //and not having an existing unfulfilled move request
                                && c.CoilStatus.IsUsable) //And coil status indicates the coil is usable
                       .OrderByDescending(c => c.IsPriority) //Order by priority coils first, then CheckinDate
                       .ThenBy(c => c.CheckInDate).ToListAsync();

      return coilsToMove;
    }
    /// <summary>
    /// Get Coil To Move By CoilId
    /// </summary>
    /// <param name="coilId"></param>
    /// <returns></returns>
    public async Task<Coil> GetCoilToMoveByCoilId(int coilId)
    {
      var coilToMove = await coilTrackingContext.Coils.Where(c => c.Id == coilId).FirstOrDefaultAsync();
      return coilToMove;
    }

    /// <summary>
    /// Get Coils For Search
    /// </summary>
    /// <param name="startTime"></param>
    /// <param name="endTime"></param>
    /// <param name="coilType"></param>
    /// <param name="coilStatusId"></param>
    /// <param name="zoneId"></param>
    /// <param name="FilterByBornOnDate"></param>
    /// <returns></returns>
    public async Task<List<Coil>> GetCoilsForSearch(DateTime? startTime = null, DateTime? endTime = null, string coilType = null, int? coilStatusId = null, int? zoneId = null, string FilterByBornOnDate = "0")
    {
      var coils = await coilTrackingContext.Coils.Where(c =>  (coilType == null || c.CoilType.Name == coilType)
                                                && (!coilStatusId.HasValue || c.CoilStatus.Id == coilStatusId)
                                                && (!zoneId.HasValue || c.CoilFieldLocation.Zone.Id == zoneId)
                                                  )
                                      .Include(c => c.Mill)
                                      .Include(c => c.CoilType)
                                      .Include(c => c.CoilType.CoilFieldZone)
                                      .Include(c => c.CoilStatus)
                                      .Include(c => c.CoilFieldLocation)
                                      .Include(c => c.CoilFieldLocation.Zone)
                                      .Include(c => c.CoilRunHistory).ToListAsync();
      return coils;
    }

    /// <summary>
    /// Get Coils By InInventory
    /// </summary>
    /// <returns></returns>
    public async Task<List<Coil>> GetCoilsByInInventory()
    {
      //Get a list of coils in inventory
      var coilsInInventory = await coilTrackingContext.Coils.Include(c => c.Mill)
                                     .Include(c => c.CoilType)
                                     .Include(c => c.CoilStatus)
                                     .Include(c => c.CoilFieldLocation.Zone)
                                     .Include(c => c.CoilRunHistory)
                                     .Where(c => c.CoilStatus.InInventory)
                                     .ToListAsync();

      return coilsInInventory;
    }

    /// <summary>
    /// Get CoilsType RunHistory By Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<Coil> GetCoilsByIdWithTypeRunHistory(int id)
    {
      var coil = await coilTrackingContext.Coils
                                .Include(c => c.CoilType)
                                .Include(c => c.CoilRunHistory)
                                .Where(c => c.Id == id).FirstOrDefaultAsync();
      return coil;
    }

    /// <summary>
    /// Get Coils By FTZ
    /// </summary>
    /// <param name="ftz"></param>
    /// <returns></returns>
    public async Task<Coil> GetCoilsByFTZ(string ftz)
    {
      var coil = await coilTrackingContext.Coils
                               .Include(c => c.Mill)
                               .Include(c => c.CoilType)
                               .Include(c => c.CoilType.CoilFieldZone)
                               .Include(c => c.CoilStatus)
                               .Include(c => c.CoilFieldLocation)
                               .Include(c => c.CoilFieldLocation.Zone)
                               .Include(c => c.CoilRunHistory)
                                    .Where(c => c.FTZ == ftz).FirstOrDefaultAsync();
      return coil;
    }




    /// <summary>
    /// Get Coils By PrefixFtz
    /// </summary>
    /// <param name="sPrefixFtz"></param>
    /// <param name="tPrefixFtz"></param>
    /// <returns></returns>
    public async Task<Coil> GetCoilsByPrefixFtz(string sPrefixFtz, string tPrefixFtz)
    {
      var coil = await coilTrackingContext.Coils
                                    .Include(c => c.Mill)
                                    .Include(c => c.CoilType)
                                    .Include(c => c.CoilType.CoilFieldZone)
                                    .Include(c => c.CoilStatus)
                                    .Include(c => c.CoilFieldLocation)
                                    .Include(c => c.CoilFieldLocation.Zone)
                                    .Include(c => c.CoilRunHistory)
                                    .Where(c => c.FTZ == sPrefixFtz ||
                                                c.FTZ == tPrefixFtz).FirstOrDefaultAsync();
      return coil;
    }


    /// <summary>
    /// Get Coils By PrefixFtz
    /// </summary>
    /// <param name="sPrefixFtz"></param>
    /// <param name="tPrefixFtz"></param>
    /// <returns></returns>
    public async Task<List<Coil>> GetRunResultCoilsByPrefixFtz(string sPrefixFtz, string tPrefixFtz)
    { //Add all partial coils that are not partials from Runs
      var coil = await coilTrackingContext.Coils
                .Include(c => c.CoilType)
                .Include(c => c.CoilRunHistory)
                .Include(c => c.CoilFieldLocation)
                .Include(c => c.CoilFieldLocation.Zone)
                .Where(c => (c.CoilStatus.Name == CoilStatusName.Partial || c.CoilStatus.Name == CoilStatusName.PartialNeedsWeighed)
                 && (c.FTZ == sPrefixFtz || c.FTZ == tPrefixFtz))
                .ToListAsync();
      return coil;
    }


    public async Task<List<Coil>> GetRunResultCoilsByFtz(string ftz)
    { //Add all partial coils that are not partials from Runs
      var coil = await coilTrackingContext.Coils
                .Include(c => c.CoilType)
                .Include(c => c.CoilRunHistory)
                .Include(c => c.CoilFieldLocation)
                .Include(c => c.CoilFieldLocation.Zone)
                .Where(c => (c.CoilStatus.Name == CoilStatusName.Partial || c.CoilStatus.Name == CoilStatusName.PartialNeedsWeighed)
                 && c.FTZ == ftz)
                .ToListAsync();
      return coil;
    }





    /// <summary>
    /// Get Coils Based on CoilFieldLocation ID
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<Coil> GetCoilsByLocationId(int id)
    {
      Coil coil = await coilTrackingContext.Coils
                               .Include(c => c.Mill)
                               .Include(c => c.CoilType)
                               .Include(c => c.CoilType.CoilFieldZone)
                               .Include(c => c.CoilStatus)
                               .Include(c => c.CoilFieldLocation)
                               .Include(c => c.CoilFieldLocation.Zone)
                               .Include(c => c.CoilRunHistory)
                               .Where(c => c.CoilFieldLocation.Id == id).FirstOrDefaultAsync();

      return coil;

    }

    /// <summary>
    /// Get Coil By ID
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<Coil> GetCoilsById(int id)
    {
      Coil coil = await coilTrackingContext.Coils.AsNoTracking()
                               .Include(c => c.Mill)
                                .Include(c => c.CoilType)
                                .Include(c => c.CoilType.CoilFieldZone)
                                .Include(c => c.CoilStatus)
                                .Include(c => c.CoilFieldLocation)
                                .Include(c => c.CoilFieldLocation.Zone)
                                .Include(c => c.CoilRunHistory)
                                .Where(c => c.Id == id).FirstOrDefaultAsync();


      return coil;

    }

    /// <summary>
    /// Get Coil By ID
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<Coil> GetCoilsIds(int id)
    {
      Coil coil = await coilTrackingContext.Coils.AsNoTracking()
               .Include(c => c.CoilType)
               .Include(c => c.CoilRunHistory).AsNoTracking()
               .Include(c => c.CoilFieldLocation.Zone)
               .Where(c => c.Id == id)
               .FirstOrDefaultAsync();
      return coil;
    }

    /// <summary>
    /// Get Coils Based on CoilStatus Names
    /// </summary>
    /// <param name="PartialNeedsWeighed"></param>
    /// <returns></returns>
    public async Task<List<Coil>> GetCoilsByCoilStatusName(string Name)
    {
      var coils = await coilTrackingContext.Coils
                .Include(c => c.Mill)
                .Include(c => c.CoilType)
                .Include(c => c.CoilFieldLocation.Zone)
                .Where(c => c.CoilStatus.Name == Name).ToListAsync();
      return coils;
    }

    /// <summary>
    /// Get Coils By coilTypeInInventory
    /// </summary>
    /// <param name="coilTypeId"></param>
    /// <returns></returns>
    /// //CoilsInventoryBYtypeId
    public async Task<List<Coil>> CoilsInventoryBYTypeId(int coilTypeId)
    {
      List<Coil> coils = await coilTrackingContext.Coils.Include(c => c.CoilStatus)
                                       .Include(c => c.CoilRunHistory)
                                       .Where(c => c.CoilType.Id == coilTypeId && c.CoilStatus.InInventory && !c.CoilStatus.Name.Contains(Constant.rejected)).ToListAsync();

      return coils;
    }

    /// <summary>
    /// Get coils by zone id.
    /// </summary>
    /// <param name="zoneId"></param>
    /// <returns>returns the list of Coils</returns>
    public async Task<List<Coil>> GetCoilsByZoneId(int zoneId)
    {
      return await coilTrackingContext.Coils.Where(c => c.CoilFieldLocation.Zone.Id == zoneId).ToListAsync();
    }

    /// <summary>
    /// Deletion of Coil info
    /// </summary>
    /// <param name="coil"></param>
    public async Task<int> DeleteCoil(Coil coil)
    {
      coilTrackingContext.Coils.Remove(coil);
      var result = await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.Checkin);
      return result;
    }

    /// <summary>
    ///Insertion of Coil info
    /// </summary>
    /// <param name="coil"></param>
    public async Task<int> InsertCoil(Coil coil)
    {
      var millName = coil.Mill.Name;
      var mil =  coilTrackingContext.Mills.AsNoTracking().Where(m => m.Name == millName).FirstOrDefault();
      if (mil != null)
      {
        coil.Mill.Id = mil.Id;
        coilTrackingContext.Entry(coil.Mill).State = EntityState.Unchanged;
        coilTrackingContext.Coils.Add(coil);
        var result = await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.Checkin);
        return result;

      }
      else
      {
        coilTrackingContext.Coils.Add(coil);
        var result = await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.Checkin);
        return result;
      }
    }

    /// <summary>
    ///Insertion of Coil info
    /// </summary>
    /// <param name="coil"></param>
    public async Task<int> ModifyCoil(Coil coil)
    {
      coilTrackingContext.Entry(coil).State = EntityState.Modified;
      var result = await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.Checkin);
      return result;
    }
    /// <summary>
    /// Get CoilStatus By CoilId
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<Coil> GetCoilStatusByCoilId(int id)
    {
      Coil coilUpdated = await coilTrackingContext.Coils
            .Include(c => c.CoilStatus)
            .Where(c => c.Id == id).FirstOrDefaultAsync();
      return coilUpdated;
    }
    /// <summary>
    /// Update CoilStatus
    /// </summary>
    /// <param name="coil"></param>
    /// <returns></returns>
    public async Task<int> UpdateCoilStatus(Coil coil)
    {
      coilTrackingContext.Entry(coil.CoilStatus).State = EntityState.Unchanged;
      coilTrackingContext.Entry(coil).State = EntityState.Modified;
      var result = await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
      return result;
    }
    /// <summary>
    /// UpdateCoils
    /// </summary>
    /// <param name="coil"></param>
    public async Task<int>  UpdateCoils(Coil coil)
    {
      if (coil.CoilFieldLocation == null)
      {
        coil.CoilFieldLocation_Id = null;
      }
      else { coil.CoilFieldLocation_Id = coil.CoilFieldLocation.Id; }
     
      coilTrackingContext.Entry(coil.Mill).State = EntityState.Modified;
      coilTrackingContext.Entry(coil.CoilStatus).State = EntityState.Modified;
      coilTrackingContext.Entry(coil).State = EntityState.Modified;

      var res =   await  coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
      return res;
    }
    /// <summary>
    /// coilUpdated For CoilRunHistory
    /// </summary>
    /// <param name="coilUpdated"></param>
    /// <returns></returns>
    /// //UpdateCoilForRunHistory
    public async Task<int> UpdateCoilForRunHistory(Coil coilUpdated)
    {
      coilTrackingContext.Entry(coilUpdated.CoilType).State = EntityState.Unchanged;
      coilTrackingContext.Entry(coilUpdated.Mill).State = EntityState.Unchanged;
      coilTrackingContext.Entry(coilUpdated).State = EntityState.Modified;
      var result = await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
      return result;

    }

    /// <summary>
    ///Coil Save Changes
    /// </summary>
    /// <returns></returns>
    public async Task<int> CoilSaveChanges(Coil coil)
    {
      coilTrackingContext.Entry(coil).State = EntityState.Modified;
      var result = await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.CoilMove);
      return result;
    }




  }
}

