using CoilTracking.Common;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.DataAccess.Implementation
{
  public class CoilTypeRepository : ICoilTypeRepository
  {
    private readonly CoilTrackingContext coilTrackingContext;
    private readonly IUserHelper usersHelper;
    public CoilTypeRepository(CoilTrackingContext coilTrackingContext, IUserHelper usersHelper)
    {
      this.coilTrackingContext = coilTrackingContext;
      this.usersHelper = usersHelper;
    }

    /// <summary>
    /// Get  list of dbCoilTypes based on CoilFieldZoneID
    /// </summary>
    /// <param name="dbZoneId"></param>
    /// <returns></returns>
    public List<CoilType> GetdbCoilTypes(List<CoilFieldZone> coilField)
    {
      var fieldLocation = coilField.Select(k => k.Id).ToList();
      return coilTrackingContext.CoilTypes.Include(x=>x.CoilFieldZone).ThenInclude(y=>y.CoilField.Zones).Where(ct => fieldLocation.Contains(ct.CoilFieldZone.Id) && (!ct.Disabled)).OrderBy(ct => ct.Name).ToList();

    }

    /// <summary>
    /// Get List of CoilType 
    /// </summary>
    /// <param name="coilTypeName"></param>
    /// <returns></returns>
    public List<CoilType> GetCoilTypes()
    {
      return coilTrackingContext.Coils.Select(x => x.CoilType).ToList();
    }

    public int GetCountIfCoilTypes()
    {
      return coilTrackingContext.CoilTypes.Count();
    }

    /// <summary>
    /// Get CoilType based on Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public CoilType GetCoilTypeById(int id)
    {
      var CoilTypesId = coilTrackingContext.CoilTypes.AsNoTracking().Where(x=>x.Id == id).FirstOrDefault();
      return CoilTypesId;
    }

    /// <summary>
    /// Deletion of CoilType
    /// </summary>
    /// <param name="coilType"></param>
    public void DeleteCoilType(CoilType coilType)
    {
      coilTrackingContext.CoilTypes.Remove(coilType);
      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
    }

    /// <summary>
    /// Deletion of CoilType
    /// </summary>
    /// <param name="coilType"></param>
    public void RemoveCoilType(CoilType coilType)
    {
      coilTrackingContext.CoilTypes.Remove(coilType);
    }
    /// <summary>
    /// Insertion of CoilType
    /// </summary>
    /// <param name="coilType"></param>
    public void InsertCoilType(CoilType coilType)
    {
      coilTrackingContext.CoilTypes.Add(coilType);
      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
    }

    /// <summary>
    /// Insertion of CoilType
    /// </summary>
    /// <param name="coilType"></param>
    public void  AddCoilType(CoilType coilType)
    {
      coilTrackingContext.CoilTypes.Add(coilType);
    }
    /// <summary>
    /// Insertion of CoilType
    /// </summary>
    /// <param name="coilType"></param>
    public async Task<int> SaveChangesAsync()
    {
    var res = await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
      return res;

    }
    /// <summary>
    /// Modify EntityState CoilType
    /// </summary>
    /// <param name="coilType"></param>
    public void ModifyCoilType(CoilType coilType)
    {
      coilTrackingContext.Entry(coilType).State = EntityState.Modified;
      coilTrackingContext.SaveChanges(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
    }


    /// <summary>
    /// Modify EntityState CoilType
    /// </summary>
    /// <param name="coilType"></param>
    public async Task<int > ModifyCoilTypes(CoilType coilType)
    {
      coilTrackingContext.Entry(coilType).State = EntityState.Modified;
   var res =  await coilTrackingContext.SaveChangesAsync(usersHelper.GetSubject(), AuditActionType.ModifyEntity);
      return res;
    }
    /// <summary>
    /// Unchanged EntityState CoilType
    /// </summary>
    /// <param name="coilType"></param>
    public void UnchangedCoilType(CoilType coilType)
    {
      coilTrackingContext.Entry(coilType).State = EntityState.Unchanged;
    }
    /// <summary>
    /// Deletion of CoilTypeYNA
    /// </summary>
    /// <param name="removedYNA"></param>
    public void DeleteCoilTypeYNA(CoilTypeYNA removedYNA)
    {
      coilTrackingContext.Entry(removedYNA).State = EntityState.Deleted;
    }
    /// <summary>
    /// Get CoilType Based On Name
    /// </summary>
    /// <param name="name"></param>
    /// <returns></returns>
    public CoilType GetCoilTypeByName(string name)
    {
      return coilTrackingContext.CoilTypes.Include(x=>x.CoilTypeYNAs).Where(c => c.Name.Equals(name)).FirstOrDefault();
    }
    /// <summary>
    /// Get CoilType Based CoilTypeDto Name
    /// </summary>
    /// <param name="coilType"></param>
    /// <returns></returns>
    public bool IsCoilTypeByName(string coilTypeName)
    {
      return coilTrackingContext.CoilTypes.Any(ct => ct.Name == coilTypeName);
    }

    /// <summary>
    /// Get original CoilType Based on Id
    /// </summary>
    /// <param name="coilType"></param>
    /// <returns></returns>
    public CoilType GetoriginalCoilTypeById(CoilTypeDto coilType)
    {
      var originalCoilType = coilTrackingContext.CoilTypes.Where(ct => ct.Id == coilType.Id).Include(ct => ct.CoilTypeYNAs).FirstOrDefault();
      return originalCoilType;
    }
    /// <summary>
    /// Get CoilTypes MaterialType 
    /// </summary>
    /// <returns></returns>
    public async Task<CoilType> GetMaterialCoilTypeById(int id)
    {
      return await coilTrackingContext.CoilTypes.Include(ct => ct.CoilTypeYNAs).ThenInclude(y => y.MaterialType).Include(c => c.CoilFieldZone).Include(ct => ct.CoilFieldZone.CoilField).Where(c => c.Id == id).FirstOrDefaultAsync();
    }
    /// <summary>
    /// Get CoilTypes MaterialType 
    /// </summary>
    /// <returns></returns>
    public async Task<IQueryable<CoilType>> GetMaterialCoilTypes()
    {
      var CoilTypes = await coilTrackingContext.CoilTypes.Include(ct => ct.CoilTypeYNAs).ThenInclude(y => y.MaterialType).Include(c => c.CoilFieldZone).Include(ct => ct.CoilFieldZone.CoilField).ToListAsync();
      return CoilTypes.AsQueryable();
    }

    /// <summary>
    /// Get List of CoilType , PartNumber, and Models
    /// </summary>
    /// <param name="partmodels"></param>
    /// <returns></returns>
    public List<CoilTypePartModel> GetCoilTypesWithAllPartNums()
    {
      var coilTypepartmodels = (from ct in coilTrackingContext.CoilTypes
                                join d in coilTrackingContext.BlankInfoes.Include(d => d.Part).Include(d => d.CoilType)
                                on ct.Id equals d.CoilType.Id into groupJoined
                                from subD in groupJoined.DefaultIfEmpty()
                                select new CoilTypePartModel
                                {
                                  CoilTypeId = ct.Id,
                                  PartNumber = ((subD == null || subD.Part == null) ? string.Empty : subD.Part.PartNumber.Substring(0, 5)),
                                  Parts = ((subD == null || subD.Part == null) ? null : subD.Part)
                                }).ToList();
      return coilTypepartmodels;
    }

    /// <summary>
    /// Get the associated items by coil field zone id.
    /// </summary>
    /// <param name="zoneId"></param>
    /// <returns>returns the list of CoilTypes</returns>
    public async Task<List<CoilType>> GetAssociatedItemsByCoilFieldZone(int zoneId)
    {
      return await coilTrackingContext.CoilTypes.Where(ct => ct.CoilFieldZone.Id == zoneId).Include(ct => ct.CoilTypeYNAs).ToListAsync();
    }
  }
}
