# Seed Repo

> Seed repo enables individual teams to control following:
>
> - Import Repos from Bitbucket to Github

## Table of Contents


- [User Guide](#user-guide)
  - [Manage Import Repository](#manage-import-repository)
    - [Import Repository from Bitbucket to Github](#import-repository-from-bitbucket-to-github)

# User Guide

## Manage Import Repository

### Import Repository from Bitbucket to Github

Seed Repo will be primarily used for import process. Existing Bitbucket repositories will be imported to github automatically using workflow.
Import repository process is triggered by creating issue on the application teams seed repo. Detail instructions are available at following confluence page:

[Importing repository from Bitbucket](https://confluence.sdlc.toyota.com/display/TDP/Importing+repository+from+Bitbucket)

