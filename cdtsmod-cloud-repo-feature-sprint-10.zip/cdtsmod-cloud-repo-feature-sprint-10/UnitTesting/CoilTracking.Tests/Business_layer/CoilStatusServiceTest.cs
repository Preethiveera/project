using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Business.Implementation.CoilMoveRequest;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using Moq;
using System.Collections.Generic;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class CoilStatusServiceTest
  {
    private readonly Mock<ICoilStatusRepository> coilStatusRepo;
    private readonly Mock<IApplicationLogger<CoilStatusService>> coilStatusServiceLogger;

    public IMapper InitializeMapper()
    {
      var mockMapper = new MapperConfiguration(cfg =>
      {
        cfg.AddProfile(new MappingProfile());
      });
      var mapper = mockMapper.CreateMapper();

      return mapper;
    }
    public CoilStatusServiceTest()
    {
      coilStatusRepo = new Mock<ICoilStatusRepository>();
      coilStatusServiceLogger = new Mock<IApplicationLogger<CoilStatusService>>();

    }
    [Fact]
    public void GetCoilStatus_ReturnsCoilStatus()
    {
      var coilStatus = new List<CoilStatus> { new CoilStatus
      {
        Id=1
      } };
      var mapper = InitializeMapper();
      var _service = new CoilStatusService(coilStatusServiceLogger.Object, coilStatusRepo.Object, mapper);
      coilStatusRepo.Setup(repo => repo.GetCoilStatuses())
     .ReturnsAsync(coilStatus);

      var result = _service.GetCoilStatuses();

      Assert.NotNull(result);
    }
    [Fact]
    public void GetCoilStatusById_Id_ReturnsCoilStatus()
    {
      var coilStatus = new CoilStatus
      {
        Id = 1
      };
      var mapper = InitializeMapper();
      var _service = new CoilStatusService(coilStatusServiceLogger.Object, coilStatusRepo.Object, mapper);
      coilStatusRepo.Setup(repo => repo.GetCoilStatusByIdAsync(1))
     .ReturnsAsync(coilStatus);

      var result = _service.GetCoilStatusById(1);

      Assert.NotNull(result);
    }
    [Fact]
    public void SaveCoilStatus_CoilStaus()
    {
      var coilStatus = new CoilStatusDto
      {
        Id = 1
      };
      var mapper = InitializeMapper();
      var _service = new CoilStatusService(coilStatusServiceLogger.Object, coilStatusRepo.Object, mapper);

      _service.InsertCoilStatus(coilStatus);

      Assert.True(true);
    }

    [Fact]
    public void UpdateCoilStatus_CoilStaus()
    {
      var dto = new CoilStatus { Id = 1, Name = "tesr" };
      var coilStatus = new CoilStatusDto
      {
        Id = 1
      };
      var mapper = InitializeMapper();
      var _service = new CoilStatusService(coilStatusServiceLogger.Object, coilStatusRepo.Object, mapper);
      coilStatusRepo.Setup(repo => repo.GetCoilStatusById(1))
 .Returns(dto);
      _service.UpdateCoilStatus(1, coilStatus);

      Assert.True(true);

    }

    [Fact]
    public void UpdateCoilStatus_Id_ReturnsCustomException()
    {
      CoilStatus coilStatus = null;
      var dto = new CoilStatusDto
      {
        Id = 1
      };
      var mapper = InitializeMapper();
      var _service = new CoilStatusService(coilStatusServiceLogger.Object, coilStatusRepo.Object, mapper);
      coilStatusRepo.Setup(repo => repo.GetCoilStatusById(1))
   .Returns(coilStatus);
      Assert.Throws<CoilTrackingException>(() => _service.UpdateCoilStatus(2, dto));

    }
    [Fact]
    public void DeleteCoilStatus_Id_ReturnsCoilStatus()
    {
      var dto = new CoilStatus
      {
        Id = 1,
        Name = "test"
      };
      var mapper = InitializeMapper();
      var _service = new CoilStatusService(coilStatusServiceLogger.Object, coilStatusRepo.Object, mapper);
      coilStatusRepo.Setup(repo => repo.DeleteCoilStatus(1))
   .Returns(dto);
      var result = _service.DeleteCoilStatus(1);
      Assert.NotNull(result);

    }

  }
}
