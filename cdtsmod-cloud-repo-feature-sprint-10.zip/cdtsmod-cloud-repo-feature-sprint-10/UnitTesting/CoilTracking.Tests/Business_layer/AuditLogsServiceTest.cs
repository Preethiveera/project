using CoilTracking.Business.Implementation;
using CoilTracking.Common.Logging;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.Tests.Service;
using Moq;
using System;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class AuditLogsServiceTest
  {
    private readonly Mock<IAuditLogsRepository> AuditLogsRepo;
    private readonly Mock<IApplicationLogger<AuditLogsService>> AuditLogsServiceLogger;


    public AuditLogsServiceTest()
    {
      AuditLogsRepo = new Mock<IAuditLogsRepository>();
      AuditLogsServiceLogger = new Mock<IApplicationLogger<AuditLogsService>>();
    }

    [Fact]
    public void AuditLogs_SaveLogs()
    {
      int Id = 0;
      var _service = new AuditLogsService(AuditLogsRepo.Object, AuditLogsServiceLogger.Object);
      var AuditLogs = _service.IsAuditLogExists(Id);
      Assert.Equal(AuditLogs, AuditLogs);
    }
    [Fact]
    public void GetAuditLogs_ReturnsAduditLogDto()
    {
      var _service = new AuditLogsService(AuditLogsRepo.Object, AuditLogsServiceLogger.Object);

      var _mockAuditLogsService = new MockAuditLogsService();
      AuditLogsRepo.Setup(repo => repo.GetAuditLogs())
    .Returns(_mockAuditLogsService.GetAuditLogs_Model());

      var blankInfo = _service.GetAuditLogs();

      Assert.NotNull(blankInfo);
    }
    [Fact]
    public void Search_ReturnsAduditLogDto()
    {
      DateTime endTime = DateTime.Now;
      DateTime startTime = DateTime.Now;
      string username = null;
      int? actionType = null;
      string className = null;
      var _service = new AuditLogsService(AuditLogsRepo.Object, AuditLogsServiceLogger.Object);

      var _mockAuditLogsService = new MockAuditLogsService();
      AuditLogsRepo.Setup(repo => repo.Search(startTime, endTime, username, actionType, className))
    .Returns(_mockAuditLogsService.GetAuditLogs_Model());

      var blankInfo = _service.Search(startTime, endTime, username, actionType, className);

      Assert.NotNull(blankInfo);
    }



  }
}
