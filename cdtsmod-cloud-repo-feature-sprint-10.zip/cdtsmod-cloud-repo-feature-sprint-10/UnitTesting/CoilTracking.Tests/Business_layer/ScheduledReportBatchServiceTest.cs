using CoilTracking.Business.Implementation;
using CoilTracking.Business.Interfaces;
using CoilTracking.Business.Interfaces.EmailService;
using CoilTracking.Common.Logging;
using CoilTracking.DataAccess.Interfaces;
using Moq;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class ScheduledReportBatchServiceTest
  {
    private readonly Mock<ICoilTypeRepository> mockCoilTypeRepo;
    private readonly Mock<IScheduleReportRepository> mockScheduleReportRepo;
    private readonly Mock<IPartModelsRepository> mockPartModelsRepo;
    private readonly Mock<IApplicationLogger<ScheduledReportBatchService>> logger;
    private readonly Mock<IEmailService> mockEmailService;
    private readonly Mock<IRunResultService> mockRunResultService;
    private readonly Mock<ICoilsService> mockCoilService;

    public ScheduledReportBatchServiceTest()
    {
      mockCoilTypeRepo = new Mock<ICoilTypeRepository>();
      mockScheduleReportRepo = new Mock<IScheduleReportRepository>();
      mockPartModelsRepo = new Mock<IPartModelsRepository>();
      logger = new Mock<IApplicationLogger<ScheduledReportBatchService>>();
      mockEmailService = new Mock<IEmailService>();
      mockRunResultService = new Mock<IRunResultService>();
      mockCoilService = new Mock<ICoilsService>();
    }

    [Fact]
    public void GetReports()
    {
      var service = new ScheduledReportBatchService(mockCoilTypeRepo.Object, mockScheduleReportRepo.Object, mockPartModelsRepo.Object, logger.Object, mockEmailService.Object, mockRunResultService.Object, mockCoilService.Object);
      service.GetReports();
      Assert.NotNull(service);
    }
  }
}
