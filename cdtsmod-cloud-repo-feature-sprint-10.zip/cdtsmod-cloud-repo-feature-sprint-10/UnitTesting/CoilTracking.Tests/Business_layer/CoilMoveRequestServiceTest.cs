using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Business.Interfaces;
using CoilTracking.Business.Interfaces.CoilMoveRequest;
using CoilTracking.Common.Constant;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.Tests.Service;
using Moq;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class CoilMoveRequestServiceTest
  {
    private readonly Mock<ICoilMoveRequestsRepository> coilMoveRequestRepo;
    private readonly Mock<IApplicationLogger<CoilMoveRequestsService>> logger;
    private readonly Mock<ICoilStatusRepository> coilStatusRepo;
    private readonly Mock<ILineRepository> lineRepo;
    private readonly Mock<ICoilTypeRepository> coilTypeRepo;
    private readonly Mock<ICoilRepository> coilRepo;
    private readonly Mock<ICoilMoveRequestFactory> coilMoveRequestFactory;
    private readonly Mock<IWebSocketClientService> webSocketClientService;

    public CoilMoveRequestServiceTest()
    {
      coilMoveRequestRepo = new Mock<ICoilMoveRequestsRepository>();
      logger = new Mock<IApplicationLogger<CoilMoveRequestsService>>();
      coilStatusRepo = new Mock<ICoilStatusRepository>();
      lineRepo = new Mock<ILineRepository>();
      coilTypeRepo = new Mock<ICoilTypeRepository>();
      coilRepo = new Mock<ICoilRepository>();
      coilMoveRequestFactory = new Mock<ICoilMoveRequestFactory>();
      webSocketClientService = new Mock<IWebSocketClientService>();
    }

    public IMapper InitializeMapper()
    {
      var mockMapper = new MapperConfiguration(cfg =>
      {
        cfg.AddProfile(new MappingProfile());
      });
      var mapper = mockMapper.CreateMapper();

      return mapper;
    }

    [Fact]
    public void GetCoilMoveRequests_ReturnsCoilMoveRequests()
    {
      var mapper = InitializeMapper();
      var service = new CoilMoveRequestsService(coilMoveRequestRepo.Object, mapper, logger.Object, coilStatusRepo.Object, lineRepo.Object, coilTypeRepo.Object,
        coilMoveRequestFactory.Object, webSocketClientService.Object);
      var mockService = new MockCoilMoveRequestService();
      coilMoveRequestRepo.Setup(repo => repo.GetAllCoilMoveRequest().Result)
    .Returns(mockService.GetCoilMoveRequestsData().ToList());

      var result = service.GetCoilMoveRequests();
      Assert.NotNull(result);
    }

    [Fact]
    public void GetUnfulfilledCoilMoveRequests_ReturnsCoilMoveRequests()
    {
      var mapper = InitializeMapper();
      var service = new CoilMoveRequestsService(coilMoveRequestRepo.Object, mapper, logger.Object, coilStatusRepo.Object, lineRepo.Object, coilTypeRepo.Object,
        coilMoveRequestFactory.Object, webSocketClientService.Object);
      var mockService = new MockCoilMoveRequestService();
      coilMoveRequestRepo.Setup(repo => repo.GetUnfulfilledCoilMoveRequests().Result)
    .Returns(mockService.GetCoilMoveRequestsData().ToList());

      var result = service.GetUnfulfilledCoilMoveRequests();
      Assert.NotNull(result);
    }

    [Fact]
    public void CancelCoilMove_ReturnsBool()
    {
      var mapper = InitializeMapper();
      var service = new CoilMoveRequestsService(coilMoveRequestRepo.Object, mapper, logger.Object, coilStatusRepo.Object, lineRepo.Object, coilTypeRepo.Object,
        coilMoveRequestFactory.Object, webSocketClientService.Object);
      var mockService = new MockCoilMoveRequestService();
      coilMoveRequestRepo.Setup(repo => repo.GetMoveRequestById(1).Result)
    .Returns(mockService.FindCoilMoveRequest(1));
      coilStatusRepo.Setup(repo => repo.GetCoilStatusByName(CoilStatusName.CompletelyUsed).Result)
    .Returns(mockService.GetCoilStatus());
      coilMoveRequestRepo.Setup(repo => repo.SaveChanges(AuditActionType.CancelCoilMoveRequest));

      var result = service.CancelCoilMove(1);
      Assert.NotNull(result);
    }

    [Fact]
    public void RequestCoilMove_ReturnsDto()
    {
      var mapper = InitializeMapper();
      var service = new CoilMoveRequestsService(coilMoveRequestRepo.Object, mapper, logger.Object, coilStatusRepo.Object, lineRepo.Object, coilTypeRepo.Object,
        coilMoveRequestFactory.Object, webSocketClientService.Object);
      var mockService = new MockCoilMoveRequestService();
      lineRepo.Setup(repo => repo.GetLineWithPlantDetails(1).Result)
    .Returns(mockService.GetLine(1));
      coilTypeRepo.Setup(repo => repo.GetCoilTypeById(1))
    .Returns(mockService.GetCoilType(1));
      coilMoveRequestRepo.Setup(repo => repo.GetUnfulfilledCoilIds().Result)
    .Returns(mockService.GetCoilIds());
      coilRepo.Setup(repo => repo.GetCoilsToMove(1, mockService.GetCoilIds()).Result)
        .Returns(mockService.GetCoils());
      coilMoveRequestRepo.Setup(repo => repo.AddCoilMoveRequest(mockService.FindCoilMoveRequest(1)));
      coilMoveRequestRepo.Setup(repo => repo.SaveChanges(AuditActionType.CoilReturn));


      var result = service.RequestCoilMove(1, 1, CoilMoveRequestType.CoilRequest);
      Assert.NotNull(result);
    }

    [Fact]
    public void FulfillCoilMoveRequest_ReturnsDto()
    {
      var mapper = InitializeMapper();
      var service = new CoilMoveRequestsService(coilMoveRequestRepo.Object, mapper, logger.Object, coilStatusRepo.Object, lineRepo.Object, coilTypeRepo.Object,
        coilMoveRequestFactory.Object, webSocketClientService.Object);
      var mockService = new MockCoilMoveRequestService();

      coilMoveRequestRepo.Setup(repo => repo.GetCoilMoveRequestWithCoilData(1).Result)
    .Returns(mockService.FindCoilMoveRequest(1));
      coilStatusRepo.Setup(repo => repo.GetCoilStatusByName("").Result)
    .Returns(mockService.GetCoilStatus());
      coilMoveRequestRepo.Setup(repo => repo.SaveChanges(AuditActionType.FulFillRequest));

      var result = service.FulfillCoilMoveRequest(1, "", "");
      Assert.NotNull(result);
    }

    [Fact]
    public void GetCoilMoveRequestAsync_ReturnsCoilMoveRequests()
    {
      var mapper = InitializeMapper();
      var service = new CoilMoveRequestsService(coilMoveRequestRepo.Object, mapper, logger.Object, coilStatusRepo.Object, lineRepo.Object, coilTypeRepo.Object,
        coilMoveRequestFactory.Object, webSocketClientService.Object);
      var mockService = new MockCoilMoveRequestService();
      coilMoveRequestRepo.Setup(repo => repo.GetMoveRequestById(1).Result)
    .Returns(mockService.FindCoilMoveRequest(1));

      var result = service.GetCoilMoveRequests();
      Assert.NotNull(result);
    }

    [Fact]
    public void PostCoilMoveRequestAsync_ReturnsCoilMoveRequests()
    {
      var mapper = InitializeMapper();
      var service = new CoilMoveRequestsService(coilMoveRequestRepo.Object, mapper, logger.Object, coilStatusRepo.Object, lineRepo.Object, coilTypeRepo.Object,
        coilMoveRequestFactory.Object, webSocketClientService.Object);
      var mockService = new MockCoilMoveRequestService();
      coilMoveRequestRepo.Setup(repo => repo.AddCoilMoveRequest(mockService.FindCoilMoveRequest(1)));
      coilMoveRequestRepo.Setup(repo => repo.SaveChanges(AuditActionType.CoilMoveRequest));

      var result = service.PostCoilMoveRequestAsync(mockService.GetCoilMoveRequestById(1));
      Assert.NotNull(result);
    }

    [Fact]
    public void DeleteCoilMoveRequestAsync_ReturnsCoilMoveRequests()
    {
      var mapper = InitializeMapper();
      var service = new CoilMoveRequestsService(coilMoveRequestRepo.Object, mapper, logger.Object, coilStatusRepo.Object, lineRepo.Object, coilTypeRepo.Object,
        coilMoveRequestFactory.Object, webSocketClientService.Object);
      var mockService = new MockCoilMoveRequestService();
      coilMoveRequestRepo.Setup(repo => repo.FindCoilMoveRequestAsync(1).Result)
        .Returns(mockService.FindCoilMoveRequest(1));
      coilMoveRequestRepo.Setup(repo => repo.DeleteCoilMoveRequest(mockService.FindCoilMoveRequest(1)));

      var result = service.DeleteCoilMoveRequest(1);
      Assert.NotNull(result);
    }
    [Fact]
    public void GetLoadedCoils_ReturnsCoilMoveRequests()
    {
      var mapper = InitializeMapper();
      var service = new CoilMoveRequestsService(coilMoveRequestRepo.Object, mapper, logger.Object, coilStatusRepo.Object, lineRepo.Object, coilTypeRepo.Object,
        coilMoveRequestFactory.Object, webSocketClientService.Object);
      var mockService = new MockCoilMoveRequestService();
      coilMoveRequestRepo.Setup(repo => repo.GetCoilsLoadedByCoilStatusName(CoilStatusName.LoadedAtLine).Result)
        .Returns(mapper.Map<List<Coil>>(mockService.GetLoadedCoils()));
      coilMoveRequestRepo.Setup(repo => repo.GetReturnRequests().Result)
        .Returns(mockService.GetCoilMoveRequestsData().ToList());

      var result = service.GetLoadedCoils(1, 1);
      Assert.NotNull(result);
    }

  }
}
