using CoilTracking.Business.Implementation;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
 public class AdminInfoServiceTest
  {
    private readonly Mock<ICoilRepository> coilsRepo;
    private readonly Mock<ILineRepository> lineRepo;
    private readonly Mock<IBlankInfoesRepository> dataRepo;
    private readonly Mock<ICoilTypeRepository> coilTypeRepo;
    private readonly Mock<ICoilFieldRepository> coilFieldRepo;
    private readonly Mock<ICoilFieldZoneRepository> coilFieldZoneRepo;
    private readonly Mock<ICoilFieldLocationRepository> coilFieldLocationRepo;
    private readonly Mock<IPartRepository> partsRepo;
    private readonly Mock<IOPCConfigRepository> kepServerRepo;
    private readonly Mock<IMillsRepository> millRepo;
    private readonly Mock<IModelRepository> modelRepo;
    private readonly Mock<IShiftRepository> shiftRepo;
    private readonly Mock<IApplicationLogger<AdminInfoService>> adminInfoServiceLogger;

    public AdminInfoServiceTest()
    {
      this.coilsRepo = new Mock<ICoilRepository>();
      this.lineRepo = new Mock<ILineRepository>();
      this.dataRepo = new Mock<IBlankInfoesRepository>();
      this.coilTypeRepo = new Mock<ICoilTypeRepository>();
      this.coilFieldRepo = new Mock<ICoilFieldRepository>();
      this.coilFieldZoneRepo = new Mock<ICoilFieldZoneRepository>();
      this.coilFieldLocationRepo = new Mock<ICoilFieldLocationRepository>();
      this.partsRepo = new Mock<IPartRepository>();
      this.kepServerRepo = new Mock<IOPCConfigRepository>();
      this.millRepo = new Mock<IMillsRepository>();
      this.modelRepo = new Mock<IModelRepository>();
      this.shiftRepo = new Mock<IShiftRepository>();
      this.adminInfoServiceLogger = new Mock<IApplicationLogger<AdminInfoService>>();
       }

    [Fact]
    public void GetDashboardCounts()
    {

      var coils = new List<CoilType> { new CoilType { Id = 1 } };
      var _service = new AdminInfoService(coilsRepo.Object, lineRepo.Object,
        dataRepo.Object, coilTypeRepo.Object, coilFieldRepo.Object, coilFieldZoneRepo.Object,
        coilFieldLocationRepo.Object, partsRepo.Object, kepServerRepo.Object, millRepo.Object,
        modelRepo.Object, shiftRepo.Object, adminInfoServiceLogger.Object);

      coilsRepo.Setup(repo => repo.GetCountOfCoils())
     .Returns(1);
      lineRepo.Setup(repo => repo.GetCountOfLines())
     .Returns(1);
      dataRepo.Setup(repo => repo.GetCountOfBlankInfoes())
     .Returns(1);
      coilTypeRepo.Setup(repo => repo.GetCoilTypes())
     .Returns(coils);
      coilFieldRepo.Setup(repo => repo.GetCountOfCoilField())
     .Returns(1);
      coilFieldLocationRepo.Setup(repo => repo.GetCountOfCoilFieldLocation())
     .Returns(1);
      partsRepo.Setup(repo => repo.GetCountOfparts())
     .Returns(1);
      kepServerRepo.Setup(repo => repo.GetCountOfOPCConfigs())
     .Returns(1);
      modelRepo.Setup(repo => repo.GetCountOfModels())
     .Returns(1);
      shiftRepo.Setup(repo => repo.GetCountofShifts())
     .Returns(1);
      millRepo.Setup(repo => repo.GetCountOfMills())
     .Returns(1);

      var result = _service.GetDashboardCounts();

      Assert.NotNull(result);
    }

  }
}
