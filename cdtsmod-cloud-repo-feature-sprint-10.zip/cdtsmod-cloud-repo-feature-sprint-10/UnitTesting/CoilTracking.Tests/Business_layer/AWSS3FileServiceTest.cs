//using AutoMapper;
//using CoilTracking.Business.Implementation;
//using CoilTracking.Business.Interfaces.BlockingDiagrams;
//using CoilTracking.Common.Exception;
//using CoilTracking.Common.Logging;
//using CoilTracking.Data.Models;
//using CoilTracking.DataAccess.Interfaces;
//using Microsoft.AspNetCore.Http;
//using Moq;
//using System.Collections.Generic;
//using System.IO;
//using Xunit;

//namespace CoilTracking.Tests.Business_layer
//{
//  public class AWSS3FileServiceTest
//  {
//    private readonly Mock<IAWSS3BucketHelper> aWSS3BucketHelper;
//    private readonly Mock<IBlockingDiagramRepository> blockingDiagramRepo;
//    private readonly Mock<IMapper> mapper;
//    private readonly Mock<IApplicationLogger<BlockingDiagramService>> logger;

//    public AWSS3FileServiceTest()
//    {
//      this.aWSS3BucketHelper = new Mock<IAWSS3BucketHelper>();
//      this.blockingDiagramRepo = new Mock<IBlockingDiagramRepository>();
//      this.logger = new Mock<IApplicationLogger<BlockingDiagramService>>();
//    }
//    public IMapper InitializeMapper()
//    {
//      var mockMapper = new MapperConfiguration(cfg =>
//      {
//        cfg.AddProfile(new MappingProfile());
//      });
//      var mapper = mockMapper.CreateMapper();

//      return mapper;
//    }
//    [Fact]
//    public void GetFiles_ReturnsStream()
//    {
//      int dataNum = 1 ;
//      Stream file = new MemoryStream();
//      var mapper = InitializeMapper();
//      var _service = new BlockingDiagramService(aWSS3BucketHelper.Object, blockingDiagramRepo.Object,mapper, logger.Object);
//      aWSS3BucketHelper.Setup(repo => repo.GetFile("1"))
//    .ReturnsAsync(file);

//      var result = _service.GetFile(dataNum);

//      Assert.NotNull(result);
//    }
//    [Fact]
//    public void GetFiles_ReturnsNull()
//    {
//      BlockingDiagrams val = new BlockingDiagrams
//      {
//        Id = 1,
//        DataNumber = 1,
//        ImagePath = "dgf"

//      };
//      string dataNum = "1";
//      Stream file = null;
//      var mapper = InitializeMapper();
//      var _service = new BlockingDiagramService(aWSS3BucketHelper.Object, blockingDiagramRepo.Object, mapper, logger.Object);
//      blockingDiagramRepo.Setup(repo => repo.GetBlockingDiagramById(1)).ReturnsAsync(val);
        
//      aWSS3BucketHelper.Setup(repo => repo.GetFile(dataNum))
//    .ReturnsAsync(file);
     
//      var result = _service.GetFile(1);

//      Assert.NotNull(result);
//    }

//    [Fact]
//    public void MappingBlockingdiagram_ReturnsBlockingDiagram()
//    {
//      var val = new List<BlockingDiagrams>
//      {
//        new BlockingDiagrams{
//        Id = 1,
//        DataNumber = 1,
//        ImagePath = "dgf"
//        }
//      };
      
//      var mapper = InitializeMapper();
//      var _service = new BlockingDiagramService(aWSS3BucketHelper.Object, blockingDiagramRepo.Object, mapper, logger.Object);
      
//      var result = _service.MapBlockingDiagram(val);

//      Assert.NotNull(result);
//    }
//    [Fact]
//    public void UploadFile_IFormFile_ReturnsFalse()
//    {
//      var file = new Mock<IFormFile>();
//      file.Setup(_ => _.FileName).Returns("test");
//      file.Setup(_ => _.Length).Returns(1);
//      var f = file.Object;
//      var ms = new System.IO.MemoryStream();
//       f.CopyToAsync(ms);
//      var mapper = InitializeMapper();
//      var _service = new BlockingDiagramService(aWSS3BucketHelper.Object, blockingDiagramRepo.Object, mapper, logger.Object);

//      Assert.ThrowsAsync<CoilTrackingException>(() => _service.UploadFile(ms, 1));

//    }
//    [Fact]
//    public void UploadFile_IFormFile_ReturnsException()
//    {
//      BlockingDiagrams item = new BlockingDiagrams { Id = 1 };
//      var stream = new MemoryStream();
//      var file = new Mock<IFormFile>();
//      file.Setup(_ => _.FileName).Returns("1");
//      file.Setup(_ => _.Length).Returns(1);
//      var f = file.Object;
//      var ms = new System.IO.MemoryStream();
//      f.CopyToAsync(ms);
//      var mapper = InitializeMapper();
//      var _service = new BlockingDiagramService(aWSS3BucketHelper.Object, blockingDiagramRepo.Object, mapper, logger.Object);

//      blockingDiagramRepo.Setup(t => t.GetBlockingDiagramByDataNum(1))
//        .ReturnsAsync(item);
//      aWSS3BucketHelper.Setup(repo => repo.UploadFile(stream, "test"))
//   .ReturnsAsync(true);

//      Assert.ThrowsAsync<CoilTrackingException>(() => _service.UploadFile(ms, 1));

//    }

//    [Fact]
//    public void DeleteFile_ReturnsException()
//    {
//      BlockingDiagrams val = new BlockingDiagrams
//      {
//        Id = 1,
//        DataNumber = 1,
//        ImagePath = "dgf"

//      };
//      string dataNum = "1";
//      Stream file = null;
//      var mapper = InitializeMapper();
//      var _service = new BlockingDiagramService(aWSS3BucketHelper.Object, blockingDiagramRepo.Object, mapper, logger.Object);
//      blockingDiagramRepo.Setup(repo => repo.GetBlockingDiagramById(1)).ReturnsAsync(val);

//      aWSS3BucketHelper.Setup(repo => repo.GetFile(dataNum))
//    .ReturnsAsync(file);

//      var result = _service.DeleteBlockingDiagram(1);

//      Assert.ThrowsAsync<CoilTrackingException>(() => _service.DeleteBlockingDiagram(1));

//    }
//    [Fact]
//    public void DeleteFile()
//    {
//      BlockingDiagrams val = new BlockingDiagrams
//      {
//        Id = 1,
//        DataNumber = 1,
//        ImagePath = "dgf"

//      };
//      string dataNum = "1";
//      Stream file = null;
//      var mapper = InitializeMapper();
//      var _service = new BlockingDiagramService(aWSS3BucketHelper.Object, blockingDiagramRepo.Object, mapper, logger.Object);
//      blockingDiagramRepo.Setup(repo => repo.GetBlockingDiagramById(1)).ReturnsAsync(val);

//      aWSS3BucketHelper.Setup(repo => repo.DeleteFile("1"))
//    .ReturnsAsync(true);

//      var result = _service.DeleteBlockingDiagram(1);
//      Assert.NotNull(result);
//      //Assert.ThrowsAsync<CoilTrackingException>(() => _service.DeleteBlockingDiagram(1));

//    }
//    [Fact]
//    public void UpdateBlockingDiagram_ReturnsException()
//    {
//      BlockingDiagrams val = new BlockingDiagrams
//      {
//        Id = 1,
//        DataNumber = 1,
//        ImagePath = "dgf"

//      };
//      var file = new Mock<IFormFile>();
//      file.Setup(_ => _.FileName).Returns("1");
//      file.Setup(_ => _.Length).Returns(1);
//      var f = file.Object;
//      var ms = new System.IO.MemoryStream();
//      f.CopyToAsync(ms);
//      var mapper = InitializeMapper();
//      var _service = new BlockingDiagramService(aWSS3BucketHelper.Object, blockingDiagramRepo.Object, mapper, logger.Object);
//      blockingDiagramRepo.Setup(repo => repo.GetBlockingDiagramById(1)).ReturnsAsync(val);

//      aWSS3BucketHelper.Setup(repo => repo.DeleteFile("1"))
//    .ReturnsAsync(true);

//      Assert.ThrowsAsync<CoilTrackingException>(() => _service.UpdateBlockingDiagram(ms, 1, 1));

//    }
//    [Fact]
//    public void UpdateBlockingDiagram()
//    {
//      BlockingDiagrams val = new BlockingDiagrams
//      {
//        Id = 1,
//        DataNumber = 1,
//        ImagePath = "dgf"

//      };
//      var file = new Mock<IFormFile>();
//      file.Setup(_ => _.FileName).Returns("1.JPG");
//      file.Setup(_ => _.Length).Returns(1);
//      var f = file.Object;
//      var ms = new System.IO.MemoryStream();
//      f.CopyToAsync(ms);
//      var mapper = InitializeMapper();
//      var _service = new BlockingDiagramService(aWSS3BucketHelper.Object, blockingDiagramRepo.Object, mapper, logger.Object);
//      blockingDiagramRepo.Setup(repo => repo.GetBlockingDiagramById(1)).ReturnsAsync(val);

//      aWSS3BucketHelper.Setup(repo => repo.DeleteFile("1"))
//    .ReturnsAsync(true);

//      Assert.ThrowsAsync<CoilTrackingException>(() => _service.UpdateBlockingDiagram(ms, 1, 1));

//    }

//    [Fact]
//    public void UpdateBlockingDiagram_ReturnsExceptionForDataNum()
//    {
//      BlockingDiagrams val = new BlockingDiagrams
//      {
//        Id = 1,
//        DataNumber = 1,
//        ImagePath = "dgf"

//      };
//      var file = new Mock<IFormFile>();
//      file.Setup(_ => _.FileName).Returns("1.JPG");
//      file.Setup(_ => _.Length).Returns(1);
//      var f = file.Object;
//      var ms = new System.IO.MemoryStream();
//      f.CopyToAsync(ms);
//      var mapper = InitializeMapper();
//      var _service = new BlockingDiagramService(aWSS3BucketHelper.Object, blockingDiagramRepo.Object, mapper, logger.Object);
//      blockingDiagramRepo.Setup(repo => repo.GetBlockingDiagramById(1)).ReturnsAsync(val);

//      aWSS3BucketHelper.Setup(repo => repo.DeleteFile("1"))
//    .ReturnsAsync(true);

//      Assert.ThrowsAsync<CoilTrackingException>(() => _service.UpdateBlockingDiagram(ms, 1, 2));

//    }


//    [Fact]
//    public void UploadBlockingDiagram_ReturnsExceptionForDataNum()
//    {
//      BlockingDiagrams val = new BlockingDiagrams
//      {
//        Id = 1,
//        DataNumber = 1,
//        ImagePath = "dgf"

//      };
//      var file = new Mock<IFormFile>();
//      file.Setup(_ => _.FileName).Returns("1.JPG");
//      file.Setup(_ => _.Length).Returns(1);
//      var f = file.Object;
//      var ms = new System.IO.MemoryStream();
//      f.CopyToAsync(ms);
//      var mapper = InitializeMapper();
//      var _service = new BlockingDiagramService(aWSS3BucketHelper.Object, blockingDiagramRepo.Object, mapper, logger.Object);
//      blockingDiagramRepo.Setup(repo => repo.GetBlockingDiagramById(1)).ReturnsAsync(val);

//      aWSS3BucketHelper.Setup(repo => repo.DeleteFile("1"))
//    .ReturnsAsync(true);

//      Assert.ThrowsAsync<CoilTrackingException>(() => _service.UploadFile(ms,1));

//    }


//    [Fact]
//    public void ImportBlockingDiagram_ReturnsExceptionForDataNum()
//    {
//      BlockingDiagrams val = new BlockingDiagrams
//      {
//        Id = 1,
//        DataNumber = 1,
//        ImagePath = "dgf"

//      };
//      var file = new Mock<IFormFileCollection>();

//      var file1 = new Mock<IFormFile>();
//      file1.Setup(_ => _.FileName).Returns("1.JPG");
//      file1.Setup(_ => _.Length).Returns(1);
//      file1.Setup(_ => _.Name).Returns("1.JPG");
//      var f1 = file1.Object;

//      file.Setup(_ => _.Count).Returns(1);
//      file.Setup(i => i.GetFile("1.JPG")).Returns(f1);
    
//      var f = file.Object;
//      var mapper = InitializeMapper();
//      var _service = new BlockingDiagramService(aWSS3BucketHelper.Object, blockingDiagramRepo.Object, mapper, logger.Object);
//      blockingDiagramRepo.Setup(repo => repo.GetBlockingDiagramById(1)).ReturnsAsync(val);

//      aWSS3BucketHelper.Setup(repo => repo.DeleteFile("1"))
//    .ReturnsAsync(true);

//      Assert.ThrowsAsync<CoilTrackingException>(() => _service.ImportBlockingDiagram(f));

//    }

//  }
//}
