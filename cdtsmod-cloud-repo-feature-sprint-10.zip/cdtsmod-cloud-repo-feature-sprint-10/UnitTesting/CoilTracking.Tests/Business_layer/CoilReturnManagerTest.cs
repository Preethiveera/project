using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Common.Constant;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.Tests.Service;
using Moq;
using System.Linq;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class CoilReturnManagerTest
  {
    private readonly Mock<ICoilRepository> coilRepo;
    private readonly Mock<ICoilFieldZoneRepository> coilFieldZoneRepo;
    private readonly Mock<ICoilStatusRepository> coilStatusRepo;

    public CoilReturnManagerTest()
    {
      coilRepo = new Mock<ICoilRepository>();
      coilFieldZoneRepo = new Mock<ICoilFieldZoneRepository>();
      coilStatusRepo = new Mock<ICoilStatusRepository>();
    }

    public IMapper InitializeMapper()
    {
      var mockMapper = new MapperConfiguration(cfg =>
      {
        cfg.AddProfile(new MappingProfile());
      });
      var mapper = mockMapper.CreateMapper();

      return mapper;
    }

    [Fact]
    public void RequestCoilMove_ReturnsCoilMoveRequest()
    {
      var coilType = new CoilType
      {
        Id = 1
      };
      var mapper = InitializeMapper();
      var service = new CoilReturnManager(coilRepo.Object, coilFieldZoneRepo.Object, coilStatusRepo.Object);
      var mockService = new MockCoilMoveRequestService();
      coilRepo.Setup(repo => repo.GetCoilToMoveByCoilId(1).Result)
    .Returns(mockService.GetCoils().FirstOrDefault());
      coilRepo.Setup(repo => repo.GetCoilsToMove(1, mockService.GetCoilIds()).Result)
    .Returns(mockService.GetCoils());

      var result = service.RequestCoilMove(coilType, CoilMoveRequestType.CoilRequest, null);
      Assert.NotNull(result);
    }

    [Fact]
    public void FulFillCoilMove_ReturnsCoilMoveRequest()
    {
      var coilFieldZone = new CoilFieldZone
      {
        Id = 1
      };

      var mapper = InitializeMapper();
      var service = new CoilReturnManager(coilRepo.Object, coilFieldZoneRepo.Object, coilStatusRepo.Object);
      var mockService = new MockCoilMoveRequestService();
      coilFieldZoneRepo.Setup(repo => repo.GetCoilFieldZoneByNameWithLocation("").Result)
    .Returns(coilFieldZone);
      coilStatusRepo.Setup(repo => repo.GetCoilStatusByName(CoilStatusName.LoadedAtLine).Result)
    .Returns(mockService.GetCoilStatus());

      var result = service.FullFillCoilMove(mockService.FindCoilMoveRequest(1), null, null);
      Assert.NotNull(result);
    }
  }
}
