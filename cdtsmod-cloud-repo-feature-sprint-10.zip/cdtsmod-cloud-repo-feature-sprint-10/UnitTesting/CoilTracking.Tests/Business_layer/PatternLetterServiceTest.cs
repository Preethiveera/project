using CoilTracking.Business.Implementation;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using Moq;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class PatternLetterServiceTest
  {
    private readonly Mock<IPatternLetterRepository> patternLetterRepo;
    private readonly Mock<IApplicationLogger<PatternLetterService>> patternLetterServiceLogger;
    private readonly Mock<IPatternCalendarRepository> patternCallendarRepo;
    public PatternLetterServiceTest()
    {
      patternLetterRepo = new Mock<IPatternLetterRepository>();
      patternLetterServiceLogger = new Mock<IApplicationLogger<PatternLetterService>>();
      patternCallendarRepo = new Mock<IPatternCalendarRepository>();

    }
    [Fact]
    public void GetPatternLetterTest()
    {

      var _service = new PatternLetterService(patternLetterRepo.Object, patternCallendarRepo.Object, patternLetterServiceLogger.Object);
      var _mockPatternLetterService = new MockPatternLetterService();
      patternLetterRepo.Setup(repo => repo.GetPatternLetter())
    .Returns(_mockPatternLetterService.GetPatternLetterModel());

      var patternLetters = _service.GetPatternLetter();

      Assert.NotNull(patternLetters);
    }
    [Fact]
    public void GetPatternLetterByIdTest()
    {
      int id = 1;
      var _service = new PatternLetterService(patternLetterRepo.Object, patternCallendarRepo.Object, patternLetterServiceLogger.Object);
      var _mockPatternLetterService = new MockPatternLetterService();
      patternLetterRepo.Setup(repo => repo.GetPatternLetterById(id))
    .Returns(_mockPatternLetterService.GetPatternLetterModelById());

      var patternLetters = _service.GetPatternLetterById(id);

      Assert.NotNull(patternLetters);
    }
    [Fact]
    public void PostPatternLetter()
    {
      string name = "A";
      var patternLetter = new PatternLetterDto()
      {
        Name = "D",
        Desc = "test",
        Disabled = false
      };

      var _service = new PatternLetterService(patternLetterRepo.Object, patternCallendarRepo.Object, patternLetterServiceLogger.Object);
      var _mockPatternLetterService = new MockPatternLetterService();
      patternLetterRepo.Setup(repo => repo.GetPatternLetterByName(name))
    .Returns(_mockPatternLetterService.GetPatternLetterModelById());


    _service.PostPatternLetter(patternLetter);

      Assert.True(true);
    }
    [Fact]
    public void PostPatternLetterAddsDefaultLetter()
    {
      string name = "A";
      var patternLetter = new PatternLetterDto()
      {
        Name = "X",
        Desc = "test",
        Disabled = false
      };
      var _service = new PatternLetterService(patternLetterRepo.Object, patternCallendarRepo.Object, patternLetterServiceLogger.Object);
      var _mockPatternLetterService = new MockPatternLetterService();
      patternLetterRepo.Setup(repo => repo.GetPatternLetterByName(name))
    .Returns(_mockPatternLetterService.GetPatternLetterModelById());

      Assert.Throws<CoilTrackingException>(() => _service.PostPatternLetter(patternLetter));

    }
    [Fact]
    public void PostPatternLetterReturnBadRequest()
    {
      string name = "A";
      var patternLetter = new PatternLetterDto()
      {
        Name = "A",
        Desc = "test",
        Disabled = false
      };
      var _service = new PatternLetterService(patternLetterRepo.Object, patternCallendarRepo.Object, patternLetterServiceLogger.Object);
      var _mockPatternLetterService = new MockPatternLetterService();
      patternLetterRepo.Setup(repo => repo.GetPatternLetterByName(name))
    .Returns(_mockPatternLetterService.GetPatternLetterModelById());
      Assert.Throws<CoilTrackingException>(() => _service.PostPatternLetter(patternLetter));


    }
    [Fact]
    public void PutPatternLetterReturnsFalse()
    {
      int id = 1;
      var patternLetter = new PatternLetter()
      {
        Name = "A",
        Desc = "test",
        Disabled = false
      };
      var patternLetterDto = new PatternLetterDto()
      {
        Name = "A",
        Desc = "test",
        Disabled = false
      };
      var _service = new PatternLetterService(patternLetterRepo.Object, patternCallendarRepo.Object, patternLetterServiceLogger.Object);
      patternLetterRepo.Setup(repo => repo.PutPatternLetter(id, patternLetter))
     .Returns(true);

      var patternLetters = _service.PutPatternLetter(id, patternLetterDto);

      Assert.False(patternLetters);
    }
    [Fact]
    public void PutPatternLetterReturnsTrue()
    {
      int id = 1;
      var patternLetter = new PatternLetter()
      {
        Name = "A",
        Desc = "test",
        Disabled = false
      };
      var patternLetterDto = new PatternLetterDto()
      {
        Name = "A",
        Desc = "test",
        Disabled = false
      };
      var _service = new PatternLetterService(patternLetterRepo.Object, patternCallendarRepo.Object, patternLetterServiceLogger.Object);
      patternLetterRepo.Setup(repo => repo.PutPatternLetter(id, patternLetter))
      .Returns(true);
      patternLetterRepo.Setup(repo => repo.PatternLetterExists(id))
    .Returns(true);


      var patternLetters = _service.PutPatternLetter(id, patternLetterDto);

      Assert.True(true);
    }

    [Fact]
    public void DeletePatternLetter()
    {
      int id = 1;
      var patternLetter = new PatternLetter()
      {
        Name = "A",
        Desc = "test",
        Disabled = false
      };
      var _service = new PatternLetterService(patternLetterRepo.Object, patternCallendarRepo.Object, patternLetterServiceLogger.Object);
      patternLetterRepo.Setup(repo => repo.GetPatternLetterById(id))
    .Returns(patternLetter);
      patternLetterRepo.Setup(repo => repo.DeletePatternLetter(id))
    .Returns(true);


      var patternLetters = _service.DeletePatternLetter(id);

      Assert.NotNull(patternLetters);
    }

    [Fact]
    public void DisablePatternLetterReturnsTrue()
    {
      int id = 1;
      bool disable = true;
      var _service = new PatternLetterService(patternLetterRepo.Object, patternCallendarRepo.Object, patternLetterServiceLogger.Object);
      patternLetterRepo.Setup(repo => repo.PatternLetterExists(id))
    .Returns(true);
      patternLetterRepo.Setup(repo => repo.DisablePatternLetter(id, disable))
    .Returns(true);

      _service.DisablePatternLetter(id, disable);

      Assert.True(true);
    }

    [Fact]
    public void DisablePatternLetterReturnsFalse()
    {
      int id = 1;
      bool disable = true;
      var _service = new PatternLetterService(patternLetterRepo.Object, patternCallendarRepo.Object, patternLetterServiceLogger.Object);
      patternLetterRepo.Setup(repo => repo.PatternLetterExists(id))
     .Returns(false);

      _service.DisablePatternLetter(id, disable);

      Assert.False(false);
    }


    [Fact]
    public void CheckDependency()
    {
      int id = 1;
      var patternLetter = new PatternLetter()
      {
        Name = "A",
        Desc = "test",
        Disabled = false
      };
      var _service = new PatternLetterService(patternLetterRepo.Object, patternCallendarRepo.Object, patternLetterServiceLogger.Object);

      patternLetterRepo.Setup(repo => repo.GetPatternLetterById(id))
    .Returns(patternLetter);
      patternCallendarRepo.Setup(repo => repo.GetPatternLetterAssociation(patternLetter))
    .Returns(true);

      var patternLetters = _service.CheckDependency(id);

      Assert.NotNull(patternLetters);
    }

    [Fact]
    public void CheckeditReturnsTrue()
    {
      int id = 1;

      var patternLetterDto = new PatternLetterDto()
      {
        Id = 1,
        Name = "A",
        Desc = "test",
        Disabled = false
      };
      var _service = new PatternLetterService(patternLetterRepo.Object, patternCallendarRepo.Object, patternLetterServiceLogger.Object);
      var _mockPatternLetterService = new MockPatternLetterService();
      patternLetterRepo.Setup(repo => repo.CheckEdit(id))
   .Returns(_mockPatternLetterService.GetPatternLetterModelById());
      var patternLetters = _service.CheckEdit(id, patternLetterDto);

      Assert.True(patternLetters);
    }
    [Fact]
    public void CheckeditReturnsFalse()
    {
      int id = 1;
      var patternLetter = new PatternLetter()
      {
        Id = 1,
        Name = "A1",
        Desc = "test",
        Disabled = false
      };
      var patternLetterDto = new PatternLetterDto()
      {
        Id = 1,
        Name = "A",
        Desc = "test",
        Disabled = false
      };
      var _service = new PatternLetterService(patternLetterRepo.Object, patternCallendarRepo.Object, patternLetterServiceLogger.Object);

      patternLetterRepo.Setup(repo => repo.CheckEdit(id))
   .Returns(patternLetter);
      var patternLetters = _service.CheckEdit(id, patternLetterDto);

      Assert.False(patternLetters);
    }


  }
}
