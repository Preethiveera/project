using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class RunOrderListServiceTest
  {
    private readonly Mock<IRunOrderRepository> runOrderListRepo;
    private readonly Mock<ICoilRepository> coilRepo;
    private readonly Mock<IShiftRepository> shiftRepo;
    private readonly Mock<ILineRepository> lineRepo;
    private readonly Mock<IPartRepository> partRepo;
    private readonly Mock<IBlankInfoesRepository> blanksRepo;
    private readonly Mock<IPatternsRepository> patternsRepo;
    private readonly Mock<IProdPlanRepository> prodPlanRepo;
    private readonly Mock<IPatternCalendarRepository> patternCalendarRepo;
    private readonly Mock<IApplicationLogger<RunOrderListService>> runOrderListServiceLogger;
    private readonly Mock<IRunResultsRepository> runResultRepo;
    private readonly Mock<ICoilRunHistoryRepository> coilRunHistoryRepo;
    private readonly Mock<IRunOrderListQuantityRepository> runOrderListQuantityRepo;
    private readonly Mock<IWebSocketClientService> webSocketClientService;

    public IMapper InitializeMapper()
    {
      var mockMapper = new MapperConfiguration(cfg =>
      {
        cfg.AddProfile(new MappingProfile());
      });
      var mapper = mockMapper.CreateMapper();

      return mapper;
    }
    public RunOrderListServiceTest()
    {
      coilRepo = new Mock<ICoilRepository>();
      runOrderListRepo = new Mock<IRunOrderRepository>();
      partRepo = new Mock<IPartRepository>();
      blanksRepo = new Mock<IBlankInfoesRepository>();
      patternCalendarRepo = new Mock<IPatternCalendarRepository>();
      prodPlanRepo = new Mock<IProdPlanRepository>();
      patternsRepo = new Mock<IPatternsRepository>();
      shiftRepo = new Mock<IShiftRepository>();
      lineRepo = new Mock<ILineRepository>();
      runOrderListServiceLogger = new Mock<IApplicationLogger<RunOrderListService>>();
      runResultRepo = new Mock<IRunResultsRepository>();
      coilRunHistoryRepo = new Mock<ICoilRunHistoryRepository>();
      runOrderListQuantityRepo = new Mock<IRunOrderListQuantityRepository>();
      webSocketClientService = new Mock<IWebSocketClientService>();
    }

    [Fact]
    public void GetRunOrderLists_ReturnsRunOrderLists()
    {
      var mapper = InitializeMapper();
      var _service = new RunOrderListService(runOrderListRepo.Object, runOrderListQuantityRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object,
        lineRepo.Object, shiftRepo.Object, patternsRepo.Object,
         prodPlanRepo.Object, patternCalendarRepo.Object,
         blanksRepo.Object, partRepo.Object, coilRepo.Object,
        runOrderListServiceLogger.Object,
        mapper, webSocketClientService.Object);
      var _mockRunOrderService = new MockRunOrderListService();
      runOrderListRepo.Setup(repo => repo.GetRunOrderListsAsync())
    .ReturnsAsync(_mockRunOrderService.GetRunOrderListreturnsRunOrderList());

      var result = _service.GetRunOrderLists();

      Assert.NotNull(result);
    }
    [Fact]
    public void GetRunOrderListById_ReturnsRunOrderList()
    {
      var mapper = InitializeMapper();
      var _service = new RunOrderListService(runOrderListRepo.Object, runOrderListQuantityRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object,
        lineRepo.Object, shiftRepo.Object, patternsRepo.Object,
         prodPlanRepo.Object, patternCalendarRepo.Object,
         blanksRepo.Object, partRepo.Object, coilRepo.Object,
        runOrderListServiceLogger.Object,
        mapper, webSocketClientService.Object);
      var _mockRunOrderService = new MockRunOrderListService();
      runOrderListRepo.Setup(repo => repo.GetRunOrderListByIdAsync(1))
    .ReturnsAsync(_mockRunOrderService.GetRunOrderListreturnsRunOrderListById(1));

      var result = _service.GetRunOrderListById(1);

      Assert.NotNull(result);
    }
    [Fact]
    public void GetCoilTypeUsableWeight_ReturnsCoilWeight()
    {
      var mapper = InitializeMapper();
      var _service = new RunOrderListService(runOrderListRepo.Object, runOrderListQuantityRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object,
        lineRepo.Object, shiftRepo.Object, patternsRepo.Object,
         prodPlanRepo.Object, patternCalendarRepo.Object,
         blanksRepo.Object, partRepo.Object, coilRepo.Object,
        runOrderListServiceLogger.Object,
        mapper, webSocketClientService.Object);
      var _mockRunOrderService = new MockRunOrderListService();

      coilRepo.Setup(repo => repo.CoilsInventoryBYTypeId(1))
    .ReturnsAsync(_mockRunOrderService.GetCoils());

      var result = _service.GetCoilTypeUsableWeight(1);

      Assert.Equal(result, result);
    }
    [Fact]
    public void RunOrderListExists_Returnsbool()
    {
      var mapper = InitializeMapper();
      var _service = new RunOrderListService(runOrderListRepo.Object, runOrderListQuantityRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object,
        lineRepo.Object, shiftRepo.Object, patternsRepo.Object,
         prodPlanRepo.Object, patternCalendarRepo.Object,
         blanksRepo.Object, partRepo.Object, coilRepo.Object,
        runOrderListServiceLogger.Object,
        mapper, webSocketClientService.Object);
      var _mockRunOrderService = new MockRunOrderListService();

      runOrderListRepo.Setup(repo => repo.GetRunOrderListByIdAsync(1))
    .ReturnsAsync(_mockRunOrderService.GetRunOrderListreturnsRunOrderListById(1));

      var result = _service.RunOrderListExists(1);

      Assert.Equal(result, result);
    }
    [Fact]
    public void MarkRunOrderItemsIncomplete()
    {
      var mapper = InitializeMapper();
      var _service = new RunOrderListService(runOrderListRepo.Object, runOrderListQuantityRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object,
        lineRepo.Object, shiftRepo.Object, patternsRepo.Object,
         prodPlanRepo.Object, patternCalendarRepo.Object,
         blanksRepo.Object, partRepo.Object, coilRepo.Object,
        runOrderListServiceLogger.Object,
        mapper, webSocketClientService.Object);
      List<IncompleteRunOrderItemDto> list = new List<IncompleteRunOrderItemDto>
      {
        new IncompleteRunOrderItemDto()
        {
          Id=1
        }
      };
      var result = _service.MarkRunOrderItemsIncomplete(list);

      Assert.Equal(result, result);
    }


    [Fact]
    public void CreateIncompleteRunoderList_RunOrderListId()
    {
      var mapper = InitializeMapper();
      var _service = new RunOrderListService(runOrderListRepo.Object, runOrderListQuantityRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object,
        lineRepo.Object, shiftRepo.Object, patternsRepo.Object,
         prodPlanRepo.Object, patternCalendarRepo.Object,
         blanksRepo.Object, partRepo.Object, coilRepo.Object,
        runOrderListServiceLogger.Object,
        mapper, webSocketClientService.Object);
      var runOrderlist = new RunOrderList
      {
        Id = 1
      };
      _service.CreateIncompleteRunOrderItemEntries(runOrderlist);

      Assert.True(true);
    }

    [Fact]
    public void CreateRunoderList_DateIdAndShiftId_ReturnsExceptionForPatternCalendar()
    {
      var mapper = InitializeMapper();
      var _service = new RunOrderListService(runOrderListRepo.Object, runOrderListQuantityRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object,
        lineRepo.Object, shiftRepo.Object, patternsRepo.Object,
         prodPlanRepo.Object, patternCalendarRepo.Object,
         blanksRepo.Object, partRepo.Object, coilRepo.Object,
        runOrderListServiceLogger.Object,
        mapper, webSocketClientService.Object);

      var _mockRunOrderService = new MockRunOrderListService();
      DateTime date = DateTime.Now;
      runOrderListRepo.Setup(repo => repo.GetListByDateLineIdAndShift(date, 1, 1))
    .ReturnsAsync(_mockRunOrderService.GetRunOrderListreturnsRunOrderListById(2));
      patternCalendarRepo.Setup(repo => repo.GetPatternCalendarByDateLineIdAndShiftId(date, 1, 1))
    .ReturnsAsync(_mockRunOrderService.GetPatternCalendar(1));

      Assert.ThrowsAsync<CoilTrackingException>(() => _service.CreateRunOrderList(date, 1, 1));
    }

    [Fact]
    public void CreateRunoderList_DateIdAndShiftId_ReturnsExceptionForPatterns()
    {
      var mapper = InitializeMapper();
      var _service = new RunOrderListService(runOrderListRepo.Object, runOrderListQuantityRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object,
        lineRepo.Object, shiftRepo.Object, patternsRepo.Object,
         prodPlanRepo.Object, patternCalendarRepo.Object,
         blanksRepo.Object, partRepo.Object, coilRepo.Object,
        runOrderListServiceLogger.Object,
        mapper, webSocketClientService.Object);

      var _mockRunOrderService = new MockRunOrderListService();
      DateTime date = DateTime.Now;
      runOrderListRepo.Setup(repo => repo.GetListByDateLineIdAndShift(date, 1, 1))
    .ReturnsAsync(_mockRunOrderService.GetRunOrderListreturnsRunOrderListById(2));
      patternCalendarRepo.Setup(repo => repo.GetPatternCalendarByDateLineIdAndShiftId(date, 1, 1))
    .ReturnsAsync(_mockRunOrderService.GetPatternCalendar(2));


      Assert.ThrowsAsync<CoilTrackingException>(() => _service.CreateRunOrderList(date, 1, 1));
    }

    //MarkRunOrderItemStatus(int runOrderItemId, RunOrderItemStatusDto status)

    [Fact]
    public async Task MarkRunOrderItemStatus_runOrderItemIdAndstatus()
    {
      var mapper = InitializeMapper();
      var _service = new RunOrderListService(runOrderListRepo.Object, runOrderListQuantityRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object,
        lineRepo.Object, shiftRepo.Object, patternsRepo.Object,
         prodPlanRepo.Object, patternCalendarRepo.Object,
         blanksRepo.Object, partRepo.Object, coilRepo.Object,
        runOrderListServiceLogger.Object,
        mapper, webSocketClientService.Object);

      var status = RunOrderItemStatusDto.CarriedOver;
      await _service.MarkRunOrderItemStatus(1, status);
      Assert.True(true);
    }
    [Fact]
    public void CreateRunoderList_DateIdAndShiftId_ReturnsRunOrderListIfNotNull()
    {
      var mapper = InitializeMapper();
      var _service = new RunOrderListService(runOrderListRepo.Object, runOrderListQuantityRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object,
        lineRepo.Object, shiftRepo.Object, patternsRepo.Object,
         prodPlanRepo.Object, patternCalendarRepo.Object,
         blanksRepo.Object, partRepo.Object, coilRepo.Object,
        runOrderListServiceLogger.Object,
        mapper, webSocketClientService.Object);
      List<string> partNum = new List<string> { "51121-06020" };

      List<int> coilTypesList = new List<int> { 1 };
      List<ProdPlan> prodPlan = new List<ProdPlan>
      {
        new ProdPlan
        {
          Id=1,
          LotSize=1,
          Part=new Part{Id=1, PartName="ssfd", PartNumber="51121-06020"}
        }
      };
      var _mockRunOrderService = new MockRunOrderListService();
      DateTime date = DateTime.Now;
      runOrderListRepo.Setup(repo => repo.GetListByDateLineIdAndShift(date, 1, 1))
    .ReturnsAsync(_mockRunOrderService.GetRunOrderList(32));

      coilRepo.Setup(repo => repo.GetCoilsList(coilTypesList))
.Returns(_mockRunOrderService.GetCoils());
      prodPlanRepo.Setup(repo => repo.GetProdPlanByPartnumberList(partNum))
              .Returns(prodPlan);
      blanksRepo.Setup(repo => repo.GetListByPartnumberLineIds(partNum, 1))
           .Returns(_mockRunOrderService.GetBlanks());
      var result = _service.CreateRunOrderList(date, 1, 1);
      Assert.NotNull(result);
    }

    [Fact]
    public async Task DeleteRunoderList_Id_ReturnsTrue()
    {
      var mapper = InitializeMapper();
      var _service = new RunOrderListService(runOrderListRepo.Object, runOrderListQuantityRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object,
        lineRepo.Object, shiftRepo.Object, patternsRepo.Object,
         prodPlanRepo.Object, patternCalendarRepo.Object,
         blanksRepo.Object, partRepo.Object, coilRepo.Object,
        runOrderListServiceLogger.Object,
        mapper, webSocketClientService.Object);
      var _mockRunOrderService = new MockRunOrderListService();

      runOrderListRepo.Setup(repo => repo.GetListByIdWithLineQuantity(1))
    .ReturnsAsync(_mockRunOrderService.GetRunOrderList(32));
      await _service.DeleteRunOrderList(1);

      Assert.True(true);
    }
    [Fact]
    public async System.Threading.Tasks.Task DeleteRunoderList_Id_ReturnsFalseAsync()
    {
      var mapper = InitializeMapper();
      var _service = new RunOrderListService(runOrderListRepo.Object, runOrderListQuantityRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object,
        lineRepo.Object, shiftRepo.Object, patternsRepo.Object,
         prodPlanRepo.Object, patternCalendarRepo.Object,
         blanksRepo.Object, partRepo.Object, coilRepo.Object,
        runOrderListServiceLogger.Object,
        mapper, webSocketClientService.Object);

      var result = await _service.DeleteRunOrderList(1);

      Assert.False(result);
    }

    [Fact]
    public void DeleteRunoderList_Id_ReturnsBadRequest()
    {
      var mapper = InitializeMapper();
      var _service = new RunOrderListService(runOrderListRepo.Object, runOrderListQuantityRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object,
        lineRepo.Object, shiftRepo.Object, patternsRepo.Object,
         prodPlanRepo.Object, patternCalendarRepo.Object,
         blanksRepo.Object, partRepo.Object, coilRepo.Object,
        runOrderListServiceLogger.Object,
        mapper, webSocketClientService.Object);

      var coilRunHist = new CoilRunHistory
      {
        Id = 1,
        WeightUsed = 100
      };

      var _mockRunOrderService = new MockRunOrderListService();

      runOrderListRepo.Setup(repo => repo.GetListByIdWithLineQuantity(1))
    .ReturnsAsync(_mockRunOrderService.GetRunOrderList(32));

      coilRunHistoryRepo.Setup(repo => repo.GetCoilRunHistoryByRunOrderListId(1))
    .ReturnsAsync(coilRunHist);

      Assert.ThrowsAsync<CoilTrackingException>(() => _service.DeleteRunOrderList(1));

    }
    [Fact]
    public void DeleteRunoderList_Id_ReturnsBadRequestForRunResult()
    {
      var mapper = InitializeMapper();
      var _service = new RunOrderListService(runOrderListRepo.Object, runOrderListQuantityRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object,
        lineRepo.Object, shiftRepo.Object, patternsRepo.Object,
         prodPlanRepo.Object, patternCalendarRepo.Object,
         blanksRepo.Object, partRepo.Object, coilRepo.Object,
        runOrderListServiceLogger.Object,
        mapper, webSocketClientService.Object);

      var runResult = new RunResult
      {
        Id = 1
      };

      var _mockRunOrderService = new MockRunOrderListService();

      runOrderListRepo.Setup(repo => repo.GetListByIdWithLineQuantity(1))
    .ReturnsAsync(_mockRunOrderService.GetRunOrderList(32));

      runResultRepo.Setup(repo => repo.GetRunResultByRunOrderListId(1))
  .ReturnsAsync(runResult);

      Assert.ThrowsAsync<CoilTrackingException>(() => _service.DeleteRunOrderList(1));

    }

    [Fact]
    public void SaveRunoderList_Id_ReturnsRunOrderList()
    {
      var mapper = InitializeMapper();
      var _service = new RunOrderListService(runOrderListRepo.Object, runOrderListQuantityRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object,
        lineRepo.Object, shiftRepo.Object, patternsRepo.Object,
         prodPlanRepo.Object, patternCalendarRepo.Object,
         blanksRepo.Object, partRepo.Object, coilRepo.Object,
        runOrderListServiceLogger.Object,
        mapper, webSocketClientService.Object);

      var runOrderList = new RunOrderListForUpdate
      {
        Date = DateTime.Now,
        LineId = 1,
        ShiftId = 1,
        RunOrderItems = new List<RunOrderItemForUpdate> { new RunOrderItemForUpdate
        { Id=119,
        SortOrder=0,
        PartNumber="51121-06020",
        ModelList="3/592N/770N/792N/844L/L/SIA/TMMI",
        RequestQuantity=0,
        OverrideQuantity=0,
        DataId=4,
        Incomplete=false,

        }
        }
      };
      var incompleteItem = new List<IncompleteRunOrderItem> {new IncompleteRunOrderItem
      {
        Id=1,
        DataNumber=4,
        Line=new Line{Id = 1,
        LineName = "BL1"},
        SortOrder=1

      } };
      var prodPlan = new List<ProdPlan> { new ProdPlan
     {
        Id=1,
        LotSize=1,
        Part=new Part
        {
          PartNumber="51121-06020",
          Id=1
        }
     } };
      var coilTypesList = new List<int> { 1 };
      var shift = new Shift { Id = 1, Name = "Blue" };
      List<string> partNum = new List<string> { "51121-06020" };
      List<int> dataNum = new List<int> { 4 };
      var _mockRunOrderService = new MockRunOrderListService();

      lineRepo.Setup(repo => repo.GetLineWithTimeZoneOpcServer(runOrderList.LineId))
    .ReturnsAsync(_mockRunOrderService.GetLines());
      blanksRepo.Setup(repo => repo.GetBlanksByDataIdList(dataNum))
    .Returns(_mockRunOrderService.GetBlanks());
      partRepo.Setup(repo => repo.GetPartsListByPartNumberList(partNum))
   .Returns(_mockRunOrderService.GetParts());
      shiftRepo.Setup(repo => repo.GetShiftByIdAsync(1))
  .ReturnsAsync(shift);
      runOrderListRepo.Setup(repo => repo.GetIncompleteRunItemByLineId(1))
  .Returns(incompleteItem);
      coilRepo.Setup(repo => repo.GetCoilsList(coilTypesList))
 .Returns(_mockRunOrderService.GetCoils());
      blanksRepo.Setup(repo => repo.GetListByPartnumberLineIds(partNum, 1))
          .Returns(_mockRunOrderService.GetBlanks());
      prodPlanRepo.Setup(repo => repo.GetProdPlanByPartnumberList(partNum))
              .Returns(prodPlan);

      var tt = _service.SaveRunOrderList(runOrderList);
      Assert.NotNull(tt);

    }
    [Fact]
    public void AssignValueToRunOrderQty_Id_ReturnsRunOrderListquantity()
    {
      var mapper = InitializeMapper();
      var _service = new RunOrderListService(runOrderListRepo.Object, runOrderListQuantityRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object,
        lineRepo.Object, shiftRepo.Object, patternsRepo.Object,
         prodPlanRepo.Object, patternCalendarRepo.Object,
         blanksRepo.Object, partRepo.Object, coilRepo.Object,
        runOrderListServiceLogger.Object,
        mapper, webSocketClientService.Object);

      var runOrderList = new RunOrderItemForUpdate
      {
        DataId = 1,
        OverrideQuantity = 1,
        RequestQuantity = 0,
        SortOrder = 8,
        PartNumber = "1"

      };
      var runQty = new RunOrderListQuantity
      {
        BlankInfo = new BlankInfo { DataNumber = 1 },
        Part = new Part { PartName = "wer", PartNumber = "1" },
        SortOrder = 1,
        OverrideQty = 1,
        Quantity = 1
      };

      var shift = new Shift { Name = "Blue" };
      List<string> partNum = new List<string> { "51121 - 06020" };
      List<int> dataNum = new List<int> { 1 };
      var _mockRunOrderService = new MockRunOrderListService();

      blanksRepo.Setup(repo => repo.GetBlanksByDataIdList(dataNum))
    .Returns(_mockRunOrderService.GetBlanks());
      partRepo.Setup(repo => repo.GetPartsListByPartNumberList(partNum))
   .Returns(_mockRunOrderService.GetParts());
      shiftRepo.Setup(repo => repo.GetShiftByIdAsync(1))
  .ReturnsAsync(shift);

      var result = _service.AssignValueToRunOrderQty(runQty, runOrderList, dataNum, partNum);
      Assert.NotNull(result);

    }
    [Fact]
    public void GetModelListFromPart_PartModel_Returnsstring()
    {
      var mapper = InitializeMapper();
      var _service = new RunOrderListService(runOrderListRepo.Object, runOrderListQuantityRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object,
        lineRepo.Object, shiftRepo.Object, patternsRepo.Object,
         prodPlanRepo.Object, patternCalendarRepo.Object,
         blanksRepo.Object, partRepo.Object, coilRepo.Object,
        runOrderListServiceLogger.Object,
        mapper, webSocketClientService.Object);

      var part = new Part
      {
        Id = 1,
        PartName = "fgh",
        PartNumber = "123456"
      };
      var partModel = new List<PartModel> {new PartModel
      {
        Id=1,
        Model=new Model{Id=1,ModelNumber="23",Name="yi"},
        Part=new Part{Id = 1,
        PartName = "fgh",
        PartNumber = "123456"}
      } };
      _service.GetModelListFromPart(part, partModel);

      Assert.True(true);
    }
    [Fact]
    public void AssignDataNumDtovalue_Coils_ReturnsDataNumDto()
    {
      var mapper = InitializeMapper();
      var _service = new RunOrderListService(runOrderListRepo.Object, runOrderListQuantityRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object,
        lineRepo.Object, shiftRepo.Object, patternsRepo.Object,
         prodPlanRepo.Object, patternCalendarRepo.Object,
         blanksRepo.Object, partRepo.Object, coilRepo.Object,
        runOrderListServiceLogger.Object,
        mapper, webSocketClientService.Object);

      var blank = new BlankInfo
      {
        Id = 1,
        DataNumber = 1,
        CoilType = new CoilType { Id = 1, Name = "1-1-C", Yield = 1 },
        Weight = 11,
        StackSize = 1
      };
      var coils = new List<Coil> {new Coil
      {
        Id=1,
        CoilType=new CoilType{Id=1, Name="1-1-C"},
        OriginalWeight=12,
        UnAccountedWeight=11

      } };
      _service.AssignDataNumDtovalue(blank, coils);

      Assert.True(true);
    }
    [Fact]
    public void CheckCallendarEntryOrPatternPresent_PatternCallendarAndPattern_ReturnsBadRequestForpattern()
    {
      var mapper = InitializeMapper();
      var _service = new RunOrderListService(runOrderListRepo.Object, runOrderListQuantityRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object,
        lineRepo.Object, shiftRepo.Object, patternsRepo.Object,
         prodPlanRepo.Object, patternCalendarRepo.Object,
         blanksRepo.Object, partRepo.Object, coilRepo.Object,
        runOrderListServiceLogger.Object,
        mapper, webSocketClientService.Object);

      var patternCallandar = new PatternCalendar
      {
        Id = 1,
        PatternLetter = "A"
      };
      Pattern pattern = null;

      Assert.Throws<CoilTrackingException>(() => _service.CheckCallendarEntryOrPatternPresent(patternCallandar, pattern));

    }
    [Fact]
    public void CheckCallendarEntryOrPatternPresent_PatternCallendarAndPattern_ReturnsBadRequestForpatternCalander()
    {
      var mapper = InitializeMapper();
      var _service = new RunOrderListService(runOrderListRepo.Object, runOrderListQuantityRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object,
        lineRepo.Object, shiftRepo.Object, patternsRepo.Object,
         prodPlanRepo.Object, patternCalendarRepo.Object,
         blanksRepo.Object, partRepo.Object, coilRepo.Object,
        runOrderListServiceLogger.Object,
        mapper, webSocketClientService.Object);

      PatternCalendar patternCallandar = null;
      Pattern pattern = new Pattern { Id = 1 };

      Assert.Throws<CoilTrackingException>(() => _service.CheckCallendarEntryOrPatternPresent(patternCallandar, pattern));

    }
    [Fact]
    public void GetpatternForGetRunOrderList_DatelineId_ReturnsBadRequestForpattern()
    {
      var mapper = InitializeMapper();
      var _service = new RunOrderListService(runOrderListRepo.Object, runOrderListQuantityRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object,
        lineRepo.Object, shiftRepo.Object, patternsRepo.Object,
         prodPlanRepo.Object, patternCalendarRepo.Object,
         blanksRepo.Object, partRepo.Object, coilRepo.Object,
        runOrderListServiceLogger.Object,
        mapper, webSocketClientService.Object);

      PatternCalendar patternCallandar = new PatternCalendar { PatternLetter = "A" };
      var date = DateTime.Now;

      Assert.Throws<CoilTrackingException>(() => _service.GetpatternForGetRunOrderList(date, 1, patternCallandar));

    }
    [Fact]
    public void GetpatternForGetRunOrderList_DatelineId_Returnspattern()
    {
      var mapper = InitializeMapper();
      var _service = new RunOrderListService(runOrderListRepo.Object, runOrderListQuantityRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object,
        lineRepo.Object, shiftRepo.Object, patternsRepo.Object,
         prodPlanRepo.Object, patternCalendarRepo.Object,
         blanksRepo.Object, partRepo.Object, coilRepo.Object,
        runOrderListServiceLogger.Object,
        mapper, webSocketClientService.Object);
      var _mockRunOrderService = new MockRunOrderListService();
      PatternCalendar patternCallandar = new PatternCalendar { PatternLetter = "A" };
      var date = DateTime.Now;
      patternsRepo.Setup(repo => repo.GetPatternsWithPlantOPCServer(1, "A", date))
  .Returns(_mockRunOrderService.GetPattern());
      var result = _service.GetpatternForGetRunOrderList(date, 1, patternCallandar);
      Assert.NotNull(result);

    }
    [Fact]
    public void AssignDataToRunOrderItem_RunOrderItem_ReturnsRunOrderItem()
    {
      var runQty = new RunOrderListQuantity
      {
        BlankInfo = new BlankInfo { DataNumber = 1, CoilType = new CoilType { Id = 1, Name = "1-1-C", CoilTypeYNAs = new List<CoilTypeYNA> { new CoilTypeYNA { Disabled = false } } } },
        Part = new Part { PartName = "wer", PartNumber = "1" },
        SortOrder = 1,
        OverrideQty = 1,
        Quantity = 1

      };
      var mapper = InitializeMapper();
      var _service = new RunOrderListService(runOrderListRepo.Object, runOrderListQuantityRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object,
        lineRepo.Object, shiftRepo.Object, patternsRepo.Object,
         prodPlanRepo.Object, patternCalendarRepo.Object,
         blanksRepo.Object, partRepo.Object, coilRepo.Object,
        runOrderListServiceLogger.Object,
        mapper, webSocketClientService.Object);

      var result = _service.AssignDataToRunOrderItem(runQty);
      Assert.NotNull(result);

    }

    [Fact]
    public void CreateRunoderList_DateIdAndShiftId_ReturnsRunOrderListIdNull()
    {
      var mapper = InitializeMapper();
      var _service = new RunOrderListService(runOrderListRepo.Object, runOrderListQuantityRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object,
        lineRepo.Object, shiftRepo.Object, patternsRepo.Object,
         prodPlanRepo.Object, patternCalendarRepo.Object,
         blanksRepo.Object, partRepo.Object, coilRepo.Object,
        runOrderListServiceLogger.Object,
        mapper, webSocketClientService.Object);
      var _mockRunOrderService = new MockRunOrderListService();

      var incompleteItem = new List<IncompleteRunOrderItem> {new IncompleteRunOrderItem
      {
        Id=1,
        DataNumber=4,
        Line=new Line{Id = 1,
        LineName = "BL1"},
        SortOrder=1,
        Part=new Part{ Id=1,PartNumber="51121-06020",PartName="abc" }

      } };
      DateTime date = DateTime.Now;
      var partNumberList = new List<string> { "51121-06020" };
      var partModel = new List<PartModel> { new PartModel { Id=1,
        Model=new Model{Id=1, Name="d",ModelNumber="sfd"},
        Part=new Part{Id=1, PartNumber="51121-06020",PartName="abc"}
      } };
      var dataNumList = new List<int> { 4 };
      var coilTypesList = new List<int> { 1 };
      var data = new List<BlankInfo>{new BlankInfo
      {
        Id = 4,
        DataNumber = 4,
        DieNo = 1,
        CoilType = new CoilType { Id = 1, Name = "1-1-C" },
        Part = new Part { Id=1, PartNumber = "51121-06020", PartName = "rt" },
        Line=new Line{ Id = 1,
        LineName = "BL1"} } };
      List<ProdPlan> prodPlan = new List<ProdPlan>
      {
        new ProdPlan
        {
          Id=1,
          LotSize=1,
          Part=new Part{Id=1, PartName="ssfd", PartNumber="51121-06020"}
        }
      };

      runOrderListRepo.Setup(repo => repo.GetListByDateLineIdAndShift(date, 1, 1))
    .ReturnsAsync(_mockRunOrderService.GetRunOrderListreturnsRunOrderListById(2));
      patternCalendarRepo.Setup(repo => repo.GetPatternCalendarByDateLineIdAndShiftId(date, 1, 1))
    .ReturnsAsync(_mockRunOrderService.GetPatternCalendar(2));
      patternsRepo.Setup(repo => repo.GetPatternsByLineIdPatternLetterAndDate(1, "A", date))
    .ReturnsAsync(_mockRunOrderService.GetPattern());
      partRepo.Setup(repo => repo.GetPartsListByPartNumberList(partNumberList))
    .Returns(_mockRunOrderService.GetParts());
      partRepo.Setup(repo => repo.GetPartModelsByPartNumberList(partNumberList))
   .Returns(partModel);
      runOrderListRepo.Setup(repo => repo.GetIncompleteRunOrderItemsByLineId(1))
  .Returns(incompleteItem);
      blanksRepo.Setup(repo => repo.GetBlankInfoByListOfDataNumAndLineId(dataNumList, 1))
  .Returns(data);
      coilRepo.Setup(repo => repo.GetCoilsList(coilTypesList))
.Returns(_mockRunOrderService.GetCoils());
      blanksRepo.Setup(repo => repo.GetListByPartnumberLineIds(partNumberList, 1))
           .Returns(_mockRunOrderService.GetBlanks());
      prodPlanRepo.Setup(repo => repo.GetProdPlanByPartnumberList(partNumberList))
             .Returns(prodPlan);

      var result = _service.CreateRunOrderList(date, 1, 1);
      Assert.NotNull(result);
    }

    [Fact]
    public void UpdateRunoderList_Id_ReturnsRunOrderList()
    {
      var mapper = InitializeMapper();
      var _service = new RunOrderListService(runOrderListRepo.Object, runOrderListQuantityRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object,
        lineRepo.Object, shiftRepo.Object, patternsRepo.Object,
         prodPlanRepo.Object, patternCalendarRepo.Object,
         blanksRepo.Object, partRepo.Object, coilRepo.Object,
        runOrderListServiceLogger.Object,
        mapper, webSocketClientService.Object);
      var runList = new RunOrderList
      {
        Id = 1,
        Date = DateTime.Now,
        PatternLetter = "A",
        Line = new Line { Id = 1, LineName = "BL1" },
        Quantities = new List<RunOrderListQuantity>
        {
          new RunOrderListQuantity
           {
            Id=1,
        Incomplete=false, Part=new Part{PartNumber="51121-06020"}, Quantity= 100, SortOrder=0, OverrideQty=0,
        BlankInfo=new BlankInfo{ Id = 4,
        DataNumber = 1,
        DieNo = 1,
        CoilType = new CoilType { Id = 1, Name = "1-1-C" },
        Part = new Part { Id=1, PartNumber = "51121-06020", PartName = "rt" },
        Line=new Line{ Id = 1,
        LineName = "BL1"}}
          }
        }
      };
      var runOrderList = new RunOrderListForUpdate
      {
        Id = 1,
        Date = DateTime.Now,
        LineId = 1,
        ShiftId = 1,
        RunOrderItems = new List<RunOrderItemForUpdate> { new RunOrderItemForUpdate
        { Id = 119,
          SortOrder = 0,
          PartNumber = "51121-06020",
          ModelList = "3/592N/770N/792N/844L/L/SIA/TMMI",
          RequestQuantity = 0,
          OverrideQuantity = 0,
          DataId = 4,
          Incomplete = false,
        }
        }
      };
      var incompleteItem = new List<IncompleteRunOrderItem> {new IncompleteRunOrderItem
      {
        Id=1,
        DataNumber=4,
        Line=new Line{Id = 1,
        LineName = "BL1"},
        SortOrder=1,
        Part=new Part{PartNumber = "51121-06020", PartName = "rt" },
        RunOrderItem=new RunOrderListQuantity{Id=1,
        Incomplete=false, Part=new Part{PartNumber="51121-06020"}, Quantity= 100, SortOrder=0, OverrideQty=0,
        BlankInfo=new BlankInfo{ Id = 4,
        DataNumber = 1,
        DieNo = 1,
        CoilType = new CoilType { Id = 1, Name = "1-1-C" },
        Part = new Part { Id=1, PartNumber = "51121-06020", PartName = "rt" },
        Line=new Line{ Id = 1,
        LineName = "BL1"}} }

      } };

      var qtyList = new List<RunOrderListQuantity> { new RunOrderListQuantity
      {
        Id=119,
        Incomplete=false,
        Part=new Part
        {
          PartNumber="51121-06020",
          Id=1
        },
        Quantity=9,
        SortOrder=0,
        BlankInfo=new BlankInfo
        {
          Id = 4,
        DataNumber = 1,
        DieNo = 1,
        CoilType = new CoilType { Id = 1, Name = "1-1-C" }

        }
      } };
      var shift = new Shift { Id = 1, Name = "Blue" };
      List<string> partNum = new List<string> { "51121-06020" };
      List<int> dataNum = new List<int> { 4 };
      var _mockRunOrderService = new MockRunOrderListService();

      List<int> qty = new List<int> { 1 };
      List<int> ids = new List<int> { 119 };
      runOrderListRepo.Setup(repo => repo.GetListByIdWithLineQuantity(1))
    .ReturnsAsync(_mockRunOrderService.GetRunOrderList(32));
      runOrderListRepo.Setup(repo => repo.GetIncompleteItemListByRunOrderId(qty))
    .ReturnsAsync(incompleteItem);
      runOrderListRepo.Setup(repo => repo.GetRunOrderListByIdAsync(1))
    .ReturnsAsync(runList);
      lineRepo.Setup(repo => repo.GetLineWithTimeZoneOpcServer(1))
    .ReturnsAsync(_mockRunOrderService.GetLines());
      shiftRepo.Setup(repo => repo.GetShiftByIdAsync(1))
  .ReturnsAsync(shift);
      runOrderListQuantityRepo.Setup(repo => repo.GetRunOrderListQuantityByQtyIdList(ids))
    .Returns(qtyList);
      blanksRepo.Setup(repo => repo.GetBlanksByDataIdList(dataNum))
    .Returns(_mockRunOrderService.GetBlanks());
      partRepo.Setup(repo => repo.GetPartsListByPartNumberList(partNum))
   .Returns(_mockRunOrderService.GetParts());

      var result = _service.UpdateRunOrderList(1, runOrderList);
      Assert.NotNull(result);

    }

    [Fact]
    public void GetRunOrderItemForGet_DateIdAndShiftId_ReturnsRunOrderListIdNull()
    {
      var mapper = InitializeMapper();
      var _service = new RunOrderListService(runOrderListRepo.Object, runOrderListQuantityRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object,
        lineRepo.Object, shiftRepo.Object, patternsRepo.Object,
         prodPlanRepo.Object, patternCalendarRepo.Object,
         blanksRepo.Object, partRepo.Object, coilRepo.Object,
        runOrderListServiceLogger.Object,
        mapper, webSocketClientService.Object);

      var runList = new RunOrderList
      {
        Id = 1,
        Date = DateTime.Now,
        PatternLetter = "A",
        Line = new Line { Id = 1, LineName = "BL1" },
        Quantities = new List<RunOrderListQuantity>
        {
          new RunOrderListQuantity
           {
            Id=1,
        Incomplete=false, Part=new Part{PartNumber="51121-06020"}, Quantity= 100, SortOrder=0, OverrideQty=0,
        BlankInfo=new BlankInfo{ Id = 4,
        DataNumber = 1,
        DieNo = 1,
        CoilType = new CoilType { Id = 1, Name = "1-1-C" , CoilTypeYNAs=new List<CoilTypeYNA>{
        new CoilTypeYNA{ Id=1,Disabled=false} } },
        Part = new Part { Id=1, PartNumber = "51121-06020", PartName = "rt" },
        Line=new Line{ Id = 1,
        LineName = "BL1"}}
          }
        },
        Shift = new Shift
        {
          Id = 1,
          Name = "Blue"
        }
      };
      DateTime date = DateTime.Now;
      runOrderListRepo.Setup(repo => repo.GetListWithQuantitiesAndShifts(date, 1, 1))
    .ReturnsAsync(runList);
      var result = _service.GetRunOrderItemForGet(date, 1, 1);
      Assert.NotNull(result);
    }
  }
}
