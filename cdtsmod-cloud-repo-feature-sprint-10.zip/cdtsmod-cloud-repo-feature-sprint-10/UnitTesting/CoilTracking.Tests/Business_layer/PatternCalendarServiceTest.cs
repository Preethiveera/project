using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class PatternCalendarServiceTest
  {
    private readonly Mock<IPatternCalendarRepository> patternCalendarRepository;
    private readonly Mock<IShiftRepository> shiftRepository;
    private readonly Mock<ILineRepository> lineRepository;
    private readonly Mock<IApplicationLogger<PatternCalendarService>> patternCalendarLogger;

    public IMapper InitializeMapper()
    {
      var mockMapper = new MapperConfiguration(cfg =>
      {
        cfg.AddProfile(new MappingProfile());
      });
      var mapper = mockMapper.CreateMapper();

      return mapper;
    }

    public PatternCalendarServiceTest()
    {
      this.patternCalendarRepository = new Mock<IPatternCalendarRepository>();
      this.shiftRepository = new Mock<IShiftRepository>();
      this.lineRepository = new Mock<ILineRepository>();
      this.patternCalendarLogger = new Mock<IApplicationLogger<PatternCalendarService>>();
    }

    [Fact]
    public void GetGetPatternCalendars_ReturnsCalendarItemDto()
    {
      var mapper = InitializeMapper();
      var _service = new PatternCalendarService(patternCalendarRepository.Object, lineRepository.Object, shiftRepository.Object, patternCalendarLogger.Object, mapper);

      var result = _service.GetPatternCalendars();

      Assert.NotNull(result);
    }

    [Fact]
    public async Task GetGetPatternCalendars_ReturnsPatternCalendarExportDto()
    {
      var patternCalendars = new List<PatternCalendar>()
      {
        new PatternCalendar(){
        Id = 1,
        Date = DateTime.Now,
        Shift = new Shift
        {
          Id = 2,
          Name = "RED",

        },
        PatternLetter = "Z",
        Line = new Line
        {
          Id = 1,
          Plant = new Plant
          {
            Id = 1,
            NAMCCode = "A",
            PlantName = "P",
            TimeZone = new PlantTimeZone
            {
              Id = 1,
              Name = "J",
              TimeZoneOffset = 2

            }

          },
          Plant_Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1,
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          OPCServer_Id = 1,
          LinePath = "-",
          Tags = "-,-,-,-,-,-,-,-,-,-,-,-,-,-",
          Subscribed = false,
          Disabled = false
        }
      } };

      var mapper = InitializeMapper();
      var service = new PatternCalendarService(patternCalendarRepository.Object, lineRepository.Object, shiftRepository.Object, patternCalendarLogger.Object, mapper);

      patternCalendarRepository.Setup(repo => repo.GetPatternCalendarByMonthAndYear(It.IsAny<int>(), It.IsAny<int>())).ReturnsAsync(patternCalendars);

      var result = await service.GetPatternCalendarsForExport();

      Assert.NotNull(result);
      Assert.NotNull(result.Data);
      Assert.True(result.Data.Count > 0);
      Assert.NotNull(result.DateList);
    }

    [Fact]
    public async Task GetPatternCalendars_ReturnsDataCountZero()
    {
      var mapper = InitializeMapper();
      var service = new PatternCalendarService(patternCalendarRepository.Object, lineRepository.Object, shiftRepository.Object, patternCalendarLogger.Object, mapper);

      patternCalendarRepository.Setup(repo => repo.GetPatternCalendarByMonthAndYear(It.IsAny<int>(), It.IsAny<int>())).ReturnsAsync(new List<PatternCalendar>());

      var result = await service.GetPatternCalendarsForExport();

      Assert.NotNull(result);
      Assert.NotNull(result.Data);
      Assert.True(result.Data.Count == 0);
      Assert.NotNull(result.DateList);
    }

    [Fact]
    public async Task GetPatternCalendar_ReturnsPatternCalendar()
    {
      var patternCalendar = new PatternCalendar()
      {
        Id = 1,
        Date = DateTime.Now,
        Shift = new Shift
        {
          Id = 2,
          Name = "RED",

        },
        PatternLetter = "Z",
        Line = new Line
        {
          Id = 1,
          Plant = new Plant
          {
            Id = 1,
            NAMCCode = "A",
            PlantName = "P",
            TimeZone = new PlantTimeZone
            {
              Id = 1,
              Name = "J",
              TimeZoneOffset = 2

            }

          },
          Plant_Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1,
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          OPCServer_Id = 1,
          LinePath = "-",
          Tags = "-,-,-,-,-,-,-,-,-,-,-,-,-,-",
          Subscribed = false,
          Disabled = false
        }
      };

      var mapper = InitializeMapper();
      var service = new PatternCalendarService(patternCalendarRepository.Object, lineRepository.Object, shiftRepository.Object, patternCalendarLogger.Object, mapper);

      var id = 1;

      patternCalendarRepository.Setup(repo => repo.GetPatternCalendarById(id)).ReturnsAsync(patternCalendar);

      var result = await service.GetPatternCalendar(id);

      Assert.NotNull(result);
      Assert.True(result.Id > 0);
    }

    [Fact]
    public async Task GetPatternCalendar_ReturnsNull()
    {

      var mapper = InitializeMapper();
      var service = new PatternCalendarService(patternCalendarRepository.Object, lineRepository.Object, shiftRepository.Object, patternCalendarLogger.Object, mapper);

      var id = 19;

      patternCalendarRepository.Setup(repo => repo.GetPatternCalendarById(id)).Returns(Task.FromResult<PatternCalendar>(null));

      var result = await service.GetPatternCalendar(id);

      Assert.Null(result);

    }

    [Fact]
    public async Task GetPatternCalendar_ReturnsCalendarItemDto()
    {
      var patternCalendars = new List<PatternCalendar>()
      {
        new PatternCalendar(){
        Id = 1,
        Date = DateTime.Now.Date,
        Shift = new Shift
        {
          Id = 2,
          Name = "RED",

        },
        PatternLetter = "Z",
        Line = new Line
        {
          Id = 1,
          Plant = new Plant
          {
            Id = 1,
            NAMCCode = "A",
            PlantName = "P",
            TimeZone = new PlantTimeZone
            {
              Id = 1,
              Name = "J",
              TimeZoneOffset = 2

            }

          },
          Plant_Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1,
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          OPCServer_Id = 1,
          LinePath = "-",
          Tags = "-,-,-,-,-,-,-,-,-,-,-,-,-,-",
          Subscribed = false,
          Disabled = false
        }
      } };

      var mapper = InitializeMapper();
      var service = new PatternCalendarService(patternCalendarRepository.Object, lineRepository.Object, shiftRepository.Object, patternCalendarLogger.Object, mapper);

      var lineId = 1;
      var shiftId = 1;

      patternCalendarRepository.Setup(repo => repo.GetPatternCalendarByMonthYearShiftIdLineId(DateTime.Now.Date.Month, DateTime.Now.Date.Year, lineId, shiftId))
        .ReturnsAsync(patternCalendars);

      var result = await service.GetPatternCalendar(DateTime.Now.Date, lineId, shiftId);

      Assert.NotNull(result);
    }

    [Fact]
    public async Task ChangePattern_ReturnsTrue()
    {

      var mapper = InitializeMapper();
      var service = new PatternCalendarService(patternCalendarRepository.Object, lineRepository.Object, shiftRepository.Object, patternCalendarLogger.Object, mapper);

      var id = 1;
      var patternLetter = "J";
      var patternCalendar = new PatternCalendar()
      {
        Id = 1,
        Date = DateTime.Now,
        Shift = new Shift
        {
          Id = 2,
          Name = "RED",

        },
        PatternLetter = "Z",
        Line = new Line
        {
          Id = 1,
          Plant = new Plant
          {
            Id = 1,
            NAMCCode = "A",
            PlantName = "P",
            TimeZone = new PlantTimeZone
            {
              Id = 1,
              Name = "J",
              TimeZoneOffset = 2

            }

          },
          Plant_Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1,
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          OPCServer_Id = 1,
          LinePath = "-",
          Tags = "-,-,-,-,-,-,-,-,-,-,-,-,-,-",
          Subscribed = false,
          Disabled = false
        }
      };

      patternCalendarRepository.Setup(repo => repo.GetPatternCalendarById(id)).ReturnsAsync(patternCalendar);
      patternCalendarRepository.Setup(repo => repo.UpdatePatternCalendar(It.IsAny<PatternCalendar>())).ReturnsAsync(true);

      var result = await service.ChangePattern(id, patternLetter);

      Assert.True(result);
    }

    [Fact]
    public async Task ChangePattern_ReturnsFalse()
    {

      var mapper = InitializeMapper();
      var service = new PatternCalendarService(patternCalendarRepository.Object, lineRepository.Object, shiftRepository.Object, patternCalendarLogger.Object, mapper);

      var id = 1;
      var patternLetter = "J";
      var patternCalendar = new PatternCalendar()
      {
        Id = 1,
        Date = DateTime.Now,
        Shift = new Shift
        {
          Id = 2,
          Name = "RED",

        },
        PatternLetter = "Z",
        Line = new Line
        {
          Id = 1,
          Plant = new Plant
          {
            Id = 1,
            NAMCCode = "A",
            PlantName = "P",
            TimeZone = new PlantTimeZone
            {
              Id = 1,
              Name = "J",
              TimeZoneOffset = 2

            }

          },
          Plant_Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1,
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          OPCServer_Id = 1,
          LinePath = "-",
          Tags = "-,-,-,-,-,-,-,-,-,-,-,-,-,-",
          Subscribed = false,
          Disabled = false
        }
      };

      patternCalendarRepository.Setup(repo => repo.GetPatternCalendarById(id)).ReturnsAsync(patternCalendar);
      patternCalendarRepository.Setup(repo => repo.UpdatePatternCalendar(It.IsAny<PatternCalendar>())).ReturnsAsync(false);

      var result = await service.ChangePattern(id, patternLetter);

      Assert.False(result);
    }

    [Fact]
    public async Task PutPatternCalendar_ReturnsTrue()
    {
      var patternCalendarDto = new PatternCalendarDto()
      {
        Id = 1,
        Date = DateTime.Now,
        Shift = new ShiftDto
        {
          Id = 2,
          Name = "RED",

        },
        PatternLetter = "Z",
        Line = new LineDto
        {
          Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfigDTO
          {
            Id = 1,
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          LinePath = "-",
          Disabled = false
        }
      };

      var mapper = InitializeMapper();
      var service = new PatternCalendarService(patternCalendarRepository.Object, lineRepository.Object, shiftRepository.Object, patternCalendarLogger.Object, mapper);


      patternCalendarRepository.Setup(repo => repo.UpdatePatternCalendar(It.IsAny<PatternCalendar>())).ReturnsAsync(true);

      var result = await service.PutPatternCalendar(patternCalendarDto);

      Assert.True(result);
    }

    [Fact]
    public async Task PutPatternCalendar_ReturnsFalse()
    {
      var patternCalendarDto = new PatternCalendarDto()
      {
        Id = 1,
        Date = DateTime.Now,
        Shift = new ShiftDto
        {
          Id = 2,
          Name = "RED",

        },
        PatternLetter = "Z",
        Line = new LineDto
        {
          Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfigDTO
          {
            Id = 1,
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          LinePath = "-",
          Disabled = false
        }
      };

      var mapper = InitializeMapper();
      var service = new PatternCalendarService(patternCalendarRepository.Object, lineRepository.Object, shiftRepository.Object, patternCalendarLogger.Object, mapper);


      patternCalendarRepository.Setup(repo => repo.UpdatePatternCalendar(It.IsAny<PatternCalendar>())).ReturnsAsync(false);

      var result = await service.PutPatternCalendar(patternCalendarDto);

      Assert.False(result);
    }

    [Fact]
    public async Task AddPatternCalendar_ReturnsPatternCalendarDto()
    {
      var patternCalendar = new PatternCalendar()
      {
        Id = 1,
        Date = DateTime.Now,
        Shift = new Shift
        {
          Id = 2,
          Name = "RED",

        },
        PatternLetter = "Z",
        Line = new Line
        {
          Id = 1,
          Plant = new Plant
          {
            Id = 1,
            NAMCCode = "A",
            PlantName = "P",
            TimeZone = new PlantTimeZone
            {
              Id = 1,
              Name = "J",
              TimeZoneOffset = 2

            }

          },
          Plant_Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1,
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          OPCServer_Id = 1,
          LinePath = "-",
          Tags = "-,-,-,-,-,-,-,-,-,-,-,-,-,-",
          Subscribed = false,
          Disabled = false
        }
      };

      var patternCalendarDto = new PatternCalendarDto()
      {
        Id = 1,
        Date = DateTime.Now,
        Shift = new ShiftDto
        {
          Id = 2,
          Name = "RED",

        },
        PatternLetter = "Z",
        Line = new LineDto
        {
          Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfigDTO
          {
            Id = 1,
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          LinePath = "-",
          Disabled = false
        }
      };

      var mapper = InitializeMapper();
      var service = new PatternCalendarService(patternCalendarRepository.Object, lineRepository.Object, shiftRepository.Object, patternCalendarLogger.Object, mapper);

      patternCalendarRepository.Setup(repo => repo.AddPatternCalendar(It.IsAny<PatternCalendar>())).ReturnsAsync(patternCalendar);

      var result = await service.PostPatternCalendar(patternCalendarDto);

      Assert.NotNull(result);
    }

    [Fact]
    public async Task RemovePatternCalendar_ReturnsPatternCalendarDto()
    {
      var patternCalendar = new PatternCalendar()
      {
        Id = 1,
        Date = DateTime.Now,
        Shift = new Shift
        {
          Id = 2,
          Name = "RED",

        },
        PatternLetter = "Z",
        Line = new Line
        {
          Id = 1,
          Plant = new Plant
          {
            Id = 1,
            NAMCCode = "A",
            PlantName = "P",
            TimeZone = new PlantTimeZone
            {
              Id = 1,
              Name = "J",
              TimeZoneOffset = 2

            }

          },
          Plant_Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1,
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          OPCServer_Id = 1,
          LinePath = "-",
          Tags = "-,-,-,-,-,-,-,-,-,-,-,-,-,-",
          Subscribed = false,
          Disabled = false
        }
      };

      var patternCalendarDto = new PatternCalendarDto()
      {
        Id = 1,
        Date = DateTime.Now,
        Shift = new ShiftDto
        {
          Id = 2,
          Name = "RED",

        },
        PatternLetter = "Z",
        Line = new LineDto
        {
          Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfigDTO
          {
            Id = 1,
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          LinePath = "-",
          Disabled = false
        }
      };

      var mapper = InitializeMapper();
      var service = new PatternCalendarService(patternCalendarRepository.Object, lineRepository.Object, shiftRepository.Object, patternCalendarLogger.Object, mapper);

      int id = 1;

      patternCalendarRepository.Setup(repo => repo.GetPatternCalendarById(id)).ReturnsAsync(patternCalendar);
      patternCalendarRepository.Setup(repo => repo.RemovePatternCalendar(It.IsAny<PatternCalendar>())).ReturnsAsync(true);



      var result = await service.DeletePatternCalendar(id);

      Assert.NotNull(result);
    }
  }
}
