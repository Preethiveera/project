using CoilTracking.Business.Implementation;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Logging;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using Microsoft.EntityFrameworkCore;
using Moq;
using System;
using System.Collections.Generic;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class AndonServiceTest : DbContext
  {
    private readonly Mock<IApplicationLogger<AndonService>> andonServiceLogger;
    private readonly Mock<IBlankInfoesRepository> blankInfoesRepo;
    private readonly Mock<IPlantsRepository> plantsRepo;
    private readonly Mock<ICoilFieldZoneRepository> coilFieldZoneRepo;
    private readonly Mock<ICoilRepository> coilRepo;
    private readonly Mock<ICoilTypeRepository> coilTypeRepo;
    private readonly Mock<ICoilFieldLocationRepository> coilFieldLocationRepo;
    public readonly Mock<IAndonService> AndonServiceMock;
    public readonly Mock<CoilTrackingContext> coilcontext;
    public static CoilTrackingContext _context;
    private readonly Mock<IUserHelper> usersHelper;

    public AndonServiceTest()
    {
      AndonServiceMock = new Mock<IAndonService>();
      andonServiceLogger = new Mock<IApplicationLogger<AndonService>>();
      blankInfoesRepo = new Mock<IBlankInfoesRepository>();
      plantsRepo = new Mock<IPlantsRepository>();
      coilFieldZoneRepo = new Mock<ICoilFieldZoneRepository>();
      coilRepo = new Mock<ICoilRepository>();
      coilTypeRepo = new Mock<ICoilTypeRepository>();
      coilFieldLocationRepo = new Mock<ICoilFieldLocationRepository>();
      coilcontext = new Mock<CoilTrackingContext>();
      usersHelper = new Mock<IUserHelper>();
    }

    [Fact]
    public void GetCoilsFeildsByZoneId_CoilsFeilds_ReturnCoilsFeilds()
    {
      string NAMC = "TMMK";
      List<int> dieNo = new List<int>() { 4 };
      int? zoneId = null;
      List<Coil> coil = new List<Coil>
            {
                new Coil()
                {
                    Id = 7,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9,
                     CoilRunHistory = new List<CoilRunHistory>(){ new CoilRunHistory() { Id = 2, Coil= new Coil {   Id = 7,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9 } }  },CoilStatus = new CoilStatus() { Id=8, Name="test", Color="test", InInventory=true, IsUsable=true, TextColor="white" }, Mill = new Mill(){ Id=9, Name="test", Disabled=true },
                    CoilType = new CoilType() { Id = 7, Name = "test" , CoilFieldZone = new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } },
                   CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } } } } }

                }
            };
      var dbzones = new List<CoilFieldZone>
            {
                new CoilFieldZone()
                {
                    Id = 1,
                    Name = "Test",
                    Disabled = true
             , Locations = new List<CoilFieldLocation>
                {
                new CoilFieldLocation()
                {
                    Id=8, Name="test", Column=8, Disabled=true, IsEmpty=true, Row=8, Zone = new CoilFieldZone(){Id=1, Disabled=true,Name="test", Color="white" , TextColor="",  CoilField = new CoilField(){ Id=3, Name="test", Disabled=true,Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } } } }
                }
            },
                    CoilField = new CoilField( ){ Id=8, Disabled=true, Name="Test", Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } }},
                    TextColor = "red",
                    Color = "white"

                }
            };
      List<CoilFieldLocation> CoilFieldLocations = new List<CoilFieldLocation>
            {
                new CoilFieldLocation()
                {
                    Id=14,  Name="test", Column=8, Disabled=true, IsEmpty=true,  Row=8,  Zone = new CoilFieldZone(){Id=1, Disabled=true,Name="test", Color="white" , TextColor="",  Locations= new List<CoilFieldLocation>(){ new CoilFieldLocation() { Id = 1, IsEmpty = true, Name = "test", Disabled = true, Column = 1, Row = 1 , Zone = new CoilFieldZone() { Id = 2, Disabled = true, TextColor = "white", Name = "red", Color = "white" } } }, CoilField = new CoilField(){ Id=8, Name="test", Disabled=true,Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true, Locations= new List<CoilFieldLocation>() { new CoilFieldLocation() { Id=1, IsEmpty=true, Name="test", Disabled=true, Column=1,Row=1,
                    Zone = new CoilFieldZone(){ Id=2, Disabled=true, TextColor="white", Name="red", Color="white", Locations= new List<CoilFieldLocation> () { new CoilFieldLocation() { Id=1, IsEmpty=true, Name="test", Column=1, Disabled=true,Row=2, Zone= new CoilFieldZone() { Id=4, Disabled=true, Name="e", Color="white", Locations=new List<CoilFieldLocation>() { new CoilFieldLocation() { Id=1, IsEmpty=true, Name="e", Column=1, Row=1, Disabled=true, Zone = new CoilFieldZone() { Id=4, Locations = new List<CoilFieldLocation>() { new CoilFieldLocation() { Id = 1, IsEmpty = true, Name = "test", Column = 1, Disabled = true, Row = 2  } } }   } } }   } } } } } } } } }
                }
            };
      plantsRepo.Setup(repo => repo.GetPlantName())
       .Returns((NAMC));
      coilRepo.Setup(repo => repo.GetCoilsFeildsByZoneId(zoneId))
     .Returns((coil));

      coilFieldZoneRepo.Setup(repo => repo.GetCoilFieldZones(zoneId))
   .Returns((dbzones));
      coilFieldLocationRepo.Setup(repo => repo.CoilFieldLocations(coil, CoilFieldLocations))
     .Returns((coil));
      blankInfoesRepo.Setup(repo => repo.GetdieNo(CoilFieldLocations))
 .Returns((dieNo));
      var _service = new AndonService(andonServiceLogger.Object, blankInfoesRepo.Object, plantsRepo.Object,  coilFieldZoneRepo.Object, coilRepo.Object, coilTypeRepo.Object, usersHelper.Object);
      var res=_service.GetCoilsFeildsByZoneId(zoneId);
      Assert.NotNull(res);
    }

    [Fact]
    public void SetCoilStatusColors_Colors_SetCoilstatus()
    {
      string dieNo = "101";
      string NAMC = "TMMI";
      Coil coils = new Coil()
      {
        Id = 1,
        IsPriority = true,
        FTZ = "",
        CoilStatus = new CoilStatus { Id = 9, Color = "red", Name = "new", TextColor = "white", IsUsable = true, InInventory = true },
        CoilFieldLocation = new CoilFieldLocation { Id = 9, Name = "y-u", IsEmpty = true, Column = 4, Zone = new CoilFieldZone { Id = 1, Name = "E-S", Color = "red", TextColor = "mm" } }
      };
      var _service = new AndonService(andonServiceLogger.Object, blankInfoesRepo.Object, plantsRepo.Object,  coilFieldZoneRepo.Object, coilRepo.Object, coilTypeRepo.Object, usersHelper.Object);
     _service.SetCoilStatusColors(coils, dieNo, NAMC);
      Assert.True(true);
    }

    [Fact]
    public void SetAndonCoilTypevalue_AndonCoilType_SetCoilType()
    {
      int numval = 0;
      AndonCoilType andonCoilType = new AndonCoilType()
      {
        Kanban = true,
        Name = "test",
        NumCoils = 1,
        WrongZone = true,
        CoilLocationsInOrder = new List<AndonCoilTypeLocation> { new AndonCoilTypeLocation() { CoilId = 2, BackgroundColor = "white", Name = "w", TextColor = "white" } }
      };
      List<Coil> coil = new List<Coil>
            {
                new Coil()
                {
                    Id = 6,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9,
                     CoilRunHistory = new List<CoilRunHistory>(){ new CoilRunHistory() { Id = 2, RunOrderList = new RunOrderList(){ }, WeightUsed=1,  Coil= new Coil {   Id = 7,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",  CoilFieldLocation = new CoilFieldLocation() { Id = 7, Disabled=true, IsEmpty=true, Row=1, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "white",  Locations = new List<CoilFieldLocation>(){ new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Disabled=true, IsEmpty=true, Row=1, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "white", TextColor = "white", Locations = new List<CoilFieldLocation>() { }, CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test",  Id = 9, Locations = new List<CoilFieldLocation>() { new CoilFieldLocation() { } }, CoilField = new CoilField() { }, Color = "white", TextColor = "white", Disabled = true } } } } } } , TextColor = "white", CoilField = new CoilField { Id = 9,  Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9,  Locations = new List<CoilFieldLocation>() { new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "white", TextColor = "white", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Locations = new List<CoilFieldLocation>() { new CoilFieldLocation() { } }, CoilField = new CoilField() { }, Color = "white", TextColor = "white", Disabled = true } } } } }  }, CoilField = new CoilField() { }, Color = "white", TextColor= "white",Disabled = true } } } } }, CoilType = new CoilType(){ Id = 7, Name = "test" , NumCoils=4, CoilFieldZone = new CoilFieldZone() { Name = "test", Id = 9, Color = "white",  Disabled = true } }  , Mill = new Mill() { Id=6, Name="white",Disabled
                    =true}, CoilStatus = new CoilStatus() { Id=4, Name="w", Color="white", InInventory=true, IsUsable=true, TextColor="white" }, CoilRunHistory = new List<CoilRunHistory>(){ new CoilRunHistory() { Id=3, WeightUsed=4, RunOrderList= new RunOrderList() { Id=8, Date=DateTime.Now, PatternLetter="h", Line = new Line() { Id=1, Disabled=true, LineName="test",LinePath="", OPCServer_Id=1,  Plant= new Plant() { Id=1, PlantName="white", TimeZone= new PlantTimeZone(){ Id=6, Name="", TimeZoneOffset=0 }
                    }   } } } },
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9 } }  },CoilStatus = new CoilStatus() { Id=8,  Name="test", Color="test", InInventory=true, IsUsable=true, TextColor="white" }, Mill = new Mill(){ Id=9, Name="test", Disabled=true  },
                    CoilType = new CoilType() { Id = 7, Name = "test" , CoilFieldZone = new CoilFieldZone() { Name = "test", Id = 9, Color = "white", Disabled = true , TextColor = "white",  CoilField = new CoilField() { Id=1, Disabled=true, Name="w", Zones = new List<CoilFieldZone>(){ new CoilFieldZone { } }  } } },
                    CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Disabled=true, IsEmpty=true, Row=1, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "white", TextColor = "white", CoilField = new CoilField { Id = 9, Name = "test",  Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "",  Disabled = true } } } } }

                }
            };
      AndonZone andonZone = new AndonZone { Name = "", BackgroundColor = "testcolor", TextColor = "red", LocationsCount = 1, MaxCoilColumns = 9, LocationsUsedCount = 9 };
      coilRepo.Setup(repo => repo.GetKanCoils())
     .Returns((coil));
      var _service = new AndonService(andonServiceLogger.Object, blankInfoesRepo.Object, plantsRepo.Object,  coilFieldZoneRepo.Object, coilRepo.Object, coilTypeRepo.Object, usersHelper.Object);
      _service.SetAndonCoilTypevalue(andonCoilType, numval, andonZone);

      Assert.True(true);
    }

    [Fact]
    public void SetAndondbCoilType_dbCoilType_ReturnNull()
    {

      AndonCoilType andonCoilType = new AndonCoilType()
      {
        Kanban = true,
        Name = "test",
        NumCoils = 0,
        WrongZone = true,
        CoilLocationsInOrder = new List<AndonCoilTypeLocation> { new AndonCoilTypeLocation() { CoilId = 8, TextColor = "w", Name = "w", BackgroundColor = "e" } }
      };
      List<Coil> coil = new List<Coil>
            {
                new Coil()
                {
                    Id = 6,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9,
                     CoilRunHistory = new List<CoilRunHistory>(){ new CoilRunHistory() { Id = 2, RunOrderList = new RunOrderList(){ }, WeightUsed=1,  Coil= new Coil {   Id = 7,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",  CoilFieldLocation = new CoilFieldLocation() { Id = 7, Disabled=true, IsEmpty=true, Row=1, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "white",  Locations = new List<CoilFieldLocation>(){ new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Disabled=true, IsEmpty=true, Row=1, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "white", TextColor = "white", Locations = new List<CoilFieldLocation>() { }, CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test",  Id = 9, Locations = new List<CoilFieldLocation>() { new CoilFieldLocation() { } }, CoilField = new CoilField() { }, Color = "white", TextColor = "white", Disabled = true } } } } } } , TextColor = "white", CoilField = new CoilField { Id = 9,  Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9,  Locations = new List<CoilFieldLocation>() { new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "white", TextColor = "white", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Locations = new List<CoilFieldLocation>() { new CoilFieldLocation() { } }, CoilField = new CoilField() { }, Color = "white", TextColor = "white", Disabled = true } } } } }  }, CoilField = new CoilField() { }, Color = "white", TextColor= "white",Disabled = true } } } } }, CoilType = new CoilType(){ Id = 7, Name = "test" , NumCoils=4, CoilFieldZone = new CoilFieldZone() { Name = "test", Id = 9, Color = "white",  Disabled = true } }  , Mill = new Mill() { Id=6, Name="white",Disabled
                    =true}, CoilStatus = new CoilStatus() { Id=4, Name="w", Color="white", InInventory=true, IsUsable=true, TextColor="white" }, CoilRunHistory = new List<CoilRunHistory>(){ new CoilRunHistory() { Id=3, WeightUsed=4, RunOrderList= new RunOrderList() { Id=8, Date=DateTime.Now, PatternLetter="h", Line = new Line() { Id=1, Disabled=true, LineName="test",LinePath="", OPCServer_Id=1,  Plant= new Plant() { Id=1, PlantName="white", TimeZone= new PlantTimeZone(){ Id=6, Name="", TimeZoneOffset=0 }
                    }   } } } },
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9 } }  },CoilStatus = new CoilStatus() { Id=8,  Name="test", Color="test", InInventory=true, IsUsable=true, TextColor="white" }, Mill = new Mill(){ Id=9, Name="test", Disabled=true  },
                    CoilType = new CoilType() { Id = 7, Name = "test" , CoilFieldZone = new CoilFieldZone() { Name = "test", Id = 9, Color = "white", Disabled = true , TextColor = "white",  CoilField = new CoilField() { Id=1, Disabled=true, Name="w", Zones = new List<CoilFieldZone>(){ new CoilFieldZone { } }  } } },
                    CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Disabled=true, IsEmpty=true, Row=1, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "white", TextColor = "white", CoilField = new CoilField { Id = 9, Name = "test",  Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "",  Disabled = true } } } } }

                }
            };
      CoilType coilType = new CoilType
      {
        Id = 4,
        Name = "test",
        Disabled = true,
        NumCoils = 0,
        Spec = "D",
        CoilFieldZone = new CoilFieldZone
        {
          Id = 1,
          Name = "F",
          Color = "white",
          TextColor = "white"
        }
      };
      AndonZone andonZone = new AndonZone { Name = "", BackgroundColor = "testcolor", TextColor = "red", LocationsCount = 1, MaxCoilColumns = 9, LocationsUsedCount = 9 };
      coilRepo.Setup(repo => repo.GetKanCoils())
     .Returns((coil));
      var _service = new AndonService(andonServiceLogger.Object, blankInfoesRepo.Object, plantsRepo.Object,  coilFieldZoneRepo.Object, coilRepo.Object, coilTypeRepo.Object, usersHelper.Object);
      _service.SetAndondbCoilType(andonCoilType, coilType, andonZone);
      Assert.True(true);
    }

    [Fact]
    public void BuildAndonZoneOnCoilFieldZone_CoilFieldZone_ReturnAndonZone()
    {
      CoilFieldZone coilFieldZones = new CoilFieldZone() { Id = 1, Color = "red", Name = "test", TextColor = "red", Disabled = true, CoilField = new CoilField { Id = 1, Disabled = true, Name = "test", Zones = new List<CoilFieldZone>() }, Locations = new List<CoilFieldLocation>() { new CoilFieldLocation() { Id = 1, Disabled = true, IsEmpty = true, Name = "test", Column = 1, Row = 1, Zone = new CoilFieldZone() { Id = 8, Disabled = true, Name = "", Locations = new List<CoilFieldLocation>() { new CoilFieldLocation() { Id = 1, Disabled = true, IsEmpty = true, Name = "test", Column = 1, Row = 1 } } } } } };
      var _service = new AndonService(andonServiceLogger.Object, blankInfoesRepo.Object, plantsRepo.Object,  coilFieldZoneRepo.Object, coilRepo.Object, coilTypeRepo.Object, usersHelper.Object);
      var AndonZones = _service.BuildAndonZoneOnCoilFieldZone(coilFieldZones);

      Assert.NotNull(AndonZones);
    }

  

    [Fact]
    public void GetCoilFieldLocation_Coils_ReturnCoilFieldLocation()
    {
      List<Coil> coil = new List<Coil>
            {
                new Coil()
                {
                    Id = 7,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9,
                     CoilRunHistory = new List<CoilRunHistory>(){ new CoilRunHistory() { Id = 2, Coil= new Coil {   Id = 7,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9 } }  },CoilStatus = new CoilStatus() { Id=8, Name="test", Color="test", InInventory=true, IsUsable=true, TextColor="white" }, Mill = new Mill(){ Id=9, Name="test", Disabled=true },
                    CoilType = new CoilType() { Id = 7, Name = "test" , CoilFieldZone = new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } },
                   CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } } } } }

                }
            };
      var _service = new AndonService(andonServiceLogger.Object, blankInfoesRepo.Object, plantsRepo.Object,  coilFieldZoneRepo.Object, coilRepo.Object, coilTypeRepo.Object, usersHelper.Object);
      var location = _service.GetCoilFieldLocation(coil);
      Assert.NotNull(location);
    }

    [Fact]
    public void GetCoilsTypesByZoneId_CoilsType_ReturnZones()
    {
      string NAMC = "TMMI";
      List<int> dieNo = new List<int>() { 22 };
      int? zoneId = null;
      var dbzones = new List<CoilFieldZone>
            {
                new CoilFieldZone()
                {
                    Id = 2,
                    Name = "Test",
                    Disabled = true
             ,   Locations = new List<CoilFieldLocation>
                {
                new CoilFieldLocation()
                {
                    Id=2, Name="test",  Column=1,  Disabled=true, IsEmpty=true, Row=1, Zone = new CoilFieldZone(){Id=1, Disabled=true,Name="test", Color="white" ,  TextColor="w", Locations = new List<CoilFieldLocation>{ new CoilFieldLocation() {
                    Id=8, Name="test", Column=1,   Disabled=true, IsEmpty=true, Row=1, Zone = new CoilFieldZone(){Id=1, Disabled=true,Name="test", Locations= new List<CoilFieldLocation>(){ },  Color="white" , TextColor="w",  CoilField = new CoilField(){ Id=2 ,  Name="test",  Disabled=true,Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 1, Color = "Z",  CoilField = new CoilField() { } , Locations= new List<CoilFieldLocation>() { }, Disabled = true } } } }
                } },  CoilField = new CoilField(){ Id=2,   Name="test", Disabled=true,Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", CoilField= new CoilField() { Id = 2, Disabled = true, Name = "Test", Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id =2, Locations = new List<CoilFieldLocation>{ new CoilFieldLocation() {
                    Id=8, Name="test", Column=1,   Disabled=true, IsEmpty=true, Row=1, Zone = new CoilFieldZone(){Id=1, Disabled=true,Name="test",  Locations= new List<CoilFieldLocation>(){ },  Color="white" , TextColor="",  CoilField = new CoilField(){ Id=2, Name="test",  Disabled=true,Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 1, Color = "Z", Locations= new List<CoilFieldLocation>() { }, CoilField= new CoilField() { }, Disabled = true } } } }
                } }, CoilField = new CoilField(){ Id=2,   Name="test", Disabled=true,Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", CoilField= new CoilField() { Id = 2, Disabled = true, Name = "Test", Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 2, Locations = new List<CoilFieldLocation>{ new CoilFieldLocation() {
                    Id=2, Name="test", Column=1,  Disabled=true,  IsEmpty=true, Row=1, Zone = new CoilFieldZone(){Id=1, Disabled=true,Name="test", Color="white" ,  Locations = new List<CoilFieldLocation>(){ }, TextColor="A",  CoilField = new CoilField(){ Id=3, Name="test",  Disabled=true,Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9,  Color = "w", CoilField = new CoilField() { } , Locations= new List<CoilFieldLocation>() { }, Disabled = true } } } }
                } },   Color = "A", Disabled = true } } }, Id = 2, Color = "A", Disabled = true } } }, TextColor="A",   Color = "A", Disabled = true } } }, Id = 2,  Color = "A", Locations = new List<CoilFieldLocation>(){ }, TextColor="a", Disabled = true } } } }
                }
            },
                    CoilField = new CoilField( ){ Id=2, Disabled=true, Name="Test", Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 2, Locations= new List<CoilFieldLocation>(){ }, CoilField = new CoilField(){ Id=2,  Name="test", Disabled=true,  Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", CoilField= new CoilField() { Id = 2, Disabled = true, Name = "Test", Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 2, Locations = new List<CoilFieldLocation>{ new CoilFieldLocation() {
                    Id=8, Name="test", Column=8,  Disabled=true, IsEmpty=true, Row=8, Zone = new CoilFieldZone(){Id=1, Disabled=true,Name="test", Color="white" , TextColor="",  CoilField = new CoilField(){ Id=3, Name="test", Disabled=true,Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 2, Color = "S", Disabled = true } } } }
                } },   Color = "D", Disabled = true } } }, Id = 2, Color = "S",  Disabled = true } } },  Color = "A", Disabled = true } }},
                    TextColor = "red",
                    Color = "white",

                }
            };
      List<CoilType> coilTypes = new List<CoilType>()  { new CoilType() { NumCoils=2, Id=7, Name="1-1-H", Disabled=true, Spec="", Width=8, MaxThickness=decimal.One, MaxWidth=decimal.One, MinThickness=decimal.One, MinWidth=decimal.One, Thickness=decimal.One, Yield=decimal.One, CoilFieldZone = new CoilFieldZone()
            {


                    Id = 2,
                    Name = "1-1-H",
                    Disabled = true
             , Locations = new List<CoilFieldLocation>
                {
                new CoilFieldLocation()
                {
                    Id=8, Name="test", Column=8, Disabled=true, IsEmpty=true, Row=8, Zone = new CoilFieldZone(){Id=1, Disabled=true,Name="test", Color="white" , TextColor="",  CoilField = new CoilField(){ Id=3, Name="test", Disabled=true,Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } } } }
                }
            },
                    CoilField = new CoilField( ){ Id=8, Disabled=true, Name="Test", Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } }},
                    TextColor = "red",
                    Color = "white"


            }, CoilTypeYNAs = new List<CoilTypeYNA>() { new CoilTypeYNA() { Id=5, DateAdded=DateTime.Now, Disabled=true, YNA = "", CoilType = new CoilType() {  } } }  } };
      List<Coil> coils = new List<Coil>
            {
                new Coil()
                {
                    Id = 2,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9,
                    CoilFieldLocation = new CoilFieldLocation() { Id = 2,  Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 2, Disabled = true, Name = "test", Color = "red", TextColor = "black", Locations = new List<CoilFieldLocation>(){ new CoilFieldLocation() { Id=2, Zone= new CoilFieldZone() { Id=2, Locations = new List<CoilFieldLocation>() { new CoilFieldLocation() { Id=2, Zone= new CoilFieldZone() { Id=2, CoilField= new CoilField() { }, Locations= new List<CoilFieldLocation>() {  } } } } }  } }, CoilField = new CoilField { Id = 2, Name = "test", Disabled = true,  Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 2, Color = "r", CoilField= new CoilField() { Id=2, Name="A", Disabled=true, Zones = new List<CoilFieldZone>() {  } }, Locations= new List<CoilFieldLocation>() { new CoilFieldLocation() { Id=1,  Zone= new CoilFieldZone() { Id=2,  } } } ,  Disabled = true } } } } },
                    CoilRunHistory = new List<CoilRunHistory>(){ new CoilRunHistory() { Id = 2, Coil= new Coil {   Id = 2,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",CoilFieldLocation = new CoilFieldLocation() { Id = 2, Name = "white", Column = 1, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 2, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 2, Color = "", Disabled = true } } } } } , OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9 } }  },
                    CoilStatus = new CoilStatus() { Id = 8, Name = "test", Color = "test", InInventory = true, IsUsable = true, TextColor = "white" },
                    Mill = new Mill() { Id = 9, Name = "test", Disabled = true },
                    CoilType = new CoilType() { Id = 2, Name = "test", CoilFieldZone = new CoilFieldZone() { Name = "test", Id = 2, Color = "", Disabled = true } },


                }
            };

      List<Coil> coil = new List<Coil>
            {
                new Coil()
                {
                    Id = 2,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9,

                    CoilType = new CoilType() { Id = 7, Name = "test" },
                    CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() } } }

                }
            };
      CoilFieldZone CoilField = new CoilFieldZone
      {
        Id = 2,
        Name = "test",
        Disabled = true,
        Color = "white",
        TextColor = "white",
        CoilField = new CoilField { Id = 7, Name = "1-8", Disabled = true, Zones = new List<CoilFieldZone>() }
      };
      CoilFieldZone zones = new CoilFieldZone() { Id = 2, Locations = new List<CoilFieldLocation>() { new CoilFieldLocation() { Id = 2, Row = 1, Name = "w", Disabled = true, Column = 1, IsEmpty = false, Zone = new CoilFieldZone() { Id = 1, Locations = new List<CoilFieldLocation>() { }, Color = "white", Name = "w", TextColor = "white", Disabled = true, CoilField = new CoilField() { Id = 1, Disabled = true, Name = "w", Zones = new List<CoilFieldZone>() { new CoilFieldZone() { } } } } } }, CoilField = new CoilField() { Id = 1, Disabled = false, Name = "S", Zones = new List<CoilFieldZone>() { } }, Color = "white", Disabled = true, Name = "white", TextColor = "white" };
      List<CoilFieldZone> coilFields = new List<CoilFieldZone>() { new CoilFieldZone() {Id = 1,
                Name = "Test",
                Disabled = true
             ,
                Locations = new List<CoilFieldLocation>
                {
                new CoilFieldLocation()
                {
                    Id=14, Name="test",  Column=1, Disabled=true, IsEmpty=true, Row=1, Zone = new CoilFieldZone(){Id=1, Disabled=true,Name="test", Locations= new List<CoilFieldLocation>(){ },  Color="white" , TextColor="e",   CoilField = new CoilField(){ Id=14, Name="test", Disabled=true,Zones = new List<CoilFieldZone>()  { new CoilFieldZone() { Name = "test", Id = 14, Color = "e", Locations = new List<CoilFieldLocation>(){ }, TextColor="e", Disabled = true , CoilField= new CoilField() { Id=14, Disabled=true,    Name="test",  Zones = new List<CoilFieldZone>() { new CoilFieldZone() {  CoilField = new CoilField() { Id= 2,   Name="test" , Disabled=false ,Zones = new List<CoilFieldZone>() { new CoilFieldZone() {  Disabled=true, Id=14,   CoilField = new CoilField(){ Id=3,  Name="test", Disabled=true,Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9,  CoilField = new CoilField() { }, TextColor="2", Locations= new List<CoilFieldLocation>() { }, Color = "e", Disabled = true } } } , Name="e", Color="red", TextColor="e",Locations = new List<CoilFieldLocation>() { new CoilFieldLocation() {
                    Id=8, Name="test", Column=8, Disabled=true, IsEmpty=true, Row=8, Zone = new CoilFieldZone(){Id=1, Disabled=true,Name="test", Color="white" , TextColor="e", Locations = new List<CoilFieldLocation>(){ },  CoilField = new CoilField(){ Id=3, Name="test",  Disabled=true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "e", CoilField=new CoilField() { }, Locations= new List<CoilFieldLocation>() { }, TextColor="e" ,Disabled = true } } } }
                }   } } } } } } }  } } } }
                }
            },
                CoilField = new CoilField() { Id = 14, Disabled = true, Name = "Test", Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 14, Color = "", Disabled = true } } },
                TextColor = "red",
                Color = "white" ,


            } };
      List<CoilFieldLocation> CoilFieldLocations = new List<CoilFieldLocation>
            {
                new CoilFieldLocation()
                {
                    Id=14,  Name="test", Column=8, Disabled=true, IsEmpty=true,  Row=8,  Zone = new CoilFieldZone(){Id=1, Disabled=true,Name="test", Color="white" , TextColor="",  Locations= new List<CoilFieldLocation>(){ new CoilFieldLocation() { Id = 1, IsEmpty = true, Name = "test", Disabled = true, Column = 1, Row = 1 , Zone = new CoilFieldZone() { Id = 2, Disabled = true, TextColor = "white", Name = "red", Color = "white" } } }, CoilField = new CoilField(){ Id=8, Name="test", Disabled=true,Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true, Locations= new List<CoilFieldLocation>() { new CoilFieldLocation() { Id=1, IsEmpty=true, Name="test", Disabled=true, Column=1,Row=1,
                    Zone = new CoilFieldZone(){ Id=2, Disabled=true, TextColor="white", Name="red", Color="white", Locations= new List<CoilFieldLocation> () { new CoilFieldLocation() { Id=1, IsEmpty=true, Name="test", Column=1, Disabled=true,Row=2, Zone= new CoilFieldZone() { Id=4, Disabled=true, Name="e", Color="white", Locations=new List<CoilFieldLocation>() { new CoilFieldLocation() { Id=1, IsEmpty=true, Name="e", Column=1, Row=1, Disabled=true, Zone = new CoilFieldZone() { Id=4, Locations = new List<CoilFieldLocation>() { new CoilFieldLocation() { Id = 1, IsEmpty = true, Name = "test", Column = 1, Disabled = true, Row = 2  } } }   } } }   } } } } } } } } }
                }
            };
      List<AndonCoilTypeLocation> andonCoilTypeLocations = new List<AndonCoilTypeLocation>() {
            new AndonCoilTypeLocation()
            {
                 Name="test", TextColor="red", CoilId=2,  BackgroundColor="white",

            }
            };

      var blankInfo = new List<BlankInfo>
            {
           new BlankInfo()
          {
            Id =1,
            Line=new Line(){ Id=1},
            MaxPitch = 12,
            MaxWidth = 22,
            MinPitch = 11,
           Part = new Part(){Id=1 },
            Pitch = 12,
            StackSize =345,
            Weight = 1234,
            Width = 123,
            Disabled = false,
            DieNo = 2,
            DataNumber = 1,
           CoilType = new CoilType() { Id = 1, Name = "test" },
            RewindWeight = 10,

           }
            };


      plantsRepo.Setup(repo => repo.GetPlantName())
       .Returns((NAMC));
      coilRepo.Setup(repo => repo.GetCoilsFeildsByZoneId(zoneId))
     .Returns((coils));
      coilFieldZoneRepo.Setup(repo => repo.GetCoilFieldZones(zoneId))
      .Returns((dbzones));
      coilTypeRepo.Setup(repo => repo.GetCoilTypes())
     .Returns((coilTypes));
      coilTypeRepo.Setup(repo => repo.GetdbCoilTypes(dbzones))
      .Returns((coilTypes));
      coilRepo.Setup(repo => repo.GetCoilLocationsInOrder(CoilField, coil))
         .Returns(andonCoilTypeLocations);
      coilFieldLocationRepo.Setup(repo => repo.CoilFieldLocations(coils, CoilFieldLocations))
     .Returns((coils));
      blankInfoesRepo.Setup(repo => repo.GetdieNo(CoilFieldLocations))
      .Returns((dieNo));
      blankInfoesRepo.Setup(repo => repo.GetdieNos(coils))
     .Returns((blankInfo));
      coilRepo.Setup(repo => repo.GetKanCoils())
     .Returns(coils);
      var _service = new AndonService(andonServiceLogger.Object, blankInfoesRepo.Object, plantsRepo.Object, coilFieldZoneRepo.Object, coilRepo.Object, coilTypeRepo.Object, usersHelper.Object);
    var result =  _service.GetCoilsTypesByZoneId(zoneId);
      Assert.NotNull(result);
    }

  }
}
