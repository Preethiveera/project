using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using Moq;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class BlankInfoServiceTest
  {

    private readonly Mock<IPlantsRepository> plantRepo;
    private readonly Mock<ILineRepository> lineRepo;
    private readonly Mock<IPartRepository> partRepo;
    private readonly Mock<ICoilTypeRepository> coilTypeRepo;
    private readonly Mock<IRunOrderRepository> runOrderRepo;
    private readonly Mock<IBlankInfoesRepository> blankInfoRepo;
    private readonly Mock<IIncompleteRunOrderItemRepository> incompleteRunOrderItemRepo;
    private readonly Mock<IRunOrderListQuantityRepository> runOrderListQuantityRepo;
    public BlankInfoServiceTest()
    {
      blankInfoRepo = new Mock<IBlankInfoesRepository>();

      plantRepo = new Mock<IPlantsRepository>();
      lineRepo = new Mock<ILineRepository>();
      partRepo = new Mock<IPartRepository>();
      coilTypeRepo = new Mock<ICoilTypeRepository>();
      runOrderRepo = new Mock<IRunOrderRepository>();
      incompleteRunOrderItemRepo = new Mock<IIncompleteRunOrderItemRepository>();
      runOrderListQuantityRepo = new Mock<IRunOrderListQuantityRepository>();
    }

    public IMapper InitializeMapper()
    {
      var mockMapper = new MapperConfiguration(cfg =>
      {
        cfg.AddProfile(new MappingProfile());
      });
      var mapper = mockMapper.CreateMapper();

      return mapper;
    }
  

    [Fact]
    public void GetDatas_ReturnsBlankInfo()
    {
      var mapper = InitializeMapper();
      var _service = new BlankInfoService(blankInfoRepo.Object, runOrderRepo.Object, coilTypeRepo.Object, partRepo.Object,lineRepo.Object, plantRepo.Object,mapper,incompleteRunOrderItemRepo.Object,runOrderListQuantityRepo.Object);
      var _mockBlankInfoService = new MockBlankInfoService();
      blankInfoRepo.Setup(repo => repo.GetAllBlankInfo())
    .Returns(_mockBlankInfoService.GetDatasReturnsmodel());

      var blankInfo = _service.GetAllBlankInfo();

      Assert.NotNull(blankInfo);
    }

    [Fact]
    public void GetBlankInfoById_ReturnsBlankInfo()
    {
      var mapper = InitializeMapper();
      var _service = new BlankInfoService(blankInfoRepo.Object, runOrderRepo.Object, coilTypeRepo.Object, partRepo.Object,
              lineRepo.Object, plantRepo.Object, mapper,incompleteRunOrderItemRepo.Object,runOrderListQuantityRepo.Object);
      var _mockBlankInfoService = new MockBlankInfoService();
      blankInfoRepo.Setup(repo => repo.GetBlankInfoById(1))
    .Returns(_mockBlankInfoService.GetBlankInfoByIdReturnsModel(1));

      var blankInfo = _service.GetBlankInfoById(1);

      Assert.NotNull(blankInfo);
    }

    [Fact]
    public void GetBlankInfoById_BlankInfo_ReturnsNull()
    {
      var mapper = InitializeMapper();
      var _service = new BlankInfoService(blankInfoRepo.Object, runOrderRepo.Object, coilTypeRepo.Object, partRepo.Object,lineRepo.Object,plantRepo.Object,mapper,incompleteRunOrderItemRepo.Object,runOrderListQuantityRepo.Object);
      var _mockBlankInfoService = new MockBlankInfoService();
      blankInfoRepo.Setup(repo => repo.GetBlankInfoById(2))
    .Returns(_mockBlankInfoService.GetBlankInfoByIdReturnsModel(2));

      var blankInfo = _service.GetBlankInfoById(2);

      Assert.Null(blankInfo);
    }

    [Fact]
    public void GetNAMCinfo_ReturnsListofString()
    {
      var mapper = InitializeMapper();
      var _service = new BlankInfoService(blankInfoRepo.Object, runOrderRepo.Object, coilTypeRepo.Object, partRepo.Object,
              lineRepo.Object, plantRepo.Object, mapper,incompleteRunOrderItemRepo.Object,runOrderListQuantityRepo.Object);
      var _mockBlankInfoService = new MockBlankInfoService();
      plantRepo.Setup(repo => repo.GetPlantName())
    .Returns(_mockBlankInfoService.GetNAMCinfo());

      var blankInfo = _service.GetNAMCinfo();

      Assert.NotNull(blankInfo);
    }

    [Fact]
    public void GetBlankInfoByDataNumAndLineId_ReturnsBlankInfo()
    {
      var mapper = InitializeMapper();
      int id = 1;
      int datanum = 2;
      var _service = new BlankInfoService(blankInfoRepo.Object, runOrderRepo.Object, coilTypeRepo.Object, partRepo.Object,
              lineRepo.Object, plantRepo.Object, mapper,incompleteRunOrderItemRepo.Object,runOrderListQuantityRepo.Object);
      var _mockBlankInfoService = new MockBlankInfoService();
      blankInfoRepo.Setup(repo => repo.GetBlankInforByDataNumAndLineId(id, datanum))
    .Returns(_mockBlankInfoService.GetBlankInfoByIdReturnsModel(1));

      var blankInfo = _service.GetBlankInfoByDataNumAndLineId(id, datanum);

      Assert.NotNull(blankInfo);
    }

    [Fact]
    public void GetBlankInfoByDataNumAndLineId_Returnsnull()
    {
      var mapper = InitializeMapper();
      int id = 1;
      int datanum = 2;
      var _service = new BlankInfoService(blankInfoRepo.Object, runOrderRepo.Object, coilTypeRepo.Object, partRepo.Object,
              lineRepo.Object, plantRepo.Object, mapper,incompleteRunOrderItemRepo.Object,runOrderListQuantityRepo.Object);
      var _mockBlankInfoService = new MockBlankInfoService();
      blankInfoRepo.Setup(repo => repo.GetBlankInforByDataNumAndLineId(id, datanum))
    .Returns(_mockBlankInfoService.GetBlankInfoByIdReturnsModel(2));

      var blankInfo = _service.GetBlankInfoByDataNumAndLineId(id, datanum);

      Assert.Null(blankInfo);
    }

    [Fact]
    public void IsBlankInfoDependent_Returnsbool()
    {
      int id = 1;
      var mapper = InitializeMapper();
      var _service = new BlankInfoService(blankInfoRepo.Object, runOrderRepo.Object, coilTypeRepo.Object, partRepo.Object,
              lineRepo.Object, plantRepo.Object, mapper,incompleteRunOrderItemRepo.Object,runOrderListQuantityRepo.Object);
      var _mockBlankInfoService = new MockBlankInfoService();
      blankInfoRepo.Setup(repo => repo.GetDependencyForBlankInfo(id))
    .Returns(_mockBlankInfoService.GetIncompleteRunOrderList());

      var blankInfo = _service.IsBlankInfoDependent(id);

      Assert.True(blankInfo);

    }
    [Fact]
    public void IsBlankInfoDependent_bool_ReturnsFalse()
    {
      int id = 1;
      var mapper = InitializeMapper();
      var _service = new BlankInfoService(blankInfoRepo.Object, runOrderRepo.Object, coilTypeRepo.Object, partRepo.Object,
              lineRepo.Object, plantRepo.Object, mapper,incompleteRunOrderItemRepo.Object,runOrderListQuantityRepo.Object);
      var _mockBlankInfoService = new MockBlankInfoService();
      blankInfoRepo.Setup(repo => repo.GetDependencyForBlankInfo(id))
    .Returns(_mockBlankInfoService.GetIncompleteRunOrderListReturnempty());

      var blankInfo = _service.IsBlankInfoDependent(id);

      Assert.False(blankInfo);

    }
    [Fact]
    public void AddNewBlankInfo_dto_ReturnsBlankInfo()
    {

      var blankInfo =
    new BlankInfo()
    {
      Id = 1,
      Line = new Line() { Id = 1 },
      MaxPitch = 12,
      MaxWidth = 22,
      MinPitch = 11,
      Part = new Part() { Id = 1 },
      Pitch = 12,
      StackSize = 345,
      Weight = 1234,
      Width = 123,
      Disabled = false,
      DieNo = 2,
      DataNumber = 1,
      CoilType = new CoilType() { Id = 2 },
      RewindWeight = 10,

    };
      var blankInfoDto =
    new BlankInfoDto()
    {
      Id = 1,
      LineId = 1,
      MaxPitch = 12,
      MaxWidth = 22,
      MinPitch = 11,
      PartId = 1,
      Pitch = 12,
      StackSize = 345,
      Weight = 1234,
      Width = 123,
      Disabled = false,
      DieNo = 2,
      DataNumber = 1,
      CoilTypeId = 2,
      RewindWeight = 10,

    };
      var mapper = InitializeMapper();
      var _service = new BlankInfoService(blankInfoRepo.Object, runOrderRepo.Object, coilTypeRepo.Object, partRepo.Object,
              lineRepo.Object, plantRepo.Object, mapper,incompleteRunOrderItemRepo.Object,runOrderListQuantityRepo.Object);
      var _mockBlankInfoService = new MockBlankInfoService();
      lineRepo.Setup(repo => repo.GetLineByLineID(blankInfo.Id))
    .Returns(_mockBlankInfoService.GetLines());

      var blanks = _service.AddNewBlankInfo(blankInfoDto);

      Assert.True(blanks.Result);

    }

    [Fact]
    public void CheckEdit_dto_ReturnsBlankInfo()
    {
      int id = 1;
      var blankInfo =
    new BlankInfo()
    {
      Id = 1,
      Line = new Line() { Id = 1 },
      MaxPitch = 12,
      MaxWidth = 22,
      MinPitch = 11,
      MinWidth=11,
      Part = new Part() { Id = 1 },
      Pitch = 12,
      StackSize = 345,
      Weight = 1234,
      Width = 123,
      Disabled = false,
      DieNo = 2,
      DataNumber = 1,
      CoilType = new CoilType() { Id = 2 },
      RewindWeight = 10,

    };
      var blankInfoDto =
    new BlankInfoDto()
    {
      Id = 1,
      LineId = 1,
      MaxPitch = 12,
      MaxWidth = 22,
      MinPitch = 11,
      MinWidth=11,
      PartId = 1,
      Pitch = 12,
      StackSize = 345,
      Weight = 1234,
      Width = 123,
      Disabled = false,
      DieNo = 2,
      DataNumber = 1,
      CoilTypeId = 2,
      RewindWeight = 10,

    };
      var mapper = InitializeMapper();
      var _service = new BlankInfoService(blankInfoRepo.Object, runOrderRepo.Object, coilTypeRepo.Object, partRepo.Object,
              lineRepo.Object, plantRepo.Object, mapper,incompleteRunOrderItemRepo.Object,runOrderListQuantityRepo.Object);
      var _mockBlankInfoService = new MockBlankInfoService();
      lineRepo.Setup(repo => repo.GetLineByLineID(blankInfo.Id))
    .Returns(_mockBlankInfoService.GetLines());
      partRepo.Setup(repo => repo.GetPartById(blankInfo.Id))
   .Returns(_mockBlankInfoService.GetPart());
      coilTypeRepo.Setup(repo => repo.GetCoilTypeById(blankInfo.Id))
  .Returns(_mockBlankInfoService.GetCoilType());
      blankInfoRepo.Setup(repo => repo.GetBlankInfoById(blankInfo.Id))
 .Returns(_mockBlankInfoService.GetBlankInfoByIdReturnsModel(1));

      _service.CheckEdit(id, blankInfoDto);

      Assert.False(false);

    }


    [Fact]
    public void IsScheduledOnRunOrder_bool_ReturnsTrue()
    {
      int id = 1;
      var mapper = InitializeMapper();
      var _service = new BlankInfoService(blankInfoRepo.Object, runOrderRepo.Object, coilTypeRepo.Object, partRepo.Object, lineRepo.Object, plantRepo.Object, mapper,incompleteRunOrderItemRepo.Object,runOrderListQuantityRepo.Object);

      runOrderRepo.Setup(repo => repo.IsScheduledOnRunOrder(id))
    .Returns(true);
      var blankInfo = _service.IsScheduledOnRunOrder(id);

      Assert.True(blankInfo);

    }
    [Fact]
    public void BlankInfoExists_Returnsbool()
    {
      int id = 1;
      var mapper = InitializeMapper();
      var _service = new BlankInfoService(blankInfoRepo.Object, runOrderRepo.Object, coilTypeRepo.Object, partRepo.Object,
              lineRepo.Object, plantRepo.Object, mapper,incompleteRunOrderItemRepo.Object,runOrderListQuantityRepo.Object);
      var _mockBlankInfoService = new MockBlankInfoService();
      blankInfoRepo.Setup(repo => repo.GetBlankInfoById(id))
    .Returns(_mockBlankInfoService.GetBlankInfoByIdReturnsModel(1));
      var blankInfo = _service.BlankInfoExists(id);

      Assert.True(blankInfo);

    }
    [Fact]
    public void BlankInfoExists_bool_Returnsfalse()
    {
      int id = 1;
      var mapper = InitializeMapper();
      var _service = new BlankInfoService(blankInfoRepo.Object, runOrderRepo.Object, coilTypeRepo.Object, partRepo.Object,
              lineRepo.Object, plantRepo.Object, mapper,incompleteRunOrderItemRepo.Object,runOrderListQuantityRepo.Object);
      var _mockBlankInfoService = new MockBlankInfoService();
      blankInfoRepo.Setup(repo => repo.GetBlankInfoById(id))
    .Returns(_mockBlankInfoService.GetBlankInfoByIdReturnsModel(2));
      var blankInfo = _service.BlankInfoExists(id);

      Assert.False(blankInfo);

    }
    [Fact]
    public void DeleteBlankInfo_Id_ReturnsBlankInfo()
    {
      int id = 1;
      var mapper = InitializeMapper();
      var _service = new BlankInfoService(blankInfoRepo.Object, runOrderRepo.Object, coilTypeRepo.Object, partRepo.Object,
              lineRepo.Object, plantRepo.Object, mapper,incompleteRunOrderItemRepo.Object,runOrderListQuantityRepo.Object);
      var _mockBlankInfoService = new MockBlankInfoService();
      blankInfoRepo.Setup(repo => repo.GetBlankInfoById(id))
    .Returns(_mockBlankInfoService.GetBlankInfoByIdReturnsModel(1));
      var blankInfo = _service.DeleteBlankInfo(id);

      Assert.NotNull(blankInfo);

    }

  }
}
