using CoilTracking.Business.Implementation;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using Moq;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class ScheduleReportServiceTest
  {
    private readonly Mock<IScheduleReportRepository> scheduleReportRepo;
    private readonly Mock<IApplicationLogger<ScheduleReportService>> scheduleReportServiceLogger;
    public ScheduleReportServiceTest()
    {
      scheduleReportRepo = new Mock<IScheduleReportRepository>();
      scheduleReportServiceLogger = new Mock<IApplicationLogger<ScheduleReportService>>();

    }

    [Fact]
    public void GetScheduleReportTest()
    {

      var _service = new ScheduleReportService(scheduleReportRepo.Object, scheduleReportServiceLogger.Object);
      var _mockScheduleReportService = new MockScheduleReportService();
      scheduleReportRepo.Setup(repo => repo.Get());

      var scheduleReports = _service.GetScheduleReport();

      Assert.NotNull(scheduleReports);
    }
    [Fact]
    public void GetScheduleReportByIDTest()
    {
      int id = 2;
      var _service = new ScheduleReportService(scheduleReportRepo.Object, scheduleReportServiceLogger.Object);
      var _mockScheduleReportService = new MockScheduleReportService();
      scheduleReportRepo.Setup(repo => repo.GetScheduleReportByID(id)).Returns(_mockScheduleReportService.GetScheduleReportByIdTest());

      var scheduleReports = _service.GetScheduleReportById(id);

      Assert.NotNull(scheduleReports);
    }
    

    
    [Fact]
    public void PutScheduleReportReturnsTrue()
    {
      int id = 3;
      var scheduleReport = new ScheduledReportEmail()
      {
        Email = "hummer@toyota.com",
        CoilReport = true,
        RunReport = false,
        ScrapReport = false,
      };
      var scheduleReportDto = new ScheduleReportDto()
      {
        Email = "hummer@toyota.com",
        CoilReport = true,
        RunReport = false,
        ScrapReport = false
      };
      var _service = new ScheduleReportService(scheduleReportRepo.Object, scheduleReportServiceLogger.Object);
      var _mockScheduleReportService = new MockScheduleReportService();
      scheduleReportRepo.Setup(repo => repo.PutScheduleReport(id, scheduleReport))
    .Returns(true);
      scheduleReportRepo.Setup(repo => repo.ScheduleReportExists(id))
    .Returns(true);


      var scheduleReports = _service.PutScheduleReport(id, scheduleReportDto);

      Assert.True(scheduleReports);
    }

    [Fact]
    public void DeleteScheduleReport()
    {
      int id = 11;
      var scheduleReport = new ScheduledReportEmail()
      {
        Email = "hrvez@toyota.com",
        CoilReport = true,
        RunReport = false,
        ScrapReport = false,
      };
      var _service = new ScheduleReportService(scheduleReportRepo.Object, scheduleReportServiceLogger.Object);
      var _mockScheduleReportService = new MockScheduleReportService();
      scheduleReportRepo.Setup(repo => repo.GetScheduleReportByID(id))
    .Returns(scheduleReport);
      scheduleReportRepo.Setup(repo => repo.DeleteScheduleReport(id))
    .Returns(true);


      var scheduleReports = _service.DeleteScheduleReport(id);

      Assert.NotNull(scheduleReports);
    }
  }
}
