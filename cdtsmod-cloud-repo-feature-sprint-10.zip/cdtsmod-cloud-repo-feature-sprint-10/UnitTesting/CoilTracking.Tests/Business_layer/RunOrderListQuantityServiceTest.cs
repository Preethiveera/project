using CoilTracking.Business.Implementation;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.Tests.Service;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class RunOrderListQuantityServiceTest
  {
    private readonly Mock<IRunOrderListQuantityRepository> runOrderListQuantityRepo;
    private readonly Mock<IApplicationLogger<RunOrderListQuantityService>> runOrderListQuantityLogger;
    private readonly Mock<IBlankInfoesRepository> blankInfoesRepo;
    private readonly Mock<ICoilRepository> coilRepo;
    private readonly Mock<IPartRepository> partRepo;
    private readonly Mock<IProdPlanRepository> prodPlanRepo;
    private readonly Mock<IWebSocketClientService> webSocketClientService;

    public RunOrderListQuantityServiceTest()
    {
      runOrderListQuantityRepo = new Mock<IRunOrderListQuantityRepository>();
      runOrderListQuantityLogger = new Mock<IApplicationLogger<RunOrderListQuantityService>>();
      blankInfoesRepo = new Mock<IBlankInfoesRepository>();
      coilRepo = new Mock<ICoilRepository>();
      partRepo = new Mock<IPartRepository>();
      prodPlanRepo = new Mock<IProdPlanRepository>();
      webSocketClientService = new Mock<IWebSocketClientService>();
    }


    [Fact]
    public void GetRunOrderListQuantities_Returns_RunOrderListQuantities()
    {
      var _mockRunOrderListQuantitiesService = new MockRunOrderListQuantitiesService();
      runOrderListQuantityRepo.Setup(repo => repo.GetRunOrderListQuantities().Result)
      .Returns(_mockRunOrderListQuantitiesService.GetRunOrderListQuantities().ToList());
      var _service = new RunOrderListQuantityService(coilRepo.Object, runOrderListQuantityRepo.Object, partRepo.Object, blankInfoesRepo.Object, prodPlanRepo.Object, runOrderListQuantityLogger.Object, webSocketClientService.Object);
      var rr = _service.GetRunOrderListQuantities();
      Assert.NotNull(rr);
    }
    [Fact]
    public void GetRunOrderListQuantityById_Returns_RunOrderListQuantity()
    {
      int id = 3;
      var _mockRunOrderListQuantitiesService = new MockRunOrderListQuantitiesService();
      runOrderListQuantityRepo.Setup(repo => repo.GetRunOrderListQuantityById(id))
      .Returns(_mockRunOrderListQuantitiesService.GetRunOrderListQuantity());
      var _service = new RunOrderListQuantityService(coilRepo.Object, runOrderListQuantityRepo.Object, partRepo.Object, blankInfoesRepo.Object, prodPlanRepo.Object, runOrderListQuantityLogger.Object, webSocketClientService.Object);
      var rr = _service.GetRunOrderListQuantity(id);
      Assert.NotNull(rr);
    }

    [Fact]
    public void GetRunOrderItem_Returns_RunOrderListQuantity()
    {
      int lineid = 3;
      string partnumber = "82378-SDF";
      int sortorder = 2;
      var prodPlan = new List<ProdPlan>();
      {
        prodPlan.Add(new ProdPlan() { Id = 1, LotSize = 12, Part = new Part() { Id = 2 } });
      }
      var blankInfo = new List<BlankInfo>
            {
           new BlankInfo()
          {
            Id =1,
            Line=new Line(){ Id=1},
            MaxPitch = 12,
            MaxWidth = 22,
            MinPitch = 11,
           Part = new Part(){Id=1 },
            Pitch = 12,
            StackSize =345,
            Weight = 1234,
            Width = 123,
            Disabled = false,
            DieNo = 2,
            DataNumber = 1,
           CoilType = new CoilType() { Id = 1, Name = "test" },
            RewindWeight = 10,

           }
            };
      List<Coil> coil = new List<Coil>
            {
                new Coil()
                {
                    Id = 2,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9,

                    CoilType = new CoilType() { Id = 7, Name = "test" },
                    CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() } } }

                }
            };
      Part part = new Part() { Id = 2, Disabled = true, PartName = "AS78", PartNumber = "A", StrokeCount = 1 };
      var _mockRunOrderListQuantitiesService = new MockRunOrderListQuantitiesService();
      partRepo.Setup(repo => repo.GetPartByName(partnumber))
     .Returns(part);
      partRepo.Setup(repo => repo.GetModelList(partnumber))
      .Returns(partnumber);
      blankInfoesRepo.Setup(repo => repo.GetBlankInfoByPartnumberLineIds(partnumber, lineid))
       .Returns(blankInfo);
      coilRepo.Setup(repo => repo.GetCoilTypeByBlanks(blankInfo))
    .Returns(coil);
      prodPlanRepo.Setup(repo => repo.GetProdPlanByPartnumber(partnumber))
      .Returns(prodPlan);
      var _service = new RunOrderListQuantityService(coilRepo.Object, runOrderListQuantityRepo.Object, partRepo.Object, blankInfoesRepo.Object, prodPlanRepo.Object, runOrderListQuantityLogger.Object, webSocketClientService.Object);
      var rr = _service.GetRunOrderItem(lineid, partnumber, sortorder);
      Assert.NotNull(rr);
    }
    [Fact]
    public void InsertRunOrderListQuantity_Returns_Success()
    {
      RunOrderListQuantity runOrderListQuantity = new RunOrderListQuantity()
      {
        Id = 3,
        BlankInfo = new BlankInfo() { CoilType = new CoilType() { Name = "A1" }, Id = 1, DataNumber = 1, DieNo = 6, Disabled = true },
        Incomplete = true,
        OverrideQty = 1,
        Quantity = 1,
        Part = new Part() { },
        RunOrderList = new RunOrderList() { },
        SortOrder = 1
      };
      var _mockRunOrderListQuantitiesService = new MockRunOrderListQuantitiesService();
      runOrderListQuantityRepo.Setup(repo => repo.InsertRunOrderListQuantity(runOrderListQuantity));
      var _service = new RunOrderListQuantityService(coilRepo.Object, runOrderListQuantityRepo.Object, partRepo.Object, blankInfoesRepo.Object, prodPlanRepo.Object, runOrderListQuantityLogger.Object, webSocketClientService.Object);
      _service.InsertRunOrderListQuantity(runOrderListQuantity);
      Assert.True(true);
    }

    [Fact]
    public void ModifyRunOrderListQuantity_Returns_Success()
    {
      int id = 3;
      RunOrderListQuantity runOrderListQuantity = new RunOrderListQuantity()
      {
        Id = 3,
        BlankInfo = new BlankInfo() { CoilType = new CoilType() { Name = "A1" }, Id = 1, DataNumber = 1, DieNo = 6, Disabled = true },
        Incomplete = true,
        OverrideQty = 1,
        Quantity = 1,
        Part = new Part() { },
        RunOrderList = new RunOrderList() { },
        SortOrder = 1
      };
      var _mockRunOrderListQuantitiesService = new MockRunOrderListQuantitiesService();
      runOrderListQuantityRepo.Setup(repo => repo.ModifyRunOrderListQuantity(runOrderListQuantity));
      var _service = new RunOrderListQuantityService(coilRepo.Object, runOrderListQuantityRepo.Object, partRepo.Object, blankInfoesRepo.Object, prodPlanRepo.Object, runOrderListQuantityLogger.Object, webSocketClientService.Object);
      _service.UpdateRunOrderListQuantity(id, runOrderListQuantity);
      Assert.True(true);
    }


  }
}
