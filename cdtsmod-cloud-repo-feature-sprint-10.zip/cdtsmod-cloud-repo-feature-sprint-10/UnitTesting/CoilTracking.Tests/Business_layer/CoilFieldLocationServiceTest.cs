using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.Tests.Service;
using Moq;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class CoilFieldLocationServiceTest
  {
    private readonly Mock<ICoilFieldLocationRepository> coilFieldLocationRepo;
    private readonly Mock<ICoilFieldZoneRepository> coilFieldZoneRepo;
    private readonly Mock<ICoilRepository> coilRepo;
    private readonly Mock<IApplicationLogger<CoilFieldLocationsService>> logger;
    private readonly Mock<IWebSocketClientService> webSocketClientService;

    public CoilFieldLocationServiceTest()
    {
      coilFieldLocationRepo = new Mock<ICoilFieldLocationRepository>();
      coilFieldZoneRepo = new Mock<ICoilFieldZoneRepository>();
      coilRepo = new Mock<ICoilRepository>();
      logger = new Mock<IApplicationLogger<CoilFieldLocationsService>>();
      webSocketClientService = new Mock<IWebSocketClientService>();
    }

    public IMapper InitializeMapper()
    {
      var mockMapper = new MapperConfiguration(cfg =>
      {
        cfg.AddProfile(new MappingProfile());
      });
      var mapper = mockMapper.CreateMapper();

      return mapper;
    }

    [Fact]
    public void GetCoilFieldLocation_ReturnsCoilFieldLocations()
    {
      var mapper = InitializeMapper();
      var service = new CoilFieldLocationsService(coilFieldLocationRepo.Object, mapper, logger.Object, coilFieldZoneRepo.Object, coilRepo.Object, webSocketClientService.Object);
      var mockService = new MockCoilFieldLocationService();
      coilFieldLocationRepo.Setup(repo => repo.GetAllCoilFieldLocations())
    .Returns(mockService.GetCoilFieldLocationsList());

      var result = service.GetCoilFieldLocations();

      Assert.NotNull(result);
    }

    [Fact]
    public void GetCoilFieldLocationById_ReturnsCoilFieldLocation()
    {
      var mapper = InitializeMapper();
      var service = new CoilFieldLocationsService(coilFieldLocationRepo.Object, mapper, logger.Object, coilFieldZoneRepo.Object, coilRepo.Object, webSocketClientService.Object);
      var mockService = new MockCoilFieldLocationService();
      coilFieldLocationRepo.Setup(repo => repo.GetCoilFieldLocationById(1))
        .Returns(mapper.Map<CoilFieldLocation>(mockService.GetCoilFieldLocationById(1)));

      var result = service.GetCoilFieldLocationById(1);

      Assert.NotNull(result);
    }

    [Fact]
    public void GetCoilFieldLocationWithZone_ReturnsCoilFieldLocation()
    {
      var coilFieldLocation = new CoilFieldLocation()
      {
        Id = 1,
        IsEmpty = true,
        Column = 1,
        Disabled = false,
        Name = "Test",
        Row = 1,
      };
      var mapper = InitializeMapper();
      var service = new CoilFieldLocationsService(coilFieldLocationRepo.Object, mapper, logger.Object, coilFieldZoneRepo.Object, coilRepo.Object, webSocketClientService.Object);
      var mockService = new MockCoilFieldLocationService();
      coilFieldLocationRepo.Setup(repo => repo.GetCoilFieldLocationWithZone(1))
        .Returns(coilFieldLocation);

      var result = service.GetCoilFieldLocationWithZone(1);

      Assert.NotNull(result);
    }

    [Fact]
    public void GetCoilFieldLocationByCoilId_ReturnsCoilFieldLocation()
    {
      var coil = new Coil
      {
        Id = 1,
        YNA = "",
        CoilFieldLocation = new CoilFieldLocation
        {
          Id = 1
        }
      };

      var mapper = InitializeMapper();
      var service = new CoilFieldLocationsService(coilFieldLocationRepo.Object, mapper, logger.Object, coilFieldZoneRepo.Object, coilRepo.Object, webSocketClientService.Object);
      var mockService = new MockCoilFieldLocationService();
      coilFieldLocationRepo.Setup(repo => repo.GetFreeLocations())
        .Returns(mockService.GetCoilFieldLocationsList().ToList());
      coilRepo.Setup(repo => repo.GetCoilWithCoilField(1))
        .Returns(coil);
      coilFieldLocationRepo.Setup(repo => repo.GetCoilFieldLocationWithZone(1));

      var result = service.GetCoilFieldLocationByCoilId(1);

      Assert.NotNull(result);
    }

    [Fact]
    public void GetCoilFieldLocationByZoneId_ReturnsCoilFieldLocation()
    {
      var mapper = InitializeMapper();
      var service = new CoilFieldLocationsService(coilFieldLocationRepo.Object, mapper, logger.Object, coilFieldZoneRepo.Object, coilRepo.Object, webSocketClientService.Object);
      var mockService = new MockCoilFieldLocationService();
      coilFieldLocationRepo.Setup(repo => repo.GetCoilFieldLocationByZoneId(1))
        .Returns(mapper.Map<List<CoilFieldLocation>>(mockService.GetCoilFieldLocationsByZoneId(1)));

      var result = service.GetCoilFieldLocationByZoneId(1);

      Assert.NotNull(result);
    }

    [Fact]
    public void UpdateCoilFieldLocation_ReturnsVoid()
    {
      var coilFieldLocation = new CoilFieldLocation()
      {
        Id = 1,
        IsEmpty = true,
        Column = 1,
        Disabled = false,
        Name = "Test",
        Row = 1,
      };

      var mapper = InitializeMapper();
      var service = new CoilFieldLocationsService(coilFieldLocationRepo.Object, mapper, logger.Object, coilFieldZoneRepo.Object, coilRepo.Object, webSocketClientService.Object);
      var mockService = new MockCoilFieldLocationService();
      coilFieldLocationRepo.Setup(repo => repo.UpdateCoilFieldLocation(1, coilFieldLocation));

      service.UpdateCoilFieldLocation(1, mockService.GetCoilFieldLocationById(1));
      Assert.NotNull(service);
    }

    [Fact]
    public void UpdateCoilFieldLocationDto_ReturnsString()
    {
      var coilFieldLocation = new CoilFieldLocation()
      {
        Id = 1,
        IsEmpty = true,
        Column = 1,
        Disabled = false,
        Name = "Test",
        Row = 1,
        Zone = new CoilFieldZone
        {
          Id = 1
        }
      };

      var coilFieldZone = new List<CoilFieldZone>
      {
        new CoilFieldZone()
      {
        Id = 1,
        Name = "Test"
      }
      };

      var mapper = InitializeMapper();
      var service = new CoilFieldLocationsService(coilFieldLocationRepo.Object, mapper, logger.Object, coilFieldZoneRepo.Object, coilRepo.Object, webSocketClientService.Object);
      var mockService = new MockCoilFieldLocationService();

      coilFieldLocationRepo.Setup(repo => repo.GetCoilFieldLocationById(1))
        .Returns(coilFieldLocation);
      coilFieldZoneRepo.Setup(repo => repo.GetCoilFieldZones(1))
        .Returns(coilFieldZone);
      coilRepo.Setup(repo => repo.GetCoilByLocationId(1));

      var result = service.UpdateCoilFieldLocationDto(1, mockService.GetCoilFieldLocationById(1));

      Assert.NotNull(result);
    }

    [Fact]
    public void AddCoilFieldLocation_ReturnsDto()
    {
      var coilFieldLocation = new CoilFieldLocation()
      {
        Id = 1,
        IsEmpty = true,
        Column = 1,
        Disabled = false,
        Name = "Test",
        Row = 1,
      };

      var zone = new List<CoilFieldZone>
      {
        new CoilFieldZone()
        {
          Id = 1
        }
      };
      var mapper = InitializeMapper();
      var service = new CoilFieldLocationsService(coilFieldLocationRepo.Object, mapper, logger.Object, coilFieldZoneRepo.Object, coilRepo.Object, webSocketClientService.Object);
      var mockService = new MockCoilFieldLocationService();
      coilFieldZoneRepo.Setup(repo => repo.GetCoilFieldZones(1))
        .Returns(zone);
      coilFieldLocationRepo.Setup(repo => repo.AddCoilFieldLocation(coilFieldLocation));

      var result = service.AddCoilFieldLocation(mockService.GetCoilFieldLocationById(1));

      Assert.NotNull(result);
    }

    [Fact]
    public void DeleteCoilFieldZone_ReturnsDto()
    {
      var coilFieldLocation = new CoilFieldLocation()
      {
        Id = 1,
        IsEmpty = true,
        Column = 1,
        Disabled = false,
        Name = "Test",
        Row = 1,
      };

      var mapper = InitializeMapper();
      var service = new CoilFieldLocationsService(coilFieldLocationRepo.Object, mapper, logger.Object, coilFieldZoneRepo.Object, coilRepo.Object, webSocketClientService.Object);
      var mockService = new MockCoilFieldLocationService();

      coilFieldLocationRepo.Setup(repo => repo.GetCoilFieldLocationById(1))
        .Returns(mapper.Map<CoilFieldLocation>(mockService.GetCoilFieldLocationById(1)));

      var result = service.DeleteCoilFieldLocation(1);

      Assert.NotNull(result);
    }
  }
}

