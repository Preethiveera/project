using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;


namespace CoilTracking.Tests.Business_layer
{
  public class CoilFieldZonesServiceTest
  {
    private readonly Mock<ICoilFieldZoneRepository> coilFieldZoneRepository;

    private readonly Mock<IApplicationLogger<CoilFieldZonesService>> coilFieldZonesServiceLogger;

    private readonly Mock<ICoilFieldLocationRepository> coilFieldLocationRepository;

    private readonly Mock<ICoilFieldRepository> coilFieldRepository;

    private readonly Mock<ICoilRepository> coilRepository;

    private readonly Mock<ICoilTypeRepository> coilTypeRepository;

    private readonly Mock<IWebSocketClientService> webSocketClientService;

    public CoilFieldZonesServiceTest()
    {
      coilFieldZonesServiceLogger = new Mock<IApplicationLogger<CoilFieldZonesService>>();
      coilFieldZoneRepository = new Mock<ICoilFieldZoneRepository>();
      coilFieldLocationRepository = new Mock<ICoilFieldLocationRepository>();
      coilFieldRepository = new Mock<ICoilFieldRepository>();
      coilRepository = new Mock<ICoilRepository>();
      coilTypeRepository = new Mock<ICoilTypeRepository>();
      webSocketClientService = new Mock<IWebSocketClientService>();
    }

    public IMapper InitializeMapper()
    {
      var mockMapper = new MapperConfiguration(cfg =>
      {
        cfg.AddProfile(new MappingProfile());
      });
      var mapper = mockMapper.CreateMapper();

      return mapper;
    }

    [Fact]
    public async Task GetCoilFieldZones_ReturnscoilFieldZones()
    {
      var list = new List<CoilFieldZone> { new CoilFieldZone()
      {
        Id=1,
        Disabled=false,
        Name="Test 1 Zone",
        CoilField = new CoilField(),
        Color = null,
        Locations = null,
        TextColor = "Red"
      } };

      var mapper = InitializeMapper();
      var _service = new CoilFieldZonesService(coilFieldZoneRepository.Object, coilFieldLocationRepository.Object, coilFieldRepository.Object
        , coilRepository.Object, coilTypeRepository.Object, coilFieldZonesServiceLogger.Object, mapper, webSocketClientService.Object);

      coilFieldZoneRepository.Setup(repo => repo.GetCoilFieldZones()).ReturnsAsync(list);

      var result = await _service.GetCoilFieldZones();

      Assert.NotNull(result);
    }

    [Fact]
    public async Task GetCoilFieldZonebyId_ReturnscoilFieldZone()
    {
      var mockCoilFieldZone = new CoilFieldZone()
      {
        Id = 1,
        Disabled = false,
        Name = "Test 1 Zone",
        CoilField = new CoilField(),
        Color = null,
        Locations = null,
        TextColor = "Red"
      };

      var mapper = InitializeMapper();
      var _service = new CoilFieldZonesService(coilFieldZoneRepository.Object, coilFieldLocationRepository.Object, coilFieldRepository.Object
       , coilRepository.Object, coilTypeRepository.Object, coilFieldZonesServiceLogger.Object, mapper, webSocketClientService.Object);

      var id = 1;
      coilFieldZoneRepository.Setup(repo => repo.GetCoilFieldZoneById(id)).ReturnsAsync(mockCoilFieldZone);

      var result = await _service.GetCoilFieldZone(id);

      Assert.NotNull(result);
    }

    [Fact]
    public async Task GetCoilFieldZoneForEdit_ReturnscoilFieldZone()
    {
      var mockCoilFieldZone = new CoilFieldZone()
      {
        Id = 1,
        Disabled = false,
        Name = "Test 1 Zone",
        CoilField = new CoilField(),
        Color = null,
        Locations = null,
        TextColor = "Red"
      };

      var mapper = InitializeMapper();
      var service = new CoilFieldZonesService(coilFieldZoneRepository.Object, coilFieldLocationRepository.Object, coilFieldRepository.Object
       , coilRepository.Object, coilTypeRepository.Object, coilFieldZonesServiceLogger.Object, mapper, webSocketClientService.Object);
      var id = 1;
      coilFieldZoneRepository.Setup(repo => repo.GetCoilFieldZoneById(id)).ReturnsAsync(mockCoilFieldZone);

      var result = await service.GetCoilFieldZoneForEdit(id);

      Assert.NotNull(result);
    }

    [Fact]
    public async Task GetAssociatedItemsByCoilFieldsZone_ReturnscoilType()
    {
      var list = new List<CoilType> { new CoilType()
      {
        Id=1,
        Disabled=false,
        Name="Coil 1",
        CoilFieldZone = null,
        MaxWidth = 2,
        CoilTypeYNAs = null,
        MaxThickness = 2,
        MinThickness = 1,
        MinWidth = 1
      } };

      var mapper = InitializeMapper();
      var service = new CoilFieldZonesService(coilFieldZoneRepository.Object, coilFieldLocationRepository.Object, coilFieldRepository.Object
       , coilRepository.Object, coilTypeRepository.Object, coilFieldZonesServiceLogger.Object, mapper, webSocketClientService.Object);

      var zoneId = 1;
      coilTypeRepository.Setup(repo => repo.GetAssociatedItemsByCoilFieldZone(zoneId)).ReturnsAsync(list);

      var result = await service.GetAssociatedItemsCoilFieldsZone(zoneId);

      Assert.NotNull(result);
    }

    [Fact]
    public async Task GetCoilsByZoneId_ReturnscoilFieldZone()
    {
      var list = new List<Coil> { new Coil()
      {
        Id=1,
        BornOnDate = DateTime.Now.AddDays(-4),
        CheckInDate = DateTime.Now.AddDays(-2),
        CoilFieldLocation = null,
        OrderNo = 12,
        SerialNum = "123"
      } };

      var mapper = InitializeMapper();
      var service = new CoilFieldZonesService(coilFieldZoneRepository.Object, coilFieldLocationRepository.Object, coilFieldRepository.Object
       , coilRepository.Object, coilTypeRepository.Object, coilFieldZonesServiceLogger.Object, mapper, webSocketClientService.Object);

      var zoneId = 1;
      coilRepository.Setup(repo => repo.GetCoilsByZoneId(zoneId)).ReturnsAsync(list);

      var result = await service.GetCoilsByZoneId(zoneId);

      Assert.NotNull(result);
    }

    [Fact]
    public async Task CheckDependencyByZoneId_ReturnscoilFieldZone()
    {
      var list = new List<Coil> { new Coil()
      {
        Id=1,
        BornOnDate = DateTime.Now.AddDays(-4),
        CheckInDate = DateTime.Now.AddDays(-2),
        CoilFieldLocation = null,
        OrderNo = 12,
        SerialNum = "123"
      } };

      var mapper = InitializeMapper();
      var _service = new CoilFieldZonesService(coilFieldZoneRepository.Object, coilFieldLocationRepository.Object, coilFieldRepository.Object
         , coilRepository.Object, coilTypeRepository.Object, coilFieldZonesServiceLogger.Object, mapper, webSocketClientService.Object);
      var zoneId = 1;

      coilRepository.Setup(repo => repo.GetCoilsByZoneId(zoneId)).ReturnsAsync(list);

      var result = await _service.CheckDependencyByZoneId(zoneId);

      Assert.NotNull(result);
    }

    //[Fact]
    //public async Task PutCoilFieldZone_ReturnsBool()
    //{
    //  var coilFieldZoneDto = new CoilFieldZoneDto
    //  {
    //    Id = 1,
    //    Name = "Coil Filed Zone Test 2",
    //    Disabled = false,
    //    CoilField = new CoilFieldDto()
    //    {
    //      Id = 1,
    //      Name = "Coil Field 1 Test 1",
    //      Zones = null,
    //      Disabled = false
    //    }
    //  };

    //  var mapper = InitializeMapper();
    //  var service = new CoilFieldZonesService(coilFieldZoneRepository.Object, coilFieldLocationRepository.Object, coilFieldRepository.Object
    //   , coilRepository.Object, coilTypeRepository.Object, coilFieldZonesServiceLogger.Object, mapper);

    //  coilFieldZoneRepository.Setup(repo => repo.UpdateCoilFieldZone(It.IsAny<CoilFieldZone>())).ReturnsAsync(true);

    //  var result = await service.PutCoilFieldZone(coilFieldZoneDto);

    //  Assert.True(result);
    //}

    [Fact]
    public async Task DisableCoilFieldZone_ReturnsBool()
    {
      var mapper = InitializeMapper();
      var service = new CoilFieldZonesService(coilFieldZoneRepository.Object, coilFieldLocationRepository.Object, coilFieldRepository.Object
       , coilRepository.Object, coilTypeRepository.Object, coilFieldZonesServiceLogger.Object, mapper, webSocketClientService.Object);

      var zoneId = 1;

      coilRepository.Setup(repo => repo.GetCoilsByZoneId(zoneId)).ReturnsAsync(new List<Coil>());
      coilFieldZoneRepository.Setup(repo => repo.GetCoilFieldZoneById(zoneId)).ReturnsAsync(new CoilFieldZone());

      coilFieldZoneRepository.Setup(repo => repo.DisableCoilFieldZone(zoneId, true)).ReturnsAsync(true);

      var result = await service.DisableCoilFieldZone(zoneId, true);

      Assert.True(result);
    }


    [Fact]
    public async Task CheckIfEdited_ReturnsString()
    {

      var coilFieldZoneDto = new CoilFieldZoneDto
      {
        Id = 1,
        Name = "Coil Filed Zone Test 2",
        Disabled = false,
        CoilFieldId = 1,
        Color = "Red",
        TextColor = "Green"
      };

      var coilFieldZone = new CoilFieldZone
      {
        Id = 1,
        Name = "Coil Filed Zone Test 2",
        Disabled = false,
        Color = "Red",
        TextColor = "Yellow",
        CoilField = new CoilField
        {
          Id = 1
        }

      };


      var mapper = InitializeMapper();
      var service = new CoilFieldZonesService(coilFieldZoneRepository.Object, coilFieldLocationRepository.Object, coilFieldRepository.Object
       , coilRepository.Object, coilTypeRepository.Object, coilFieldZonesServiceLogger.Object, mapper, webSocketClientService.Object);

      var zoneId = 1;
      coilFieldZoneRepository.Setup(repo => repo.GetCoilFieldZoneById(zoneId)).ReturnsAsync(coilFieldZone);

      var result = await service.CheckIfEdited(coilFieldZoneDto);

      Assert.False(String.IsNullOrEmpty(result));
    }

    [Fact]
    public async Task UpdateCoilFieldZone_ReturnsVoid()
    {
      var coilFieldZoneDto = new CoilFieldZoneDto
      {
        Id = 1,
        Name = "Coil Filed Zone Test 2",
        Disabled = false,
        LocationId = new List<int> { 1 },
        CoilField = new CoilFieldDto()
        {
          Id = 1,
          Name = "Coil Field 1 Test 1",
          Zones = null,
          Disabled = false
        }
      };

      var mockCoilFieldZone = new CoilFieldZone()
      {
        Id = 1,
        Name = "Coil Filed Zone Test 2",
        Disabled = false,
        CoilField = new CoilField()
        {
          Id = 1
        },
        Color = null,
        Locations = new List<CoilFieldLocation>
        {
          new CoilFieldLocation
          {
            Id = 1,
            Name = "Banglore"
          }
        },
        TextColor = "Red"
      };

      var mockCoilField = new CoilField()
      {
        Id = 1,
        Name = "Coil Field 1 Test 1",
        Zones = null,
        Disabled = false
      };

      var mockCoilFieldLocations = new List<CoilFieldLocation>
      {
        new CoilFieldLocation
        {
          Id=1,
          Name ="banglore"
        }
      };

      var mapper = InitializeMapper();
      var service = new CoilFieldZonesService(coilFieldZoneRepository.Object, coilFieldLocationRepository.Object, coilFieldRepository.Object
       , coilRepository.Object, coilTypeRepository.Object, coilFieldZonesServiceLogger.Object, mapper, webSocketClientService.Object);

      var zoneId = 1;


      coilFieldZoneRepository.Setup(repo => repo.GetCoilFieldZoneById(zoneId)).ReturnsAsync(mockCoilFieldZone);

      coilFieldLocationRepository.Setup(repo => repo.GetCoilFieldLocationByZoneId(zoneId)).Returns(mockCoilFieldLocations);

      coilFieldRepository.Setup(repo => repo.GetCoilFieldById(zoneId)).Returns(mockCoilField);




      await service.UpdateCoilFieldZone(coilFieldZoneDto);

      Assert.True(true);
    }

    //[Fact]
    //public async Task PostCoilFieldZone_ReturnsBool()
    //{
    //  var coilFieldZoneDto = new CoilFieldZoneDto
    //  {
    //    Name = "Coil Filed Zone Test 2",
    //    Disabled = false,
    //    CoilField = new CoilFieldDto()
    //    {
    //      Id = 1,
    //      Name = "Coil Field 1 Test 1",
    //      Zones = null,
    //      Disabled = false
    //    }
    //  };

    //  var coilFieldZone = new CoilFieldZone
    //  {
    //    Id = 1,
    //    Name = "Coil Filed Zone Test 2",
    //    Disabled = false,
    //    CoilField = new CoilField()
    //    {
    //      Id = 1,
    //      Name = "Coil Field 1 Test 1",
    //      Zones = null,
    //      Disabled = false
    //    }
    //  };

    //  var mapper = InitializeMapper();
    //  var service = new CoilFieldZonesService(coilFieldZoneRepository.Object, coilFieldLocationRepository.Object, coilFieldRepository.Object
    //   , coilRepository.Object, coilTypeRepository.Object, coilFieldZonesServiceLogger.Object, mapper, webSocketClientService.Object);

    //  coilFieldZoneRepository.Setup(repo => repo.AddCoilFieldZone(It.IsAny<CoilFieldZone>())).ReturnsAsync(coilFieldZone);

    //  var result = await service.PostCoilFieldZone(coilFieldZoneDto);

    //  Assert.NotNull(result);
    //  Assert.True(result.Id > 0);
    //}

    [Fact]
    public async Task SaveCoilFieldZone_ReturnsVoid()
    {
      var coilFieldZoneDto = new CoilFieldZoneDto
      {
        Id = 1,
        Name = "Coil Filed Zone Test 2",
        Disabled = false,
        LocationId = new List<int> { 1 },
        CoilField = new CoilFieldDto()
        {
          Id = 1,
          Name = "Coil Field 1 Test 1",
          Zones = null,
          Disabled = false
        }
      };

      var mockCoilFieldZone = new CoilFieldZone()
      {
        Id = 1,
        Name = "Coil Filed Zone Test 2",
        Disabled = false,
        CoilField = new CoilField()
        {
          Id = 1
        },
        Color = null,
        Locations = new List<CoilFieldLocation>
        {
          new CoilFieldLocation
          {
            Id = 1,
            Name = "Banglore"
          }
        },
        TextColor = "Red"
      };

      var mockCoilField = new CoilField()
      {
        Id = 1,
        Name = "Coil Field 1 Test 1",
        Zones = null,
        Disabled = false
      };

      var mockCoilFieldLocations = new List<CoilFieldLocation>
      {
        new CoilFieldLocation
        {
          Id=1,
          Name ="Banglore"
        }
      };

      var mapper = InitializeMapper();
      var service = new CoilFieldZonesService(coilFieldZoneRepository.Object, coilFieldLocationRepository.Object, coilFieldRepository.Object
       , coilRepository.Object, coilTypeRepository.Object, coilFieldZonesServiceLogger.Object, mapper, webSocketClientService.Object);

      var zoneId = 1;

      coilFieldLocationRepository.Setup(repo => repo.GetAllCoilFieldLocations()).Returns(mockCoilFieldLocations.AsQueryable());

      coilFieldRepository.Setup(repo => repo.GetCoilFieldById(zoneId)).Returns(mockCoilField);

      coilFieldZoneRepository.Setup(repo => repo.AddCoilFieldZone(It.IsAny<CoilFieldZone>())).ReturnsAsync(mockCoilFieldZone);


      var result = await service.SaveCoilFieldZone(coilFieldZoneDto);

      Assert.NotNull(result);
    }

    [Fact]
    public async Task DeleteCoilField_Id_ReturnscoilField()
    {

      var mockCoilFieldZone = new CoilFieldZone()
      {
        Id = 1,
        Disabled = false,
        Name = "Test 1 Zone",
        CoilField = new CoilField(),
        Color = null,
        Locations = null,
        TextColor = "Red"
      };

      var mapper = InitializeMapper();
      var service = new CoilFieldZonesService(coilFieldZoneRepository.Object, coilFieldLocationRepository.Object, coilFieldRepository.Object
       , coilRepository.Object, coilTypeRepository.Object, coilFieldZonesServiceLogger.Object, mapper, webSocketClientService.Object);

      var zoneId = 1;

      coilFieldZoneRepository.Setup(repo => repo.GetCoilFieldZoneById(zoneId)).ReturnsAsync(mockCoilFieldZone);
      coilFieldZoneRepository.Setup(repo => repo.DeleteCoilFieldZone(zoneId)).ReturnsAsync(true);

      var result = await service.DeleteCoilFieldZone(zoneId);

      Assert.NotNull(result);
    }

  }
}
