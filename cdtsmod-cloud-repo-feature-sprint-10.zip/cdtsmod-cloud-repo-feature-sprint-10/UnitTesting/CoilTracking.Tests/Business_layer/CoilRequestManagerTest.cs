using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Common.Constant;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.Tests.Service;
using Moq;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class CoilRequestManagerTest
  {
    private readonly Mock<ICoilRepository> coilRepo;
    private readonly Mock<ICoilMoveRequestsRepository> coilMoveRequestRepo;
    private readonly Mock<IRunResultsRepository> runResultRepo;
    private readonly Mock<ICoilRunHistoryRepository> coilRunHistoryRepo;
    private readonly Mock<ICoilStatusRepository> coilStatusRepo;

    public CoilRequestManagerTest()
    {
      coilRepo = new Mock<ICoilRepository>();
      coilMoveRequestRepo = new Mock<ICoilMoveRequestsRepository>();
      runResultRepo = new Mock<IRunResultsRepository>();
      coilRunHistoryRepo = new Mock<ICoilRunHistoryRepository>();
      coilStatusRepo = new Mock<ICoilStatusRepository>();
    }
    public IMapper InitializeMapper()
    {
      var mockMapper = new MapperConfiguration(cfg =>
      {
        cfg.AddProfile(new MappingProfile());
      });
      var mapper = mockMapper.CreateMapper();

      return mapper;
    }

    [Fact]
    public void RequestCoilMove_ReturnsCoilMoveRequest()
    {
      var coilType = new CoilType
      {
        Id = 1
      };
      var mapper = InitializeMapper();
      var service = new CoilRequestManager(coilRepo.Object, coilMoveRequestRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object, coilStatusRepo.Object);
      var mockService = new MockCoilMoveRequestService();
      coilMoveRequestRepo.Setup(repo => repo.GetUnfulfilledCoilIds().Result)
    .Returns(mockService.GetCoilIds());
      coilRepo.Setup(repo => repo.GetCoilsToMove(1, mockService.GetCoilIds()).Result)
    .Returns(mockService.GetCoils());

      var result = service.RequestCoilMove(coilType, CoilMoveRequestType.CoilRequest, null);
      Assert.NotNull(result);
    }

    [Fact]
    public void FulFillCoilMove_ReturnsCoilMoveRequest()
    {
      var runResult = new RunResult
      {
        Id = 1
      };

      var runHistory = new CoilRunHistory
      {
        Id = 1
      };
      var mapper = InitializeMapper();
      var service = new CoilRequestManager(coilRepo.Object, coilMoveRequestRepo.Object, runResultRepo.Object, coilRunHistoryRepo.Object, coilStatusRepo.Object);
      var mockService = new MockCoilMoveRequestService();
      runResultRepo.Setup(repo => repo.GetNewestRunResultForCoil(1).Result)
    .Returns(runResult);
      coilRunHistoryRepo.Setup(repo => repo.SaveCoilRunHistories(runHistory))
    .Returns(true);
      coilStatusRepo.Setup(repo => repo.GetCoilStatusByName(CoilStatusName.LoadedAtLine).Result)
    .Returns(mockService.GetCoilStatus());

      var result = service.FullFillCoilMove(mockService.FindCoilMoveRequest(1), null, null);
      Assert.NotNull(result);
    }
  }
}
