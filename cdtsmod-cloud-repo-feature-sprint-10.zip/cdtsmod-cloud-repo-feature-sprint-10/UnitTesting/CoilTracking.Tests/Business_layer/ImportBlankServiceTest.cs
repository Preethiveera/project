using CoilTracking.Business.Implementation;
using CoilTracking.Business.Kentucky;
using CoilTracking.Common.Logging;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.Tests.Service;
using Moq;
using OfficeOpenXml;
using System.IO;
using System.Text;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class ImportBlankServiceTest
  {
    private readonly Mock<IPlantsRepository> plantRepo;
    private readonly Mock<ILineRepository> lineRepo;
    private readonly Mock<IPartRepository> partRepo;
    private readonly Mock<ICoilTypeRepository> coilTypeRepo;


    private readonly Mock<IBlankInfoesRepository> blankInfoRepo;
    private readonly Mock<IApplicationLogger<ImportBlankData>> blankInfoServiceLogger;
    private readonly Mock<IImportBlankInfoFactory> importBlankFactory;
    private readonly Mock<IPressRepository> pressRepo;


    public ImportBlankServiceTest()
    {
      blankInfoRepo = new Mock<IBlankInfoesRepository>();
      blankInfoServiceLogger = new Mock<IApplicationLogger<ImportBlankData>>();

      lineRepo = new Mock<ILineRepository>();
      partRepo = new Mock<IPartRepository>();
      coilTypeRepo = new Mock<ICoilTypeRepository>();
      importBlankFactory = new Mock<IImportBlankInfoFactory>();
      pressRepo = new Mock<IPressRepository>();
    }

    [Fact]
    public void Import_memoryStreamAndUserName_ReturnserrorMsgs()
    {
      var _service = new ImportBlankData(blankInfoRepo.Object, lineRepo.Object, pressRepo.Object, coilTypeRepo.Object, partRepo.Object,
            blankInfoServiceLogger.Object, importBlankFactory.Object);
      using var test_Stream = new MemoryStream(Encoding.UTF8.GetBytes("whatever"));
      var result = _service.Import(test_Stream, "User");

      // Assert    
      Assert.NotNull(result);
    }
    [Fact]
    public void Import_memoryStreamAndUserName_ReturnsMsgs()
    {
      var _service = new ImportBlankData(blankInfoRepo.Object, lineRepo.Object, pressRepo.Object, coilTypeRepo.Object, partRepo.Object,
            blankInfoServiceLogger.Object, importBlankFactory.Object);

      using var package = new ExcelPackage();
      var worksheet = package.Workbook.Worksheets.Add("UploadedFile");
      worksheet.Cells[1, 1].Value = "Data#/MSUS#";
      worksheet.Cells[1, 2].Value = "19";

      var stream = new MemoryStream(package.GetAsByteArray());
      var result = _service.Import(stream, "User");

      Assert.NotNull(result);
    }
    [Fact]
    public void ImportData_WorkheetAndUserName_ReturnsMsgsForTmmk()
    {
      var _service = new ImportBlankData(blankInfoRepo.Object, lineRepo.Object, pressRepo.Object, coilTypeRepo.Object, partRepo.Object,
            blankInfoServiceLogger.Object, importBlankFactory.Object);
      var _mockBlankInfoService = new MockBlankInfoService();
      lineRepo.Setup(repo => repo.GetLines())
    .Returns(_mockBlankInfoService.GetLinesList());
      importBlankFactory.Setup(x => x.Create()).Returns(new ImportBlanks());

      using var package = new ExcelPackage();
      var worksheet = package.Workbook.Worksheets.Add("UploadedFile");
      worksheet.Cells[1, 1].Value = "DataNumber";
      worksheet.Cells[1, 2].Value = 19;
      worksheet.Cells[2, 1].Value = "Part No";
      worksheet.Cells[2, 2].Value = "61111-06190";
      worksheet.Cells[3, 1].Value = "LineName";
      worksheet.Cells[3, 2].Value = "BL1";
      worksheet.Cells[4, 1].Value = "CoilTypeName";
      worksheet.Cells[4, 2].Value = "1-1-A";
      worksheet.Cells[5, 1].Value = "PressName";
      worksheet.Cells[5, 2].Value = "1A";
      worksheet.Cells[6, 1].Value = "Pitch";
      worksheet.Cells[6, 2].Value = 1234;
      worksheet.Cells[7, 1].Value = "StackSize";
      worksheet.Cells[7, 2].Value = 234;
      worksheet.Cells[8, 1].Value = "Width";
      worksheet.Cells[8, 2].Value = 123;
      worksheet.Cells[9, 1].Value = "Weight";
      worksheet.Cells[9, 2].Value = 234;
      worksheet.Cells[10, 1].Value = "RewindWeight";
      worksheet.Cells[10, 2].Value = 23;
      worksheet.Cells[11, 1].Value = "MinPitch";
      worksheet.Cells[11, 2].Value = 12;
      worksheet.Cells[12, 1].Value = "MaxPitch";
      worksheet.Cells[12, 2].Value = 23;
      worksheet.Cells[13, 1].Value = "MinWidth";
      worksheet.Cells[13, 2].Value = 67;
      worksheet.Cells[14, 1].Value = "MaxWidth";
      worksheet.Cells[14, 2].Value = 88;
      worksheet.Cells[15, 1].Value = "DieNo";
      worksheet.Cells[15, 2].Value = "1234";


      var stream = new MemoryStream(package.GetAsByteArray());
      var result = _service.ImportData(worksheet, "User");

      Assert.NotNull(result);
    }
    [Fact]
    public void ImportData_WorkheetAndUserName_ReturnsMsgsForTMMI()
    {
      var _service = new ImportBlankData(blankInfoRepo.Object, lineRepo.Object, pressRepo.Object, coilTypeRepo.Object, partRepo.Object,
            blankInfoServiceLogger.Object, importBlankFactory.Object);
      var _mockBlankInfoService = new MockBlankInfoService();
      lineRepo.Setup(repo => repo.GetLines())
    .Returns(_mockBlankInfoService.GetLinesList());
      importBlankFactory.Setup(x => x.Create()).Returns(new ImportBlankForTMMI());

      using (var package = new ExcelPackage())
      {
        var worksheet = package.Workbook.Worksheets.Add("UploadedFile");
        worksheet.Cells[1, 1].Value = "DataNumber";
        worksheet.Cells[1, 2].Value = 19;
        worksheet.Cells[2, 1].Value = "Part No";
        worksheet.Cells[2, 2].Value = "61111-06190";
        worksheet.Cells[3, 1].Value = "LineName";
        worksheet.Cells[3, 2].Value = "BL1";
        worksheet.Cells[4, 1].Value = "CoilTypeName";
        worksheet.Cells[4, 2].Value = "1-1-A";
        worksheet.Cells[5, 1].Value = "PressName";
        worksheet.Cells[5, 2].Value = "1A";
        worksheet.Cells[6, 1].Value = "Pitch";
        worksheet.Cells[6, 2].Value = 1234;
        worksheet.Cells[7, 1].Value = "StackSize";
        worksheet.Cells[7, 2].Value = 234;
        worksheet.Cells[8, 1].Value = "Width";
        worksheet.Cells[8, 2].Value = 123;
        worksheet.Cells[9, 1].Value = "Weight";
        worksheet.Cells[9, 2].Value = 234;
        worksheet.Cells[10, 1].Value = "RewindWeight";
        worksheet.Cells[10, 2].Value = 23;
        worksheet.Cells[11, 1].Value = "MinPitch";
        worksheet.Cells[11, 2].Value = 12;
        worksheet.Cells[12, 1].Value = "MaxPitch";
        worksheet.Cells[12, 2].Value = 23;
        worksheet.Cells[13, 1].Value = "MinWidth";
        worksheet.Cells[13, 2].Value = 67;
        worksheet.Cells[14, 1].Value = "MaxWidth";
        worksheet.Cells[14, 2].Value = 88;
        worksheet.Cells[15, 1].Value = "DieNo";
        worksheet.Cells[15, 2].Value = "1234";

        var stream = new MemoryStream(package.GetAsByteArray());
        var result = _service.ImportData(worksheet, "User");

        Assert.NotNull(result);

      }
    }

  }
}
