using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Common.Logging;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using Moq;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class ProdPlanServiceTest
  {
    private readonly Mock<IApplicationLogger<ProdPlanService>> logger;
    private readonly Mock<IProdPlanRepository> mockProdPlanRepository;

    public ProdPlanServiceTest()
    {
      logger = new Mock<IApplicationLogger<ProdPlanService>>();
      mockProdPlanRepository = new Mock<IProdPlanRepository>();
    }

    public IMapper InitializeMapper()
    {
      var mockMapper = new MapperConfiguration(cfg =>
      {
        cfg.AddProfile(new MappingProfile());
      });
      var mapper = mockMapper.CreateMapper();

      return mapper;
    }

    [Fact]
    public void GetProdPlans_ReturnsDto()
    {
      var mapper = InitializeMapper();
      var service = new ProdPlanService(logger.Object, mockProdPlanRepository.Object, mapper);
      var result = service.GetProdPlans();
      Assert.NotNull(result);
    }

    [Fact]
    public void GetProdPlanById_ReturnsDto()
    {
      var mapper = InitializeMapper();
      var service = new ProdPlanService(logger.Object, mockProdPlanRepository.Object, mapper);
      var result = service.GetProdPlanById(1);
      Assert.NotNull(result);
    }

    [Fact]
    public void PutProdPlan()
    {
      var prodPlan = new ProdPlanDto
      {
        Id = 1
      };
      var mapper = InitializeMapper();
      var service = new ProdPlanService(logger.Object, mockProdPlanRepository.Object, mapper);
      var result = service.PutProdPlan(1, prodPlan);
      Assert.NotNull(result);
    }

    [Fact]
    public void PostProdPlan()
    {
      var prodPlan = new ProdPlanDto
      {
        Id = 1
      };
      var mapper = InitializeMapper();
      var service = new ProdPlanService(logger.Object, mockProdPlanRepository.Object, mapper);
      var result = service.PostProdPlan(prodPlan);
      Assert.NotNull(result);
    }

    [Fact]
    public void DeleteProdPlan()
    {
      var mapper = InitializeMapper();
      var service = new ProdPlanService(logger.Object, mockProdPlanRepository.Object, mapper);
      var result = service.DeleteProdPlan(1);
      Assert.NotNull(result);
    }
  }
}
