using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Business.Implementation.Lines;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Logging;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using Moq;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class LineDataManagerTest
  {
    private readonly Mock<ILineRepository> lineRepo;
    private readonly Mock<IApplicationLogger<LineDataManager>> logger;
    private readonly Mock<IWebSocketClientService> webSocketClientService;

    public LineDataManagerTest()
    {
      lineRepo = new Mock<ILineRepository>();
      logger = new Mock<IApplicationLogger<LineDataManager>>();
      webSocketClientService = new Mock<IWebSocketClientService>();
    }

    public IMapper InitializeMapper()
    {
      var mockMapper = new MapperConfiguration(cfg =>
      {
        cfg.AddProfile(new MappingProfile());
      });
      var mapper = mockMapper.CreateMapper();

      return mapper;
    }

    [Fact]
    public void ProcessSavedData_ReturnDto()
    {
      var mapper = InitializeMapper();
      var mockService = new MockLineService();
      string[] plcTags = mockService.GetLine().Tags.Split(',');
      var data = new DataUpdateDto
      {
        IsNew = false
      };
      var service = new LineDataManager(lineRepo.Object, mapper, logger.Object, webSocketClientService.Object);
      var lines = service.ProcessSavedData(mockService.GetLineData(), mockService.GetLineDataDto(), mockService.GetLine(), plcTags, data);
      Assert.NotNull(lines);
    }

    [Fact]
    public void CreateNewRun_ReturnDto()
    {
      var mapper = InitializeMapper();
      var mockService = new MockLineService();
      var data = new DataUpdateDto
      {
        IsNew = false
      };
      var service = new LineDataManager(lineRepo.Object, mapper, logger.Object, webSocketClientService.Object);
      var lines = service.CreateNewRun(mockService.GetLineDataDto(), data);
      Assert.NotNull(lines);
    }
  }
}
