using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Common.Logging;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using Moq;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class ShiftServiceTest
  {
    private readonly Mock<IApplicationLogger<ShiftService>> logger;
    private readonly Mock<IShiftRepository> shiftRepo;
    private readonly Mock<ILineRepository> lineRepo;
    private readonly Mock<IRunOrderRepository> runOrderRepo;
    private readonly Mock<IIncompleteRunOrderItemsRepository> incompleteRunOrderItemsRepo;

    public ShiftServiceTest()
    {
      logger = new Mock<IApplicationLogger<ShiftService>>();
      shiftRepo = new Mock<IShiftRepository>();
      lineRepo = new Mock<ILineRepository>();
      runOrderRepo = new Mock<IRunOrderRepository>();
      incompleteRunOrderItemsRepo = new Mock<IIncompleteRunOrderItemsRepository>();
    }

    public IMapper InitializeMapper()
    {
      var mockMapper = new MapperConfiguration(cfg =>
      {
        cfg.AddProfile(new MappingProfile());
      });
      var mapper = mockMapper.CreateMapper();

      return mapper;
    }

    [Fact]
    public void GetShifts_ReturnsDto()
    {
      var mapper = InitializeMapper();
      var service = new ShiftService(logger.Object, shiftRepo.Object, mapper, lineRepo.Object, runOrderRepo.Object, incompleteRunOrderItemsRepo.Object);
      var result = service.GetShifts();
      Assert.NotNull(result);
    }

    [Fact]
    public void GetShiftById_ReturnsDto()
    {
      var mapper = InitializeMapper();
      var service = new ShiftService(logger.Object, shiftRepo.Object, mapper, lineRepo.Object, runOrderRepo.Object, incompleteRunOrderItemsRepo.Object);
      var result = service.GetShiftById(1);
      Assert.NotNull(result);
    }

    [Fact]
    public void GetCurrentShift_ReturnsDto()
    {
      var mapper = InitializeMapper();
      var service = new ShiftService(logger.Object, shiftRepo.Object, mapper, lineRepo.Object, runOrderRepo.Object, incompleteRunOrderItemsRepo.Object);
      var result = service.GetCurrentShift(1);
      Assert.NotNull(result);
    }

    [Fact]
    public void GetNextShift_ReturnsDto()
    {
      var mapper = InitializeMapper();
      var service = new ShiftService(logger.Object, shiftRepo.Object, mapper, lineRepo.Object, runOrderRepo.Object, incompleteRunOrderItemsRepo.Object);
      var result = service.GetNextShift(1);
      Assert.NotNull(result);
    }

    [Fact]
    public void PutShift()
    {
      var shift = new ShiftDto
      {
        Id = 1
      };
      var mapper = InitializeMapper();
      var service = new ShiftService(logger.Object, shiftRepo.Object, mapper, lineRepo.Object, runOrderRepo.Object, incompleteRunOrderItemsRepo.Object);
      var result = service.PutShift(1, shift);
      Assert.NotNull(result);
    }

    [Fact]
    public void DisableShift()
    {
      var mapper = InitializeMapper();
      var service = new ShiftService(logger.Object, shiftRepo.Object, mapper, lineRepo.Object, runOrderRepo.Object, incompleteRunOrderItemsRepo.Object);
      var result = service.DisableShift(1, true);
      Assert.NotNull(result);
    }

    [Fact]
    public void AddShift_ReturnsDto()
    {
      var shift = new ShiftDto
      {
        Id = 1
      };
      var mapper = InitializeMapper();
      var service = new ShiftService(logger.Object, shiftRepo.Object, mapper, lineRepo.Object, runOrderRepo.Object, incompleteRunOrderItemsRepo.Object);
      var result = service.AddShift(shift);
      Assert.NotNull(result);
    }

    [Fact]
    public void DeleteShift_ReturnsDto()
    {
      var mapper = InitializeMapper();
      var service = new ShiftService(logger.Object, shiftRepo.Object, mapper, lineRepo.Object, runOrderRepo.Object, incompleteRunOrderItemsRepo.Object);
      var result = service.DeleteShift(1);
      Assert.NotNull(result);
    }
  }
}
