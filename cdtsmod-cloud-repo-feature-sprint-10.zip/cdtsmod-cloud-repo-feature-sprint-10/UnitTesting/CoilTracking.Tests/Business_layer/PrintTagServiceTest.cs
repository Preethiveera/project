using CoilTracking.Business.Implementation;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Logging;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.AspNetCore.Hosting;
using Moq;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class PrintTagServiceTest
  {
    private readonly Mock<IIncompleteRunOrderItemsRepository> mockIncompleteRunOrderItemsRepository;
    private readonly Mock<IRunResultsRepository> mockRunResultsRepository;
    private readonly Mock<IBlankInfoesRepository> mockBlankInfoesRepository;
    private readonly Mock<IPrintFunctions> mockPrintFunctions;
    private readonly Mock<IPlantsRepository> mockPlantsRepository;
    private readonly Mock<IPartRepository> mockPartRepository;
    [Obsolete]
    private readonly Mock<IHostingEnvironment> mockHostingEnvironment;
    private readonly Mock<IApplicationLogger<PrintTagService>> logger;
    private readonly Mock<IUserHelper> userHelper;
    [Obsolete]
    public PrintTagServiceTest()
    {
      mockIncompleteRunOrderItemsRepository = new Mock<IIncompleteRunOrderItemsRepository>();
      mockRunResultsRepository = new Mock<IRunResultsRepository>();
      mockBlankInfoesRepository = new Mock<IBlankInfoesRepository>();
      mockPrintFunctions = new Mock<IPrintFunctions>();
      mockPlantsRepository = new Mock<IPlantsRepository>();
      mockPartRepository = new Mock<IPartRepository>();
      mockHostingEnvironment = new Mock<IHostingEnvironment>();
      logger = new Mock<IApplicationLogger<PrintTagService>>();
      userHelper = new Mock<IUserHelper>();
    }

    [Fact]
    [Obsolete]
    public void GetCurrentRunListAsync()
    {
      var service = new PrintTagService(mockIncompleteRunOrderItemsRepository.Object, mockRunResultsRepository.Object, mockBlankInfoesRepository.Object, mockPrintFunctions.Object, mockPlantsRepository.Object, mockPartRepository.Object, mockHostingEnvironment.Object, logger.Object, userHelper.Object);
      var result = service.GetCurrentRunListAsync(1);
      Assert.NotNull(result);
    }

    [Fact]
    [Obsolete]
    public void PrintBlankTagAsync()
    {
      var type = "";
      var obj = new JObject();
      var service = new PrintTagService(mockIncompleteRunOrderItemsRepository.Object, mockRunResultsRepository.Object, mockBlankInfoesRepository.Object, mockPrintFunctions.Object, mockPlantsRepository.Object, mockPartRepository.Object, mockHostingEnvironment.Object, logger.Object, userHelper.Object);
      var result = service.PrintBlankTagAsync(type, obj);
      Assert.NotNull(result);
    }

    [Fact]
    [Obsolete]
    public void PrintBlankTagTest()
    {
      var service = new PrintTagService(mockIncompleteRunOrderItemsRepository.Object, mockRunResultsRepository.Object, mockBlankInfoesRepository.Object, mockPrintFunctions.Object, mockPlantsRepository.Object, mockPartRepository.Object, mockHostingEnvironment.Object, logger.Object, userHelper.Object);
      var result = service.PrintBlankTagTest();
      Assert.NotNull(service);
    }
  }
}
