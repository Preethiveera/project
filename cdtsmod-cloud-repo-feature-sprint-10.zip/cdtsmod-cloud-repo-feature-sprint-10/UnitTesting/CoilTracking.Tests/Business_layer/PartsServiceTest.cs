using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Exception;
using CoilTracking.DataAccess.Interfaces;

using CoilTracking.Tests.Service;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class PartsServiceTest
  {
    public readonly Mock<IPartModelsRepository> partModelsRepo;
    public readonly Mock<IPartRepository> partRepo;
    public readonly Mock<IBlankInfoesRepository> blankInfoesRepo;
    public readonly Mock<IModelRepository> modelRepo;
    private readonly IMapper mapper;
   private readonly Mock<IBlankInfoService> blankInfoservice;
    int id = 23;

    public PartsServiceTest()
    {
      partModelsRepo = new Mock<IPartModelsRepository>();
      partRepo = new Mock<IPartRepository>();
      blankInfoesRepo = new Mock<IBlankInfoesRepository>();
      modelRepo = new Mock<IModelRepository>();
     blankInfoservice = new Mock<IBlankInfoService>();

    }



    public IMapper InitializeMapper()
    {
      var mockMapper = new MapperConfiguration(cfg =>
      {
        cfg.AddProfile(new MappingProfile());
      });
      var mapper = mockMapper.CreateMapper();

      return mapper;
    }

    [Fact]
    public async Task GetParts_Latest_ReturnsPartsDtos()
    {
      var mockpartsService = new MockPartsService();
      var mapper = InitializeMapper();
      partRepo.Setup(repo => repo.GetPartsAsync())
      .ReturnsAsync(mockpartsService.GetParts());
      var service = new PartsService(partRepo.Object, partModelsRepo.Object, blankInfoesRepo.Object, modelRepo.Object,  blankInfoservice.Object);
      var parts = await service.GetParts();
      Assert.NotNull(parts);
    }
    [Fact]
    public async Task GetPartById_Latest_ReturnsPartsDtos()
    {
      var mockpartsService = new MockPartsService();
      var mapper = InitializeMapper();
      partRepo.Setup(repo => repo.GetPartByIdAsync(id))
      .ReturnsAsync(mockpartsService.GetPart());
      var service = new PartsService(partRepo.Object, partModelsRepo.Object, blankInfoesRepo.Object, modelRepo.Object,  blankInfoservice.Object);
      var parts = await service.GetPartById(id);
      Assert.NotNull(parts);
    }
    [Fact]
    public async Task GetPartDtos_ReturnsPartsDtos()
    {
      var mockpartsService = new MockPartsService();
      var mapper = InitializeMapper();
      partRepo.Setup(repo => repo.GetPartsAsync())
      .ReturnsAsync(mockpartsService.GetParts());
      var service = new PartsService(partRepo.Object, partModelsRepo.Object, blankInfoesRepo.Object, modelRepo.Object,  blankInfoservice.Object);
      var parts = await service.GetParts();
      Assert.NotNull(parts);
    }

    [Fact]
    public void GetPartModelsById_ReturnsPartsDtos()
    {
      var mockpartsService = new MockPartsService();
      var mapper = InitializeMapper();
      partRepo.Setup(repo => repo.GetPartByIdAsync(id))
      .ReturnsAsync(mockpartsService.GetPart());
      partModelsRepo.Setup(repo => repo.GetPartModelByPartId(id))
      .Returns(mockpartsService.GetModels());
      var service = new PartsService(partRepo.Object, partModelsRepo.Object, blankInfoesRepo.Object, modelRepo.Object,  blankInfoservice.Object);
      Assert.ThrowsAsync<CoilTrackingException>(() => service.GetPartModelsById(id));
    }


    [Fact]
    public void GetAutoCompleteInfo_ReturnsPartsDtos()
    {
      int lineid = 12;
      string partnumber = "533";
      List<string> partNumber = new List<string>(3)
      {
        "533333",
        "53333344",
        "53333366666"
      };
      var mockpartsService = new MockPartsService();
      var mapper = InitializeMapper();
      blankInfoesRepo.Setup(repo => repo.GetBlankInfoByLineIdAndPartNumber(lineid, partNumber))
      .ReturnsAsync(mockpartsService.GetBlankInfo());
      partModelsRepo.Setup(repo => repo.GetPartmodelsByPartnumber(partnumber))
      .ReturnsAsync(mockpartsService.GetPartModelByPartIdsAndModelId());
      var service = new PartsService(partRepo.Object, partModelsRepo.Object, blankInfoesRepo.Object, modelRepo.Object,  blankInfoservice.Object);
      Assert.ThrowsAsync<CoilTrackingException>(() => service.GetAutoCompleteInfo(partnumber, lineid));
    }

    [Fact]
    public async Task UpdatePart_Returns()
    {
      var mockpartsService = new MockPartsService();
      var part = mockpartsService.GetPart();

      var mapper = InitializeMapper();
      partRepo.Setup(repo => repo.GetPartByIdAsync(id))
      .ReturnsAsync(mockpartsService.GetPart());
      var service = new PartsService(partRepo.Object, partModelsRepo.Object, blankInfoesRepo.Object, modelRepo.Object,  blankInfoservice.Object);
      ///Assert.ThrowsAsync<CoilTrackingException>(() => service.GetPartModelsById(id));  
      await service.UpdatePart(id, part);
      Assert.True(true);
    }

    [Fact]
    public async Task InsertPart_Returns()
    {
      var mockpartsService = new MockPartsService();
      var part = mockpartsService.GetPart();
      string name = "Ever";
      var mapper = InitializeMapper();
      partRepo.Setup(repo => repo.GetPartByName(name))
      .Returns(mockpartsService.GetPart());
      var service = new PartsService(partRepo.Object, partModelsRepo.Object, blankInfoesRepo.Object, modelRepo.Object,  blankInfoservice.Object);
      ///Assert.ThrowsAsync<CoilTrackingException>(() => service.GetPartModelsById(id));  
      await service.InsertPart(part);
      Assert.True(true);
    }


    [Fact]
    public async Task DeletePart_Returns()
    {
      var mockpartsService = new MockPartsService();
      var mapper = InitializeMapper();
      partRepo.Setup(repo => repo.GetPartByIdAsync(id))
      .ReturnsAsync(mockpartsService.GetPart());
      var service = new PartsService(partRepo.Object, partModelsRepo.Object, blankInfoesRepo.Object, modelRepo.Object,  blankInfoservice.Object);
      ///Assert.ThrowsAsync<CoilTrackingException>(() => service.GetPartModelsById(id));  
      await service.DeletePart(id);
      Assert.True(true);
    }

    [Fact]
    public async Task DisablePart_Returns()
    {
      var mockpartsService = new MockPartsService();
      var mapper = InitializeMapper();
      partRepo.Setup(repo => repo.GetPartByIdAsync(id))
      .ReturnsAsync(mockpartsService.GetPart());
      var service = new PartsService(partRepo.Object, partModelsRepo.Object, blankInfoesRepo.Object, modelRepo.Object,  blankInfoservice.Object);
      ///Assert.ThrowsAsync<CoilTrackingException>(() => service.GetPartModelsById(id));  
      await service.DisablePart(id, true);
      Assert.True(true);
    }

    [Fact]
    public void ChangeModels_Returns()
    {
      var mockpartsService = new MockPartsService();
      var models = mockpartsService.GetModels();

      var mapper = InitializeMapper();
      partRepo.Setup(repo => repo.GetPartByIdAsync(id))
      .ReturnsAsync(mockpartsService.GetPart());
      partModelsRepo.Setup(repo => repo.GetPartModelByPartId(id))
.Returns(mockpartsService.GetModels());
      partModelsRepo.Setup(repo => repo.GetPartmodelsByPartId(id))
.ReturnsAsync(mockpartsService.GetPartModelByPartIdsAndModelId());
      partModelsRepo.Setup(repo => repo.GetPartmodelsByPartIdwithOut(id))
.ReturnsAsync(mockpartsService.GetPartModelByPartIdsAndModelId());
      
      var service = new PartsService(partRepo.Object, partModelsRepo.Object, blankInfoesRepo.Object, modelRepo.Object,  blankInfoservice.Object);
      ///Assert.ThrowsAsync<CoilTrackingException>(() => service.GetPartModelsById(id));  
   var r =  service.ChangeModels(models, id);
      Assert.True(true);
    }


    [Fact]
    public  void PartCheckEdit_ReturnsCoilTrackingException()
    {
      var mockpartsService = new MockPartsService();
      var part = mockpartsService.GetPart();
      string name = "Ever";
      var mapper = InitializeMapper();
      partRepo.Setup(repo => repo.GetPartByIdAsync(id))
       .ReturnsAsync(mockpartsService.GetPart());
      var service = new PartsService(partRepo.Object, partModelsRepo.Object, blankInfoesRepo.Object, modelRepo.Object,  blankInfoservice.Object);
      Assert.ThrowsAsync<CoilTrackingException>(() => service.PartCheckEdit(id, part));  
  
    }


    [Fact]
    public  void GetPartProdPlanAssociation_Returnsstring()
    {
      var mockpartsService = new MockPartsService();
      var blankinfo = mockpartsService.GetBlankInfo();
      var mapper = InitializeMapper();
      partRepo.Setup(repo => repo.GetPartByIdAsync(id))
       .ReturnsAsync(mockpartsService.GetPart());
      blankInfoesRepo.Setup(repo => repo.GetBlankInfoByPartId(id))
    .ReturnsAsync(mockpartsService.GetBlankInfo());
      blankInfoservice.Setup(repo => repo.GetBlankInfoRunOrder(blankinfo))
  .ReturnsAsync(mockpartsService.GetIncompleteRunOrderList());
      var service = new PartsService(partRepo.Object, partModelsRepo.Object, blankInfoesRepo.Object, modelRepo.Object,  blankInfoservice.Object);
      Assert.ThrowsAsync<CoilTrackingException>(() => service.GetPartProdPlanAssociation(id));
    }
  }
}
