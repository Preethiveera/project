using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using Moq;
using System;
using System.Collections.Generic;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class RunResultftzTMMIManagerTest
  {
    private readonly Mock<IApplicationLogger<RunResultService>> runServiceLogger;

    private readonly Mock<ICoilRepository> coilRepo;

    public RunResultftzTMMIManagerTest()
    {
      runServiceLogger = new Mock<IApplicationLogger<RunResultService>>();
      coilRepo = new Mock<ICoilRepository>();
    }
    [Fact]
    public void GetRunResultCoilsByPrefixFtz_ReturnFTZ()
    {
      string sPrefixFtz = 'S' + "34353";
      string tPrefixFtz = 'T' + "564343";
      var mockCoilsservice = new MockCoilsservice();
      coilRepo.Setup(repo => repo.GetRunResultCoilsByPrefixFtz(sPrefixFtz, tPrefixFtz))
      .ReturnsAsync(mockCoilsservice.GetCoils());
      var _service = new RunResultftzTMMIManager(coilRepo.Object,runServiceLogger.Object);
      var rr = _service.GetRunResultCoilFTZByPrefix(sPrefixFtz);
      Assert.NotNull(rr);
    }
  }
}
