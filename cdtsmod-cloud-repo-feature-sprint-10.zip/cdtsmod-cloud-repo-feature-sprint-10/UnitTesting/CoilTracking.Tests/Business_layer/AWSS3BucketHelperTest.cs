using Amazon.S3;
using CoilTracking.Business.Implementation;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Moq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class AWSS3BucketHelperTest
  {
    private readonly Mock<IAmazonS3> amazonS3;
    private readonly Mock<IConfiguration> settings;
    private readonly Mock<IApplicationLogger<AWSS3BucketHelper>> logger;
    public AWSS3BucketHelperTest()
    {
      this.amazonS3 = new Mock<IAmazonS3>();
      this.settings = new Mock<IConfiguration>();
      this.logger = new Mock<IApplicationLogger<AWSS3BucketHelper>>();
    }
    [Fact]
    public void GetFiles()
    {
      string dataNum = "1";

      var _service = new AWSS3BucketHelper(amazonS3.Object, logger.Object, settings.Object);

      var result = _service.GetFile(dataNum);

      Assert.NotNull(result);
    }
    [Fact]
    public void UploadFiles()
    {
      string dataNum = "1";
      Stream val = null;
      var _service = new AWSS3BucketHelper(amazonS3.Object, logger.Object, settings.Object);

      var result = _service.UploadFile(val, dataNum);

      Assert.NotNull(result);
    }

  }
}
