using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Business.Interfaces;
using CoilTracking.Business.Interfaces.Lines;
using CoilTracking.Common.Logging;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using Moq;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class LineServiceTest
  {
    private readonly Mock<ILineRepository> lineRepo;
    private readonly Mock<IApplicationLogger<LineService>> lineServiceLogger;
    private readonly Mock<IOPCClientServiceManager> OPCClientService;
    private readonly Mock<IOPCConfigRepository> oPCConfigRepo;
    private readonly Mock<IPlantsRepository> plantRepo;
    private readonly Mock<ILineDataManager> lineDataManager;
    private readonly Mock<IPatternsRepository> mockPatternsRepo;
    private readonly Mock<IPatternCalendarRepository> mockPatternCalenderRepository;
    private readonly Mock<IUserHelper> usersHelper;

    public LineServiceTest()
    {
      lineRepo = new Mock<ILineRepository>();
      lineServiceLogger = new Mock<IApplicationLogger<LineService>>();
      OPCClientService = new Mock<IOPCClientServiceManager>();
      oPCConfigRepo = new Mock<IOPCConfigRepository>();
      plantRepo = new Mock<IPlantsRepository>();
      lineDataManager = new Mock<ILineDataManager>();
      mockPatternsRepo = new Mock<IPatternsRepository>();
      mockPatternCalenderRepository = new Mock<IPatternCalendarRepository>();
      usersHelper = new Mock<IUserHelper>();
    }

    public IMapper InitializeMapper()
    {
      var mockMapper = new MapperConfiguration(cfg =>
      {
        cfg.AddProfile(new MappingProfile());
      });
      var mapper = mockMapper.CreateMapper();

      return mapper;
    }

    [Fact]
    public void GetLines_AndonLines_ReturnLines()
    {
      var mapper = InitializeMapper();
      var _service = new LineService(lineRepo.Object, lineServiceLogger.Object, mapper, OPCClientService.Object, oPCConfigRepo.Object, plantRepo.Object, lineDataManager.Object, mockPatternsRepo.Object, mockPatternCalenderRepository.Object, usersHelper.Object);
      var andonline = _service.GetLinesForAndons();

      Assert.NotNull(andonline);
    }

    [Fact]
    public void GetLines_ReturnLines()
    {
      var mapper = InitializeMapper();
      var service = new LineService(lineRepo.Object, lineServiceLogger.Object, mapper, OPCClientService.Object, oPCConfigRepo.Object, plantRepo.Object, lineDataManager.Object, mockPatternsRepo.Object, mockPatternCalenderRepository.Object, usersHelper.Object);
      var lines = service.GetLines();

      Assert.NotNull(lines);
    }

    [Fact]
    public void GetLine_ReturnLine()
    {
      var mapper = InitializeMapper();
      var service = new LineService(lineRepo.Object, lineServiceLogger.Object, mapper, OPCClientService.Object, oPCConfigRepo.Object, plantRepo.Object, lineDataManager.Object, mockPatternsRepo.Object, mockPatternCalenderRepository.Object, usersHelper.Object);
      var lines = service.GetLineById(1);

      Assert.NotNull(lines);
    }

    [Fact]
    public void GetLineForEdit_ReturnLine()
    {
      var mapper = InitializeMapper();
      var service = new LineService(lineRepo.Object, lineServiceLogger.Object, mapper, OPCClientService.Object, oPCConfigRepo.Object, plantRepo.Object, lineDataManager.Object, mockPatternsRepo.Object, mockPatternCalenderRepository.Object, usersHelper.Object);
      var lines = service.GetLineForEdit(1);

      Assert.NotNull(lines);
    }

    [Fact]
    public void UpdateLineSubscription_ReturnLine()
    {
      var mapper = InitializeMapper();
      var service = new LineService(lineRepo.Object, lineServiceLogger.Object, mapper, OPCClientService.Object, oPCConfigRepo.Object, plantRepo.Object, lineDataManager.Object, mockPatternsRepo.Object, mockPatternCalenderRepository.Object, usersHelper.Object);
      var lines = service.UpdateLineSubscription(1, true);

      Assert.NotNull(lines);
    }

    [Fact]
    public void GetSubscribedLines_ReturnLine()
    {
      var mapper = InitializeMapper();
      var service = new LineService(lineRepo.Object, lineServiceLogger.Object, mapper, OPCClientService.Object, oPCConfigRepo.Object, plantRepo.Object, lineDataManager.Object, mockPatternsRepo.Object, mockPatternCalenderRepository.Object, usersHelper.Object);
      var lines = service.GetSubscribedLines("02");

      Assert.NotNull(lines);
    }

    [Fact]
    public void DisableLine_ReturnLine()
    {
      var mapper = InitializeMapper();
      var service = new LineService(lineRepo.Object, lineServiceLogger.Object, mapper, OPCClientService.Object, oPCConfigRepo.Object, plantRepo.Object, lineDataManager.Object, mockPatternsRepo.Object, mockPatternCalenderRepository.Object, usersHelper.Object);
      var lines = service.DisableLine(1, true);

      Assert.NotNull(lines);
    }

    [Fact]
    public void PutLine_ReturnBool()
    {
      var line = new LineDto
      {
        Id = 1
      };
      var mapper = InitializeMapper();
      var service = new LineService(lineRepo.Object, lineServiceLogger.Object, mapper, OPCClientService.Object, oPCConfigRepo.Object, plantRepo.Object, lineDataManager.Object, mockPatternsRepo.Object, mockPatternCalenderRepository.Object, usersHelper.Object);
      var lines = service.PutLine(line);

      Assert.NotNull(lines);
    }

    [Fact]
    public void UpdateLine_ReturnsDto()
    {
      var line = new LineDto
      {
        Id = 1
      };
      var mapper = InitializeMapper();
      var service = new LineService(lineRepo.Object, lineServiceLogger.Object, mapper, OPCClientService.Object, oPCConfigRepo.Object, plantRepo.Object, lineDataManager.Object, mockPatternsRepo.Object, mockPatternCalenderRepository.Object, usersHelper.Object);
      var lines = service.UpdateLine(1, line);

      Assert.NotNull(lines);
    }

    [Fact]
    public void AddLine_ReturnsDto()
    {
      var line = new LineDto
      {
        Id = 1
      };
      var mapper = InitializeMapper();
      var service = new LineService(lineRepo.Object, lineServiceLogger.Object, mapper, OPCClientService.Object, oPCConfigRepo.Object, plantRepo.Object, lineDataManager.Object, mockPatternsRepo.Object, mockPatternCalenderRepository.Object, usersHelper.Object);
      var lines = service.AddLine(line);

      Assert.NotNull(lines);
    }

    [Fact]
    public void SaveLine_ReturnsDto()
    {
      var line = new LineDto
      {
        Id = 1
      };
      var mapper = InitializeMapper();
      var service = new LineService(lineRepo.Object, lineServiceLogger.Object, mapper, OPCClientService.Object, oPCConfigRepo.Object, plantRepo.Object, lineDataManager.Object, mockPatternsRepo.Object, mockPatternCalenderRepository.Object, usersHelper.Object);
      var lines = service.SaveLine(line);

      Assert.NotNull(lines);
    }

    [Fact]
    public void PostLineData_ReturnsDto()
    {
      var lineData = new LineDataDto
      {
        Id = 1
      };
      var mapper = InitializeMapper();
      var service = new LineService(lineRepo.Object, lineServiceLogger.Object, mapper, OPCClientService.Object, oPCConfigRepo.Object, plantRepo.Object, lineDataManager.Object, mockPatternsRepo.Object, mockPatternCalenderRepository.Object, usersHelper.Object);
      var lines = service.PostLineData(lineData);

      Assert.NotNull(lines);
    }

    [Fact]
    public void DeleteLine_ReturnsDto()
    {
      var mapper = InitializeMapper();
      var service = new LineService(lineRepo.Object, lineServiceLogger.Object, mapper, OPCClientService.Object, oPCConfigRepo.Object, plantRepo.Object, lineDataManager.Object, mockPatternsRepo.Object, mockPatternCalenderRepository.Object, usersHelper.Object);
      var lines = service.DeleteLine(1);

      Assert.NotNull(lines);
    }
  }
}
