using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using Moq;
using System;
using System.Collections.Generic;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class RunResultServiceTest
  {
    private readonly Mock<IRunResultsRepository> runResultsRepo;
    private readonly Mock<IApplicationLogger<RunResultService>> runServiceLogger;
    private readonly Mock<IBlankInfoesRepository> blankInfoesRepo;
    private readonly Mock<ICoilRepository> coilRepo;
    private readonly Mock<IRunOrderRepository> runOrderRepo;
    private readonly Mock<IMapper> mapper;
    private readonly Mock<ICoilRunHistoryRepository> coilRunHistoryRepo;
    private readonly Mock<IPlantsRepository> plantsRepo;
    private readonly Mock<IRunResultFactory> runResultFactory;
    private readonly Mock<ICoilStatusRepository> coilstatusRepo;
    private readonly Mock<IWebSocketClientService> webSocketClientService;

    public RunResultServiceTest()
    {
      runResultsRepo = new Mock<IRunResultsRepository>();
      runServiceLogger = new Mock<IApplicationLogger<RunResultService>>();
      blankInfoesRepo = new Mock<IBlankInfoesRepository>();
      coilRepo = new Mock<ICoilRepository>();
      runOrderRepo = new Mock<IRunOrderRepository>();
      mapper = new Mock<IMapper>();
      coilRunHistoryRepo = new Mock<ICoilRunHistoryRepository>();
      plantsRepo = new Mock<IPlantsRepository>();
      runResultFactory = new Mock<IRunResultFactory>();
      coilstatusRepo = new Mock<ICoilStatusRepository>();
      webSocketClientService = new Mock<IWebSocketClientService>();
    }

    public IMapper InitializeMapper()
    {
      var mockMapper = new MapperConfiguration(cfg =>
      {
        cfg.AddProfile(new MappingProfile());
      });
      var mapper = mockMapper.CreateMapper();

      return mapper;
    }


    [Fact]
    public void GetLatestRunResult_Latest_ReturnsRecentRunFinishedRecord()
    {
      var _mockLineService = new MockRunService();
      var mapper = InitializeMapper();
      runResultsRepo.Setup(repo => repo.GetRunResults())
      .ReturnsAsync(_mockLineService.GetRunResults());
      var _service = new RunResultService(runServiceLogger.Object, runResultsRepo.Object, blankInfoesRepo.Object, coilRepo.Object, runOrderRepo.Object, mapper, coilRunHistoryRepo.Object, plantsRepo.Object, runResultFactory.Object,coilstatusRepo.Object, webSocketClientService.Object);
      var rr = _service.GetLatestRunResult();
      Assert.NotNull(rr);
    }


    [Fact]
    public void GetRunResultsSearch_RunResults_ReturnsRunResults()
    {
      var runResults = new List<RunResult>
            {
                new RunResult()
                {
                    Id = 1,
                    AdcDt = 4,
                    BlankCoilTypeName = "we",
                    BlankDieNo = decimal.One,
                    BlankPitch = decimal.One,
                    BlanksProduced = 4,
                    BlanksRequested = 3,
                    BlankStackSize = decimal.One,
                    BlankWeight = decimal.One,
                    BlankWidth = decimal.One,
                    CoilWeightBefore = decimal.One,
                    KanbanDt = 8,
                    MaintDt = 9,
                    MeasuredPitch = 8,
                    MeasuredThickness = decimal.One,
                    MeasuredWidth = 8,
                    PressCount = 6,
                    ProdDt = 5,
                    RunStarted = DateTime.Now,
                    SchdDt = 9,
                    ToolDieDt = 9,
                    TryoutDt = 8,
                    WeightUsed = decimal.One,
                    Coil = new Coil()
                    {
                        Id = 7,
                        OrderNo = 6,
                        IsPriority = true,
                        CheckInDate = DateTime.Now,
                        SerialNum = "test",
                        YNA = "c",
                        FTZ = "te",
                        OriginalWeight = 1,
                        ReturnedToField = DateTime.Now,
                        UnAccountedWeight = 9,

                        CoilType = new CoilType() { Id = 7, Name = "test", NumCoils = 9 },
                        CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 1, Disabled = true, IsEmpty = true, Row = 1 }
                    },
                    DownTime = 5,
                    DataNumber = 9,
                    RunFinished = DateTime.Now,
                    Comments = "test",
                    ModifiedBy = "A",
                    PartNumber = "3",
                    RunOrderList = new RunOrderList() { Id = 8, Shift = new Shift() { Name = "qq" }, Date = DateTime.Now, PatternLetter = "00", Line = new Line() { Id = 7, Disabled = true, LineName = "", LinePath = "", OPCServer_Id = 88, Plant_Id = 8, Subscribed = true, Tags = "tags", Plant = new Plant() { Id = 5, PlantName = "NAMC", TimeZone = new PlantTimeZone() { Id = 9, Name = "test", TimeZoneOffset = 0 } } } }
                }
            };
      DateTime? startTime = null; DateTime? endTime = null; string partNum = null; int? dataNum = null; string coilType = null; int? lineId = null; int? shiftId = null; string ftz = null;
      var _mockLineService = new MockRunService();
      runResultsRepo.Setup(repo => repo.GetRunResultsSearch(startTime, endTime, partNum, dataNum, coilType, lineId, shiftId, ftz))
      .Returns(runResults);
      var _service = new RunResultService(runServiceLogger.Object, runResultsRepo.Object, blankInfoesRepo.Object, coilRepo.Object, runOrderRepo.Object, mapper.Object, coilRunHistoryRepo.Object, plantsRepo.Object, runResultFactory.Object,coilstatusRepo.Object, webSocketClientService.Object);
      var rr = _service.GetRunResultsSearch(startTime, endTime, partNum, dataNum, coilType, lineId, shiftId, ftz);
      Assert.NotNull(rr);
    }

    [Fact]
    public void GetRunResultsSearch_RunResults_ThrowsException()
    {

      List<RunResult> runResults = null;
      DateTime? startTime = null; DateTime? endTime = null; string partNum = null; int? dataNum = null; string coilType = null; int? lineId = null; int? shiftId = null; string ftz = null;
      var _mockLineService = new MockRunService();
      runResultsRepo.Setup(repo => repo.GetRunResultsSearch(startTime, endTime, partNum, dataNum, coilType, lineId, shiftId, ftz))
      .Returns(runResults);
      var _service = new RunResultService(runServiceLogger.Object, runResultsRepo.Object, blankInfoesRepo.Object, coilRepo.Object, runOrderRepo.Object, mapper.Object, coilRunHistoryRepo.Object, plantsRepo.Object, runResultFactory.Object,coilstatusRepo.Object, webSocketClientService.Object);
      Assert.Throws<CoilTrackingException>(() => _service.GetRunResultsSearch(startTime, endTime, partNum, dataNum, coilType, lineId, shiftId, ftz));
    }
    [Fact]
    public void GetScrapResults_RunResults_ReturnsScrapResults()
    {
      var runResults = new List<RunResult>
            {
                new RunResult()
                {
                    Id = 1,
                    AdcDt = 4,
                    BlankCoilTypeName = "we",
                    BlankDieNo = decimal.One,
                    BlankPitch = decimal.One,
                    BlanksProduced = 4,
                    BlanksRequested = 3,
                    BlankStackSize = decimal.One,
                    BlankWeight = decimal.One,
                    BlankWidth = decimal.One,
                    CoilWeightBefore = decimal.One,
                    KanbanDt = 8,
                    MaintDt = 9,
                    MeasuredPitch = 8,
                    MeasuredThickness = decimal.One,
                    MeasuredWidth = 8,
                    PressCount = 6,
                    ProdDt = 5,
                    RunStarted = DateTime.Now,
                    SchdDt = 9,
                    ToolDieDt = 9,
                    TryoutDt = 8,
                    WeightUsed = decimal.One,
                    Coil = new Coil()
                    {
                        Id = 7,
                        OrderNo = 6,
                        IsPriority = true,
                        CheckInDate = DateTime.Now,
                        SerialNum = "test",
                        YNA = "c",
                        FTZ = "te",
                        OriginalWeight = 1,
                        ReturnedToField = DateTime.Now,
                        UnAccountedWeight = 9,

                        CoilType = new CoilType() { Id = 7, Name = "test", NumCoils = 9 },
                        CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 1, Disabled = true, IsEmpty = true, Row = 1 }
                    },
                    DownTime = 5,
                    DataNumber = 9,
                    RunFinished = DateTime.Now,
                    Comments = "test",
                    ModifiedBy = "A",
                    PartNumber = "3",
                    RunOrderList = new RunOrderList() { Id = 8, Shift = new Shift() { Name = "qq" }, Date = DateTime.Now, PatternLetter = "00", Line = new Line() { Id = 7, Disabled = true, LineName = "", LinePath = "", OPCServer_Id = 88, Plant_Id = 8, Subscribed = true, Tags = "tags", Plant = new Plant() { Id = 5, PlantName = "NAMC", TimeZone = new PlantTimeZone() { Id = 9, Name = "test", TimeZoneOffset = 0 } } } }
                }
            };
      DateTime? startTime = null; DateTime? endTime = null; string partNum = null; int? dataNum = null; string coilType = null; int? lineId = null; int? shiftId = null; string ftz = null;
      var _mockLineService = new MockRunService();
      runResultsRepo.Setup(repo => repo.GetRunResultsSearch(startTime, endTime, partNum, dataNum, coilType, lineId, shiftId, ftz))
      .Returns(runResults);
      var _service = new RunResultService(runServiceLogger.Object, runResultsRepo.Object, blankInfoesRepo.Object, coilRepo.Object, runOrderRepo.Object, mapper.Object, coilRunHistoryRepo.Object, plantsRepo.Object, runResultFactory.Object,coilstatusRepo.Object, webSocketClientService.Object);
      var rr = _service.GetScrapResults(startTime, endTime, partNum, dataNum, coilType, lineId, shiftId, ftz);
      Assert.NotNull(rr);
    }

    [Fact]
    public void GetRunResults_RunResults_ReturnsRunResults()
    {
      var _mockLineService = new MockRunService();
      var mapper = InitializeMapper();
      runResultsRepo.Setup(repo => repo.GetRunResults())
      .ReturnsAsync(_mockLineService.GetRunResults());
      var _service = new RunResultService(runServiceLogger.Object, runResultsRepo.Object, blankInfoesRepo.Object, coilRepo.Object, runOrderRepo.Object, mapper, coilRunHistoryRepo.Object,plantsRepo.Object,runResultFactory.Object,coilstatusRepo.Object, webSocketClientService.Object);
      var rr = _service.GetRunResults();
      Assert.NotNull(rr);
    }

    [Fact]
    public void GetCurrentStackSize_RunResults_ReturnsRunResultsById()
    {
      int num = 103;
      var blankInfo =
    new BlankInfoDto()
    {
      Id = 1,
      LineId = 1,
      MaxPitch = 12,
      MaxWidth = 22,
      MinPitch = 11,
      PartId = 1,
      Pitch = 12,
      StackSize = 345,
      Weight = 1234,
      Width = 123,
      Disabled = false,
      DieNo = 2,
      DataNumber = 1,
      CoilTypeId = 2,
      RewindWeight = 10,

    };
      var _mockLineService = new MockRunService();
      var mapper = InitializeMapper();
      var rr = blankInfoesRepo.Setup(repo => repo.GetCurrentStackSize(num))
       .Returns(_mockLineService.GetCurrentStackSizes());
      var _service = new RunResultService(runServiceLogger.Object, runResultsRepo.Object, blankInfoesRepo.Object, coilRepo.Object, runOrderRepo.Object, mapper, coilRunHistoryRepo.Object, plantsRepo.Object, runResultFactory.Object,coilstatusRepo.Object, webSocketClientService.Object);
      var datanum = _service.GetCurrentStackSize(num);
      Assert.NotNull(datanum);
    }

    [Fact]
    public void GetRunResultById_RunResults_ReturnsRunResultsById()
    {
      int num = 1;
      var _mockLineService = new MockRunService();
      var mapper = InitializeMapper();
      var rr = runResultsRepo.Setup(repo => repo.GetRunResults())
       .ReturnsAsync(_mockLineService.GetRunResults());
      var _service = new RunResultService(runServiceLogger.Object, runResultsRepo.Object, blankInfoesRepo.Object, coilRepo.Object, runOrderRepo.Object, mapper, coilRunHistoryRepo.Object, plantsRepo.Object, runResultFactory.Object,coilstatusRepo.Object, webSocketClientService.Object);
      var datanum = _service.GetRunResultById(num);
      Assert.NotNull(datanum);
    }

    [Fact]
    public void GetRunResultForEditByID_RunResults_ReturnsRunResultsById()
    {

      int num = 1;
      var _mockLineService = new MockRunService();
      var rr = runResultsRepo.Setup(repo => repo.GetRunResults())
       .ReturnsAsync(_mockLineService.GetRunResults());
      var _service = new RunResultService(runServiceLogger.Object, runResultsRepo.Object, blankInfoesRepo.Object, coilRepo.Object, runOrderRepo.Object, mapper.Object, coilRunHistoryRepo.Object, plantsRepo.Object, runResultFactory.Object,coilstatusRepo.Object, webSocketClientService.Object);
      var datanum = _service.GetRunResultForEditByID(num);
      Assert.NotNull(datanum);
    }

    [Fact]
    public void GetRunResultForEditByID_RunResults_Returns_ThrowsException()
    {

      int num = 0;
      var _mockLineService = new MockRunService();
      var rr = runResultsRepo.Setup(repo => repo.GetRunResults())
       .ReturnsAsync(_mockLineService.GetRunResults());
      var _service = new RunResultService(runServiceLogger.Object, runResultsRepo.Object, blankInfoesRepo.Object, coilRepo.Object, runOrderRepo.Object, mapper.Object, coilRunHistoryRepo.Object, plantsRepo.Object, runResultFactory.Object,coilstatusRepo.Object, webSocketClientService.Object);
      Assert.ThrowsAsync<CoilTrackingException>(() => _service.GetRunResultForEditByID(num));
    }

    [Fact]
    public void GetRunOrderRunResult_RunResults_ReturnsRunResultsById()
    {
      var runResults = new List<RunResult>
            {
                new RunResult()
                {
                    Id = 7,
                    AdcDt = 4,
                    BlankCoilTypeName = "we",
                    BlankDieNo = decimal.One,
                    BlankPitch = decimal.One,
                    BlanksProduced = 4,
                    BlanksRequested = 3,
                    BlankStackSize = decimal.One,
                    BlankWeight = decimal.One,
                    BlankWidth = decimal.One,
                    CoilWeightBefore = decimal.One,
                    KanbanDt = 8,
                    MaintDt = 9,
                    MeasuredPitch = 8,
                    MeasuredThickness = decimal.One,
                    MeasuredWidth = 8,
                    PressCount = 6,
                    ProdDt = 5,
                    RunStarted = DateTime.Now,
                    SchdDt = 9,
                    ToolDieDt = 9,
                    TryoutDt = 8,
                    WeightUsed = decimal.One,
                    Coil = new Coil()
                    {
                        Id = 7,
                        OrderNo = 6,
                        IsPriority = true,
                        CheckInDate = DateTime.Now,
                        SerialNum = "test",
                        YNA = "c",
                        FTZ = "te",
                        OriginalWeight = 1,
                        ReturnedToField = DateTime.Now,
                        UnAccountedWeight = 9, Mill = new Mill(){ Id=1, Name="A", Disabled=true },
                        CoilRunHistory = new List<CoilRunHistory> {  },  CoilStatus = new CoilStatus(){ Id=1, Name="A" },
                        CoilType = new CoilType() { Id = 7, Name = "test", NumCoils = 9 },
                        CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 1, Disabled = true, IsEmpty = true, Row = 1 }
                    },
                    DownTime = 5,
                    DataNumber = 9,
                    RunFinished = DateTime.Now,
                    Comments = "test",
                    ModifiedBy = "A",
                    PartNumber = "3",
                    RunOrderList = new RunOrderList() { Id = 8, Shift = new Shift() { Name = "qq" }, Date = DateTime.Now, PatternLetter = "00", Line = new Line() { Id = 7, Disabled = true, LineName = "", LinePath = "", OPCServer_Id = 88, Plant_Id = 8, Subscribed = true, Tags = "tags", Plant = new Plant() { Id = 5, PlantName = "NAMC", TimeZone = new PlantTimeZone() { Id = 9, Name = "test", TimeZoneOffset = 0 } } } }
                }
            };

      int num = 7;
      var mapper = InitializeMapper();
      var _mockLineService = new MockRunService();
      var rr = runResultsRepo.Setup(repo => repo.GetRunOrderRunResultById(num))
       .Returns(runResults);
      var _service = new RunResultService(runServiceLogger.Object, runResultsRepo.Object, blankInfoesRepo.Object, coilRepo.Object, runOrderRepo.Object, mapper, coilRunHistoryRepo.Object, plantsRepo.Object, runResultFactory.Object,coilstatusRepo.Object, webSocketClientService.Object);
      var datanum = _service.GetRunOrderRunResult(num);
      Assert.NotNull(datanum);
    }


    [Fact]
    public void GetRunOrderRunResult_RunResults_ReturnsThrowsException()
    {

      int num = 0;
      List<RunResult> runResults = null;
      var _mockLineService = new MockRunService();
      var rr = runResultsRepo.Setup(repo => repo.GetRunOrderRunResultById(num))
       .Returns(runResults);
      var _service = new RunResultService(runServiceLogger.Object, runResultsRepo.Object, blankInfoesRepo.Object, coilRepo.Object, runOrderRepo.Object, mapper.Object, coilRunHistoryRepo.Object, plantsRepo.Object, runResultFactory.Object,coilstatusRepo.Object, webSocketClientService.Object);
      Assert.Throws<CoilTrackingException>(() => _service.GetRunOrderRunResult(num));
    }

    [Fact]
    public void PopulateDto_SetRunResults_Returnsdto()
    {
      var runResults = new RunResult

      {
        Id = 1,

        AdcDt = 4,
        BlankCoilTypeName = "",
        BlankDieNo = decimal.One,
        BlankPitch = decimal.One,
        BlanksProduced = 4,
        BlanksRequested = 3,
        BlankStackSize = decimal.One,
        BlankWeight = decimal.One,
        BlankWidth = decimal.One,
        CoilWeightBefore = decimal.One,
        KanbanDt = 8,
        MaintDt = 9,
        MeasuredPitch = 8,
        MeasuredThickness = decimal.One,
        MeasuredWidth = 8,
        PressCount = 6,
        ProdDt = 5,
        RunStarted = DateTime.Now,
        SchdDt = 9,
        ToolDieDt = 9,
        TryoutDt = 8,
        WeightUsed = decimal.One,
        Coil = new Coil()
        {
          Id = 7,
          OrderNo = 6,
          IsPriority = true,
          CheckInDate = DateTime.Now,
          SerialNum = "test",
          YNA = "c",
          FTZ = "te",
          OriginalWeight = 1,
          ReturnedToField = DateTime.Now,
          UnAccountedWeight = 9,

          CoilType = new CoilType() { Id = 7, Name = "test", NumCoils = 9 },
          CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white" }
        },
        DownTime = 5,
        DataNumber = 9,
        RunFinished = DateTime.Now,
        Comments = "test",
        ModifiedBy = "A",
        PartNumber = "3",
        RunOrderList = new RunOrderList() { Id = 8, Date = DateTime.Now, Shift = new Shift { Name = "test", Id = 8, BackgroundColor = "", Disabled = true }, PatternLetter = "00", Line = new Line() { Id = 7, Disabled = true, LineName = "", LinePath = "", OPCServer_Id = 88, Plant_Id = 8, Subscribed = true, Tags = "tags", Plant = new Plant() { Id = 5, PlantName = "NAMC", TimeZone = new PlantTimeZone() { Id = 9, Name = "test", TimeZoneOffset = 0 }, } } }
      };
      var _service = new RunResultService(runServiceLogger.Object, runResultsRepo.Object, blankInfoesRepo.Object, coilRepo.Object, runOrderRepo.Object, mapper.Object, coilRunHistoryRepo.Object, plantsRepo.Object, runResultFactory.Object,coilstatusRepo.Object, webSocketClientService.Object);
      var dto = _service.PopulateDto(runResults);
      Assert.NotNull(dto);
    }

    [Fact]
    public void GetCoilsToBeWeighed_RunResults_ReturnsCoilsToBeWeighed()
    {
      var runResults = new List<RunResult>
            {
                new RunResult()
                {
                    Id = 1,
                    AdcDt = 4,
                    BlankCoilTypeName = "",
                    BlankDieNo = decimal.One,
                    BlankPitch = decimal.One,
                    BlanksProduced = 4,
                    BlanksRequested = 3,
                    BlankStackSize = decimal.One,
                    BlankWeight = decimal.One,
                    BlankWidth = decimal.One,
                    CoilWeightBefore = decimal.One,
                    KanbanDt = 8,
                    MaintDt = 9,
                    MeasuredPitch = 8,
                    MeasuredThickness = decimal.One,
                    MeasuredWidth = 8,
                    PressCount = 6,
                    ProdDt = 5,
                    RunStarted = DateTime.Now,
                    SchdDt = 9,
                    ToolDieDt = 9,
                    TryoutDt = 8,
                    WeightUsed = decimal.One,
                    Coil = new Coil()
                    {
                        Id = 4,
                        OrderNo = 6,
                        IsPriority = true,
                        CheckInDate = DateTime.Now,
                        SerialNum = "test",
                        YNA = "c",
                        FTZ = "te",
                        OriginalWeight = 1,
                        ReturnedToField = DateTime.Now,
                        UnAccountedWeight = 9,

                        CoilType = new CoilType() { Id = 7, Name = "test", NumCoils = 9 },

                        CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } } } } }
                    },
                    DownTime = 5,
                    DataNumber = 9,
                    RunFinished = DateTime.Now,
                    Comments = "test",
                    ModifiedBy = "A",
                    PartNumber = "3",
                    RunOrderList = new RunOrderList() { Id = 1, Date = DateTime.Now, PatternLetter = "00", Line = new Line() { Id = 7, Disabled = true, LineName = "", LinePath = "", OPCServer_Id = 88, Plant_Id = 8, Subscribed = true, Tags = "tags", Plant = new Plant() { Id = 5, PlantName = "NAMC", TimeZone = new PlantTimeZone() { Id = 9, Name = "test", TimeZoneOffset = 0 } } } }
                }
            };
      var _mockLineService = new MockRunService();
      var rr = runResultsRepo.Setup(repo => repo.GetCoilsToBeWeighed())
       .Returns((runResults));
      var coils = coilRepo.Setup(repo => repo.GetPartialsCoils())
      .Returns(_mockLineService.GetPartialsCoils());
      var _service = new RunResultService(runServiceLogger.Object, runResultsRepo.Object, blankInfoesRepo.Object, coilRepo.Object, runOrderRepo.Object, mapper.Object, coilRunHistoryRepo.Object, plantsRepo.Object, runResultFactory.Object,coilstatusRepo.Object, webSocketClientService.Object);
      var rrcoils = _service.GetRunCoilsToBeWeighed();
      Assert.NotNull(rrcoils);
    }

    [Fact]
    public void SetcoilsToBeWeighed_RunResults_ReturnsCoilsToBeWeighed()
    {
      Coil coil = new Coil()
      {

        Id = 1,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() } } }


      };
      CoilToBeWeighed CoilToBeWeighed = new CoilToBeWeighed()
      {
        RunResultId = 1,
        RunOrderListId = 1,
        CoilId = 1,
        FTZ = "a",
        CoilType = "a",
        YNA = "a",
        OriginalWeight = 1,
        Zone = "a",
        CoilLocation = "a",
        NewWeight = 1,
        AttachedToRunResult = true,
        CoilTypeName = "a",
        CoilStatusName = "a",
        CoilFieldLocationName = "a"

      };
      List<CoilToBeWeighed> CoilToBeWeigheds = new List<CoilToBeWeighed>();
      {
        CoilToBeWeigheds.Add(new CoilToBeWeighed()
        {
          RunResultId = 1,
          RunOrderListId = 1,
          CoilId = 1,
          FTZ = "a",
          CoilType = "a",
          YNA = "a",
          OriginalWeight = 1,
          Zone = "a",
          CoilLocation = "a",
          NewWeight = 1,
          AttachedToRunResult = true,
          CoilTypeName = "a",
          CoilStatusName = "a",
          CoilFieldLocationName = "a"
        });

      }
      var _service = new RunResultService(runServiceLogger.Object, runResultsRepo.Object, blankInfoesRepo.Object, coilRepo.Object, runOrderRepo.Object, mapper.Object, coilRunHistoryRepo.Object, plantsRepo.Object, runResultFactory.Object,coilstatusRepo.Object, webSocketClientService.Object);
      var rrcoils = _service.SetcoilsToBeWeighed(CoilToBeWeighed, coil, CoilToBeWeigheds);
      Assert.NotNull(rrcoils);
    }

    [Fact]
    public void GetCoilByFTZToBeWeighed_RunResults_ReturnsCoilsToBeWeighed()
    {
      var runResults = new List<RunResult>
            {
                new RunResult()
                {
                    Id = 1,
                    AdcDt = 4,
                    BlankCoilTypeName = "",
                    BlankDieNo = decimal.One,
                    BlankPitch = decimal.One,
                    BlanksProduced = 4,
                    BlanksRequested = 3,
                    BlankStackSize = decimal.One,
                    BlankWeight = decimal.One,
                    BlankWidth = decimal.One,
                    CoilWeightBefore = decimal.One,
                    KanbanDt = 8,
                    MaintDt = 9,
                    MeasuredPitch = 8,
                    MeasuredThickness = decimal.One,
                    MeasuredWidth = 8,
                    PressCount = 6,
                    ProdDt = 5,
                    RunStarted = DateTime.Now,
                    SchdDt = 9,
                    ToolDieDt = 9,
                    TryoutDt = 8,
                    WeightUsed = decimal.One,
                    Coil = new Coil()
                    {
                        Id = 4,
                        OrderNo = 6,
                        IsPriority = true,
                        CheckInDate = DateTime.Now,
                        SerialNum = "test",
                        YNA = "c",
                        FTZ = "te",
                        OriginalWeight = 1,
                        ReturnedToField = DateTime.Now,
                        UnAccountedWeight = 9,

                        CoilType = new CoilType() { Id = 7, Name = "test", NumCoils = 9 },

                        CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } } } } }
                    },
                    DownTime = 5,
                    DataNumber = 9,
                    RunFinished = DateTime.Now,
                    Comments = "test",
                    ModifiedBy = "A",
                    PartNumber = "3",
                    RunOrderList = new RunOrderList() { Id = 1, Date = DateTime.Now, PatternLetter = "00", Line = new Line() { Id = 7, Disabled = true, LineName = "", LinePath = "", OPCServer_Id = 88, Plant_Id = 8, Subscribed = true, Tags = "tags", Plant = new Plant() { Id = 5, PlantName = "NAMC", TimeZone = new PlantTimeZone() { Id = 9, Name = "test", TimeZoneOffset = 0 } } } }
                }
            };
      string ftz = "56";
      var _mockLineService = new MockRunService();
      var rr = runResultsRepo.Setup(repo => repo.GetCoilsToBeWeighed())
       .Returns((runResults));
      var coils = coilRepo.Setup(repo => repo.GetPartialsCoils())
      .Returns(_mockLineService.GetPartialsCoils());
      var _service = new RunResultService(runServiceLogger.Object, runResultsRepo.Object, blankInfoesRepo.Object, coilRepo.Object, runOrderRepo.Object, mapper.Object, coilRunHistoryRepo.Object, plantsRepo.Object, runResultFactory.Object,coilstatusRepo.Object, webSocketClientService.Object);
      var rrcoils = _service.GetCoilByFTZToBeWeighed(ftz);
      Assert.NotNull(rrcoils);
    }

    [Fact]
    public void UpdateCurrentWeight_Returns_Update()
    {
      int id = 1;
      CoilToBeWeighed CoilToBeWeighed = new CoilToBeWeighed()
      {
        RunResultId = 1,
        RunOrderListId = 1,
        CoilId = 1,
        FTZ = "a",
        CoilType = "a",
        YNA = "a",
        OriginalWeight = 1,
        Zone = "a",
        CoilLocation = "a",
        NewWeight = 1,
        AttachedToRunResult = true,
        CoilTypeName = "a",
        CoilStatusName = "a",
        CoilFieldLocationName = "a"

      };
      RunOrderList runOrders = new RunOrderList()
      {
        Id = 1,
        Date = DateTime.Now,
        Shift = new Shift() { Id = 1, BackgroundColor = "Black", Disabled = true, Finish = TimeSpan.Zero, Name = "V", Start = TimeSpan.Zero, TextColor = "A", },
        Line = new Line() { LineName = "", Id = 3, Plant_Id = 1, LinePath = "A" },
        Quantities = new List<RunOrderListQuantity>() { }
      };

      Coil Coil = new Coil()
      {
        Id = 1,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "56",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,
        CoilType = new CoilType() { Id = 1, Name = "test" },
        CoilStatus = new CoilStatus() { Name = "Partial Needs Weighed", Id = 1 },
        CoilRunHistory = new List<CoilRunHistory>() { },
        CoilFieldLocation = new CoilFieldLocation() { Id = 1, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 1, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } } } } }

      };
      CoilRunHistory coilRunHistory = new CoilRunHistory()
      {
        Coil = new Coil()
        {
          Id = 1,
          OrderNo = 6,
          IsPriority = true,
          CheckInDate = DateTime.Now,
          SerialNum = "test",
          YNA = "c",
          FTZ = "56",
          OriginalWeight = 1,
          ReturnedToField = DateTime.Now,
          UnAccountedWeight = 9,
          CoilType = new CoilType() { Id = 1, Name = "test" },
          CoilStatus = new CoilStatus() { Name = "Partial Needs Weighed", Id = 1 },
          CoilRunHistory = new List<CoilRunHistory>() { },
          CoilFieldLocation = new CoilFieldLocation() { Id = 1, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 1, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } } } } }

        },
        Id = 1,
        WeightUsed = 1,
        RunOrderList = new RunOrderList() { Id = 1, Date = DateTime.Now, Shift = new Shift() { Id = 1, BackgroundColor = "Black", Disabled = true, Finish = TimeSpan.Zero, Name = "V", Start = TimeSpan.Zero, TextColor = "A", }, Line = new Line() { LineName = "", Id = 3, Disabled = true, OPCServer_Id = 1, Plant = new Plant() { Id = 1, PlantName = "TMMK", TimeZone = new PlantTimeZone() { } }, Subscribed = true, Tags = "A", Plant_Id = 1, LinePath = "A" }, Quantities = new List<RunOrderListQuantity>() { } }
      };
      var runResults = new RunResult()
      {


        Id = 1,
        AdcDt = 4,
        BlankCoilTypeName = "",
        BlankDieNo = decimal.One,
        BlankPitch = decimal.One,
        BlanksProduced = 4,
        BlanksRequested = 3,
        BlankStackSize = decimal.One,
        BlankWeight = decimal.One,
        BlankWidth = decimal.One,
        CoilWeightBefore = decimal.One,
        KanbanDt = 8,
        MaintDt = 9,
        MeasuredPitch = 8,
        MeasuredThickness = decimal.One,
        MeasuredWidth = 8,
        PressCount = 6,
        ProdDt = 5,
        RunStarted = DateTime.Now,
        SchdDt = 9,
        ToolDieDt = 9,
        TryoutDt = 8,
        WeightUsed = decimal.One,
        Coil = new Coil()
        {
          Id = 4,
          OrderNo = 6,
          IsPriority = true,
          CheckInDate = DateTime.Now,
          SerialNum = "test",
          YNA = "c",
          FTZ = "te",
          OriginalWeight = 1,
          ReturnedToField = DateTime.Now,
          UnAccountedWeight = 9,

          CoilType = new CoilType() { Id = 7, Name = "test", NumCoils = 9 },

          CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } } } } }
        },
        DownTime = 5,
        DataNumber = 9,
        RunFinished = DateTime.Now,
        Comments = "test",
        ModifiedBy = "A",
        PartNumber = "3",
        RunOrderList = new RunOrderList() { Id = 1, Date = DateTime.Now, PatternLetter = "00", Line = new Line() { Id = 7, Disabled = true, LineName = "", LinePath = "", OPCServer_Id = 88, Plant_Id = 8, Subscribed = true, Tags = "tags", Plant = new Plant() { Id = 5, PlantName = "NAMC", TimeZone = new PlantTimeZone() { Id = 9, Name = "test", TimeZoneOffset = 0 } } } }
      };
      runResultsRepo.Setup(repo => repo.GetRunResultId(id))
      .Returns((runResults));
      runOrderRepo.Setup(repo => repo.GetRunOrderListId(id))
       .Returns((runOrders));
      coilRunHistoryRepo.Setup(repo => repo.SaveCoilRunHistories(coilRunHistory))
   .Returns(true);
      coilRepo.Setup(repo => repo.GetCoilsWithAllInfo(id))
   .Returns(Coil);
      var _service = new RunResultService(runServiceLogger.Object, runResultsRepo.Object, blankInfoesRepo.Object, coilRepo.Object, runOrderRepo.Object, mapper.Object, coilRunHistoryRepo.Object, plantsRepo.Object, runResultFactory.Object,coilstatusRepo.Object, webSocketClientService.Object);
       _service.UpdateCurrentWeight(CoilToBeWeighed);
      Assert.True(true);
    }
    [Fact]
    public void SaveReturnWeight_Returns_ReturnWeight()
    {
      List<int> ids = new List<int>() { 1 };
      List<Coil> coil = new List<Coil>
            {
                new Coil()
                {
                    Id = 1,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9,

                    CoilType = new CoilType() { Id = 7, Name = "test" },
                    CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() } } }

                }
            };
      List<CoilToBeWeighed> CoilToBeWeighed = new List<CoilToBeWeighed>();
      {
        CoilToBeWeighed.Add(new CoilToBeWeighed()
        {
          RunResultId = 1,
          RunOrderListId = 1,
          CoilId = 1,
          FTZ = "a",
          CoilType = "a",
          YNA = "a",
          OriginalWeight = 1,
          Zone = "a",
          CoilLocation = "a",
          NewWeight = 1,
          AttachedToRunResult = true,
          CoilTypeName = "a",
          CoilStatusName = "a",
          CoilFieldLocationName = "a"
        });

      }
      List<RunOrderList> runOrders = new List<RunOrderList>();
      {
        runOrders.Add(new RunOrderList() { Id = 1, Date = DateTime.Now, Shift = new Shift() { Id = 1, BackgroundColor = "Black", Disabled = true, Finish = TimeSpan.Zero, Name = "V", Start = TimeSpan.Zero, TextColor = "A", }, Line = new Line() { LineName = "", Id = 3, Plant_Id = 1, LinePath = "A" }, Quantities = new List<RunOrderListQuantity>() { } });
      }
      CoilRunHistory coilRunHistory = new CoilRunHistory() { Coil = new Coil() { Id = 1 }, Id = 1, WeightUsed = 1, RunOrderList = new RunOrderList() { Id = 1, Date = DateTime.Now, Shift = new Shift() { Id = 1, BackgroundColor = "Black", Disabled = true, Finish = TimeSpan.Zero, Name = "V", Start = TimeSpan.Zero, TextColor = "A", }, Line = new Line() { LineName = "", Id = 3, Plant_Id = 1, LinePath = "A" }, Quantities = new List<RunOrderListQuantity>() { } } };

      var runResults = new List<RunResult>
            {
                new RunResult()
                {
                    Id = 1,
                    AdcDt = 4,
                    BlankCoilTypeName = "",
                    BlankDieNo = decimal.One,
                    BlankPitch = decimal.One,
                    BlanksProduced = 4,
                    BlanksRequested = 3,
                    BlankStackSize = decimal.One,
                    BlankWeight = decimal.One,
                    BlankWidth = decimal.One,
                    CoilWeightBefore = decimal.One,
                    KanbanDt = 8,
                    MaintDt = 9,
                    MeasuredPitch = 8,
                    MeasuredThickness = decimal.One,
                    MeasuredWidth = 8,
                    PressCount = 6,
                    ProdDt = 5,
                    RunStarted = DateTime.Now,
                    SchdDt = 9,
                    ToolDieDt = 9,
                    TryoutDt = 8,
                    WeightUsed = decimal.One,
                    Coil = new Coil()
                    {
                        Id = 4,
                        OrderNo = 6,
                        IsPriority = true,
                        CheckInDate = DateTime.Now,
                        SerialNum = "test",
                        YNA = "c",
                        FTZ = "te",
                        OriginalWeight = 1,
                        ReturnedToField = DateTime.Now,
                        UnAccountedWeight = 9,

                        CoilType = new CoilType() { Id = 7, Name = "test", NumCoils = 9 },

                        CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } } } } }
                    },
                    DownTime = 5,
                    DataNumber = 9,
                    RunFinished = DateTime.Now,
                    Comments = "test",
                    ModifiedBy = "A",
                    PartNumber = "3",
                    RunOrderList = new RunOrderList() { Id = 1, Date = DateTime.Now, PatternLetter = "00", Line = new Line() { Id = 7, Disabled = true, LineName = "", LinePath = "", OPCServer_Id = 88, Plant_Id = 8, Subscribed = true, Tags = "tags", Plant = new Plant() { Id = 5, PlantName = "NAMC", TimeZone = new PlantTimeZone() { Id = 9, Name = "test", TimeZoneOffset = 0 } } } }
                }
            };
      var _mockLineService = new MockRunService();
      runResultsRepo.Setup(repo => repo.GetRunResultIds(ids))
      .Returns((runResults));
      runOrderRepo.Setup(repo => repo.GetRunOrderListByPartialIds(ids))
       .Returns((runOrders));
      coilRepo.Setup(repo => repo.GetCoilRunHistoryByIds(ids))
        .Returns(coil);
      coilRunHistoryRepo.Setup(repo => repo.SaveCoilRunHistories(coilRunHistory))
   .Returns(true);
      var _service = new RunResultService(runServiceLogger.Object, runResultsRepo.Object, blankInfoesRepo.Object, coilRepo.Object, runOrderRepo.Object, mapper.Object, coilRunHistoryRepo.Object, plantsRepo.Object, runResultFactory.Object,coilstatusRepo.Object, webSocketClientService.Object);
      var Save = _service.SaveReturnWeight(CoilToBeWeighed);
      Assert.True(Save);
    }
    [Fact]
    public void SaveRunResult_RunResult_ReturnsrunResultDtos()
    {
      int id = 1;
      RunOrderList runOrder = new RunOrderList() { Id = 1, Date = DateTime.Now, Shift = new Shift() { Id = 1, BackgroundColor = "Black", Disabled = true, Finish = TimeSpan.Zero, Name = "V", Start = TimeSpan.Zero, TextColor = "A", }, Line = new Line() { LineName = "", Id = 3, Plant_Id = 1, LinePath = "A" }, Quantities = new List<RunOrderListQuantity>() { } };
      var runResults = new List<RunResult>
            {
                new RunResult()
                {
                    Id = 1,
                    AdcDt = 4,
                    BlankCoilTypeName = "",
                    BlankDieNo = decimal.One,
                    BlankPitch = decimal.One,
                    BlanksProduced = 4,
                    BlanksRequested = 3,
                    BlankStackSize = decimal.One,
                    BlankWeight = decimal.One,
                    BlankWidth = decimal.One,
                    CoilWeightBefore = decimal.One,
                    KanbanDt = 8,
                    MaintDt = 9,
                    MeasuredPitch = 8,
                    MeasuredThickness = decimal.One,
                    MeasuredWidth = 8,
                    PressCount = 6,
                    ProdDt = 5,
                    RunStarted = DateTime.Now,
                    SchdDt = 9,
                    ToolDieDt = 9,
                    TryoutDt = 8,
                    WeightUsed = decimal.One,
                    Coil = new Coil()
                    {
                        Id = 4,
                        OrderNo = 6,
                        IsPriority = true,
                        CheckInDate = DateTime.Now,
                        SerialNum = "test",
                        YNA = "c",
                        FTZ = "te",
                        OriginalWeight = 1,
                        ReturnedToField = DateTime.Now,
                        UnAccountedWeight = 9,

                        CoilType = new CoilType() { Id = 7, Name = "test", NumCoils = 9 },

                        CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } } } } }
                    },
                    DownTime = 5,
                    DataNumber = 9,
                    RunFinished = DateTime.Now,
                    Comments = "test",
                    ModifiedBy = "A",
                    PartNumber = "3",
                    RunOrderList = new RunOrderList() { Id = 1, Date = DateTime.Now, PatternLetter = "00", Line = new Line() { Id = 7, Disabled = true, LineName = "", LinePath = "", OPCServer_Id = 88, Plant_Id = 8, Subscribed = true, Tags = "tags", Plant = new Plant() { Id = 5, PlantName = "NAMC", TimeZone = new PlantTimeZone() { Id = 9, Name = "test", TimeZoneOffset = 0 } } } }
                }
            };
      runOrderRepo.Setup(repo => repo.GetRunOrderListId(id))
      .Returns((runOrder));
      var runResultDto = new RunResultDto()

      {
        Id = 1,
        AdcDt = 4,
        DownTime = 5,
        DataNumber = 9,
        RunFinished = DateTime.Now,
        Comments = "test",
        ModifiedBy = "A",
        PartNumber = "3",
        Line = "A1",
        CoilCurrentWeight = decimal.Zero,
        BlankDieNo = decimal.One,
        CoilId = 9,
        CoilType = "",
        RunOrderListId = 1,
        Shift = "",
        BlankPitch = decimal.One,
        BlanksProduced = 8,
        WeightAfter = 9,
        WeightBefore = 88,
        ProdDt = 9,
        SchdDt = 99,
        FTZ = "test",
        BlanksRequested = 7,
        YNANumber = "",
        PressCount = 9,
        BlankStackSize = decimal.One,
        BlankWeight = decimal.One,
        BlankWidth = decimal.One,
        KanbanDt = 8,
        MaintDt = 9,
        MeasuredPitch = 8,
        MeasuredThickness = decimal.One,
        MeasuredWidth = 8,
        RunStarted = DateTime.Now,
        ToolDieDt = 9,
        TryoutDt = 8,
        WeightUsed = decimal.One,
      };
      var _service = new RunResultService(runServiceLogger.Object, runResultsRepo.Object, blankInfoesRepo.Object, coilRepo.Object, runOrderRepo.Object, mapper.Object, coilRunHistoryRepo.Object, plantsRepo.Object, runResultFactory.Object,coilstatusRepo.Object, webSocketClientService.Object);
      var runResultDtos = _service.InsertRunResult(runResultDto);
      Assert.NotNull(runResultDtos);

    }



    [Fact]
    public void UpdateRunResult_RunResult_ReturnsrunResult()
    {
      int id = 1;
      var runResultDto = new RunResultDto()

      {
        Id = 1,
        AdcDt = 4,
        DownTime = 5,
        DataNumber = 9,
        RunFinished = DateTime.Now,
        Comments = "test",
        ModifiedBy = "A",
        PartNumber = "3",
        Line = "A1",
        CoilCurrentWeight = decimal.Zero,
        BlankDieNo = decimal.One,
        CoilId = 9,
        CoilType = "",
        RunOrderListId = 1,
        Shift = "",
        BlankPitch = decimal.One,
        BlanksProduced = 8,
        WeightAfter = 9,
        WeightBefore = 88,
        ProdDt = 9,
        SchdDt = 99,
        FTZ = "test",
        BlanksRequested = 7,
        YNANumber = "",
        PressCount = 9,
        BlankStackSize = decimal.One,
        BlankWeight = decimal.One,
        BlankWidth = decimal.One,
        KanbanDt = 8,
        MaintDt = 9,
        MeasuredPitch = 8,
        MeasuredThickness = decimal.One,
        MeasuredWidth = 8,
        RunStarted = DateTime.Now,
        ToolDieDt = 9,
        TryoutDt = 8,
        WeightUsed = decimal.One,
      };
      var _mockLineService = new MockRunService();
      runResultsRepo.Setup(repo => repo.GetRunResultsById(id))
      .ReturnsAsync((_mockLineService.GetCoilRunOrderListRunResults()));
      var _service = new RunResultService(runServiceLogger.Object, runResultsRepo.Object, blankInfoesRepo.Object, coilRepo.Object, runOrderRepo.Object, mapper.Object, coilRunHistoryRepo.Object, plantsRepo.Object, runResultFactory.Object,coilstatusRepo.Object, webSocketClientService.Object);
      var runResults = _service.UpdateRunResult(id, runResultDto);
      Assert.NotNull(runResults);

    }
    [Fact]
    public void GetRunResultExists_Returns()
    {
      int id = 1;
      var _mockLineService = new MockRunService();
      runResultsRepo.Setup(repo => repo.IsRunResultExists(id))
      .Returns((true));
      var _service = new RunResultService(runServiceLogger.Object, runResultsRepo.Object, blankInfoesRepo.Object, coilRepo.Object, runOrderRepo.Object, mapper.Object, coilRunHistoryRepo.Object, plantsRepo.Object, runResultFactory.Object,coilstatusRepo.Object, webSocketClientService.Object);
      var runResult = _service.IsRunResultExists(id);
      Assert.True(runResult);
    }
    [Fact]
    public void DeleteRunResult_RunResult_ReturnsRunResults()
    {
      int id = 1;
      var _mockLineService = new MockRunService();
      runResultsRepo.Setup(repo => repo.GetRunResultId(id))
      .Returns((_mockLineService.GetRunResultById()));
      var _service = new RunResultService(runServiceLogger.Object, runResultsRepo.Object, blankInfoesRepo.Object, coilRepo.Object, runOrderRepo.Object, mapper.Object, coilRunHistoryRepo.Object, plantsRepo.Object, runResultFactory.Object,coilstatusRepo.Object, webSocketClientService.Object);
      var runResult = _service.DeleteRunResult(id);
      Assert.NotNull(runResult);
    }


    [Fact]
    public void RunResultModified_RunResult_ReturnsSavechanges()
    {

      var runResults = new RunResult

      {
        Id = 1,
        AdcDt = 4,
        BlankCoilTypeName = "",
        Coil = new Coil()
        {
          Id = 7,
          OrderNo = 6,
          IsPriority = true,
          CheckInDate = DateTime.Now,
          SerialNum = "test",
          YNA = "c",
          FTZ = "te",
          OriginalWeight = 1,
          ReturnedToField = DateTime.Now,
          UnAccountedWeight = 9,

          CoilType = new CoilType() { Id = 7, Name = "test", NumCoils = 9 },
          CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white" }
        },
        DownTime = 5,
        DataNumber = 9,
        RunFinished = DateTime.Now,
        Comments = "test",
        ModifiedBy = "A",
        PartNumber = "3",
        RunOrderList = new RunOrderList() { Id = 8, Date = DateTime.Now, PatternLetter = "00", Line = new Line() { Id = 7, Disabled = true, LineName = "", LinePath = "", OPCServer_Id = 88, Plant_Id = 8, Subscribed = true, Tags = "tags", Plant = new Plant() { Id = 5, PlantName = "NAMC", TimeZone = new PlantTimeZone() { Id = 9, Name = "test", TimeZoneOffset = 0 }, } } }
      };
      var _mockLineService = new MockRunService();
      runResultsRepo.Setup(repo => repo.ModifyRunResult(runResults))
      .Returns((true));
      var _service = new RunResultService(runServiceLogger.Object, runResultsRepo.Object, blankInfoesRepo.Object, coilRepo.Object, runOrderRepo.Object, mapper.Object, coilRunHistoryRepo.Object, plantsRepo.Object, runResultFactory.Object,coilstatusRepo.Object, webSocketClientService.Object);
      //var runResult = _service.in(runResults);
      Assert.False(false);
    }



  }
}
