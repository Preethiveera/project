using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class ModelServiceTest
  {
    private readonly Mock<IModelRepository> modelRepository;
    private readonly Mock<IIncompleteRunOrderItemRepository> incompleteRunOrderItemRepository;
    private readonly Mock<IPartModelsRepository> partModelsRepository;
    private readonly Mock<ILineRepository> lineRepository;
    private readonly Mock<IApplicationLogger<ModelService>> modelServiceLogger;

    public ModelServiceTest()
    {
      modelRepository = new Mock<IModelRepository>();
      incompleteRunOrderItemRepository = new Mock<IIncompleteRunOrderItemRepository>();
      partModelsRepository = new Mock<IPartModelsRepository>();
      lineRepository = new Mock<ILineRepository>();
      modelServiceLogger = new Mock<IApplicationLogger<ModelService>>();
    }

    public IMapper InitializeMapper()
    {
      var mockMapper = new MapperConfiguration(cfg =>
      {
        cfg.AddProfile(new MappingProfile());
      });
      var mapper = mockMapper.CreateMapper();

      return mapper;
    }

    [Fact]
    public async Task GetModelsTest()
    {
      var mapper = InitializeMapper();
      var _service = new ModelService(modelRepository.Object, partModelsRepository.Object, incompleteRunOrderItemRepository.Object,
        modelServiceLogger.Object, mapper);

      var mockModelService = new MockModelService();

      modelRepository.Setup(repo => repo.GetModels())
            .ReturnsAsync(mockModelService.GetModels());

      var models = await _service.GetModels();

      Assert.NotNull(models);
    }

    [Fact]
    public async Task GetModelTest()
    {
      var id = 1;
      var mapper = InitializeMapper();
      var _service = new ModelService(modelRepository.Object, partModelsRepository.Object, incompleteRunOrderItemRepository.Object,
        modelServiceLogger.Object, mapper);

      var mockModelService = new MockModelService();

      modelRepository.Setup(repo => repo.GetModelById(id))
            .ReturnsAsync(mockModelService.GetModelById());

      var patterns = await _service.GetModel(id);

      Assert.NotNull(patterns);
    }

    [Fact]
    public async Task CheckEditTest()
    {
      var id = 1;
      var modelDto = new ModelDto
      {
        Id = 1,
        Name = "HVT",
        ModelNumber = "FK"
      };
      var mapper = InitializeMapper();
      var _service = new ModelService(modelRepository.Object, partModelsRepository.Object, incompleteRunOrderItemRepository.Object,
        modelServiceLogger.Object, mapper);

      var mockModelService = new MockModelService();

      modelRepository.Setup(repo => repo.GetModelById(id))
            .ReturnsAsync(mockModelService.GetModelById());

      var result = await _service.CheckEdit(id, modelDto);

      Assert.True(result);
    }

    [Fact]
    public async Task GetPartsRelatedToModels()
    {
      var id = 1;

      var mapper = InitializeMapper();
      var _service = new ModelService(modelRepository.Object, partModelsRepository.Object, incompleteRunOrderItemRepository.Object,
        modelServiceLogger.Object, mapper);

      var mockModelService = new MockModelService();

      partModelsRepository.Setup(repo => repo.GetPartsRelatedToModels(id))
            .ReturnsAsync(mockModelService.GetParts());

      var result = await _service.GetPartsRelatedToModels(id);

      Assert.NotNull(result);
    }

    [Fact]
    public async Task GetPartsInRunOrderByModelId()
    {
      var partIds = new int[] { 1, 2, 3 };
      var id = 1;
      var mapper = InitializeMapper();
      var _service = new ModelService(modelRepository.Object, partModelsRepository.Object, incompleteRunOrderItemRepository.Object,
        modelServiceLogger.Object, mapper);

      var mockModelService = new MockModelService();

      incompleteRunOrderItemRepository.Setup(repo => repo.GetIncompleteRunOrderItemsByStatus(RunOrderItemStatus.New,
               RunOrderItemStatus.RunStarted, RunOrderItemStatus.Incomplete))
            .ReturnsAsync(mockModelService.GetParts());

      partModelsRepository.Setup(repo => repo.GetPartModelByPartIdsAndModelId(partIds, id))
        .ReturnsAsync(mockModelService.GetPartModelByPartIdsAndModelId());

      var result = await _service.GetPartsInRunOrderByModelId(id);

      Assert.NotNull(result);
    }

    [Fact]
    public async Task CheckDependency()
    {
      var partIds = new int[] { 1, 2, 3 };
      var id = 1;
      var mapper = InitializeMapper();
      var _service = new ModelService(modelRepository.Object, partModelsRepository.Object, incompleteRunOrderItemRepository.Object,
        modelServiceLogger.Object, mapper);

      var mockModelService = new MockModelService();

      partModelsRepository.Setup(repo => repo.GetPartModelByPartIdsAndModelId(partIds, id))
            .ReturnsAsync(mockModelService.GetPartModelByPartIdsAndModelId());

      incompleteRunOrderItemRepository.Setup(repo => repo.GetIncompleteRunOrderItemsByStatus(RunOrderItemStatus.New,
               RunOrderItemStatus.RunStarted, RunOrderItemStatus.Incomplete))
            .ReturnsAsync(mockModelService.GetParts());

      var result = await _service.CheckDependency(id);

      Assert.NotNull(result);
    }

    [Fact]
    public async Task PutModel()
    {
      var partIds = new int[] { 1, 2, 3 };
      var id = 1;
      var mapper = InitializeMapper();

      var modelDto = new ModelDto
      {
        Id = 1,
        Name = "HVT",
        ModelNumber = "FK"
      };

      var _service = new ModelService(modelRepository.Object, partModelsRepository.Object, incompleteRunOrderItemRepository.Object,
        modelServiceLogger.Object, mapper);

      var mockModelService = new MockModelService();

      modelRepository.Setup(repo => repo.GetModelById(id))
            .ReturnsAsync(mockModelService.GetModelById());

      partModelsRepository.Setup(repo => repo.GetPartModel(id))
      .ReturnsAsync(mockModelService.GetPartModel());

      partModelsRepository.Setup(repo => repo.UpdatePartModel(It.IsAny<PartModel>()))
        .Returns(true);

      modelRepository.Setup(repo => repo.UpdateModel(It.IsAny<Model>(), AuditActionType.ModifyEntity))
      .ReturnsAsync(true);

      var result = await _service.PutModel(modelDto);

      Assert.True(result);
    }

    [Fact]
    public async Task DisableModel()
    {
      var id = 1;
      var mapper = InitializeMapper();
      var _service = new ModelService(modelRepository.Object, partModelsRepository.Object, incompleteRunOrderItemRepository.Object,
        modelServiceLogger.Object, mapper);

      modelRepository.Setup(repo => repo.GetModelById(id))
            .ReturnsAsync(new Model { Id = 1});

      modelRepository.Setup(repo => repo.UpdateModel(It.IsAny<Model>(), AuditActionType.EnableDisable))
          .ReturnsAsync(true);

      var result = await _service.DisableModel(id, true);

      Assert.True(result);
    }

    [Fact]
    public async Task PostModel()
    {
      var modelDto = new ModelDto
      {
        Id = 1,
        Name = "HVT",
        ModelNumber = "FK"
      };

      var mapper = InitializeMapper();
      var _service = new ModelService(modelRepository.Object, partModelsRepository.Object, incompleteRunOrderItemRepository.Object,
        modelServiceLogger.Object, mapper);

      var mockModelService = new MockModelService();

      modelRepository.Setup(repo => repo.GetModelByModelNo(It.IsAny<string>()))
            .ReturnsAsync(new List<Model>());

      modelRepository.Setup(repo => repo.AddModel(It.IsAny<Model>()))
          .ReturnsAsync(true);

      var result = await _service.PostModel(modelDto);

      Assert.NotNull(result);
    }

    [Fact]
    public async Task DeleteModel()
    {
      var id = 1;

      var mapper = InitializeMapper();
      var _service = new ModelService(modelRepository.Object, partModelsRepository.Object, incompleteRunOrderItemRepository.Object,
        modelServiceLogger.Object, mapper);

      var mockModelService = new MockModelService();

      modelRepository.Setup(repo => repo.GetModelById(id))
            .ReturnsAsync(mockModelService.GetModelById());

      var result = await _service.DeleteModel(id);

      Assert.NotNull(result);
    }
  }
}
