using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using Moq;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class PatternServiceTest
  {
    private readonly Mock<IPatternsRepository> patternRepository;
    private readonly Mock<IBlankInfoesRepository> blankInfosRepository;
    private readonly Mock<IPatternItemRepository> patternItemRepository;
    private readonly Mock<ILineRepository> lineRepository;
    private readonly Mock<IApplicationLogger<PatternService>> patternServiceLogger;


    public PatternServiceTest()
    {
      patternRepository = new Mock<IPatternsRepository>();
      blankInfosRepository = new Mock<IBlankInfoesRepository>();
      patternItemRepository = new Mock<IPatternItemRepository>();
      lineRepository = new Mock<ILineRepository>();
      patternServiceLogger = new Mock<IApplicationLogger<PatternService>>();
    }

    public IMapper InitializeMapper()
    {
      var mockMapper = new MapperConfiguration(cfg =>
      {
        cfg.AddProfile(new MappingProfile());
      });
      var mapper = mockMapper.CreateMapper();

      return mapper;
    }


    [Fact]
    public void GetPatternsTest()
    {
      var mapper = InitializeMapper();
      var _service = new PatternService(patternRepository.Object, blankInfosRepository.Object, patternItemRepository.Object, lineRepository.Object, patternServiceLogger.Object, mapper);

      var _mockPatternLetterService = new MockPatternService();

      patternRepository.Setup(repo => repo.GetPatterns())
            .ReturnsAsync(_mockPatternLetterService.GetPatterns());

      var patterns = _service.GetPatterns();

      Assert.NotNull(patterns);
    }

    [Fact]
    public void GetPatternTest()
    {
      var id = 1;

      var mapper = InitializeMapper();
      var _service = new PatternService(patternRepository.Object, blankInfosRepository.Object, patternItemRepository.Object, lineRepository.Object, patternServiceLogger.Object, mapper);

      var _mockPatternLetterService = new MockPatternService();

      patternRepository.Setup(repo => repo.GetPatternById(id))
            .ReturnsAsync(_mockPatternLetterService.GetPattern());

      var patternLetters = _service.GetPattern(id);

      Assert.NotNull(patternLetters);
    }

    [Fact]
    public void GetPatternsForExportTest()
    {
      var month = 1;
      var year = 1;
      var mapper = InitializeMapper();
      var _service = new PatternService(patternRepository.Object, blankInfosRepository.Object, patternItemRepository.Object, lineRepository.Object, patternServiceLogger.Object, mapper);

      var _mockPatternLetterService = new MockPatternService();

      patternRepository.Setup(repo => repo.GetPatternByMonthAndYear(month, year))
            .ReturnsAsync(_mockPatternLetterService.GetPatterns());

      var patternLetters = _service.GetPatternsForExport();

      Assert.NotNull(patternLetters);
    }

    [Fact]
    public void GetPattern_LineId_PatternLetter_Year_Month_Test()
    {
      var patternLetter = "S";
      var lineId = 1;
      var month = 1;
      var year = 1;
      var mapper = InitializeMapper();
      var _service = new PatternService(patternRepository.Object, blankInfosRepository.Object, patternItemRepository.Object, lineRepository.Object, patternServiceLogger.Object, mapper);

      var _mockPatternService = new MockPatternService();

      patternRepository.Setup(repo => repo.GetPatternByLineId_PatternLetter_Year_Month(lineId, patternLetter, year, month))
            .ReturnsAsync(_mockPatternService.GetPattern());

      var pattern = _service.GetPattern(lineId, patternLetter, year, month);

      Assert.NotNull(pattern);
    }

    [Fact]
    public void PutPattern_PatternDto_Test()
    {

      PatternDto patternDto = new PatternDto
      {
        Id = 1,
        Name = "P"
      };

      var id = 1;

      var mapper = InitializeMapper();
      var _service = new PatternService(patternRepository.Object, blankInfosRepository.Object, patternItemRepository.Object, lineRepository.Object, patternServiceLogger.Object, mapper);

      var _mockPatternLetterService = new MockPatternService();

      patternRepository.Setup(repo => repo.GetPatternById(id))
      .ReturnsAsync(_mockPatternLetterService.GetPattern());

      patternRepository.Setup(repo => repo.UpdatePattern(It.IsAny<Pattern>()))
            .Returns(true);

      var pattern = _service.PutPattern(id, patternDto);

      Assert.NotNull(pattern);
    }

    [Fact]
    public void PostPattern_PatternDto_Test()
    {

      PatternDto patternDto = new PatternDto
      {
        Name = "P"
      };

      var mapper = InitializeMapper();
      var _service = new PatternService(patternRepository.Object, blankInfosRepository.Object, patternItemRepository.Object, lineRepository.Object, patternServiceLogger.Object, mapper);

      var _mockPatternService = new MockPatternService();
      
      patternRepository.Setup(repo => repo.AddPattern(It.IsAny<Pattern>()))
            .ReturnsAsync(_mockPatternService.GetPattern());

      var pattern = _service.PostPattern(patternDto);

      Assert.NotNull(pattern);
    }


    [Fact]
    public void DeletePattern_Id_Test()
    {
      var id = 1;

      var mapper = InitializeMapper();
      var _service = new PatternService(patternRepository.Object, blankInfosRepository.Object, patternItemRepository.Object, lineRepository.Object, patternServiceLogger.Object, mapper);

      var _mockPatternService = new MockPatternService();

      patternRepository.Setup(repo => repo.GetPatternById(id))
      .ReturnsAsync(_mockPatternService.GetPattern());

      patternRepository.Setup(repo => repo.RemovePattern(It.IsAny<Pattern>()))
            .ReturnsAsync(true);

      var pattern = _service.DeletePattern(id);

      Assert.NotNull(pattern);
    }

  }
}
