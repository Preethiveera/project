using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using Moq;
using System.Collections.Generic;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class CoilTypeServiceTest
  {
    private readonly Mock<IMaterialTypesRepository> materialTypesRepo;
    private readonly Mock<ICoilRepository> coilRepo;
    private readonly Mock<IApplicationLogger<CoilTypeService>> coilTypeServiceLogger;
    private readonly Mock<ICoilTypeRepository> coilTypeRepo;
    private readonly Mock<ICoilMoveRequestsRepository> coilMoveRequestsRepo;
    private readonly Mock<ICoilFieldZoneRepository> coilFieldZoneRepo;
    private readonly Mock<ICoilTypeYNARepository> coilTypeYNARepo;
    private readonly Mock<IWebSocketClientService> webSocketClientService;
    public CoilTypeServiceTest()
    {
      materialTypesRepo = new Mock<IMaterialTypesRepository>();
      coilRepo = new Mock<ICoilRepository>();
      coilTypeServiceLogger = new Mock<IApplicationLogger<CoilTypeService>>();
      coilTypeRepo = new Mock<ICoilTypeRepository>();
      coilMoveRequestsRepo = new Mock<ICoilMoveRequestsRepository>();
      coilFieldZoneRepo = new Mock<ICoilFieldZoneRepository>();
      coilTypeYNARepo = new Mock<ICoilTypeYNARepository>();
      webSocketClientService = new Mock<IWebSocketClientService>();
    }

    public IMapper InitializeMapper()
    {
      var mockMapper = new MapperConfiguration(cfg =>
      {
        cfg.AddProfile(new MappingProfile());
      });
      var mapper = mockMapper.CreateMapper();

      return mapper;
    }
    [Fact]
    public void GetCoilTypes_Returns_CoilType()
    {

      var mockCoilTypeService = new MockCoilTypeService();
      var mapper = InitializeMapper();
      coilTypeRepo.Setup(repo => repo.GetMaterialCoilTypes())
     .ReturnsAsync(mockCoilTypeService.GetMaterialCoilsTypes());
      var service = new CoilTypeService(coilTypeRepo.Object, materialTypesRepo.Object, coilRepo.Object, mapper, coilTypeServiceLogger.Object, coilMoveRequestsRepo.Object, coilFieldZoneRepo.Object, coilTypeYNARepo.Object, webSocketClientService.Object);

      var coilTypes = service.GetCoilTypes();
      Assert.NotNull(coilTypes);
    }
    [Fact]
    public void GetCoilsTypes_Returns_CoilType()
    {
      var mockCoilTypeService = new MockCoilTypeService();
      var mapper = InitializeMapper();
      coilTypeRepo.Setup(repo => repo.GetMaterialCoilTypes())
     .ReturnsAsync(mockCoilTypeService.GetMaterialCoilsTypes());
      var service = new CoilTypeService(coilTypeRepo.Object, materialTypesRepo.Object, coilRepo.Object, mapper, coilTypeServiceLogger.Object, coilMoveRequestsRepo.Object, coilFieldZoneRepo.Object, coilTypeYNARepo.Object, webSocketClientService.Object);

      var coilTypes = service.GetCoilsTypes();
      Assert.NotNull(coilTypes);
    }

    [Fact]
    public void GetCoilTypesById_Returns_CoilType()
    {
      int id = 5;
      var mockCoilTypeService = new MockCoilTypeService();
      var mapper = InitializeMapper();
      coilTypeRepo.Setup(repo => repo.GetMaterialCoilTypes())
     .ReturnsAsync(mockCoilTypeService.GetMaterialCoilsTypes());
      var service = new CoilTypeService(coilTypeRepo.Object, materialTypesRepo.Object, coilRepo.Object, mapper, coilTypeServiceLogger.Object, coilMoveRequestsRepo.Object, coilFieldZoneRepo.Object, coilTypeYNARepo.Object, webSocketClientService.Object);

      var coilTypes = service.GetCoilTypesById(id);
      Assert.NotNull(coilTypes);
    }

    [Fact]
    public void GetMaterialTypes_Returns_CoilType()
    {
      var mockCoilTypeService = new MockCoilTypeService();
      var mapper = InitializeMapper();
      materialTypesRepo.Setup(repo => repo.GetCoilsMaterialTypes())
     .ReturnsAsync(mockCoilTypeService.GetCoilsMaterialTypes());
      var service = new CoilTypeService(coilTypeRepo.Object, materialTypesRepo.Object, coilRepo.Object, mapper, coilTypeServiceLogger.Object, coilMoveRequestsRepo.Object, coilFieldZoneRepo.Object, coilTypeYNARepo.Object, webSocketClientService.Object);
      var materialType = service.GetMaterialTypes();
      Assert.NotNull(materialType);
    }

    [Fact]
    public void GetCoilsByCoilTypeId_Returns_CoilType()
    {
      int id = 4;
      var mockCoilTypeService = new MockCoilTypeService();
      var mapper = InitializeMapper();
      coilRepo.Setup(repo => repo.GetCoilsByCoilTypeId(id))
     .ReturnsAsync(mockCoilTypeService.GetCoilsByCoilTypeId());
      var service = new CoilTypeService(coilTypeRepo.Object, materialTypesRepo.Object, coilRepo.Object, mapper, coilTypeServiceLogger.Object, coilMoveRequestsRepo.Object, coilFieldZoneRepo.Object, coilTypeYNARepo.Object, webSocketClientService.Object);
      var coilTypes = service.GetCoilsByCoilTypeId(id);
      Assert.NotNull(coilTypes);
    }


    [Fact]
    public void CheckEdit_AddcoilTypeDto_Returns_CoilType()
    {
      int id = 1;
      CoilTypeDto coilTypeDto = new CoilTypeDto() { Id = 1, NAMC = "", Yield = decimal.Zero, Name = "T", Width = 1, Spec = "A", Thickness = decimal.One, MinWidth = decimal.One, NumCoils = 104, MinThickness = decimal.One, MaxWidth = decimal.One, MaterialTypeName = "A", MaxThickness = decimal.Zero, CoilFieldZone = new CoilFieldZoneDto() { Id = 1, Name = "A", Color = "S", Disabled = true, TextColor = "W", CoilFieldId = 1, Locations = new List<CoilFieldLocationDto>() { } } };
      var mockCoilTypeService = new MockCoilTypeService();
      var mapper = InitializeMapper();
      coilTypeRepo.Setup(repo => repo.GetCoilTypeById(id))
     .Returns(mockCoilTypeService.GetCoilsType());
      var service = new CoilTypeService(coilTypeRepo.Object, materialTypesRepo.Object, coilRepo.Object, mapper, coilTypeServiceLogger.Object, coilMoveRequestsRepo.Object, coilFieldZoneRepo.Object, coilTypeYNARepo.Object, webSocketClientService.Object);
      Assert.ThrowsAsync<CoilTrackingException>(() => service.CheckEdit(id, coilTypeDto));

    }

    [Fact]
    public void CheckEdit_ReturnsThrowsException()
    {
      int id = 1;
      CoilTypeDto coilTypeDto = new CoilTypeDto() { Id = 7, NAMC = "", Yield = decimal.Zero, Name = "T", Width = 1, Spec = "A", Thickness = decimal.One, MinWidth = decimal.One, NumCoils = 104, MinThickness = decimal.One, MaxWidth = decimal.One, MaterialTypeName = "A", MaxThickness = decimal.Zero, CoilFieldZone = new CoilFieldZoneDto() { Id = 1, Name = "A", Color = "S", Disabled = true, TextColor = "W", CoilFieldId = 1, Locations = new List<CoilFieldLocationDto>() { } } };
      var mockCoilTypeService = new MockCoilTypeService();
      var mapper = InitializeMapper();
      coilTypeRepo.Setup(repo => repo.GetCoilTypeById(id))
     .Returns(mockCoilTypeService.GetCoilsType());
      var service = new CoilTypeService(coilTypeRepo.Object, materialTypesRepo.Object, coilRepo.Object, mapper, coilTypeServiceLogger.Object, coilMoveRequestsRepo.Object, coilFieldZoneRepo.Object, coilTypeYNARepo.Object, webSocketClientService.Object);
     Assert.NotNull(service);
    }

    [Fact]
    public void GetCoilsLoadedForCoilType_Returns_CoilType()
    {
      int id = 5;
      var mockCoilTypeService = new MockCoilTypeService();
      var mapper = InitializeMapper();
      coilRepo.Setup(repo => repo.GetCoilsLoadedById(id))
     .ReturnsAsync(mockCoilTypeService.GetCoilsByCoilTypeId());
      var service = new CoilTypeService(coilTypeRepo.Object, materialTypesRepo.Object, coilRepo.Object, mapper, coilTypeServiceLogger.Object, coilMoveRequestsRepo.Object, coilFieldZoneRepo.Object, coilTypeYNARepo.Object, webSocketClientService.Object);

      var coilTypes = service.GetCoilsLoadedForCoilType(id);
      Assert.NotNull(coilTypes);
    }
    [Fact]
    public void CheckDependency_Returns_CoilType()
    {
      int id = 5;
      var mockCoilTypeService = new MockCoilTypeService();
      var mapper = InitializeMapper();
      coilMoveRequestsRepo.Setup(repo => repo.GetCoilMoveRequestById(id))
     .Returns(mockCoilTypeService.GetCoilMoverequest());
      coilRepo.Setup(repo => repo.GetCoilsLoadedById(id))
     .ReturnsAsync(mockCoilTypeService.GetCoilsByCoilTypeId());
      var service = new CoilTypeService(coilTypeRepo.Object, materialTypesRepo.Object, coilRepo.Object, mapper, coilTypeServiceLogger.Object, coilMoveRequestsRepo.Object, coilFieldZoneRepo.Object, coilTypeYNARepo.Object, webSocketClientService.Object);
      var coilTypes = service.CheckDependency(id);
      Assert.NotNull(coilTypes);
    }
    [Fact]
    public void DeleteCoilTypeById_Returns_CoilType()
    {
      int id = 0;
      var coilType = new CoilType

      {
        Id = 0,
        Name = "test",
        NumCoils = 9,
        CoilTypeYNAs = new List<CoilTypeYNA> { new CoilTypeYNA() { Id = 1, YNA = "YNA0011171", CoilType = new CoilType() { }, MaterialType = new MaterialType() { Name = "YAS" } } },
        CoilFieldZone = new CoilFieldZone()
        {
          Id = 1,
          CoilField = new CoilField() { Id = 1, Disabled = true, Name = "A", Zones = new List<CoilFieldZone>() { } }
        }
      };
      var mockCoilTypeService = new MockCoilTypeService();
      var mapper = InitializeMapper();
      coilTypeRepo.Setup(repo => repo.DeleteCoilType(coilType));
      coilTypeRepo.Setup(repo => repo.GetCoilTypeById(id))
     .Returns(mockCoilTypeService.GetCoilsType());
      var service = new CoilTypeService(coilTypeRepo.Object, materialTypesRepo.Object, coilRepo.Object, mapper, coilTypeServiceLogger.Object, coilMoveRequestsRepo.Object, coilFieldZoneRepo.Object, coilTypeYNARepo.Object, webSocketClientService.Object);
      Assert.ThrowsAsync<CoilTrackingException>(() => service.DeleteCoilTypeById(id));
    }
    [Fact]
    public void DisableCoilType_Returns_CoilType()
    {
      int id = 20;
      var mockCoilTypeService = new MockCoilTypeService();
      var mapper = InitializeMapper();
      coilTypeRepo.Setup(repo => repo.GetCoilTypeById(id))
     .Returns(mockCoilTypeService.GetCoilsType());
      var service = new CoilTypeService(coilTypeRepo.Object, materialTypesRepo.Object, coilRepo.Object, mapper, coilTypeServiceLogger.Object, coilMoveRequestsRepo.Object, coilFieldZoneRepo.Object, coilTypeYNARepo.Object, webSocketClientService.Object);

      var coilTypes = service.DisableCoilType(id, true);
      Assert.NotNull(coilTypes);
    }
    [Fact]
    public void InsertCoilType_Returns_CoilType()
    {
      var coilType = new CoilType
      {
        Id = 1,
        Name = "2424",
        NumCoils = 1,
        CoilFieldZone = new CoilFieldZone() { Id = 1, Name = "A", CoilField = new CoilField() { Id = 3, Name = "A" } },
        CoilTypeYNAs = new List<CoilTypeYNA>() { new CoilTypeYNA() { Id = 1, YNA = "A", CoilType = new CoilType() { Id = 1, CoilTypeYNAs = new List<CoilTypeYNA> { }, CoilFieldZone = new CoilFieldZone() { }, Name = "123", Disabled = true }, MaterialType = new MaterialType { Id = 1, Name = "AQ" }, Disabled = true } }
      };
      var CoilTypeYNAs = new List<CoilTypeYNA> { new CoilTypeYNA() { Id = 1, YNA = "YNA0011171", CoilType = new CoilType() { Id=1,  Name = "test",
        NumCoils = 9,  Disabled= true }, MaterialType = new MaterialType() { Name = "YAS" } } };
      CoilTypeDto coilTypeDto = new CoilTypeDto() { Id = 1, CoilTypeYNAs = new List<CoilTypeYNADto>() { new CoilTypeYNADto() { Id = 1, YNA = "A", MaterialType = new MaterialTypeDto { Id = 1, Name = "AQ" } } }, NAMC = "", Yield = decimal.Zero, Name = "T", Width = 1, Spec = "A", Thickness = decimal.One, MinWidth = decimal.One, NumCoils = 104, MinThickness = decimal.One, MaxWidth = decimal.One, MaterialTypeName = "A", MaxThickness = decimal.Zero, CoilFieldZone = new CoilFieldZoneDto() { Id = 1, Name = "A", Color = "S", Disabled = true, TextColor = "W", CoilFieldId = 1, Locations = new List<CoilFieldLocationDto>() { } } };
      var mockCoilTypeService = new MockCoilTypeService();
      var mapper = InitializeMapper();
      coilTypeRepo.Setup(repo => repo.IsCoilTypeByName(coilType.Name)).Returns(true);
      coilTypeRepo.Setup(repo => repo.InsertCoilType(coilType));
      coilFieldZoneRepo.Setup(repo => repo.GetCoilFieldZoneById(coilType.Id))
     .ReturnsAsync(mockCoilTypeService.GetCoilFeildZone());
      materialTypesRepo.Setup(repo => repo.GetMaterialTypesById(coilType.Id))
     .Returns(mockCoilTypeService.GetMaterialsTypes());

      coilTypeYNARepo.Setup(repo => repo.GetCoilTypeYNAsByYNA(CoilTypeYNAs))
    .Returns(CoilTypeYNAs);
      var service = new CoilTypeService(coilTypeRepo.Object, materialTypesRepo.Object, coilRepo.Object, mapper, coilTypeServiceLogger.Object, coilMoveRequestsRepo.Object, coilFieldZoneRepo.Object, coilTypeYNARepo.Object, webSocketClientService.Object);

      var coilTypes = service.InsertCoilType(coilTypeDto);
      Assert.NotNull(coilTypes);
    }

    [Fact]
    public void InsertCoilType_Returns_Throws()
    {
      var coilType = new CoilType
      {
        Id = 1,
        Name = "2424",
        NumCoils = 1,
        CoilFieldZone = new CoilFieldZone() { Id = 1, Name = "A", CoilField = new CoilField() { Id = 3, Name = "A" } },
        CoilTypeYNAs = new List<CoilTypeYNA>() { new CoilTypeYNA() { Id = 1, YNA = "A", CoilType = new CoilType() { Id = 1, CoilTypeYNAs = new List<CoilTypeYNA> { }, CoilFieldZone = new CoilFieldZone() { }, Name = "123", Disabled = true }, MaterialType = new MaterialType { Id = 1, Name = "AQ" }, Disabled = true } }
      };
      var CoilTypeYNAs = new List<CoilTypeYNA> { new CoilTypeYNA() { Id = 1, YNA = "YNA0011171", CoilType = new CoilType() { Id=1,  Name = "test",
        NumCoils = 9,  Disabled= true }, MaterialType = new MaterialType() { Name = "YAS" } } };
      CoilTypeDto coilTypeDto = new CoilTypeDto() { Id = 1, CoilTypeYNAs = new List<CoilTypeYNADto>() { new CoilTypeYNADto() { Id = 1, YNA = "A", MaterialType = new MaterialTypeDto { Id = 1, Name = "AQ" } } }, NAMC = "", Yield = decimal.Zero, Name = "T", Width = 1, Spec = "A", Thickness = decimal.One, MinWidth = decimal.One, NumCoils = 104, MinThickness = decimal.One, MaxWidth = decimal.One, MaterialTypeName = "A", MaxThickness = decimal.Zero, CoilFieldZone = new CoilFieldZoneDto() { Id = 1, Name = "A", Color = "S", Disabled = true, TextColor = "W", CoilFieldId = 1, Locations = new List<CoilFieldLocationDto>() { } } };
      var mockCoilTypeService = new MockCoilTypeService();
      var mapper = InitializeMapper();
      coilTypeRepo.Setup(repo => repo.IsCoilTypeByName(coilType.Name)).Returns(true);
      coilTypeRepo.Setup(repo => repo.InsertCoilType(coilType));
      coilFieldZoneRepo.Setup(repo => repo.GetCoilFieldZoneById(coilType.Id))
     .ReturnsAsync(mockCoilTypeService.GetCoilFeildZone());
      materialTypesRepo.Setup(repo => repo.GetMaterialTypesById(coilType.Id))
     .Returns(mockCoilTypeService.GetMaterialsTypes());

      coilTypeYNARepo.Setup(repo => repo.GetCoilTypeYNAsByYNA(CoilTypeYNAs))
    .Returns(CoilTypeYNAs);
      var service = new CoilTypeService(coilTypeRepo.Object, materialTypesRepo.Object, coilRepo.Object, mapper, coilTypeServiceLogger.Object, coilMoveRequestsRepo.Object, coilFieldZoneRepo.Object, coilTypeYNARepo.Object, webSocketClientService.Object);
      Assert.ThrowsAsync<CoilTrackingException>(() => service.InsertCoilType(coilTypeDto));
    }
    [Fact]
    public void UpdateCoilType_Returns_CoilType()
    {
      int id = 1;
      CoilTypeDto coilTypeDto = new CoilTypeDto() { Id = 1, CoilTypeYNAs = new List<CoilTypeYNADto>() { new CoilTypeYNADto() { Id = 1, YNA = "A", MaterialType = new MaterialTypeDto { Id = 1, Name = "AQ" } } }, NAMC = "", Yield = decimal.Zero, Name = "T", Width = 1, Spec = "A", Thickness = decimal.One, MinWidth = decimal.One, NumCoils = 104, MinThickness = decimal.One, MaxWidth = decimal.One, MaterialTypeName = "A", MaxThickness = decimal.Zero, CoilFieldZone = new CoilFieldZoneDto() { Id = 1, Name = "A", Color = "S", Disabled = true, TextColor = "W", CoilFieldId = 1, Locations = new List<CoilFieldLocationDto>() { } } };
      var mockCoilTypeService = new MockCoilTypeService();
      var mapper = InitializeMapper();
      coilTypeRepo.Setup(repo => repo.GetoriginalCoilTypeById(coilTypeDto))
     .Returns(mockCoilTypeService.GetCoilsType());
      coilFieldZoneRepo.Setup(repo => repo.GetCoilFieldZoneById(id))
   .ReturnsAsync(mockCoilTypeService.GetCoilFeildZone());
      materialTypesRepo.Setup(repo => repo.GetMaterialTypesById(id))
   .Returns(mockCoilTypeService.GetMaterialsTypes());
      var service = new CoilTypeService(coilTypeRepo.Object, materialTypesRepo.Object, coilRepo.Object, mapper, coilTypeServiceLogger.Object, coilMoveRequestsRepo.Object, coilFieldZoneRepo.Object, coilTypeYNARepo.Object, webSocketClientService.Object);

      var coiltype = service.UpdateCoilType(id, coilTypeDto);
      Assert.True(true);
    }
  }
}
