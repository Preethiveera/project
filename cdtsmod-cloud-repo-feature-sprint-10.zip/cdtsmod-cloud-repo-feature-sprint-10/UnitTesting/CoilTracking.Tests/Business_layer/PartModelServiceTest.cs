using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Common.Logging;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class PartModelServiceTest
  {
    private readonly Mock<IPartModelsRepository> mockPartModelsRepo;
    private readonly Mock<IApplicationLogger<PartModelService>> logger;

    public PartModelServiceTest()
    {
      mockPartModelsRepo = new Mock<IPartModelsRepository>();
      logger = new Mock<IApplicationLogger<PartModelService>>();
    }

    public IMapper InitializeMapper()
    {
      var mockMapper = new MapperConfiguration(cfg =>
      {
        cfg.AddProfile(new MappingProfile());
      });
      var mapper = mockMapper.CreateMapper();

      return mapper;
    }

    [Fact]
    public void GetPartModels_ReturnsDto()
    {
      var mapper = InitializeMapper();
      var service = new PartModelService(mockPartModelsRepo.Object, mapper, logger.Object);
      var response = service.GetPartModels();
      Assert.NotNull(response);
    }

    [Fact]
    public void GetPartModelById_ReturnsDto()
    {
      var mapper = InitializeMapper();
      var service = new PartModelService(mockPartModelsRepo.Object, mapper, logger.Object);
      var response = service.GetPartModelById(1);
      Assert.NotNull(response);
    }

    [Fact]
    public void PutPartModel()
    {
      var partModel = new PartModelDto
      {
        Id = 1
      };
      var mapper = InitializeMapper();
      var service = new PartModelService(mockPartModelsRepo.Object, mapper, logger.Object);
      var response = service.PutPartModel(1, partModel);
      Assert.NotNull(response);
    }

    [Fact]
    public void PostPartModel()
    {
      var partModel = new PartModelDto
      {
        Id = 1
      };
      var mapper = InitializeMapper();
      var service = new PartModelService(mockPartModelsRepo.Object, mapper, logger.Object);
      var response = service.AddPartModel(partModel);
      Assert.NotNull(response);
    }

    [Fact]
    public void DeletePartModel()
    {
      var mapper = InitializeMapper();
      var service = new PartModelService(mockPartModelsRepo.Object, mapper, logger.Object);
      var response = service.DeletePartModel(1);
      Assert.NotNull(response);
    }
  }
}
