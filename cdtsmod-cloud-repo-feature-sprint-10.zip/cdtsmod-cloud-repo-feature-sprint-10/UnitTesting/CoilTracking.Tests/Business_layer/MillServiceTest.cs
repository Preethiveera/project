using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using Moq;
using System;
using System.Collections.Generic;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class MillServiceTest
  {
    private readonly Mock<IMillsRepository> millsRepo;
    private readonly Mock<ICoilRepository> coilRepo;
    private readonly Mock<IApplicationLogger<MillService>> millsServiceLogger;

    public IMapper InitializeMapper()
    {
      var mockMapper = new MapperConfiguration(cfg =>
      {
        cfg.AddProfile(new MappingProfile());
      });
      var mapper = mockMapper.CreateMapper();

      return mapper;
    }

    public MillServiceTest()
    {
      millsRepo = new Mock<IMillsRepository>();
      millsServiceLogger = new Mock<IApplicationLogger<MillService>>();
      coilRepo = new Mock<ICoilRepository>();

    }

    [Fact]
    public void GetMills_ReturnsMills()
    {
      var mapper = InitializeMapper();
      var _service = new MillService(millsRepo.Object, coilRepo.Object, millsServiceLogger.Object, mapper);
      var _mockMillsService = new MockMillService();
      millsRepo.Setup(repo => repo.GetMills())
    .Returns(_mockMillsService.GetMillsList());

      var result = _service.GetMills();

      Assert.NotNull(result);
    }

    [Fact]
    public void GetMillsById_Id_ReturnsMills()
    {
      var mills = new Mill()
      {
        Id = 1,
        Name = "Mittal",
        Disabled = false
      };
      var mapper = InitializeMapper();
      var _service = new MillService(millsRepo.Object, coilRepo.Object, millsServiceLogger.Object, mapper);

      millsRepo.Setup(repo => repo.GetMillById(1))
    .Returns(mills);

      var result = _service.GetMillById(1);

      Assert.NotNull(result);
    }

    [Fact]
    public void GetAssociatedItemsMills_Id_ReturnsCoils()
    {
      var coils = new List<Coil>() {
        new Coil()
                {
                    Id = 4,
                    OrderNo = 6,
                    Mill= new Mill{ Id=1, Name="A",Disabled=false},
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "56",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9,
                    CoilType = new CoilType() { Id = 1, Name = "test" }, CoilStatus = new CoilStatus(){ Name = "Partial Needs Weighed", Id=1},
                    CoilFieldLocation = new CoilFieldLocation() { Id = 7,  Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones =  new List<CoilFieldZone>( ){ new CoilFieldZone() { Name="test", Id=9, Color="", Disabled=true } } } } }

                }
      };
      var mapper = InitializeMapper();
      var _service = new MillService(millsRepo.Object, coilRepo.Object, millsServiceLogger.Object, mapper);

      coilRepo.Setup(repo => repo.GetCoilsByMillId(1))
    .Returns(coils);

      _service.GetAssociatedItemsMills(1);

      Assert.NotNull(coils);
    }

    [Fact]
    public void GetLoadedcoilsById_Id_ReturnsCoils()
    {
      var coils = new List<Coil>() {
        new Coil()
                {
                    Id = 4,
                    OrderNo = 6,
                    Mill= new Mill{ Id=1, Name="A",Disabled=false},
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "56",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9,
                    CoilType = new CoilType() { Id = 1, Name = "test" }, CoilStatus = new CoilStatus(){ Name = "Partial Needs Weighed", Id=1},
                    CoilFieldLocation = new CoilFieldLocation() { Id = 7,  Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones =  new List<CoilFieldZone>( ){ new CoilFieldZone() { Name="test", Id=9, Color="", Disabled=true } } } } }

                }
      };
      var mapper = InitializeMapper();
      var _service = new MillService(millsRepo.Object, coilRepo.Object, millsServiceLogger.Object, mapper);

      coilRepo.Setup(repo => repo.GetLoadedCoilsById(1))
    .Returns(coils);

      var result = _service.GetLoadedCoilsById(1);

      Assert.NotNull(result);
    }
    [Fact]
    public void CheckIfEdited_Id_ReturnsString()
    {
      var mill = new Mill()
      {
        Id = 1,
        Name = "1",
        Disabled = false

      };
      var millDto = new MillDto()
      {
        Id = 1,
        Name = "1",
        Disabled = false

      };
      var mapper = InitializeMapper();
      var _service = new MillService(millsRepo.Object, coilRepo.Object, millsServiceLogger.Object, mapper);

      millsRepo.Setup(repo => repo.CheckIfEdited(1, mill)).Returns(false);

      var result = _service.CheckIfEdited(1, millDto);
      if (result != null)
      {
        Assert.IsType<string>(result);
      }

    }

    [Fact]
    public void CheckIfEdited_Id_ReturnsNull()
    {
      var mill = new Mill()
      {
        Id = 1,
        Name = "1",
        Disabled = false

      };
      var millDto = new MillDto()
      {
        Id = 1,
        Name = "1",
        Disabled = false

      };
      var mapper = InitializeMapper();
      var _service = new MillService(millsRepo.Object, coilRepo.Object, millsServiceLogger.Object, mapper);

      millsRepo.Setup(repo => repo.CheckIfEdited(1, mill))
    .Returns(false);

      var result = _service.CheckIfEdited(1, millDto);

      Assert.Null(result);
    }

    [Fact]
    public void CheckDependencyType_Id_ReturnsListOfStrings()
    {
      var coils = new List<Coil>() {
        new Coil()
                {
                    Id = 4,
                    OrderNo = 6,
                    Mill= new Mill{ Id=1, Name="A",Disabled=false},
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "56",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9,
                    CoilType = new CoilType() { Id = 1, Name = "test" }, CoilStatus = new CoilStatus(){ Name = "Partial Needs Weighed", Id=1},
                    CoilFieldLocation = new CoilFieldLocation() { Id = 7,  Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones =  new List<CoilFieldZone>( ){ new CoilFieldZone() { Name="test", Id=9, Color="", Disabled=true } } } } }

                }
      };
      var mapper = InitializeMapper();
      var _service = new MillService(millsRepo.Object, coilRepo.Object, millsServiceLogger.Object, mapper);

      coilRepo.Setup(repo => repo.IsmillIdPresentInCoilMoveRequest(1)).Returns(true);
      coilRepo.Setup(repo => repo.GetLoadedCoilsById(1)).Returns(coils);

      var result = _service.CheckDependencyType(1);

      Assert.NotNull(result);
    }


    [Fact]
    public void DisableMill_IdAndDisable_Returnsbool()
    {
      var mill = new Mill()
      {
        Id = 1,
        Name = "1",
        Disabled = false

      };
      var mapper = InitializeMapper();
      var _service = new MillService(millsRepo.Object, coilRepo.Object, millsServiceLogger.Object, mapper);

      millsRepo.Setup(repo => repo.DisableMill(1, false));
      millsRepo.Setup(repo => repo.GetMillById(1)).Returns(mill);

      var result = _service.DisableMill(1, false);

      Assert.True(result);
    }
    [Fact]
    public void DisableMill_IdAndDisable_Returnsfalse()
    {
      Mill mill = null;
      var mapper = InitializeMapper();
      var _service = new MillService(millsRepo.Object, coilRepo.Object, millsServiceLogger.Object, mapper);

      millsRepo.Setup(repo => repo.DisableMill(1, false));
      millsRepo.Setup(repo => repo.GetMillById(1)).Returns(mill);

      var result = _service.DisableMill(1, false);

      Assert.False(result);
    }
    [Fact]
    public void MillsExist_Id_ReturnsTrue()
    {
      var mill = new Mill()
      {
        Id = 1,
        Name = "1",
        Disabled = false

      };
      var mapper = InitializeMapper();
      var _service = new MillService(millsRepo.Object, coilRepo.Object, millsServiceLogger.Object, mapper);

      millsRepo.Setup(repo => repo.GetMillById(1)).Returns(mill);

      var result = _service.MillExists(1);

      Assert.True(result);
    }

    [Fact]
    public void MillsExist_Id_ReturnsFalse()
    {
      Mill mill = null;
      var mapper = InitializeMapper();
      var _service = new MillService(millsRepo.Object, coilRepo.Object, millsServiceLogger.Object, mapper);

      millsRepo.Setup(repo => repo.GetMillById(1)).Returns(mill);

      var result = _service.MillExists(1);

      Assert.False(result);
    }

    [Fact]
    public void InsertMill_mill_ReturnsBool()
    {
      Mill mill = null;
      var millDto = new MillDto()
      {
        Id = 1,
        Name = "1",
        Disabled = false

      };
      var mapper = InitializeMapper();
      var _service = new MillService(millsRepo.Object, coilRepo.Object, millsServiceLogger.Object, mapper);

      millsRepo.Setup(repo => repo.InsertMill(mill));

      var result = _service.InsertMill(millDto);

      Assert.True(result);
    }

    [Fact]
    public void DeleteMill_id_ReturnsMill()
    {
      Mill mill = new Mill()
      {
        Id = 1,
        Name = "1",
        Disabled = false

      };
      var mapper = InitializeMapper();
      var _service = new MillService(millsRepo.Object, coilRepo.Object, millsServiceLogger.Object, mapper);

      millsRepo.Setup(repo => repo.DeleteMill(1)).Returns(mill);

      var result = _service.DeleteMill(1);

      Assert.NotNull(result);
    }

    [Fact]
    public void Update_mill_ReturnsBool()
    {
      Mill mill = new Mill()
      {
        Id = 1,
        Name = "1",
        Disabled = false

      };
      var millDto = new MillDto()
      {
        Id = 1,
        Name = "1",
        Disabled = false

      };
      var mapper = InitializeMapper();
      var _service = new MillService(millsRepo.Object, coilRepo.Object, millsServiceLogger.Object, mapper);

      millsRepo.Setup(repo => repo.GetMillById(1)).Returns(mill);
      millsRepo.Setup(repo => repo.UpdateMill(mill)).Returns(true);

      var result = _service.UpdateMill(1, millDto);

      Assert.True(result);
    }
    [Fact]
    public void Update_mill_ReturnsFalse()
    {
      Mill mill = null;
      var millDto = new MillDto()
      {
        Id = 1,
        Name = "1",
        Disabled = false

      };
      var mapper = InitializeMapper();
      var _service = new MillService(millsRepo.Object, coilRepo.Object, millsServiceLogger.Object, mapper);

      millsRepo.Setup(repo => repo.GetMillById(1)).Returns(mill);
      millsRepo.Setup(repo => repo.UpdateMill(mill)).Returns(true);

      var result = _service.UpdateMill(1, millDto);

      Assert.False(result);
    }

  }
}
