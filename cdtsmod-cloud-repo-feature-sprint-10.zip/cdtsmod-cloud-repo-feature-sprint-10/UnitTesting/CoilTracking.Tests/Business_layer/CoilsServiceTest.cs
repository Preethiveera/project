using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constant;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using Moq;
using System;
using System.Collections.Generic;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class CoilsServiceTest
  {

    private readonly Mock<IPlantsRepository> plantsRepo;
    private readonly Mock<ICoilRepository> coilRepo;
    private readonly Mock<IApplicationLogger<CoilsService>> coilsServiceLogger;
    private readonly Mock<ICoilTypeRepository> coilTypeRepo;
    private readonly Mock<ICoilMoveRequestsRepository> coilMoveRequestsRepo;
    private readonly Mock<ICoilFieldLocationRepository> coilFieldLocationRepo;
    private readonly Mock<ICoilTypeYNARepository> coilTypeYNARepo;
    private readonly Mock<IPartModelsRepository> partModelsRepo;
    private readonly Mock<ICoilFactory> coilFactory;
    private readonly Mock<IMillsRepository> millsRepo;
    private readonly Mock<ICoilStatusRepository> coilStatusRepo;
    private readonly Mock<IRunOrderRepository> runOrderRepo;
    private readonly Mock<ILineRepository> lineRepo;
    private readonly Mock<ICoilLocationManagerFactory> coilNewLocationFactory;
    private readonly Mock<IWebSocketClientService> webSocketClientService;

    public CoilsServiceTest()
    {
      plantsRepo = new Mock<IPlantsRepository>();
      coilRepo = new Mock<ICoilRepository>();
      coilsServiceLogger = new Mock<IApplicationLogger<CoilsService>>();
      coilTypeRepo = new Mock<ICoilTypeRepository>();
      coilMoveRequestsRepo = new Mock<ICoilMoveRequestsRepository>();
      coilFieldLocationRepo = new Mock<ICoilFieldLocationRepository>();
      coilTypeYNARepo = new Mock<ICoilTypeYNARepository>();
      partModelsRepo = new Mock<IPartModelsRepository>();
      coilFactory = new Mock<ICoilFactory>();
      millsRepo = new Mock<IMillsRepository>();
      coilStatusRepo = new Mock<ICoilStatusRepository>();
      runOrderRepo = new Mock<IRunOrderRepository>();
      lineRepo = new Mock<ILineRepository>();
      coilNewLocationFactory = new Mock<ICoilLocationManagerFactory>();
      webSocketClientService = new Mock<IWebSocketClientService>();
    }

    public IMapper InitializeMapper()
    {
      var mockMapper = new MapperConfiguration(cfg =>
      {
        cfg.AddProfile(new MappingProfile());
      });
      var mapper = mockMapper.CreateMapper();

      return mapper;
    }

    [Fact]
    public void GetCoils_returnCoils()
    {
      var mockCoilsService = new MockCoilsservice();
      var mapper = InitializeMapper();
      coilRepo.Setup(repo => repo.GetCoils())
     .ReturnsAsync(mockCoilsService.GetCoilsList());
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      var coils = service.GetCoils();
      Assert.NotNull(coils);
    }

    [Fact]
    public void GetPlantCode()
    {
      var mapper = InitializeMapper();
      plantsRepo.Setup(repo => repo.GetPlantNAMCCode())
     .ReturnsAsync("TMMK");
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      var coils = service.GetPlantCode();
      Assert.NotNull(coils);
    }

    [Fact]
    public void SearchForCoils_returnCoils()
    {
      DateTime startTime = DateTime.Now;
      DateTime endTime = DateTime.Now;
      string FilterByBornOnDate = "1";
      int? zoneId = null;
      string coilType = null;
      int? coilStatusId = null;
      var mockCoilsService = new MockCoilsservice();
      var mapper = InitializeMapper();
      coilRepo.Setup(repo => repo.GetCoilsForSearch(startTime, endTime, coilType, coilStatusId, zoneId, FilterByBornOnDate))
     .ReturnsAsync(mockCoilsService.GetCoils());
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      var coils = service.SearchForCoils();
      Assert.NotNull(coils);
    }

    [Fact]
    public void SearchForCoils_FilterByBornOnDate_returnCoils()
    {
      DateTime? startTime = null;
      DateTime? endTime = null;
      string FilterByBornOnDate = "0";
      int? zoneId = null;
      string coilType = null;
      int? coilStatusId = null;
      var mockCoilsService = new MockCoilsservice();
      var mapper = InitializeMapper();
      coilRepo.Setup(repo => repo.GetCoilsForSearch(startTime, endTime, coilType, coilStatusId, zoneId, FilterByBornOnDate))
     .ReturnsAsync(mockCoilsService.GetCoils());
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      var coils = service.SearchForCoils();
      Assert.NotNull(coils);
    }


    [Fact]
    public void GetCoilInventory_returnCoils()
    {
      List<PartModel> partModels = new List<PartModel>();
      {
        partModels.Add(new PartModel() { Id = 4, Part = new Part() { Id = 2, PartName = "test", Disabled = true, PartNumber = "433", StrokeCount = 1 }, Model = new Model() { Id = 4, Disabled = true, ModelNumber = "test", Name = "Test" } });
      }

      List<CoilTypePartModel> coilTypePartModels = new List<CoilTypePartModel>();
      {
        coilTypePartModels.Add(new CoilTypePartModel() { CoilTypeId = 4, Models = "FS", PartNumber = "RR", Parts = new Part() { Id = 2, PartName = "test", Disabled = true, PartNumber = "433", StrokeCount = 1 } });
      }

      var mockCoilsService = new MockCoilsservice();
      var mapper = InitializeMapper();
      partModelsRepo.Setup(repo => repo.GetPartModels())
     .ReturnsAsync(partModels);
      coilTypeRepo.Setup(repo => repo.GetCoilTypesWithAllPartNums())
    .Returns(coilTypePartModels);
      coilRepo.Setup(repo => repo.GetCoilsByInInventory())
    .ReturnsAsync(mockCoilsService.GetCoils());
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      var coils = service.GetCoilInventory();
      Assert.NotNull(coils);
    }


    [Fact]
    public void GetCoilsById_returnCoils()
    {
      int id = 2;
      var mockCoilsService = new MockCoilsservice();
      var mapper = InitializeMapper();
      coilRepo.Setup(repo => repo.GetCoilsByIdWithTypeRunHistory(id))
     .ReturnsAsync(mockCoilsService.Getcoil());
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      var coils = service.GetCoilsById(id);
      Assert.NotNull(coils);
    }


    [Fact]
    public void GetCoilByFTZ_returnCoils()
    {
      string ftz = "T241213101A01";
      var mockCoilsService = new MockCoilsservice();
      var mapper = InitializeMapper();
      coilRepo.Setup(repo => repo.GetCoilsByFTZ(ftz))
    .ReturnsAsync(mockCoilsService.Getcoil());
      plantsRepo.Setup(repo => repo.GetPlantNAMCCode())
     .ReturnsAsync("TMMK");
      coilRepo.Setup(repo => repo.GetCoilsByPrefixFtz(ftz, ftz))
     .ReturnsAsync(mockCoilsService.Getcoil());
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      var coils = service.GetCoilByFTZ(ftz);
      Assert.NotNull(coils);
    }





    [Fact]
    public void GetCoilsLocationName_returnCoils()
    {
      string location = "Test";
      string zone = "Test";
      int id = 30;
      CoilFieldLocation coilFieldLocation = new CoilFieldLocation()
      {
        Id = 2,
        Column = 1,
        Disabled = true,
        IsEmpty = true,
        Name = "Test",
        Row = 2,
        Zone = new CoilFieldZone() { Id = 2, Name = "Test", Disabled = true, Color = "Red", CoilField = new CoilField() { }, Locations = new List<CoilFieldLocation>() { }, TextColor = "text" }
      };
      var mockCoilsService = new MockCoilsservice();
      var mapper = InitializeMapper();
      coilFieldLocationRepo.Setup(repo => repo.GetCoilFieldLocationByName(zone, location))
        .ReturnsAsync(coilFieldLocation);
      coilRepo.Setup(repo => repo.GetCoilsByLocationId(id))
    .ReturnsAsync(mockCoilsService.Getcoil());
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      var coils = service.GetCoilsLocationName(location);
      Assert.NotNull(coils);
    }


    [Fact]
    public void GetCoilsByLocationId_returnCoils()
    {
      int id = 30;
      var mockCoilsService = new MockCoilsservice();
      var mapper = InitializeMapper();
      coilRepo.Setup(repo => repo.GetCoilsByLocationId(id))
     .ReturnsAsync(mockCoilsService.Getcoil());
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      var coils = service.GetCoilsByLocationId(id);
      Assert.NotNull(coils);
    }


    [Fact]
    public void GetCoilForModify_returnCoils()
    {
      int id = 30;
      var mockCoilsService = new MockCoilsservice();
      var mapper = InitializeMapper();
      coilRepo.Setup(repo => repo.GetCoilsById(id))
     .ReturnsAsync(mockCoilsService.Getcoil());
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      var coils = service.GetCoilForModify(id);
      Assert.NotNull(coils);
    }
    [Fact]
    public void GetCoilsToBeWeighed_returnCoils()
    {
      string Name = CoilStatusName.PartialNeedsWeighed;
      var mockCoilsService = new MockCoilsservice();
      var mapper = InitializeMapper();
      coilRepo.Setup(repo => repo.GetCoilsByCoilStatusName(Name))
     .ReturnsAsync(mockCoilsService.GetCoils());
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      var coils = service.GetCoilsToBeWeighed();
      Assert.NotNull(coils);
    }


    [Fact]
    public void GetRemainingCoilWeightById_returnCoils()
    {
      int id = 30;
      var coilType = new CoilType

      {
        Id = 4,
        Name = "test",
        NumCoils = 9,
        CoilTypeYNAs = new List<CoilTypeYNA> { new CoilTypeYNA() { Id = 1, YNA = "YNA0011171", CoilType = new CoilType() { }, MaterialType = new MaterialType() { Name = "YAS" } } },
        CoilFieldZone = new CoilFieldZone()
        {
          Id = 1,
          CoilField = new CoilField() { Id = 1, Disabled = true, Name = "A", Zones = new List<CoilFieldZone>() { } }
        }
      };
      var mockCoilsService = new MockCoilsservice();
      var mapper = InitializeMapper();
      coilTypeRepo.Setup(repo => repo.GetCoilTypeById(id))
     .Returns(coilType);
      coilRepo.Setup(repo => repo.CoilsInventoryBYTypeId(id))
    .ReturnsAsync(mockCoilsService.GetCoils);
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      var coils = service.GetRemainingCoilWeightById(id);
      Assert.NotNull(coils);
    }

    [Fact]
    public void GetMaterialTypeByYNA_returnCoils()
    {
      string yna = "YNA8346423";
      var mapper = InitializeMapper();
      coilTypeYNARepo.Setup(repo => repo.GetMaterialTypeByYNA(yna))
     .ReturnsAsync("YNA8346423");
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      var coils = service.GetMaterialTypeByYNA(yna);
      Assert.NotNull(coils);
    }


    [Fact]
    public void CheckDependency_returnCoils()
    {
      int id = 30;
      List<CoilMoveRequest> coilMoveRequests = new List<CoilMoveRequest>();
      {
        coilMoveRequests.Add(new CoilMoveRequest() { Id = 2, Coil = new Coil() { }, Line = new Line() { }, Fulfilled = DateTime.Now, Requested = DateTime.Now, IsCancelled = true, RequestType = new CoilMoveRequestType() { } });
      }
      var mockCoilsService = new MockCoilsservice();
      var mapper = InitializeMapper();
      coilMoveRequestsRepo.Setup(repo => repo.GetCoilMoveRequestById(id))
     .Returns(coilMoveRequests);
      coilRepo.Setup(repo => repo.GetCoilsLoadedById(id))
    .ReturnsAsync(mockCoilsService.GetCoils);
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      var coils = service.CheckDependency(id);
      Assert.NotNull(coils);
    }


    [Fact]
    public void InsertCoil_returnCoils()
    {
      Coil coil = new Coil
      {

        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,
        CoilRunHistory = new List<CoilRunHistory>(){ new CoilRunHistory() { Id = 2, Coil= new Coil {   Id = 7,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9 } }  },
        CoilStatus = new CoilStatus() { Id = 8, Name = "test", Color = "test", InInventory = true, IsUsable = true, TextColor = "white" },
        Mill = new Mill() { Id = 9, Name = "test", Disabled = true },
        CoilType = new CoilType() { Id = 7, Name = "test", CoilFieldZone = new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } },
        CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } } } } }


      };
      var mapper = InitializeMapper();
      coilRepo.Setup(repo => repo.InsertCoil(coil))
     .ReturnsAsync(1);
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      var coils = service.InsertCoil(coil);
      Assert.NotNull(coils);
    }



    [Fact]
    public void UpdateCoil_returnCoils()
    {
      int id = 121;
      Coil coil = new Coil
      {
        Id = 121,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,
        CoilRunHistory = new List<CoilRunHistory>(){ new CoilRunHistory() { Id = 2, Coil= new Coil {   Id = 7,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9 } }  },
        CoilStatus = new CoilStatus() { Id = 8, Name = "test", Color = "test", InInventory = true, IsUsable = true, TextColor = "white" },
        Mill = new Mill() { Id = 9, Name = "test", Disabled = true },
        CoilType = new CoilType() { Id = 7, Name = "test", CoilFieldZone = new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } },
        CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } } } } }


      };
      var mapper = InitializeMapper();
      coilRepo.Setup(repo => repo.ModifyCoil(coil))
     .ReturnsAsync(1);
      coilRepo.Setup(repo => repo.GetCoilId(id))
   .ReturnsAsync(coil);
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      var coils = service.UpdateCoil(id, coil);
      Assert.NotNull(coils);
    }

    [Fact]
    public void UpdateUnAccountedWeight_returnCoils()
    {
      int id = 30;
      Coil coil = new Coil
      {
        Id = 30,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,
        CoilRunHistory = new List<CoilRunHistory>(){ new CoilRunHistory() { Id = 2, Coil= new Coil {   Id = 7,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9 } }  },
        CoilStatus = new CoilStatus() { Id = 8, Name = "test", Color = "test", InInventory = true, IsUsable = true, TextColor = "white" },
        Mill = new Mill() { Id = 9, Name = "test", Disabled = true },
        CoilType = new CoilType() { Id = 7, Name = "test", CoilFieldZone = new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } },
        CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } } } } }


      };
      var mockCoilsService = new MockCoilsservice();
      var mapper = InitializeMapper();
      coilRepo.Setup(repo => repo.GetCoilStatusByCoilId(id))
     .ReturnsAsync(mockCoilsService.Getcoil());
      coilRepo.Setup(repo => repo.UpdateCoilStatus(coil))
    .ReturnsAsync(1);
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      var coils = service.UpdateUnAccountedWeight(id, id);
      Assert.NotNull(coils);
    }

    [Fact]
    public void CoilCheckEdit_returnCoils()
    {
      int id = 124;
      CoilDto coildto = new CoilDto()
      {
        Id = 124,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        CoilTypeId = 4,
        CoilRunHistory = new List<CoilRunHistoryDto>() { },
        CoilStatusId = 2,
        ZoneId = 1,
        CoilStatus = new CoilStatusDto() { },
        CoilFieldLocation = new CoilFieldLocationDto() { },
        CoilFieldLocationId = 2,
        CoilFieldLocationName = "Name",
        MillId = 2,
        Mill = new MillDto() { },
        OriginalWeight = 4000,
        MillName = "A",
        CoilStatusName = "AA",
        CoilType = new CoilTypeDto() { },
        CoilTypeName = "AA",
        CurrentWeight = 22
      };
      var mockCoilsService = new MockCoilsservice();
      var mapper = InitializeMapper();
      coilRepo.Setup(repo => repo.GetCoilStatusByCoilId(id))
     .ReturnsAsync(mockCoilsService.Getcoil());
      coilRepo.Setup(repo => repo.GetCoilId(id))
    .ReturnsAsync(mockCoilsService.Getcoil);
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      var coils = service.CoilCheckEdit(id, coildto);
      Assert.NotNull(coils);
    }


    [Fact]
    public void DeleteCoilById_returnCoils()
    {
      int id = 0;
      Coil coil = new Coil();
      var mapper = InitializeMapper();
      var mockCoilsService = new MockCoilsservice();
      coilRepo.Setup(repo => repo.GetCoilId(id))
   .ReturnsAsync(mockCoilsService.Getcoil);
      coilRepo.Setup(repo => repo.DeleteCoil(coil))
 .ReturnsAsync(1);
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      Assert.ThrowsAsync<ArgumentNullException>(() => service.DeleteCoilById(id));
    }

    [Fact]
    public void CheckIn_ReturnsCoils()
    {
      string YNANo = "YNA0231512";
      CoilCheckIn coilCheckIn = new CoilCheckIn()
      {
        YNANo = "YNA0231512",
        Weight = 100,
        Width = 1370,
        Thickness = decimal.Zero,
        Location = "Test-Test",
        FTZ = "56",
        Mill = "USS",
        BornOnDate = null,
        IsPriorityCoil = false,
        SerialNum = "123"
      };
      CoilFieldLocation coilFieldLocation = new CoilFieldLocation()
      {
        Id = 2,
        Column = 1,
        Disabled = true,
        IsEmpty = true,
        Name = "Test",
        Row = 2,
        Zone = new CoilFieldZone() { Id = 2, Name = "Test", Disabled = true, Color = "Red", CoilField = new CoilField() { }, Locations = new List<CoilFieldLocation>() { }, TextColor = "text" }
      };
      var mills = new Mill()
      {
        Id = 1,
        Name = "Mittal",
        Disabled = false
      };
      string location = "Test";
      string zone = "Test";
      var CoilTypeYNAs = new CoilTypeYNA() { Id = 1, YNA = "YNA0011171", CoilType = new CoilType() { Id=1,  Name = "test",
        NumCoils = 9,  Disabled= true }, MaterialType = new MaterialType() { Name = "YAS" } };

      Coil coil = new Coil
      {
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,
        CoilRunHistory = new List<CoilRunHistory>(){ new CoilRunHistory() { Id = 2, Coil= new Coil {   Id = 7,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9 } }  },
        CoilStatus = new CoilStatus() { Id = 8, Name = "test", Color = "test", InInventory = true, IsUsable = true, TextColor = "white" },
        Mill = new Mill() { Id = 9, Name = "test", Disabled = true },
        CoilType = new CoilType() { Id = 7, Name = "test", CoilFieldZone = new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } },
        CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } } } } }


      };
      var mockCoilsService = new MockCoilsservice();
      var mapper = InitializeMapper();
      coilStatusRepo.Setup(repo => repo.GetCoilStatusByName(CoilStatusName.New))
     .ReturnsAsync(mockCoilsService.Getcoilstatus());
    //  coilTypeYNARepo.Setup(repo => repo.GetcoilTypeYNAsByYNANo(YNANo))
    //.ReturnsAsync(CoilTypeYNAs);
      coilFieldLocationRepo.Setup(repo => repo.GetCoilFieldLocationByName(zone, location))
 .ReturnsAsync(coilFieldLocation);
      millsRepo.Setup(repo => repo.GetMillByName(coilCheckIn.Mill))
.ReturnsAsync(mills);
      coilRepo.Setup(repo => repo.InsertCoil(coil))
.ReturnsAsync(1);
      coilRepo.Setup(repo => repo.DeleteCoil(coil))
.ReturnsAsync(1);
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      var coils = service.CoilsCheckIn(coilCheckIn);
      Assert.NotNull(coils);
    }

    [Fact]
    public void CheckIn_ReturnsCoilsMill()
    {
      string YNANo = "YNA0231512";
      Coil coil = new Coil
      {
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,
        CoilRunHistory = new List<CoilRunHistory>(){ new CoilRunHistory() { Id = 2, Coil= new Coil {   Id = 7,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9 } }  },
        CoilStatus = new CoilStatus() { Id = 8, Name = "test", Color = "test", InInventory = true, IsUsable = true, TextColor = "white" },
        Mill = new Mill() { Id = 9, Name = "test", Disabled = true },
        CoilType = new CoilType() { Id = 7, Name = "test", CoilFieldZone = new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } },
        CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } } } } }


      };
      CoilCheckIn coilCheckIn = new CoilCheckIn()
      {
        YNANo = "YNA0231512",
        Weight = 100,
        Width = 1370,
        Thickness = decimal.Zero,
        Location = "Test-Test",
        FTZ = "56",
        Mill = "A777",
        BornOnDate = null,
        IsPriorityCoil = false,
        SerialNum = "123"
      };
      CoilFieldLocation coilFieldLocation = new CoilFieldLocation()
      {
        Id = 2,
        Column = 1,
        Disabled = true,
        IsEmpty = true,
        Name = "Test",
        Row = 2,
        Zone = new CoilFieldZone() { Id = 2, Name = "Test", Disabled = true, Color = "Red", CoilField = new CoilField() { }, Locations = new List<CoilFieldLocation>() { }, TextColor = "text" }
      };
      var mills = new Mill()
      {
        Id = 1,
        Name = "Mittal",
        Disabled = false
      };
      string location = "Test";
      string zone = "Test";
      var CoilTypeYNAs = new  CoilTypeYNA() { Id = 1, YNA = "YNA0011171", CoilType = new CoilType() { Id=1,  Name = "test",
        NumCoils = 9,  Disabled= true }, MaterialType = new MaterialType() { Name = "YAS" } };
      var mockCoilsService = new MockCoilsservice();
      var mapper = InitializeMapper();
      coilStatusRepo.Setup(repo => repo.GetCoilStatusByName(CoilStatusName.New))
     .ReturnsAsync(mockCoilsService.Getcoilstatus());
    //  coilTypeYNARepo.Setup(repo => repo.GetcoilTypeYNAsByYNANo(YNANo))
    //.ReturnsAsync(CoilTypeYNAs);
      coilFieldLocationRepo.Setup(repo => repo.GetCoilFieldLocationByName(zone, location))
 .ReturnsAsync(coilFieldLocation);
      millsRepo.Setup(repo => repo.GetMillByName(coilCheckIn.Mill))
.ReturnsAsync(mills);
      coilRepo.Setup(repo => repo.InsertCoil(coil))
.ReturnsAsync(1);
      coilRepo.Setup(repo => repo.DeleteCoil(coil))
.ReturnsAsync(1);
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      var coils = service.CoilsCheckIn(coilCheckIn);
      Assert.NotNull(coils);
    }

    [Fact]
    public void CheckIn_ReturnsThrowsCoilTrackingException()
    {
      string YNANo = "YNA0231512";
      Coil coil = new Coil
      {
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,
        CoilRunHistory = new List<CoilRunHistory>(){ new CoilRunHistory() { Id = 2, Coil= new Coil {   Id = 7,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9 } }  },
        CoilStatus = new CoilStatus() { Id = 8, Name = "test", Color = "test", InInventory = true, IsUsable = true, TextColor = "white" },
        Mill = new Mill() { Id = 9, Name = "test", Disabled = true },
        CoilType = new CoilType() { Id = 7, Name = "test", CoilFieldZone = new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } },
        CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } } } } }


      };
      CoilCheckIn coilCheckIn = new CoilCheckIn()
      {
        YNANo = "YNA0231512",
        Weight = 100,
        Width = 1370,
        Thickness = decimal.Zero,
        Location = "Test-Test",
        FTZ = "56",
        Mill = "A777",
        BornOnDate = null,
        IsPriorityCoil = false,
        SerialNum = "123"
      };
      CoilFieldLocation coilFieldLocation = new CoilFieldLocation()
      {
        Id = 2,
        Column = 1,
        Disabled = true,
        IsEmpty = true,
        Name = "Test",
        Row = 2,
        Zone = new CoilFieldZone() { Id = 2, Name = "Test", Disabled = true, Color = "Red", CoilField = new CoilField() { }, Locations = new List<CoilFieldLocation>() { }, TextColor = "text" }
      };
      var mills = new Mill()
      {
        Id = 1,
        Name = "Mittal",
        Disabled = false
      };
      string location = "Test";
      string zone = "Test";
      var CoilTypeYNAs = new  CoilTypeYNA() { Id = 1, YNA = "YNA0011171", CoilType = new CoilType() { Id=1,  Name = "test",
        NumCoils = 9,  Disabled= true }, MaterialType = new MaterialType() { Name = "YAS" } } ;
      var mockCoilsService = new MockCoilsservice();
      var mapper = InitializeMapper();
      coilStatusRepo.Setup(repo => repo.GetCoilStatusByName(CoilStatusName.New))
     .ReturnsAsync(mockCoilsService.Getcoilstatus());
    //  coilTypeYNARepo.Setup(repo => repo.GetcoilTypeYNAsByYNANo(YNANo))
    //.ReturnsAsync(CoilTypeYNAs);
      coilFieldLocationRepo.Setup(repo => repo.GetCoilFieldLocationByName(zone, location))
 .ReturnsAsync(coilFieldLocation);
      millsRepo.Setup(repo => repo.GetMillByName(coilCheckIn.Mill))
.ReturnsAsync(mills);
      coilRepo.Setup(repo => repo.InsertCoil(coil))
.ReturnsAsync(1);
      coilRepo.Setup(repo => repo.DeleteCoil(coil))
.ReturnsAsync(1);
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      Assert.ThrowsAsync<CoilTrackingException>(() => service.CoilsCheckIn(coilCheckIn));
    }

    [Fact]
    public void CreateCoilRunHistory_ReturnsCoils()
    {
      Coil coil = new Coil
      {
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,
        CoilRunHistory = new List<CoilRunHistory>(){ new CoilRunHistory() { Id = 2, Coil= new Coil {   Id = 7,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9 } }  },
        CoilStatus = new CoilStatus() { Id = 8, Name = "test", Color = "test", InInventory = true, IsUsable = true, TextColor = "white" },
        Mill = new Mill() { Id = 9, Name = "test", Disabled = true },
        CoilType = new CoilType() { Id = 7, Name = "test", CoilFieldZone = new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } },
        CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } } } } }


      };
      int id = 125;
      int runOrderListId = 12;
      int weightUsed = 120;
      RunOrderList runOrderList = new RunOrderList();
      var mockCoilsService = new MockCoilsservice();
      var mapper = InitializeMapper();
      coilRepo.Setup(repo => repo.GetCoilsWithAllInfo(id))
     .Returns(mockCoilsService.Getcoil());
      runOrderRepo.Setup(repo => repo.GetRunOrderListByIdAsync(id))
    .ReturnsAsync(runOrderList);
      coilStatusRepo.Setup(repo => repo.GetCoilStatusByName(CoilStatusName.New))
   .ReturnsAsync(mockCoilsService.Getcoilstatus());
      coilRepo.Setup(repo => repo.UpdateCoilForRunHistory(coil))
  .ReturnsAsync(1);
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      var coils = service.UpdateCoilRunHistory(id, runOrderListId, weightUsed);
      Assert.NotNull(coils);
    }

    [Fact]
    public void CreateCoilRunHistory_ReturnsThrowsCoilTrackingException()
    {

      Coil coil = new Coil
      {
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,
        CoilRunHistory = new List<CoilRunHistory>(){ new CoilRunHistory() { Id = 2, Coil= new Coil {   Id = 7,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9 } }  },
        CoilStatus = new CoilStatus() { Id = 8, Name = "test", Color = "test", InInventory = true, IsUsable = true, TextColor = "white" },
        Mill = new Mill() { Id = 9, Name = "test", Disabled = true },
        CoilType = new CoilType() { Id = 7, Name = "test", CoilFieldZone = new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } },
        CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } } } } }


      };
      int id = 125;
      int runOrderListId = 12;
      int weightUsed = 120;
      RunOrderList runOrderList = new RunOrderList();
      var mockCoilsService = new MockCoilsservice();
      var mapper = InitializeMapper();
      coilRepo.Setup(repo => repo.GetCoilsWithAllInfo(id))
     .Returns(mockCoilsService.Getcoil());
      runOrderRepo.Setup(repo => repo.GetRunOrderListByIdAsync(id))
    .ReturnsAsync(runOrderList);
      coilStatusRepo.Setup(repo => repo.GetCoilStatusByName(CoilStatusName.New))
   .ReturnsAsync(mockCoilsService.Getcoilstatus());
      coilRepo.Setup(repo => repo.UpdateCoilForRunHistory(coil))
  .ReturnsAsync(1);
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      Assert.ThrowsAsync<CoilTrackingException>(() => service.UpdateCoilRunHistory(id, runOrderListId, weightUsed));
    }


    [Fact]
    public void MoveCoil_ReturnsThrowsCoilTrackingException()
    {
      int coilId = 125;
      string newLocation = Constant.supplier;
      int newStatusId = 7;
      bool isPriorityCoil = false;
      int? lineId = null;
      CoilFieldLocation coilFieldLocation = new CoilFieldLocation()
      {
        Id = 2,
        Column = 1,
        Disabled = true,
        IsEmpty = true,
        Name = "Test",
        Row = 2,
        Zone = new CoilFieldZone() { Id = 2, Name = "Test", Disabled = true, Color = "Red", CoilField = new CoilField() { }, Locations = new List<CoilFieldLocation>() { }, TextColor = "text" }
      };
      string location = "Test";
      string zone = "Test";
      Line line = new Line();
      var mockCoilsService = new MockCoilsservice();
      var mapper = InitializeMapper();
      coilRepo.Setup(repo => repo.GetCoilsById(coilId))
     .ReturnsAsync(mockCoilsService.Getcoil());
      coilStatusRepo.Setup(repo => repo.GetCoilStatusByIdAsync(newStatusId))
    .ReturnsAsync(mockCoilsService.Getcoilstatuses());
      coilFieldLocationRepo.Setup(repo => repo.GetCoilFieldLocationByName(zone, location))
 .ReturnsAsync(coilFieldLocation);
      lineRepo.Setup(repo => repo.GetLineByLineID(coilId))
    .Returns(line);

      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      var coils = service.UpdateMoveCoilsByIds(coilId, newLocation, newStatusId, isPriorityCoil, lineId);
      Assert.NotNull(coils);
    }

    [Fact]
    public void MoveCoil_ReturnsCoils()
    {
      int coilId = 125;
      string newLocation = "Test-Test";
      int newStatusId = 7;
      bool isPriorityCoil = false;
      int? lineId = null;
      CoilFieldLocation coilFieldLocation = new CoilFieldLocation()
      {
        Id = 2,
        Column = 1,
        Disabled = true,
        IsEmpty = true,
        Name = "Test",
        Row = 2,
        Zone = new CoilFieldZone() { Id = 2, Name = "Test", Disabled = true, Color = "Red", CoilField = new CoilField() { }, Locations = new List<CoilFieldLocation>() { }, TextColor = "text" }
      };
      string location = "Test";
      string zone = "Test";
      Line line = new Line();
      var mockCoilsService = new MockCoilsservice();
      var mapper = InitializeMapper();
      coilRepo.Setup(repo => repo.GetCoilsById(coilId))
     .ReturnsAsync(mockCoilsService.Getcoil());
      coilStatusRepo.Setup(repo => repo.GetCoilStatusByIdAsync(newStatusId))
    .ReturnsAsync(mockCoilsService.Getcoilstatuses());
      coilFieldLocationRepo.Setup(repo => repo.GetCoilFieldLocationByName(zone, location))
 .ReturnsAsync(coilFieldLocation);
      lineRepo.Setup(repo => repo.GetLineByLineID(coilId))
    .Returns(line);
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      Assert.ThrowsAsync<CoilTrackingException>(() => service.UpdateMoveCoilsByIds(coilId, newLocation, newStatusId, isPriorityCoil, lineId));
    }

    [Fact]
    public void MoveCoil_ReturnsCoils_Coils()
    {
      int coilId = 13;
      string newLocation = Constant.other;
      int newStatusId = 8;
      bool isPriorityCoil = true;
      int? lineId = 5;
      CoilFieldLocation coilFieldLocation = new CoilFieldLocation()
      {
        Id = 2,
        Column = 1,
        Disabled = true,
        IsEmpty = true,
        Name = "Test",
        Row = 2,
        Zone = new CoilFieldZone() { Id = 2, Name = "Test", Disabled = true, Color = "Red", CoilField = new CoilField() { }, Locations = new List<CoilFieldLocation>() { }, TextColor = "text" }
      };
      string location = "Test";
      string zone = "Test";
      Line line = new Line();
      CoilStatus coilStatuses = new CoilStatus()
      { Id = 4, Color = "red", Name = "Loaded at Line" };
      var mockCoilsService = new MockCoilsservice();
      var mapper = InitializeMapper();
      coilRepo.Setup(repo => repo.GetCoilsById(coilId))
     .ReturnsAsync(mockCoilsService.Getcoil());
      coilStatusRepo.Setup(repo => repo.GetCoilStatusByIdAsync(newStatusId))
    .ReturnsAsync(coilStatuses);
      coilFieldLocationRepo.Setup(repo => repo.GetCoilFieldLocationByName(zone, location))
 .ReturnsAsync(coilFieldLocation);
      lineRepo.Setup(repo => repo.GetLineByLineID(coilId))
    .Returns(line);
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      Assert.ThrowsAsync<CoilTrackingException>(() => service.UpdateMoveCoilsByIds(coilId, newLocation, newStatusId, isPriorityCoil, lineId));
    }


    [Fact]
    public void MoveCoil_ReturnsCoils_CoilsMills()
    {
      int coilId = 16;
      string newLocation = Constant.other;
      int newStatusId = 8;
      bool isPriorityCoil = true;
      int? lineId = 5;
      CoilFieldLocation coilFieldLocation = null;
      string location = "Test";
      string zone = "Test";
      Line line = new Line() { Id = 4, Disabled = true, LineName = "A5", Plant_Id = 7 };
      CoilStatus coilStatuses = new CoilStatus()
      { Id = 4, Color = "red", Name = "Loaded at Line" };
      var mockCoilsService = new MockCoilsservice();
      var mapper = InitializeMapper();
      coilRepo.Setup(repo => repo.GetCoilsById(coilId))
     .ReturnsAsync(mockCoilsService.Getcoil());
      coilStatusRepo.Setup(repo => repo.GetCoilStatusByIdAsync(newStatusId))
    .ReturnsAsync(coilStatuses);
      coilFieldLocationRepo.Setup(repo => repo.GetCoilFieldLocationByName(zone, location))
 .ReturnsAsync(coilFieldLocation);
      lineRepo.Setup(repo => repo.GetLineByLineID(coilId))
    .Returns(line);
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      var coils = service.UpdateMoveCoilsByIds(coilId, newLocation, newStatusId, isPriorityCoil, lineId);
      Assert.NotNull(coils);
    }

    [Fact]
    public void MoveCoil_ReturnsCoil()
    {
      int coilId = 124;
      string newLocation = Constant.other;
      int newStatusId = 7;
      bool isPriorityCoil = false;
      int? lineId = 8;
      CoilFieldLocation coilFieldLocation = new CoilFieldLocation()
      {
        Id = 2,
        Column = 1,
        Disabled = true,
        IsEmpty = true,
        Name = "Test",
        Row = 2,
        Zone = new CoilFieldZone() { Id = 2, Name = "Test", Disabled = true, Color = "Red", CoilField = new CoilField() { }, Locations = new List<CoilFieldLocation>() { }, TextColor = "text" }
      };
      string location = "Test";
      string zone = "Test";
      Line line = new Line();
      var mockCoilsService = new MockCoilsservice();
      var mapper = InitializeMapper();
      coilRepo.Setup(repo => repo.GetCoilsById(coilId))
     .ReturnsAsync(mockCoilsService.Getcoil());
      coilStatusRepo.Setup(repo => repo.GetCoilStatusByIdAsync(newStatusId))
    .ReturnsAsync(mockCoilsService.Getcoilstatuses());
      coilFieldLocationRepo.Setup(repo => repo.GetCoilFieldLocationByName(zone, location))
 .ReturnsAsync(coilFieldLocation);
      lineRepo.Setup(repo => repo.GetLineByLineID(coilId))
    .Returns(line);
      var service = new CoilsService(coilRepo.Object, coilsServiceLogger.Object, coilTypeRepo.Object, coilMoveRequestsRepo.Object, coilFieldLocationRepo.Object, coilTypeYNARepo.Object, plantsRepo.Object, mapper, partModelsRepo.Object, coilFactory.Object, millsRepo.Object, coilStatusRepo.Object, runOrderRepo.Object, lineRepo.Object, coilNewLocationFactory.Object, webSocketClientService.Object);
      var coils = service.UpdateMoveCoilsByIds(coilId, newLocation, newStatusId, isPriorityCoil, lineId);
      Assert.NotNull(coils);
    }

  }
}
