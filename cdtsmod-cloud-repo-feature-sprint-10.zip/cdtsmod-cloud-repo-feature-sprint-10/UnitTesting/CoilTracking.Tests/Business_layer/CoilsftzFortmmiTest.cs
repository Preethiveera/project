using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using Moq;
using System;
using System.Collections.Generic;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
 public class CoilsftzFortmmiTest
  {
    private readonly Mock<IApplicationLogger<CoilsService>> coilServiceLogger;

    private readonly Mock<ICoilRepository> coilRepo;

    public CoilsftzFortmmiTest()
    {
      coilServiceLogger = new Mock<IApplicationLogger<CoilsService>>();
      coilRepo = new Mock<ICoilRepository>();
    }
    [Fact]
    public void GetCoilsByFtztmmi_Returnftz()
    {
      string sPrefixFtz = 'S' + "34353";
      string tPrefixFtz = 'T' + "564343";
      var mockCoilsservice = new MockCoilsservice();
      coilRepo.Setup(repo => repo.GetCoilsByPrefixFtz(sPrefixFtz,tPrefixFtz))
      .ReturnsAsync(mockCoilsservice.Getcoil());
      var _service = new CoilsFTZForTMMI(coilRepo.Object, coilServiceLogger.Object);
      var rr = _service.GetCoilFTZByPrefix(sPrefixFtz);
      Assert.NotNull(rr);
    }
  }
}
