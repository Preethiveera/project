using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using Moq;
using System.Collections.Generic;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class CoilFieldServiceTest
  {

    private readonly Mock<ICoilFieldZoneRepository> coilFieldZoneRepo;
    private readonly Mock<ICoilFieldRepository> coilFieldRepo;
    private readonly Mock<ICoilRepository> coilRepo;
    private readonly Mock<IApplicationLogger<CoilFieldsService>> coilFieldServiceLogger;
    private readonly Mock<IWebSocketClientService> webSocketClientService;


    public CoilFieldServiceTest()
    {
      coilFieldRepo = new Mock<ICoilFieldRepository>();
      coilRepo = new Mock<ICoilRepository>();
      coilFieldServiceLogger = new Mock<IApplicationLogger<CoilFieldsService>>();
      coilFieldZoneRepo = new Mock<ICoilFieldZoneRepository>();
      webSocketClientService = new Mock<IWebSocketClientService>();
    }

    public IMapper InitializeMapper()
    {
      var mockMapper = new MapperConfiguration(cfg =>
      {
        cfg.AddProfile(new MappingProfile());
      });
      var mapper = mockMapper.CreateMapper();

      return mapper;
    }

    [Fact]
    public void GetCoilFields_ReturnscoilFields()
    {
      var list = new List<CoilField> { new CoilField()
      {
        Id=1,
        Disabled=false,
        Name="TMMI"
      } };

      var mapper = InitializeMapper();
      var _service = new CoilFieldsService(coilFieldRepo.Object, coilRepo.Object, coilFieldServiceLogger.Object, mapper, coilFieldZoneRepo.Object, webSocketClientService.Object);

      coilFieldRepo.Setup(repo => repo.GetCoilFields())
    .Returns(list);

      var result = _service.GetCoilFields();

      Assert.NotNull(result);
    }
    [Fact]
    public void GetCoilFieldById_Id_ReturnscoilField()
    {
      var list = new CoilField()
      {
        Id = 1,
        Disabled = false,
        Name = "TMMI"
      };

      var mapper = InitializeMapper();
      var _service = new CoilFieldsService(coilFieldRepo.Object, coilRepo.Object, coilFieldServiceLogger.Object, mapper, coilFieldZoneRepo.Object, webSocketClientService.Object);
      coilFieldRepo.Setup(repo => repo.GetCoilFieldWithZonesById(1))
    .Returns(list);

      var result = _service.GetCoilFieldById(1);

      Assert.NotNull(result);
    }
    [Fact]
    public void GetCoilFieldForEdit_Id_ReturnscoilField()
    {
      var list = new CoilField()
      {
        Id = 1,
        Disabled = false,
        Name = "TMMI"
      };

      var mapper = InitializeMapper();
      var _service = new CoilFieldsService(coilFieldRepo.Object, coilRepo.Object, coilFieldServiceLogger.Object, mapper, coilFieldZoneRepo.Object, webSocketClientService.Object);
      coilFieldRepo.Setup(repo => repo.GetCoilFieldWithZonesById(1))
     .Returns(list);

      var result = _service.GetCoilFieldForEdit(1);

      Assert.NotNull(result);
    }

    [Fact]
    public void CheckIfEdited_Id_ReturnsString()
    {
      var model = new CoilField()
      {
        Id = 1,
        Disabled = true,
        Name = "TMMI"
      };
      var dto = new CoilFieldDto()
      {
        Id = 1,
        Disabled = false,
        Name = "TMMI"
      };

      var mapper = InitializeMapper();
      var _service = new CoilFieldsService(coilFieldRepo.Object, coilRepo.Object, coilFieldServiceLogger.Object, mapper, coilFieldZoneRepo.Object, webSocketClientService.Object);
      coilFieldRepo.Setup(repo => repo.GetCoilFieldWithZonesById(1))
     .Returns(model);

      var result = _service.CheckIfEdited(1, dto);

      Assert.NotNull(result);
    }
    [Fact]
    public void CheckIfEdited_Id_ReturnsNull()
    {
      var model = new CoilField()
      {
        Id = 1,
        Disabled = false,
        Name = "TMMI"
      };
      var dto = new CoilFieldDto()
      {
        Id = 1,
        Disabled = false,
        Name = "TMMI"
      };

      var mapper = InitializeMapper();
      var _service = new CoilFieldsService(coilFieldRepo.Object, coilRepo.Object, coilFieldServiceLogger.Object, mapper, coilFieldZoneRepo.Object, webSocketClientService.Object);
      coilFieldRepo.Setup(repo => repo.GetCoilFieldWithZonesById(1))
    .Returns(model);

      var result = _service.CheckIfEdited(1, dto);

      Assert.Null(result);
    }

    [Fact]
    public void GetAssociatedItemsCoilFielsZone_Id_ReturnscoilFieldZone()
    {
      var list = new List<CoilFieldZone>{new CoilFieldZone
      {
        Id = 1,
        Disabled = false,
        Name = "TMMI"
      }
      };

      var mapper = InitializeMapper();
      var _service = new CoilFieldsService(coilFieldRepo.Object, coilRepo.Object, coilFieldServiceLogger.Object, mapper, coilFieldZoneRepo.Object, webSocketClientService.Object);
      coilFieldZoneRepo.Setup(repo => repo.GetCoilFieldsZoneByCoilFieldId(1))
     .Returns(list);

      var result = _service.GetCoilFieldsZoneByCoilFieldId(1);

      Assert.NotNull(result);
    }


    [Fact]
    public void GetCoilsByCoilField_Id_Returnscoils()
    {
      var list = new List<Coil>{new Coil
      {
        Id = 1,
        FTZ="1"
      }
      };

      var mapper = InitializeMapper();
      var _service = new CoilFieldsService(coilFieldRepo.Object, coilRepo.Object, coilFieldServiceLogger.Object, mapper, coilFieldZoneRepo.Object, webSocketClientService.Object);
      coilRepo.Setup(repo => repo.GetCoilsByCoilField(1))
    .Returns(list);

      var result = _service.GetCoilsByCoilField(1);

      Assert.NotNull(result);
    }

    [Fact]
    public void GetCoilsFieldAssociationType_Id_ReturnsListOfString()
    {
      var list = new List<Coil>{new Coil
      {
        Id = 1,
        FTZ="1"
      }
      };

      var mapper = InitializeMapper();
      var _service = new CoilFieldsService(coilFieldRepo.Object, coilRepo.Object, coilFieldServiceLogger.Object, mapper, coilFieldZoneRepo.Object, webSocketClientService.Object);

      coilRepo.Setup(repo => repo.GetCoilsByCoilField(1))
    .Returns(list);

      var result = _service.GetCoilsFieldAssociationType(1);

      Assert.NotNull(result);
    }




    [Fact]
    public void DisableCoilField_IdAnddisable_ReturnsFalse()
    {

      var dto = new List<Coil>();


      var mapper = InitializeMapper();
      var _service = new CoilFieldsService(coilFieldRepo.Object, coilRepo.Object, coilFieldServiceLogger.Object, mapper, coilFieldZoneRepo.Object, webSocketClientService.Object);
      coilRepo.Setup(repo => repo.GetCoilsByCoilField(1))
   .Returns(dto);
      coilFieldRepo.Setup(repo => repo.DisableCoilField(1, true))
    .Returns(true);

      var result = _service.DisableCoilField(1, true);

      Assert.False(result);
    }

    [Fact]
    public void CoilFieldExist_Id_ReturnsBool()
    {
      var list = new CoilField
      {
        Id = 1,
        Name = "1"

      };

      var mapper = InitializeMapper();
      var _service = new CoilFieldsService(coilFieldRepo.Object, coilRepo.Object, coilFieldServiceLogger.Object, mapper, coilFieldZoneRepo.Object, webSocketClientService.Object);
      coilFieldRepo.Setup(repo => repo.GetCoilFieldById(1))
     .Returns(list);

      var result = _service.CoilFieldExists(1);

      Assert.True(result);
    }

    [Fact]
    public void UpdateCoilField_IdAndDto_ReturnsFalse()
    {

      var dto = new List<Coil>();
      var coilField = new CoilField
      {
        Id = 1,
        Name = "1"

      };
      var coilFielddto = new CoilFieldDto
      {
        Id = 1,
        Name = "1",
        ZoneId = new List<int> { 1 }

      };
      var zoneIds = new List<int> { 1 };
      var zones = new List<CoilFieldZone> { new CoilFieldZone { Id = 1 } };
      var mapper = InitializeMapper();
      var _service = new CoilFieldsService(coilFieldRepo.Object, coilRepo.Object, coilFieldServiceLogger.Object, mapper, coilFieldZoneRepo.Object, webSocketClientService.Object);
      coilRepo.Setup(repo => repo.GetCoilsByCoilField(1))
   .Returns(dto);
      coilFieldRepo.Setup(repo => repo.GetCoilFieldById(1))
    .Returns(coilField);
      coilFieldRepo.Setup(repo => repo.UpdateCoilField(1, coilField))
    .Returns(true);
      coilFieldZoneRepo.Setup(repo => repo.GetCoilFieldZoneByIds(zoneIds))
    .Returns(zones);

      _service.UpdateCoilFieldDto(1, coilFielddto);
      Assert.True(true);
    }

    [Fact]
    public void SaveCoilField_CoilField_ReturnsBool()
    {

      var model = new CoilField()
      {
        Id = 1,
        Disabled = false,
        Name = "TMMI"
      };
      var dto = new CoilFieldDto()
      {
        Id = 1,
        Disabled = false,
        Name = "TMMI"
      };

      var mapper = InitializeMapper();
      var _service = new CoilFieldsService(coilFieldRepo.Object, coilRepo.Object, coilFieldServiceLogger.Object, mapper, coilFieldZoneRepo.Object, webSocketClientService.Object);
      coilFieldRepo.Setup(repo => repo.SaveCoilField(model))
     .Returns(true);
      _service.SaveCoilFieldDto(dto);

      Assert.True(true);
    }

    [Fact]
    public void DeleteCoilField_Id_ReturnscoilField()
    {

      var model = new CoilField()
      {
        Id = 1,
        Disabled = false,
        Name = "TMMI"
      };

      var mapper = InitializeMapper();
      var _service = new CoilFieldsService(coilFieldRepo.Object, coilRepo.Object, coilFieldServiceLogger.Object, mapper, coilFieldZoneRepo.Object, webSocketClientService.Object);
      coilFieldRepo.Setup(repo => repo.DeleteCoilField(1))
     .Returns(model);

      var result = _service.DeleteCoilField(1);

      Assert.NotNull(result);
    }
  }
}
