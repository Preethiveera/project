using CoilTracking.Business.Implementation;
using CoilTracking.Common.Logging;
using CoilTracking.DataAccess.Interfaces;
using Moq;
using System.IO;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class ImportPressPatternTest
  {
    private Mock<ILineRepository> mockLineRepo;
    private Mock<IShiftRepository> mockShiftRepo;
    private Mock<IPatternCalendarRepository> mockPatternCalenderRepo;
    private Mock<IPartRepository> mockPartRepo;
    private Mock<IApplicationLogger<ImportPressPattern>> logger;

    public ImportPressPatternTest()
    {
      mockLineRepo = new Mock<ILineRepository>();
      mockShiftRepo = new Mock<IShiftRepository>();
      mockPatternCalenderRepo = new Mock<IPatternCalendarRepository>();
      mockPartRepo = new Mock<IPartRepository>();
      logger = new Mock<IApplicationLogger<ImportPressPattern>>();
    }

    [Fact]
    public void ImportMemoryStream()
    {
      var ms = new MemoryStream();
      var service = new ImportPressPattern(mockLineRepo.Object, mockShiftRepo.Object, mockPatternCalenderRepo.Object, mockPartRepo.Object, logger.Object);
      var result = service.Import(ms, "");
      Assert.NotNull(result);
    }
  }
}
