using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using Microsoft.AspNetCore.Http;
using Moq;
using System.Collections.Generic;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class UserEventServiceTest
  {
    private readonly Mock<IUserEventRepository> repo;
    private readonly Mock<IApplicationLogger<UserEventService>> logger;
    private readonly Mock<IPlantsRepository> plantrepo;
    private readonly Mock<IHttpContextAccessor> httpContextAccessor;
    public IMapper InitializeMapper()
    {
      var mockMapper = new MapperConfiguration(cfg =>
      {
        cfg.AddProfile(new MappingProfile());
      });
      var mapper = mockMapper.CreateMapper();

      return mapper;
    }

    public UserEventServiceTest()
    {
      this.repo = new Mock<IUserEventRepository>();
      this.logger = new Mock<IApplicationLogger<UserEventService>>();
      this.plantrepo = new Mock<IPlantsRepository>();
      this.httpContextAccessor = new Mock<IHttpContextAccessor>();
    }

    [Fact]
    public void GetUserEventById_Returnsevents()
    {
      var events = new UserEvent { Id = 1 };
      var mapper = InitializeMapper();
      var _service = new UserEventService(repo.Object,plantrepo.Object, mapper, logger.Object, httpContextAccessor.Object);
     repo.Setup(repo => repo.GetUserEventById(1))
    .ReturnsAsync(events);

      var result = _service.GetUserEventById(1);

      Assert.NotNull(result);
    }
    [Fact]
    public void GetUserEvents_Returnsevents()
    {
      var events = new List<UserEvent>{ new UserEvent { Id = 1 } };
      var mapper = InitializeMapper();
      var _service = new UserEventService(repo.Object, plantrepo.Object, mapper, logger.Object, httpContextAccessor.Object);

      repo.Setup(repo => repo.GetUserEvents())
     .ReturnsAsync(events);

      var result = _service.GetUserEvents();

      Assert.NotNull(result);
    }
    [Fact]
    public void GetUserEventsBetween_Returnsevents()
    {
      var events = new List<UserEvent> { new UserEvent { Id = 1 , UserName="test"} };
      var mapper = InitializeMapper();
      var _service = new UserEventService(repo.Object, plantrepo.Object, mapper, logger.Object, httpContextAccessor.Object);
      repo.Setup(repo => repo.GetUserEventsBetween(null, null, "test"))
     .ReturnsAsync(events);

      var result = _service.GetUserEventsBetween(null, null, "test") ;

      Assert.NotNull(result);
    }

    [Fact]
    public void InsertUserEventsBetween_Returnsevents()
    {
      var events = new UserEvent { Id = 1, UserName = "test"  };
      var eventsdto =  new UserEventDto { Id = 1, UserName = "test"  };

      var mapper = InitializeMapper();
      var _service = new UserEventService(repo.Object, plantrepo.Object, mapper, logger.Object, httpContextAccessor.Object);
      repo.Setup(repo => repo.InsertUserEvent(events))
     .ReturnsAsync(events);

      var result = _service.InsertUserEvent(eventsdto);

      Assert.NotNull(result);
    }
    [Fact]
    public void DeleteUserEventsBetween_Returnsevents()
    {
      var events = new UserEvent { Id = 1, UserName = "test" };
      
      var mapper = InitializeMapper();
      var _service = new UserEventService(repo.Object, plantrepo.Object, mapper, logger.Object, httpContextAccessor.Object);
      repo.Setup(repo => repo.DeleteUserEvent(1))
     .ReturnsAsync(events);

      var result = _service.DeleteUserEvent(1);

      Assert.NotNull(result);
    }
    [Fact]
    public void UpdateUserEventsBetween_Returnsevents()
    {
      var events = new UserEvent { Id = 1, UserName = "test" };
      var eventsdto = new UserEventDto { Id = 1, UserName = "test" };

      var mapper = InitializeMapper();
      var _service = new UserEventService(repo.Object, plantrepo.Object, mapper, logger.Object, httpContextAccessor.Object);
      repo.Setup(repo => repo.UpdateUserEvent(1, events))
     .Returns(events);

      _service.UpdateUserEvent(1, eventsdto);

      Assert.True(true);
    }
  }
}
