using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using Moq;
using System;
using System.Collections.Generic;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
 public class CoilsftzTest
  {
    private readonly Mock<IApplicationLogger<CoilsService>> coilServiceLogger;

    private readonly Mock<ICoilRepository> coilRepo;

    public CoilsftzTest()
    {
      coilServiceLogger = new Mock<IApplicationLogger<CoilsService>>();
      coilRepo = new Mock<ICoilRepository>();
    }
    [Fact]
    public void GetCoilsByFtz_Returnftz()
    {
      string sPrefixFtz = 'S' + "34353";
      string tPrefixFtz = 'T' + "564343";
      var mockCoilsservice = new MockCoilsservice();
      coilRepo.Setup(repo => repo.GetCoilsByFTZ(sPrefixFtz))
      .ReturnsAsync(mockCoilsservice.Getcoil());
      var _service = new CoilsFTZ(coilRepo.Object, coilServiceLogger.Object);
      var rr = _service.GetCoilFTZByPrefix(sPrefixFtz);
      Assert.NotNull(rr);
    }
  }
}

