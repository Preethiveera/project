using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace CoilTracking.Tests.Business_layer
{
  public class OPCConfigServiceTest
  {
    private readonly Mock<IOPCConfigRepository> configRepository;
    private readonly Mock<ILineRepository> lineRepo;
    private readonly Mock<IMapper> mapper;
    private readonly Mock<IApplicationLogger<OPCConfigService>> logger;

    public IMapper InitializeMapper()
    {
      var mockMapper = new MapperConfiguration(cfg =>
      {
        cfg.AddProfile(new MappingProfile());
      });
      var mapper = mockMapper.CreateMapper();

      return mapper;
    }
    public OPCConfigServiceTest()
    {
      configRepository = new Mock<IOPCConfigRepository>();
      lineRepo = new Mock<ILineRepository>();
      logger = new Mock<IApplicationLogger<OPCConfigService>>();
    }

    [Fact]
    public async Task GetOPCConfigs_ReturnsConfigs()
    {
      var list = new List<OPCConfig>
      {
        new OPCConfig{Id=1}
      };
      var mapper = InitializeMapper();
      var _service = new OPCConfigService(configRepository.Object,mapper, logger.Object, lineRepo.Object);
      
      configRepository.Setup(repo => repo.GetOPCConfigsAsync())
    .ReturnsAsync(list);

      var result =await  _service.GetOPCConfigs();

      Assert.NotNull(result);
    }
    [Fact]
    public async Task GetOPCConfigsById_ReturnsConfigs()
    {
      var list = 
        new OPCConfig{Id=1
      };
      var mapper = InitializeMapper();
      var _service = new OPCConfigService(configRepository.Object, mapper, logger.Object, lineRepo.Object);

      configRepository.Setup(repo => repo.GetOPCConfigById(1))
    .ReturnsAsync(list);

      var result = await _service.GetOPCConfigById(1);

      Assert.NotNull(result);
    }

    [Fact]
    public async Task GetDependencyForKep_ReturnsLines()
    {
      var list = new List<Line>
      {
        new Line{Id=1}
      };
      var mapper = InitializeMapper();
      var _service = new OPCConfigService(configRepository.Object, mapper, logger.Object, lineRepo.Object);

      lineRepo.Setup(repo => repo.GetLinesByOPcConfigId(1))
    .ReturnsAsync(list);

      var result = await _service.GetDependencyForKep(1);

      Assert.NotNull(result);
    }
    [Fact]
    public async Task UpdateOPCConfigs()
    {
      var list = 
        new OPCConfigDTO
        {
          Id=1
      };
      var mapper = InitializeMapper();
      var _service = new OPCConfigService(configRepository.Object, mapper, logger.Object, lineRepo.Object);

      
       Assert.Throws<CoilTrackingException>(() => _service.UpdateOPCConfig(2, list));

    }
    [Fact]
    public async Task OPCConfigExist_Returnsconfigs()
    {
      var list = 
        new OPCConfig{Id=1
      };
      var mapper = InitializeMapper();
      var _service = new OPCConfigService(configRepository.Object, mapper, logger.Object, lineRepo.Object);

      configRepository.Setup(repo => repo.OPCConfigExistsbyId(1))
    .Returns(list);

      _service.OPCConfigExists(1);

      Assert.True(true);
    }
    [Fact]
    public async Task OPCConfigExist_Returnsfalse()
    {
      
      var mapper = InitializeMapper();
      var _service = new OPCConfigService(configRepository.Object, mapper, logger.Object, lineRepo.Object);

      _service.OPCConfigExists(1);

      Assert.True(true);
    }
    [Fact]
    public void DisableOPCConfigs_ReturnsException()
    {
      var mapper = InitializeMapper();
      var _service = new OPCConfigService(configRepository.Object, mapper, logger.Object, lineRepo.Object);
    
      Assert.ThrowsAsync<CoilTrackingException>(() => _service.DisableOPCConfig(2, false));

    }

    [Fact]
    public void DeleteOPCConfigs_ReturnsException()
    {
      var mapper = InitializeMapper();
      var _service = new OPCConfigService(configRepository.Object, mapper, logger.Object, lineRepo.Object);

      Assert.ThrowsAsync<CoilTrackingException>(() => _service.DeleteOPCConfig(2));

    }
    
    [Fact]
    public void InsertOPCConfig_Returnsconfigs()
    {
      var list =
        new OPCConfig
        {
          Id = 1
        };
      var dto =
        new OPCConfigDTO
        {
          Id = 1
        };
      var mapper = InitializeMapper();
      var _service = new OPCConfigService(configRepository.Object, mapper, logger.Object, lineRepo.Object);

      configRepository.Setup(repo => repo.InsertOPCConfig(list))
    .ReturnsAsync(list);

     var res= _service.InsertOPCConfig(dto);

      Assert.NotNull(res);
    }

    [Fact]
    public void GetLinesInRunOrderById_Returnslines()
    {
      var list = new List<Line> { 
        new Line
        {
          Id = 1 }
        };
     
      var mapper = InitializeMapper();
      var _service = new OPCConfigService(configRepository.Object, mapper, logger.Object, lineRepo.Object);

      lineRepo.Setup(repo => repo.GetLinesByOPcConfigId(1))
    .ReturnsAsync(list);
      lineRepo.Setup(repo => repo.GetIncompleteRunLinesByLineList(list))
    .Returns(list);

      var res = _service.GetLinesInRunOrderById(1);

      Assert.NotNull(res);
    }
    [Fact]
    public async Task Checkedit_Returnsbool()
    {
      var dto =
        new OPCConfig
        {
          Id = 1
        };
      var list =
        new OPCConfigDTO
        {
          Id = 1
        };
      var mapper = InitializeMapper();
      var _service = new OPCConfigService(configRepository.Object, mapper, logger.Object, lineRepo.Object);

      configRepository.Setup(repo => repo.GetOPCConfigById(1))
    .ReturnsAsync(dto);

      var result = await _service.CheckIfEdited(1, list);

      Assert.True(true);
    }
  }
}
