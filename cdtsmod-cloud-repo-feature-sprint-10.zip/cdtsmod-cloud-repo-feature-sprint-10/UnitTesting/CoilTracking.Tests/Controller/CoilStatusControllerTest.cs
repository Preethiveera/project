using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Controllers;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Collections.Generic;
using Xunit;

namespace CoilTracking.Tests.Controller
{
  public class CoilStatusControllerTest
  {
    private readonly Mock<ICoilStatusService> coilStatusServiceMock;

    public CoilStatusControllerTest()
    {
      coilStatusServiceMock = new Mock<ICoilStatusService>();
    }


    [Fact]
    public void GetCoilStatuses_ReturnsGetCoilStatuses()
    {
      var coilStatus = new List<CoilStatusDto> { new CoilStatusDto
      {
        Id=1,
        Name="test"
      } };

      var controller = new CoilStatusController(coilStatusServiceMock.Object);
      coilStatusServiceMock.Setup(service => service.GetCoilStatuses())
        .ReturnsAsync(coilStatus);

      var result = controller.GetCoilStatuses();

      Assert.NotNull(result);
    }
    [Fact]
    public void GetCoilStatus_Id_ReturnsGetCoilStatuses()
    {
      var coilStatus = new CoilStatusDto
      {
        Id = 1,
        Name = "test"
      };

      var controller = new CoilStatusController(coilStatusServiceMock.Object);
      coilStatusServiceMock.Setup(service => service.GetCoilStatusById(1))
        .ReturnsAsync(coilStatus);

      var result = controller.GetCoilStatus(1);

      Assert.NotNull(result);
    }
    [Fact]
    public void GetCoilStatus_Id_ReturnsNotFound()
    {
      CoilStatusDto coilStatus = null;

      var controller = new CoilStatusController(coilStatusServiceMock.Object);
      coilStatusServiceMock.Setup(service => service.GetCoilStatusById(1))
        .ReturnsAsync(coilStatus);

      var result = controller.GetCoilStatus(1);

      Assert.IsType<NotFoundResult>(result.Result);
    }

    [Fact]
    public void PostCoilStatus_CoilStatusDto_ReturnsCoilStatusDto()
    {
      var coilStatus = new CoilStatusDto
      {
        Id = 1,
        Name = "test"
      };

      var controller = new CoilStatusController(coilStatusServiceMock.Object);

      var result = controller.PostCoilStatus(coilStatus);

      Assert.NotNull(result);
    }
    [Fact]
    public void PutCoilStatus_CoilStatusDtoId()
    {
      var coilStatus = new CoilStatusDto
      {
        Id = 1,
        Name = "test"
      };

      var controller = new CoilStatusController(coilStatusServiceMock.Object);

      var result = controller.PutCoilStatus(1, coilStatus);

      Assert.NotNull(result);
    }
    [Fact]
    public void PutCoilStatus_CoilStatusDto_ReturnsBadRequest()
    {
      var coilStatus = new CoilStatusDto
      {
        Id = 1,
        Name = "test"
      };

      var controller = new CoilStatusController(coilStatusServiceMock.Object);

      var result = controller.PutCoilStatus(2, coilStatus);

      Assert.IsType<BadRequestResult>(result);
    }
    [Fact]
    public void DeleteCoilStatus_Id_ReturnsNotFound()
    {
      CoilStatusDto coilStatus = null;
      var controller = new CoilStatusController(coilStatusServiceMock.Object);
      coilStatusServiceMock.Setup(service => service.DeleteCoilStatus(1))
        .Returns(coilStatus);

      var result = controller.DeleteCoilStatus(2);

      Assert.IsType<NotFoundResult>(result);
    }
    [Fact]
    public void DeleteCoilStatus_Id_ReturnsCoilstatus()
    {
      CoilStatusDto coilStatus = new CoilStatusDto
      {
        Id = 1
      };
      var controller = new CoilStatusController(coilStatusServiceMock.Object);
      coilStatusServiceMock.Setup(service => service.DeleteCoilStatus(1))
        .Returns(coilStatus);

      var result = controller.DeleteCoilStatus(2);

      Assert.NotNull(result);
    }
  }
}
