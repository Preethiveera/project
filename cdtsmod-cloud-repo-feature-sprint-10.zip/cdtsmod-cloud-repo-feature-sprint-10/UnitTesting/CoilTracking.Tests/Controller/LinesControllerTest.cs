using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Controllers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using System.Linq;
using Xunit;

namespace CoilTracking.Tests.Controller
{
  public class LinesControllerTest
  {
    private readonly Mock<ILineService> lineServiceMock;
    private readonly Mock<IConfiguration> config;
    private readonly Mock<ILogger<LinesController>> logger;
    public LinesControllerTest()
    {
      lineServiceMock = new Mock<ILineService>();
      config = new Mock<IConfiguration>();
      logger = new Mock<ILogger<LinesController>>();
    }

    [Fact]
    public void GetLines_ReturnsDto()
    {
      var mockService = new MockLineService();
      var controller = new LinesController(lineServiceMock.Object, config.Object, logger.Object);
      lineServiceMock.Setup(repo => repo.GetLines().Result)
      .Returns(mockService.GetLinesDto().AsQueryable());
      var result = controller.GetLines();
      Assert.NotNull(result);
    }

    [Fact]
    public void GetLine_ReturnsDto()
    {
      var mockService = new MockLineService();
      var controller = new LinesController(lineServiceMock.Object, config.Object, logger.Object);
      lineServiceMock.Setup(repo => repo.GetLineById(1).Result)
      .Returns(mockService.GetLinesDto().FirstOrDefault());
      var result = controller.GetLine(1);
      Assert.NotNull(result);
    }

    [Fact]
    public void GetLineForEdit_ReturnsDto()
    {
      var mockService = new MockLineService();
      var controller = new LinesController(lineServiceMock.Object, config.Object, logger.Object);
      lineServiceMock.Setup(repo => repo.GetLineForEdit(1).Result)
      .Returns(mockService.GetLinesDto().FirstOrDefault());
      var result = controller.GetLineForEdit(1);
      Assert.NotNull(result);
    }

    [Fact]
    public void UpdateLineSubscription_ReturnsDto()
    {
      var mockService = new MockLineService();
      var controller = new LinesController(lineServiceMock.Object, config.Object, logger.Object);
      lineServiceMock.Setup(repo => repo.UpdateLineSubscription(1, true, null).Result)
      .Returns(mockService.GetLinesDto().FirstOrDefault());
      var result = controller.UpdateLineSubscription(1, true);
      Assert.NotNull(result);
    }

    [Fact]
    public void GetSubscribedLines_ReturnsDto()
    {
      var mockService = new MockLineService();
      var controller = new LinesController(lineServiceMock.Object, config.Object, logger.Object);
      lineServiceMock.Setup(repo => repo.GetSubscribedLines("02").Result)
      .Returns(mockService.GetLineInfo());
      var result = controller.GetSubscribedLines("02");
      Assert.NotNull(result);
    }

    [Fact]
    public void DisableLine()
    {
      var controller = new LinesController(lineServiceMock.Object, config.Object, logger.Object);
      lineServiceMock.Setup(repo => repo.DisableLine(1, true));
      var result = controller.DisableLine(1, true).Result;
      Assert.IsType<NoContentResult>(result);
    }

    [Fact]
    public void PutLine()
    {
      var line = new LineDto
      {
        Id = 1
      };

      var controller = new LinesController(lineServiceMock.Object, config.Object, logger.Object);
      lineServiceMock.Setup(repo => repo.PutLine(line));
      var result = controller.PutLine(1, line).Result;
      Assert.IsType<NoContentResult>(result);
    }

    [Fact]
    public void UpdateLineDto()
    {
      var line = new LineDto
      {
        Id = 1
      };

      var controller = new LinesController(lineServiceMock.Object, config.Object, logger.Object);
      lineServiceMock.Setup(repo => repo.UpdateLine(1, line).Result)
        .Returns(line);
      var result = controller.UpdateLineDto(1, line).Result;
      Assert.NotNull(result);
    }

    [Fact]
    public void PostLine()
    {
      var line = new LineDto
      {
        Id = 1
      };

      var controller = new LinesController(lineServiceMock.Object, config.Object, logger.Object);
      lineServiceMock.Setup(repo => repo.AddLine(line).Result)
        .Returns(1);
      var result = controller.PostLine(line);
      Assert.NotNull(result);
    }

    [Fact]
    public void SaveLineDto()
    {
      var line = new LineDto
      {
        Id = 1
      };

      var controller = new LinesController(lineServiceMock.Object, config.Object, logger.Object);
      lineServiceMock.Setup(repo => repo.SaveLine(line).Result)
        .Returns(line);
      var result = controller.SaveLineDto(line);
      Assert.NotNull(result);
    }

    [Fact]
    public void PostLineData()
    {
      var lineData = new LineDataDto
      {
        Id = 1
      };

      var controller = new LinesController(lineServiceMock.Object, config.Object, logger.Object);
      lineServiceMock.Setup(repo => repo.PostLineData(lineData).Result)
        .Returns(lineData);
      var result = controller.PostLineData(lineData, "02");
      Assert.NotNull(result);
    }

    [Fact]
    public void DeleteLine()
    {
      var line = new LineDto
      {
        Id = 1
      };
      var controller = new LinesController(lineServiceMock.Object, config.Object, logger.Object);
      lineServiceMock.Setup(repo => repo.DeleteLine(1).Result)
        .Returns(line);
      var result = controller.DeleteLine(1);
      Assert.NotNull(result);
    }
  }
}
