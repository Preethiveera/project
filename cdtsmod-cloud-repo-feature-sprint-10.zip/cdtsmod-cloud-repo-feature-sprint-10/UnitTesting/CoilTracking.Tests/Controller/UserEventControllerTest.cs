using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Controllers;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace CoilTracking.Tests.Controller
{
 public class UserEventControllerTest
  {
    private readonly Mock<IUserEventService> userEventService;
    public UserEventControllerTest()
    {
      this.userEventService = new Mock<IUserEventService>();
    }

    [Fact]
    public async Task GetUserEvents_ReturnsEvents()
    {
      var events =new List<UserEventDto>{ new UserEventDto { Id = 1, UserName = "Test" }};
      var controller = new UserEventsController(userEventService.Object);

      userEventService.Setup(repo => repo.GetUserEvents())
     .ReturnsAsync(events);
      var result = await controller.GetUserEvents();
      Assert.NotNull(result);
    }

    [Fact]
    public async Task GetUserEventsBetween_TimeUserName_ReturnsEvents()
    {
      
      var events = new List<UserEventDto> { new UserEventDto { Id = 1, UserName = "Test" } };
      var controller = new UserEventsController(userEventService.Object);

      userEventService.Setup(repo => repo.GetUserEventsBetween(null, null, "test"))
     .ReturnsAsync(events);
      var result = await controller.GetUserEventsBetween(null,null, "test");
      Assert.NotNull(result);
    }

    [Fact]
    public void GetUserEventType()
    {
     var controller = new UserEventsController(userEventService.Object);

      var result =  controller.GetUserEventTypes();
      Assert.NotNull(result);
    }

    [Fact]
    public async Task GetUserEvents_Id_ReturnsEvent()
    {
      var events = new UserEventDto { Id = 1, UserName = "Test"  };
      var controller = new UserEventsController(userEventService.Object);

      userEventService.Setup(repo => repo.GetUserEventById(1))
     .ReturnsAsync(events);
      var result = await controller.GetUserEvent(1);
      Assert.NotNull(result);
    }
    [Fact]
    public async Task GetUserEvents_Id_ReturnsNotFound()
    {
      var events = new UserEventDto { Id = 1, UserName = "Test" };
      var controller = new UserEventsController(userEventService.Object);

      var result = await controller.GetUserEvent(1);
      Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public async Task PutUserEvents_IdUserEvent()
    {
      var events = new UserEventDto { Id = 1, UserName = "Test" };
      var controller = new UserEventsController(userEventService.Object);

      userEventService.Setup(repo => repo.UpdateUserEvent(1, events));

      var result = await controller.PutUserEvent(1, events);
      Assert.IsType<NoContentResult>(result);
    }
    [Fact]
    public async Task PutUserEvents_IdUserEvent_ReturnsBadReq()
    {
      var events = new UserEventDto { Id = 1, UserName = "Test" };
      var controller = new UserEventsController(userEventService.Object);

      userEventService.Setup(repo => repo.UpdateUserEvent(1, events));

      var result = await controller.PutUserEvent(11, events);
      Assert.IsType<BadRequestResult>(result);
    }
    //[Fact]
    //public async Task PostUserEvents_UserEvent_ReturnsEvents()
    //{
    //  var events = new UserEventDto { Id = 1, UserName = "Test" };
    //  var controller = new UserEventsController(userEventService.Object);

    //  userEventService.Setup(repo => repo.InsertUserEvent(events))
    //    .ReturnsAsync(events);

    //  var result = await controller.PostUserEvent(events);
    //  Assert.NotNull(result);
    //}
    [Fact]
    public async Task DeleteUserEvents_UserEvent_ReturnsEvents()
    {
      var events = new UserEventDto { Id = 1, UserName = "Test" };
      var controller = new UserEventsController(userEventService.Object);

      userEventService.Setup(repo => repo.DeleteUserEvent(1))
        .ReturnsAsync(events);

      var result = await controller.DeleteUserEvent(1);
      Assert.NotNull(result);
    }
    [Fact]
    public async Task DeleteUserEvents_UserEvent_ReturnsNotFound()
    {
      var controller = new UserEventsController(userEventService.Object);

      var result = await controller.DeleteUserEvent(1);
      Assert.IsType<NotFoundResult>(result);
    }

  }


}
