using CoilTracking.Business.Interfaces;
using CoilTracking.Data.Models;
using CoilTracking.Tests.Service;
using CoilTracking.WebAPI.Controllers;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Linq;
using Xunit;

namespace CoilTracking.Tests.Controller
{
  public class CoilMoveRequestControllerTest
  {
    private readonly Mock<ICoilMoveRequestService> coilFieldLocationServiceMock;

    public CoilMoveRequestControllerTest()
    {
      coilFieldLocationServiceMock = new Mock<ICoilMoveRequestService>();
    }

    [Fact]
    public void GetCoilMoveRequests()
    {
      var mockService = new MockCoilMoveRequestService();
      var controller = new CoilMoveRequestsController(coilFieldLocationServiceMock.Object);
      coilFieldLocationServiceMock.Setup(repo => repo.GetCoilMoveRequests().Result)
      .Returns(mockService.GetCoilMoveRequests());
      var result = controller.GetCoilMoveRequests();
      Assert.NotNull(result);
    }

    [Fact]
    public void GetPendingRequestsByLine_ReturnsDto()
    {
      var mockService = new MockCoilMoveRequestService();
      var controller = new CoilMoveRequestsController(coilFieldLocationServiceMock.Object);
      coilFieldLocationServiceMock.Setup(repo => repo.GetPendingRequestsByLine(1, null, null).Result)
      .Returns(mockService.GetCoilMoveRequests());
      var result = controller.GetPendingRequestsByLine(1);
      Assert.NotNull(result);
    }

    [Fact]
    public void GetUnfulfilledCoilMoveRequests_ReturnsDto()
    {
      var mockService = new MockCoilMoveRequestService();
      var controller = new CoilMoveRequestsController(coilFieldLocationServiceMock.Object);
      coilFieldLocationServiceMock.Setup(repo => repo.GetUnfulfilledCoilMoveRequests().Result)
      .Returns(mockService.GetCoilMoveRequests().ToList());
      var result = controller.GetUnfulfilledCoilMoveRequests();
      Assert.NotNull(result);
    }

    [Fact]
    public void CancelCoilMove_Returns_Ok()
    {
      var mockService = new MockCoilMoveRequestService();
      var controller = new CoilMoveRequestsController(coilFieldLocationServiceMock.Object);
      coilFieldLocationServiceMock.Setup(repo => repo.CancelCoilMove(1).Result)
      .Returns(true);
      var result = controller.CancelCoilMove(1).Result;
      Assert.IsType<OkObjectResult>(result);
    }

    [Fact]
    public void RequestCoilMove_Returns_Id()
    {
      var mockService = new MockCoilMoveRequestService();
      var controller = new CoilMoveRequestsController(coilFieldLocationServiceMock.Object);
      coilFieldLocationServiceMock.Setup(repo => repo.RequestCoilMove(1, 1, CoilMoveRequestType.CoilReject, null).Result)
      .Returns(mockService.GetCoilMoveRequests().FirstOrDefault());
      var result = controller.RequestCoilMove(1, 1, CoilMoveRequestType.CoilReject);
      Assert.NotNull(result);
    }

    [Fact]
    public void FulfillCoilMoveRequest_Returns_dto()
    {
      var mockService = new MockCoilMoveRequestService();
      var controller = new CoilMoveRequestsController(coilFieldLocationServiceMock.Object);
      coilFieldLocationServiceMock.Setup(repo => repo.FulfillCoilMoveRequest(1, "", "").Result)
      .Returns(mockService.GetCoilMoveRequests().FirstOrDefault());
      var result = controller.FulfillCoilMoveRequest(1, "", "").Result;
      Assert.IsType<OkObjectResult>(result);
    }

    [Fact]
    public void GetCoilMoveRequest_Returns_Ok()
    {
      var mockService = new MockCoilMoveRequestService();
      var controller = new CoilMoveRequestsController(coilFieldLocationServiceMock.Object);
      coilFieldLocationServiceMock.Setup(repo => repo.GetCoilMoveRequestAsync(1).Result)
      .Returns(mockService.GetCoilMoveRequestById(1));
      var result = controller.GetCoilMoveRequest(1).Result;
      Assert.IsType<OkObjectResult>(result);
    }

    [Fact]
    public void GetCoilMoveRequest_Returns_NotFound()
    {
      var mockService = new MockCoilMoveRequestService();
      var controller = new CoilMoveRequestsController(coilFieldLocationServiceMock.Object);
      coilFieldLocationServiceMock.Setup(repo => repo.GetCoilMoveRequestAsync(2).Result)
      .Returns(mockService.GetCoilMoveRequestById(2));
      var result = controller.GetCoilMoveRequest(1).Result;
      Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public void PostCoilMoveRequest()
    {
      var mockService = new MockCoilMoveRequestService();
      var controller = new CoilMoveRequestsController(coilFieldLocationServiceMock.Object);
      coilFieldLocationServiceMock.Setup(repo => repo.PostCoilMoveRequestAsync(mockService.GetCoilMoveRequestById(1)).Result)
      .Returns(mockService.GetCoilMoveRequestById(1));
      var result = controller.PostCoilMoveRequest(mockService.GetCoilMoveRequestById(1));
      Assert.NotNull(result);
    }

    [Fact]
    public void DeleteCoilMoveRequest()
    {
      var mockService = new MockCoilMoveRequestService();
      var controller = new CoilMoveRequestsController(coilFieldLocationServiceMock.Object);
      coilFieldLocationServiceMock.Setup(repo => repo.DeleteCoilMoveRequest(1).Result)
      .Returns(mockService.GetCoilMoveRequestById(1));
      var result = controller.DeleteCoilMoveRequest(1);
      Assert.NotNull(result);
    }

    [Fact]
    public void GetLoadedCoils_Returns_LoadedCoils()
    {
      var mockService = new MockCoilMoveRequestService();
      var controller = new CoilMoveRequestsController(coilFieldLocationServiceMock.Object);
      coilFieldLocationServiceMock.Setup(repo => repo.GetLoadedCoils(1, 1).Result)
      .Returns(mockService.GetLoadedCoils());
      var result = controller.GetLoadedCoils(1, 1);
      Assert.NotNull(result);
    }
  }
}
