using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Exception;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using CoilTracking.WebAPI.Controllers;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace CoilTracking.Tests.Controller
{
  public class RunOrderListControllerTest
  {
    private readonly Mock<IRunOrderListService> runOrderListServiceMock;

    public RunOrderListControllerTest()
    {
      runOrderListServiceMock = new Mock<IRunOrderListService>();
    }

    [Fact]
    public void GetRunOrderLists_ReturnsGetRunOrderLists()
    {
      var service = new MockRunOrderListService();
      var controller = new RunOrderListsController(runOrderListServiceMock.Object);
      runOrderListServiceMock.Setup(repo => repo.GetRunOrderLists())
      .ReturnsAsync(service.GetRunOrderList());
      var result = controller.GetRunOrderLists();
      Assert.NotNull(result);
    }

    [Fact]
    public void GetRunOrderListsById_ReturnsGetRunOrderLists()
    {
      var service = new MockRunOrderListService();
      var controller = new RunOrderListsController(runOrderListServiceMock.Object);
      runOrderListServiceMock.Setup(repo => repo.GetRunOrderListById(1))
      .ReturnsAsync(service.GetRunOrderListById(1));
      var result = controller.GetRunOrderList(1);
      Assert.NotNull(result);
    }
    [Fact]
    public async Task GetRunOrderListsById_ReturnsNotFoundAsync()
    {
      var service = new MockRunOrderListService();
      var controller = new RunOrderListsController(runOrderListServiceMock.Object);
      runOrderListServiceMock.Setup(repo => repo.GetRunOrderListById(1))
      .ReturnsAsync(service.GetRunOrderListById(2));
      var result = await controller.GetRunOrderList(1);
      Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public void MarkRunOrderItemStarted_ReturnsNoContent()
    {
      var controller = new RunOrderListsController(runOrderListServiceMock.Object);
      var result = controller.MarkRunOrderItemStarted(1);
      Assert.NotNull(result);
    }

    [Fact]
    public void MarkRunOrderItemCompleted_ReturnsNoContent()
    {
      var controller = new RunOrderListsController(runOrderListServiceMock.Object);
      var result = controller.MarkRunOrderItemComplete(1);
      Assert.NotNull(result);
    }

    [Fact]
    public void CreateRunOrderList_ReturnsRunOrderListForCreate()
    {
      DateTime date = DateTime.Now;
      var service = new MockRunOrderListService();
      var controller = new RunOrderListsController(runOrderListServiceMock.Object);
      runOrderListServiceMock.Setup(repo => repo.CreateRunOrderList(date, 1, 1))
      .ReturnsAsync(service.GetRunOrderListForCreate());
      var result = controller.CreateRunOrderList(date, 1, 1);
      Assert.NotNull(result);
    }

    [Fact]
    public void GetRunOrderList_ReturnsRunOrderListForGet()
    {
      DateTime date = DateTime.Now;
      var service = new MockRunOrderListService();
      var controller = new RunOrderListsController(runOrderListServiceMock.Object);
      runOrderListServiceMock.Setup(repo => repo.GetRunOrderItemForGet(date, 1, 1))
      .ReturnsAsync(service.GetRunOrderListForGet());
      var result = controller.GetRunOrderList(date, 1, 1);
      Assert.NotNull(result);
    }

    [Fact]
    public void DeleteRunOrderList_Id()
    {
      var controller = new RunOrderListsController(runOrderListServiceMock.Object);
      runOrderListServiceMock.Setup(repo => repo.DeleteRunOrderList(1))
      .ReturnsAsync(true);
      var result = controller.DeleteRunOrderList(1);
      Assert.NotNull(result);
    }
    [Fact]
    public void DeleteRunOrderList_Id_ReturnsNotFound()
    {
      var controller = new RunOrderListsController(runOrderListServiceMock.Object);
      runOrderListServiceMock.Setup(repo => repo.DeleteRunOrderList(1))
      .ReturnsAsync(false);
      var result = controller.DeleteRunOrderList(1).Result;
      Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public void SaveRunOrderList_RunOrderListForUpdate_ReturnsBadRequest()
    {
      RunOrderListForUpdate runItem = null;
      var controller = new RunOrderListsController(runOrderListServiceMock.Object);

      Assert.ThrowsAsync<CoilTrackingException>(() => controller.SaveRunOrderList(runItem));

    }
    [Fact]
    public void SaveRunOrderList_RunOrderListForUpdate_ReturnsBadRequestForDataId()
    {
      RunOrderListForUpdate runItem = new RunOrderListForUpdate
      {
        Id = 1,
        RunOrderItems = new List<RunOrderItemForUpdate> { new RunOrderItemForUpdate
        {
          Id=0
        } }
      };
      var controller = new RunOrderListsController(runOrderListServiceMock.Object);

      Assert.ThrowsAsync<CoilTrackingException>(() => controller.SaveRunOrderList(runItem));

    }
    [Fact]
    public void SaveRunOrderList_RunOrderListForUpdate_ReturnsRunOrderList()
    {
      RunOrderListForUpdate runItem = new RunOrderListForUpdate
      {
        Id = 1,
        RunOrderItems = new List<RunOrderItemForUpdate> { new RunOrderItemForUpdate
        {
          Id=0
        } }
      };
      RunOrderListForCreate res = new RunOrderListForCreate { Id = 1 };
      var controller = new RunOrderListsController(runOrderListServiceMock.Object);
      runOrderListServiceMock.Setup(repo => repo.SaveRunOrderList(runItem))
      .ReturnsAsync(res);
      var result = controller.SaveRunOrderList(runItem);
      Assert.NotNull(result);
    }

    [Fact]
    public void UpdateRunOrderList_RunOrderListForUpdate()
    {
      RunOrderListForUpdate runItem = new RunOrderListForUpdate
      {
        Id = 1,
        RunOrderItems = new List<RunOrderItemForUpdate> { new RunOrderItemForUpdate
        {
          Id=0
        } }
      };
      var controller = new RunOrderListsController(runOrderListServiceMock.Object);
      var result = controller.UpdateRunOrderList(1, runItem);
      Assert.NotNull(result);
    }
    [Fact]
    public void UpdateRunOrderList_RunOrderListForUpdate_ReturnsBadRequest()
    {
      RunOrderListForUpdate runItem = new RunOrderListForUpdate
      {
        Id = 1,
        RunOrderItems = new List<RunOrderItemForUpdate> { new RunOrderItemForUpdate
        {
          Id=0
        } }
      };
      var controller = new RunOrderListsController(runOrderListServiceMock.Object);

      var result = controller.UpdateRunOrderList(2, runItem).Result;
      Assert.IsType<BadRequestResult>(result);
    }

  }
}
