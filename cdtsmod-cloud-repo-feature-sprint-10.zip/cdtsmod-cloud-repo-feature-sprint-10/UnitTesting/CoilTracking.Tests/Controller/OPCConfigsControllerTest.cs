using CoilTracking.Business.Implementation;
using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Controllers;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace CoilTracking.Tests.Controller
{
 public class OPCConfigsControllerTest
  {
    private readonly Mock<IOPCConfigService> configService;
    public OPCConfigsControllerTest()
    {
      this.configService = new Mock<IOPCConfigService>();
    }
    [Fact]
    public void GetOPCConfigs_ReturnsOPCConfigs()
    {
      List<OPCConfigDTO> list = new List<OPCConfigDTO>() {
        new OPCConfigDTO{Id=1}
      };
      var t = list.AsQueryable();
      var controller = new OPCConfigsController(configService.Object);
      configService.Setup(repo => repo.GetOPCConfigs())
      .ReturnsAsync(t);

      var result = controller.GetOPCConfigs();
      Assert.NotNull(result);
    }
    [Fact]
    public void GetOPCConfigsById_ReturnsOPCConfigs()
    {
      var list = 
        new OPCConfigDTO{Id=1
      };
      
      var controller = new OPCConfigsController(configService.Object);
      configService.Setup(repo => repo.GetOPCConfigById(1))
      .ReturnsAsync(list);

      var result = controller.GetOPCConfig(1);
      Assert.NotNull(result);
    }

    [Fact]
    public async Task GetOPCConfigsById_Returnsnull()
    {
      var controller = new OPCConfigsController(configService.Object);
     
      var result =await controller.GetOPCConfig(1);
      Assert.IsType<NotFoundResult>(result);
    }
    [Fact]
    public async Task KepGetDependency_ReturnsLines()
    {
      var list =new List<LineDto> { 
        new LineDto
        {
          Id = 1 }
        };

      var controller = new OPCConfigsController(configService.Object);
      configService.Setup(repo => repo.GetDependencyForKep(1))
      .ReturnsAsync(list);

      var result =await controller.KepGetDependency(1);
      Assert.NotNull(result);
    }

    [Fact]
    public void PutOPCConfigs_Returnsnull()
    {
      var controller = new OPCConfigsController(configService.Object);
      var config = new OPCConfigDTO { Id = 2 };
      var result =  controller.PutOPCConfig(1,config);
      Assert.IsType<BadRequestResult>(result);
    }
    [Fact]
    public void PutOPCConfigs_ReturnsNoContent()
    {
      var controller = new OPCConfigsController(configService.Object);
      var config = new OPCConfigDTO { Id = 1 };
      var result = controller.PutOPCConfig(1, config);
      Assert.IsType<NoContentResult>(result);
    }
    [Fact]
    public async Task DisableOPCConfigs_ReturnsNoContent()
    {
      var controller = new OPCConfigsController(configService.Object);
      
      var result =await controller.DisableOPCConfig(1, true);
      Assert.IsType<NoContentResult>(result);
    }

    [Fact]
    public async Task PostOPCConfigs_Returnsconfig()
    {
      var controller = new OPCConfigsController(configService.Object);
      var config = new OPCConfigDTO { Id = 1 };
      configService.Setup(repo => repo.InsertOPCConfig(config))
     .ReturnsAsync(config);
      var result = await controller.PostOPCConfig(config);
      Assert.NotNull(result);
    }
    [Fact]
    public async Task DeleteOPCConfigs_Returnsconfig()
    {
      var controller = new OPCConfigsController(configService.Object);
      var config = new OPCConfigDTO { Id = 1 };
      configService.Setup(repo => repo.DeleteOPCConfig(1))
     .ReturnsAsync(config);
      var result = await controller.DeleteOPCConfig(1);
      Assert.NotNull(result);
    }

    [Fact]
    public async Task GetLinesInRunOrderList_ReturnsLines()
    {
      var controller = new OPCConfigsController(configService.Object);
      var config =new List<LineDto> { new LineDto { Id = 1 } };
      configService.Setup(repo => repo.GetLinesInRunOrderById(1))
     .ReturnsAsync(config);
      var result = await controller.GetLinesInRunOrderById(1);
      Assert.NotNull(result);
    }

    [Fact]
    public async Task CheckDependency_ReturnsLines()
    {
      var controller = new OPCConfigsController(configService.Object);
      var config = new List<LineDto> { new LineDto { Id = 1 } };
      configService.Setup(repo => repo.GetLinesInRunOrderById(1))
     .ReturnsAsync(config);
      var result = await controller.CheckDependency(1);
      Assert.NotNull(result);
    }
    [Fact]
    public async Task CheckEdit_Returnsbool()
    {
      var controller = new OPCConfigsController(configService.Object);
      var config =  new OPCConfigDTO { Id = 1  };
      configService.Setup(repo => repo.CheckIfEdited(1,config))
     .ReturnsAsync(false);
      var result = await controller.CheckEdit(1,config);
      Assert.IsType<BadRequestResult>(result);
    }


  }
}
