using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using CoilTracking.WebAPI.Controllers;
using Moq;
using System;
using System.Threading.Tasks;
using Xunit;

namespace CoilTracking.Tests.Controller
{
  public class PatternCalendarControllerTest
  {
    private readonly Mock<IPatternCalendarService> patternCalendarServiceMock;

    public PatternCalendarControllerTest()
    {
      patternCalendarServiceMock = new Mock<IPatternCalendarService>();
    }

    [Fact]
    public void GetPatternLetterTest_ReturnsCalendarItemDtos()
    {
      var mockPatternCalendarService = new MockPatternCalendarService();

      var controller = new PatternCalendarController(patternCalendarServiceMock.Object);
      patternCalendarServiceMock.Setup(service => service.GetPatternCalendars())
        .Returns(mockPatternCalendarService.GetPatternCalendars());

      var result = controller.GetPatternCalendars();

      Assert.NotNull(result);
    }

    [Fact]
    public async Task GetPatternCalendarsForExport_ReturnsPatternCalendarExportDto()
    {
      var mockPatternCalendarService = new MockPatternCalendarService();

      var controller = new PatternCalendarController(patternCalendarServiceMock.Object);
      patternCalendarServiceMock.Setup(service => service.GetPatternCalendarsForExport())
        .ReturnsAsync(mockPatternCalendarService.GetPatternCalendarsForExport());

      var result = await controller.GetPatternCalendarsForExport();

      Assert.NotNull(result);
    }

    [Fact]
    public async Task GetPatternCalendar_Id_ReturnsPatternCalendarDto()
    {
      var mockPatternCalendarService = new MockPatternCalendarService();

      var controller = new PatternCalendarController(patternCalendarServiceMock.Object);
      var id = 1;
      patternCalendarServiceMock.Setup(service => service.GetPatternCalendar(id))
        .ReturnsAsync(mockPatternCalendarService.GetPatternCalendarDto());

      var result = await controller.GetPatternCalendar(id);

      Assert.NotNull(result);
    }

    [Fact]
    public async Task GetPatternCalendar_LineId_ShiftId_ReturnsNull()
    {
      var mockPatternCalendarService = new MockPatternCalendarService();


      var controller = new PatternCalendarController(patternCalendarServiceMock.Object);
      var shiftId = 1;
      var lineId = 1;
      patternCalendarServiceMock.Setup(service => service.GetPatternCalendar(DateTime.Today.Date, shiftId, lineId))
        .ReturnsAsync(mockPatternCalendarService.GetPatternCalendars());

      var result = await controller.GetPatternCalendar(shiftId, lineId);

      Assert.NotNull(result);
    }

    [Fact]
    public async Task ChangePattern_Id_PatternLetter_ReturnsTrue()
    {
      var mockPatterCalendarService = new MockPatternCalendarService();

      var controller = new PatternCalendarController(patternCalendarServiceMock.Object);
      var id = 1;
      var pattern = "P";
      patternCalendarServiceMock.Setup(service => service.ChangePattern(id, pattern))
        .ReturnsAsync(true);

      var result = await controller.ChangePattern(id, pattern);

      Assert.NotNull(result);
    }

    [Fact]
    public async Task PutPatternCalendar_Id_PatternCalendarDto_ReturnsTrue()
    {
      var mockPatternCalendarService = new MockPatternCalendarService();

      var controller = new PatternCalendarController(patternCalendarServiceMock.Object);
      var id = 1;
      patternCalendarServiceMock.Setup(service => service.PutPatternCalendar(It.IsAny<PatternCalendarDto>()))
        .ReturnsAsync(true);

      var result = await controller.PutPatternCalendar(id, mockPatternCalendarService.GetPatternCalendarDto());

      Assert.NotNull(result);
    }

    [Fact]
    public async Task PostPatternCalendar_PatternCalendarDto_ReturnsPatternCalendarDto()
    {
      var mockPatternCalendarService = new MockPatternCalendarService();

      var controller = new PatternCalendarController(patternCalendarServiceMock.Object);

      patternCalendarServiceMock.Setup(service => service.PostPatternCalendar(It.IsAny<PatternCalendarDto>()))
        .ReturnsAsync(mockPatternCalendarService.GetPatternCalendarDto());

      var result = await controller.PostPatternCalendar(mockPatternCalendarService.GetPatternCalendarDto());

      Assert.NotNull(result);
    }

    [Fact]
    public async Task DeletePatternCalendar_PatternCalendarDto_PatternLetter_ReturnsPatternCalendarDto()
    {
      var mockPatternCalendarService = new MockPatternCalendarService();

      var controller = new PatternCalendarController(patternCalendarServiceMock.Object);
      var id = 1;
      patternCalendarServiceMock.Setup(service => service.DeletePatternCalendar(id))
        .ReturnsAsync(mockPatternCalendarService.GetPatternCalendarDto());

      var result = await controller.DeletePatternCalendar(id);

      Assert.NotNull(result);
    }
  }
}
