using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using CoilTracking.WebAPI.Controllers;
using Moq;
using System.Threading.Tasks;
using Xunit;

namespace CoilTracking.Tests.Controller
{
  public class CoilFieldZonesControllerTest
  {
    private readonly Mock<ICoilFieldZonesService> coilFieldZonesService;
    public CoilFieldZonesControllerTest()
    {
      coilFieldZonesService = new Mock<ICoilFieldZonesService>();
    }

    [Fact]
    public async Task GetCoilFieldZones_ReturnsCoilFieldZones()
    {
      var _mockCoilFieldsService = new MockCoilFieldZoneService();

      var controller = new CoilFieldZonesController(coilFieldZonesService.Object);

      coilFieldZonesService.Setup(serv => serv.GetCoilFieldZones())
         .Returns(_mockCoilFieldsService.GetCoilFieldZones());

      var result = await controller.GetCoilFieldZones();
      Assert.NotNull(result);
    }

    [Fact]
    public async Task GetCoilFieldZonesById_ReturnsCoilFieldZone()
    {
      var _mockCoilFieldsService = new MockCoilFieldZoneService();

      var controller = new CoilFieldZonesController(coilFieldZonesService.Object);

      var zoneId = 1;



      coilFieldZonesService.Setup(serv => serv.GetCoilFieldZone(zoneId))
      .Returns(_mockCoilFieldsService.GetCoilFieldZone(zoneId));

      var result = await controller.GetCoilFieldZones(zoneId);
      Assert.NotNull(result);
    }

    [Fact]
    public async Task GetCoilFieldZoneForEdit_ReturnsCoilFieldZone()
    {
      var _mockCoilFieldsService = new MockCoilFieldZoneService();

      var controller = new CoilFieldZonesController(coilFieldZonesService.Object);

      var zoneId = 1;

      coilFieldZonesService.Setup(serv => serv.GetCoilFieldZoneForEdit(zoneId))
      .Returns(_mockCoilFieldsService.GetCoilFieldZoneForEdit(zoneId));

      var result = await controller.GetCoilFieldZoneForEdit(zoneId);
      Assert.NotNull(result);
    }

    [Fact]
    public async Task GetAssociatedItemsCoilFieldsZone_ReturnsCoilType()
    {
      var _mockCoilFieldsService = new MockCoilFieldZoneService();

      var controller = new CoilFieldZonesController(coilFieldZonesService.Object);

      var zoneId = 1;

      coilFieldZonesService.Setup(serv => serv.GetAssociatedItemsCoilFieldsZone(zoneId))
      .Returns(_mockCoilFieldsService.GetAssociatedItemsCoilFieldsZone(zoneId));

      var result = await controller.GetAssociatedItemsCoilFieldsZone(zoneId);
      Assert.NotNull(result);
    }

    [Fact]
    public async Task GetCoilsByZoneId_ReturnsCoils()
    {
      var _mockCoilFieldsService = new MockCoilFieldZoneService();

      var controller = new CoilFieldZonesController(coilFieldZonesService.Object);

      var zoneId = 1;

      coilFieldZonesService.Setup(serv => serv.GetCoilsByZoneId(zoneId))
      .Returns(_mockCoilFieldsService.GetCoilsByZoneId(zoneId));

      var result = await controller.GetCoilsByZoneId(zoneId);
      Assert.NotNull(result);
    }

    [Fact]
    public async Task CheckDependency_ReturnsStrings()
    {
      var _mockCoilFieldsService = new MockCoilFieldZoneService();

      var controller = new CoilFieldZonesController(coilFieldZonesService.Object);

      var zoneId = 1;


      coilFieldZonesService.Setup(serv => serv.CheckDependencyByZoneId(zoneId))
      .Returns(_mockCoilFieldsService.CheckDependencyByZoneId(zoneId));

      var result = await controller.CheckDependency(zoneId);
      Assert.NotNull(result);
    }


    [Fact]
    public async Task DisableCoilFieldZone_ReturnsNoContent()
    {
      var coilField = new CoilFieldDto()
      {
        Id = 2,
        Disabled = false,
        Name = "TMMI"
      };
      var _mockCoilFieldsService = new MockCoilFieldService();
      var controller = new CoilFieldZonesController(coilFieldZonesService.Object);

      var zoneId = 1;

      coilFieldZonesService.Setup(repo => repo.DisableCoilFieldZone(zoneId, true)).ReturnsAsync(true);

      var result = await controller.DisableCoilFieldZone(zoneId, true);
      Assert.NotNull(result);
    }

    [Fact]
    public async Task CheckEdit_ReturnsNotFound()
    {
      var coilFieldZone = new CoilFieldZoneDto()
      {
        Id = 1,
        Disabled = false,
        Name = "TMMI"
      };
      var _mockCoilFieldsService = new MockCoilFieldService();
      var controller = new CoilFieldZonesController(coilFieldZonesService.Object);

      var zoneId = 1;

      coilFieldZonesService.Setup(service => service.CheckIfEdited(coilFieldZone)).ReturnsAsync(Constant.edited);



      var result = await controller.CheckEdit(zoneId, coilFieldZone);
      Assert.NotNull(result);
    }

    [Fact]
    public async Task UpdateCoilFieldZone_ReturnsNoContent()
    {
      var coilFieldZone = new CoilFieldZoneDto()
      {
        Id = 1,
        Disabled = false,
        Name = "TMMI",

      };
      var _mockCoilFieldsService = new MockCoilFieldService();
      var controller = new CoilFieldZonesController(coilFieldZonesService.Object);
      coilFieldZonesService.Setup(service => service.UpdateCoilFieldZone(coilFieldZone));

      var zoneId = 1;

      var result = await controller.UpdateCoilFieldZoneDto(zoneId, coilFieldZone);
      Assert.NotNull(result);
    }

    //[Fact]
    //public async Task PostCoilFieldZone_coilFieldZoneDto_ReturnscoilFieldZone()
    //{
    //  var coilFieldZone = new CoilFieldZoneDto()
    //  {
    //    Id = 1,
    //    Disabled = false,
    //    Name = "TMMI",

    //  };
    //  var _mockCoilFieldsService = new MockCoilFieldService();
    //  var controller = new CoilFieldZonesController(coilFieldZonesService.Object);
    //  coilFieldZonesService.Setup(service => service.PostCoilFieldZone(It.IsAny<CoilFieldZoneDto>())).ReturnsAsync(coilFieldZone);

    //  var result = await controller.PostCoilFieldZone(coilFieldZone);
    //  Assert.NotNull(result);
    //}

    [Fact]
    public async Task SaveCoilFieldZone_coilFieldZoneDto_ReturnscoilFieldZone()
    {
      var coilFieldZone = new CoilFieldZoneDto()
      {
        Id = 1,
        Disabled = false,
        Name = "TMMI",

      };
      var _mockCoilFieldsService = new MockCoilFieldService();
      var controller = new CoilFieldZonesController(coilFieldZonesService.Object);
      coilFieldZonesService.Setup(service => service.SaveCoilFieldZone(It.IsAny<CoilFieldZoneDto>())).ReturnsAsync(coilFieldZone);

      var result = await controller.SaveCoilFieldZoneDto(coilFieldZone);
      Assert.NotNull(result);
    }

    [Fact]
    public async Task DeleteCoilFieldZone_ZoneId_ReturnsCoilFieldZone()
    {
      var coilFieldZone = new CoilFieldZoneDto()
      {
        Id = 1,
        Disabled = false,
        Name = "TMMI",
      };

      var _mockCoilFieldsService = new MockCoilFieldService();
      var controller = new CoilFieldZonesController(coilFieldZonesService.Object);

      var zoneId = 1;

      coilFieldZonesService.Setup(service => service.DeleteCoilFieldZone(zoneId)).ReturnsAsync(coilFieldZone);

      var result = await controller.DeleteCoilFieldZone(zoneId);

      Assert.NotNull(result);
    }

  }
}
