using CoilTracking.Business.Interfaces;
using CoilTracking.WebAPI.Controllers;
using Moq;
using Xunit;

namespace CoilTracking.Tests.Controller
{
  public class ScheduleReportBatchControllerTest
  {
    private readonly Mock<IScheduledReportBatchService> mockScheduleReportBatchService;

    public ScheduleReportBatchControllerTest()
    {
      mockScheduleReportBatchService = new Mock<IScheduledReportBatchService>();
    }

    [Fact]
    public void Get()
    {
      var controller = new ScheduledReportBatchController(mockScheduleReportBatchService.Object);
      controller.Get();
      Assert.NotNull(controller);
    }
  }
}
