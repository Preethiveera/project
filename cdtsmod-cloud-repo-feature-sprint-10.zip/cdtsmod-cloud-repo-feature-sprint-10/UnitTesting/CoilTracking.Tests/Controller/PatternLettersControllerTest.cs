using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using CoilTracking.WebAPI.Controllers;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

namespace CoilTracking.Tests.Controller
{
  public class PatternLettersControllerTest
  {

    private readonly Mock<IPatternLetterService> _patternLetterServiceMock;

    public PatternLettersControllerTest()
    {
      _patternLetterServiceMock = new Mock<IPatternLetterService>();
    }

    [Fact]
    public void GetPatternLetterTest()
    {

      var _mockPatternLetterService = new MockPatternLetterService();
      var controller = new PatternLettersController(_patternLetterServiceMock.Object);
      _patternLetterServiceMock.Setup(repo => repo.GetPatternLetter())
      .Returns(_mockPatternLetterService.GetPatternLetter());
      var result = controller.GetPatternLetter();
      Assert.NotNull(result);
    }

    [Fact]
    public void GetPatternLetterByIdTest()
    {
      var _mockPatternLetterService = new MockPatternLetterService();
      var controller = new PatternLettersController(_patternLetterServiceMock.Object);
      _patternLetterServiceMock.Setup(repo => repo.GetPatternLetterById(1))
      .Returns(_mockPatternLetterService.GetPatternLetterById());
      var result = controller.GetPatternLetterById(1);
      Assert.NotNull(result);
    }
    [Fact]
    public void GetPatternLetterByIdReturnsBadRequest()
    {
      var _mockPatternLetterService = new MockPatternLetterService();
      var controller = new PatternLettersController(_patternLetterServiceMock.Object);
      _patternLetterServiceMock.Setup(repo => repo.GetPatternLetterById(100))
      .Returns(_mockPatternLetterService.GetPatternLetterByIdReturnsbadRequest(100));
      var result = controller.GetPatternLetterById(100);
      Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public void PostPatternLetter()
    {
      var pattern = new PatternLetterDto
      {
        Id = 1,
        Name = "A",
        Desc = "test",
        Disabled = false,
      };

      var _mockPatternLetterService = new MockPatternLetterService();
      var controller = new PatternLettersController(_patternLetterServiceMock.Object);
      _patternLetterServiceMock.Setup(repo => repo.PostPatternLetter(pattern))
      .Returns(_mockPatternLetterService.GetPatternLetterModelById());
      var result = controller.PostPatternLetter(pattern);
      Assert.NotNull(result);
    }



    [Fact]
    public void PutPatternLetterReturnsNocontent()
    {
      int id = 1;
      var pattern = new PatternLetterDto
      {
        Id = 1,
        Name = "A",
        Desc = "test",
        Disabled = false,
      };

      var _mockPatternLetterService = new MockPatternLetterService();
      var controller = new PatternLettersController(_patternLetterServiceMock.Object);
      _patternLetterServiceMock.Setup(repo => repo.PutPatternLetter(id, pattern))
      .Returns(_mockPatternLetterService.PutPatternLetter(id, pattern));
      var result = controller.PutPatternLetter(id, pattern);
      Assert.IsType<NoContentResult>(result);
    }

    [Fact]
    public void PutPatternLetterReturnsBadRequest()
    {
      int id = 2;
      var pattern = new PatternLetterDto
      {
        Id = 1,
        Name = "A",
        Desc = "test",
        Disabled = false,
      };

      var _mockPatternLetterService = new MockPatternLetterService();
      var controller = new PatternLettersController(_patternLetterServiceMock.Object);
      _patternLetterServiceMock.Setup(repo => repo.PutPatternLetter(id, pattern))
      .Returns(_mockPatternLetterService.PutPatternLetter(id, pattern));
      var result = controller.PutPatternLetter(id, pattern);
      Assert.IsType<BadRequestResult>(result);

    }
    [Fact]
    public void PutPatternLetterReturnsNotFound()
    {
      int id = 1;
      var pattern = new PatternLetterDto
      {
        Id = 1,
        Name = "A",
        Desc = "test",
        Disabled = false,
      };

      var _mockPatternLetterService = new MockPatternLetterService();
      var controller = new PatternLettersController(_patternLetterServiceMock.Object);
      _patternLetterServiceMock.Setup(repo => repo.PutPatternLetter(id, pattern))
      .Returns(_mockPatternLetterService.PutPatternLetterReturnsNotFound(id, pattern));
      var result = controller.PutPatternLetter(id, pattern);
      Assert.IsType<NotFoundResult>(result);

    }


    [Fact]
    public void DeletePatternLetter()
    {
      //Arrange  
      var controller = new PatternLettersController(_patternLetterServiceMock.Object);
      var Id = 1;

      //Act  
      var data = controller.DeletePatternLetter(Id);
      //Assert  
      Assert.NotNull(data);

    }


    [Fact]
    public void DisablePatternLetterReturnsNotFound()
    {
      int id = 2;
      bool disable = true;

      var _mockPatternLetterService = new MockPatternLetterService();
      var controller = new PatternLettersController(_patternLetterServiceMock.Object);
      _patternLetterServiceMock.Setup(repo => repo.DisablePatternLetter(id, disable))
      .Returns(_mockPatternLetterService.DisablePatternLetter(id, disable));
      var result = controller.DisablePatternLetter(id, disable);
      Assert.IsType<NotFoundResult>(result);
    }
    [Fact]
    public void DisablePatternLetterReturnsNoContent()
    {
      int id = 1;
      bool disable = true;

      var _mockPatternLetterService = new MockPatternLetterService();
      var controller = new PatternLettersController(_patternLetterServiceMock.Object);
      _patternLetterServiceMock.Setup(repo => repo.DisablePatternLetter(id, disable))
      .Returns(_mockPatternLetterService.DisablePatternLetter(id, disable));
      var result = controller.DisablePatternLetter(id, disable);
      Assert.IsType<NoContentResult>(result);
    }


    [Fact]
    public void CheckEditReturnsBadrequest()
    {
      int id = 1;
      var pattern = new PatternLetterDto
      {
        Id = 1,
        Name = "B",
        Desc = "test",
        Disabled = false,
      };
      var _mockPatternLetterService = new MockPatternLetterService();
      var controller = new PatternLettersController(_patternLetterServiceMock.Object);
      _patternLetterServiceMock.Setup(repo => repo.CheckEdit(id, pattern))
      .Returns(_mockPatternLetterService.CheckEdit(id, pattern));
      var result = controller.CheckEdit(id, pattern);
      Assert.IsType<BadRequestResult>(result);

    }
    [Fact]
    public void CheckEditReturnsNotFound()
    {
      int id = 1;
      var pattern = new PatternLetterDto
      {
        Id = 1,
        Name = "A",
        Desc = "test",
        Disabled = false,
      };
      var _mockPatternLetterService = new MockPatternLetterService();
      var controller = new PatternLettersController(_patternLetterServiceMock.Object);
      _patternLetterServiceMock.Setup(repo => repo.CheckEdit(id, pattern))
      .Returns(_mockPatternLetterService.CheckEdit(id, pattern));
      var result = controller.CheckEdit(id, pattern);
      Assert.IsType<NotFoundResult>(result);

    }



    [Fact]
    public void CheckDependency()
    {
      int id = 1;
      var _mockPatternLetterService = new MockPatternLetterService();
      var controller = new PatternLettersController(_patternLetterServiceMock.Object);
      _patternLetterServiceMock.Setup(repo => repo.CheckDependency(id))
      .Returns(_mockPatternLetterService.CheckDependency());
      var result = controller.CheckDependency(id);
      Assert.NotNull(result);

    }
  }
}
