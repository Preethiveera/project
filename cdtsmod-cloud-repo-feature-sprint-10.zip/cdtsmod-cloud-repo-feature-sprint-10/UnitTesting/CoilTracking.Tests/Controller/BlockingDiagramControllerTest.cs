using CoilTracking.Business.Interfaces;
using CoilTracking.Business.Interfaces.BlockingDiagrams;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Controllers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Moq;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Xunit;

namespace CoilTracking.Tests.Controller
{
  public class BlockingDiagramControllerTest
  {
    private readonly Mock<IApplicationLogger<BlockingDiagramsController>> logger;
    private readonly Mock<IOptions<BlockingDiagramConfiguration>> settings;
    private readonly Mock<IBlockingDiagramService> aWSS3FileService;

    public BlockingDiagramControllerTest()
    {
      logger = new Mock<IApplicationLogger<BlockingDiagramsController>>();
      settings = new Mock<IOptions<BlockingDiagramConfiguration>>();
      aWSS3FileService = new Mock<IBlockingDiagramService>();
    }

    
    [Fact]
    public void GetFileById_Id_ReturnsStream()
    {
      BlockingDiagramDto dto = new BlockingDiagramDto
      {
        Id=1
      };
      Stream file = null;
      var controller = new BlockingDiagramsController(aWSS3FileService.Object,settings.Object, logger.Object);
      aWSS3FileService.Setup(repo => repo.GetBlockingDiagramById(1))
      .ReturnsAsync(dto);
      var result = controller.GetBlockingDiagram(1);
      Assert.NotNull(result);

    }
    [Fact]
    public async Task GetFileById_Id_ReturnsNotFound()
    {
      
      Stream file = null;
      var controller = new BlockingDiagramsController(aWSS3FileService.Object, settings.Object, logger.Object);

      var result =await controller.GetBlockingDiagram(1);
      Assert.IsType<NotFoundResult>(result);

    }
    [Fact]
    public void GetBlockingDiagrams_Returns_BlockingDiagram()
    {
      List<BlockingDiagramDto> dto = new List<BlockingDiagramDto>
      {
        new BlockingDiagramDto{
        Id = 1
        }
      };
      Stream file = null;
      var controller = new BlockingDiagramsController(aWSS3FileService.Object, settings.Object, logger.Object);
      aWSS3FileService.Setup(repo => repo.GetBlockingDiagrams())
      .ReturnsAsync(dto);
      var result = controller.GetBlockingDiagrams();
      Assert.NotNull(result);

    }
    [Fact]
    public void SaveBlockingDiagrams_Returns_BlockingDiagram()
    {
      Stream file = null;
      var controller = new BlockingDiagramsController(aWSS3FileService.Object, settings.Object, logger.Object);
      aWSS3FileService.Setup(repo => repo.GetFile(1))
      .ReturnsAsync(file);
      var result = controller.SaveBlockingDiagramDto();
      Assert.NotNull(result);

    }
    [Fact]
    public void GetBlockingDiagramsById_Returns_Stream()
    {
      BlockingDiagramDto dto = new BlockingDiagramDto
      {
        Id = 1
      };
      Stream file = null;
      var controller = new BlockingDiagramsController(aWSS3FileService.Object, settings.Object, logger.Object);
      aWSS3FileService.Setup(repo => repo.GetBlockingDiagramById(1))
      .ReturnsAsync(dto);
      var result = controller.GetBlockingDiagramById(1);
      Assert.NotNull(result);

    }
    [Fact]
    public void DeleteBlockingDiagramsById_Returns_BlockingDiagram()
    {
      BlockingDiagramDto dto = new BlockingDiagramDto
      {
        Id = 1
      };
      Stream file = null;
      var controller = new BlockingDiagramsController(aWSS3FileService.Object, settings.Object, logger.Object);
      aWSS3FileService.Setup(repo => repo.DeleteBlockingDiagram(1))
      .ReturnsAsync(dto);
      var result = controller.DeleteBlockingDiagram(1);
      Assert.NotNull(result);

    }
   
  }
}
