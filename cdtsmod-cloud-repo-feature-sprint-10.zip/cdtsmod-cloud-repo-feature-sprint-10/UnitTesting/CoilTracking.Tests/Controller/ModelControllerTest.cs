using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using CoilTracking.WebAPI.Controllers;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace CoilTracking.Tests.Controller
{
  public class ModelControllerTest
  {
    private readonly Mock<IModelService> modelService;


    public ModelControllerTest()
    {
      modelService = new Mock<IModelService>();
    }

    [Fact]
    public async Task GetModels()
    {
      var _mockModelService = new MockModelService();

      var controller = new ModelsController(modelService.Object);

      modelService.Setup(serv => serv.GetModels())
         .ReturnsAsync(_mockModelService.GetModelsDto());

      var result = await controller.GetModels();
      Assert.NotNull(result);
    }

    [Fact]
    public async Task GetModel()
    {
      var id = 1;
      var _mockModelService = new MockModelService();

      var controller = new ModelsController(modelService.Object);

      modelService.Setup(serv => serv.GetModel(id))
         .ReturnsAsync(_mockModelService.GetModelByIdDto());

      var result = await controller.GetModel(id);
      Assert.NotNull(result);
    }

    [Fact]
    public async Task CheckEdit()
    {
      var id = 1;
      var _mockModelService = new MockModelService();

      var controller = new ModelsController(modelService.Object);

      modelService.Setup(serv => serv.CheckEdit(id, It.IsAny<ModelDto>()))
         .ReturnsAsync(true);

      var result = await controller.CheckEdit(id, It.IsAny<ModelDto>());
      Assert.NotNull(result);
    }

    [Fact]
    public async Task GetPartsRelatedToModels()
    {
      var id = 1;
      var _mockModelService = new MockModelService();

      var controller = new ModelsController(modelService.Object);

      modelService.Setup(serv => serv.GetPartsRelatedToModels(id))
         .ReturnsAsync(_mockModelService.GetPartsDto());

      var result = await controller.GetPartsRelatedToModels(id);
      Assert.NotNull(result);
    }

    [Fact]
    public async Task GetPartsInRunOrderByModelId()
    {
      var id = 1;
      var _mockModelService = new MockModelService();

      var controller = new ModelsController(modelService.Object);

      modelService.Setup(serv => serv.GetPartsInRunOrderByModelId(id))
         .ReturnsAsync(_mockModelService.GetPartModelByPartIdsAndModelIdDto());

      var result = await controller.GetPartsRelatedToModels(id);
      Assert.NotNull(result);
    }

    [Fact]
    public async Task CheckDependency()
    {
      var id = 1;
      var _mockModelService = new MockModelService();

      var controller = new ModelsController(modelService.Object);

      modelService.Setup(serv => serv.CheckDependency(id))
         .ReturnsAsync(new List<string>() { "Runorder" });

      var result = await controller.CheckDependency(id);
      Assert.NotNull(result);
    }


    [Fact]
    public async Task PutModel()
    {
      var model = new ModelDto
      {
        Id = 1,
        Name = "Mittal",
        Disabled = false,
        ModelNumber = "592N"
      };
      var id = 1;

      var _mockModelService = new MockModelService();

      var controller = new ModelsController(modelService.Object);

      modelService.Setup(serv => serv.PutModel(It.IsAny<ModelDto>()))
         .ReturnsAsync(true);

      var result = await controller.PutModel(id, model);
      Assert.NotNull(result);
    }

    [Fact]
    public async Task DisableModel()
    {
      var model = new ModelDto
      {
        Id = 1,
        Name = "Mittal",
        Disabled = false,
        ModelNumber = "592N"
      };
      var id = 1;

      var _mockModelService = new MockModelService();

      var controller = new ModelsController(modelService.Object);

      modelService.Setup(serv => serv.PutModel(It.IsAny<ModelDto>()))
         .ReturnsAsync(true);

      var result = await controller.PutModel(id, model);
      Assert.NotNull(result);
    }

    [Fact]
    public async Task PostModel()
    {
      var model = new ModelDto
      {
        Name = "Mittal",
        Disabled = false,
        ModelNumber = "592N"
      };


      var _mockModelService = new MockModelService();

      var controller = new ModelsController(modelService.Object);

      modelService.Setup(serv => serv.PostModel(It.IsAny<ModelDto>()))
         .ReturnsAsync(model);

      var result = await controller.PostModel(model);

      Assert.NotNull(result);
    }

    [Fact]
    public async Task DeleteModel()
    {
      var id = 1;
      var model = new ModelDto
      {
        Name = "Mittal",
        Disabled = false,
        ModelNumber = "592N"
      };


      var _mockModelService = new MockModelService();

      var controller = new ModelsController(modelService.Object);

      modelService.Setup(serv => serv.DeleteModel(id))
         .ReturnsAsync(model);

      var result = await controller.DeleteModel(id);

      Assert.NotNull(result);
    }

  }
}
