using CoilTracking.Business.Interfaces;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data.Models;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using CoilTracking.WebAPI.Controllers;
using Moq;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace CoilTracking.Tests.Controller
{
 public class PartsControllerTest
  {
    int id = 21;
    private readonly Mock<IPartsService> partsServiceMock;
    private readonly Mock<IBlankInfoService> blankInfoServiceMock;
    private readonly Mock<IImportPartData> importPartDataService;
    private readonly Mock<IUserHelper> usersHelper;
    public PartsControllerTest()
    {
      partsServiceMock = new Mock<IPartsService>();
      blankInfoServiceMock = new Mock<IBlankInfoService>();
      importPartDataService = new Mock<IImportPartData>();
      usersHelper = new Mock<IUserHelper>();
    }

    [Fact]
    public async Task GetParts_ReturnsPartsDto()
    {
      var mockPartsService = new MockPartsService();
      var controller = new PartsController(partsServiceMock.Object, blankInfoServiceMock.Object, importPartDataService.Object, usersHelper.Object);
      partsServiceMock.Setup(repo => repo.GetParts())
      .ReturnsAsync(mockPartsService.GetPartsDto());
      var result = await controller.GetParts();
      Assert.NotNull(result);
    }


    [Fact]
    public async Task GetPartDto_ReturnsPartsDto()
    {
      var mockPartsService = new MockPartsService();
      var controller = new PartsController(partsServiceMock.Object, blankInfoServiceMock.Object, importPartDataService.Object, usersHelper.Object);
      partsServiceMock.Setup(repo => repo.GetParts())
      .ReturnsAsync(mockPartsService.GetPartsDto());
      var result = await controller.GetPartDtos();
      Assert.NotNull(result);
    }

    [Fact]
    public async Task GetPartById_ReturnsPartsDto()
    {
      
      var mockPartsService = new MockPartsService();
      var controller = new PartsController(partsServiceMock.Object, blankInfoServiceMock.Object, importPartDataService.Object, usersHelper.Object);
      partsServiceMock.Setup(repo => repo.GetParts())
      .ReturnsAsync(mockPartsService.GetPartsDto());
      var result = await controller.GetPart(id);
      Assert.NotNull(result);
    }


    [Fact]
    public async Task GetPartModels_ReturnsPartsDto()
    {
     
      var mockPartsService = new MockPartsService();
      var controller = new PartsController(partsServiceMock.Object, blankInfoServiceMock.Object, importPartDataService.Object, usersHelper.Object);
      partsServiceMock.Setup(repo => repo.GetParts())
      .ReturnsAsync(mockPartsService.GetPartsDto());
      var result = await controller.GetPartModels(id);
      Assert.NotNull(result);
    }


    [Fact]
    public async Task GetPartsInRunOrder_ReturnsPartsDto()
    {
      
      var mockPartsService = new MockPartsService();
      var controller = new PartsController(partsServiceMock.Object, blankInfoServiceMock.Object, importPartDataService.Object, usersHelper.Object);
      partsServiceMock.Setup(repo => repo.GetParts())
      .ReturnsAsync(mockPartsService.GetPartsDto());
      var result = await controller.GetPartsInRunOrder(id);
      Assert.NotNull(result);
    }

    [Fact]
    public async Task PartProdPlanAssociation_ReturnsPartsDto()
    {
      
      var mockPartsService = new MockPartsService();
      var controller = new PartsController(partsServiceMock.Object, blankInfoServiceMock.Object, importPartDataService.Object, usersHelper.Object);
      partsServiceMock.Setup(repo => repo.GetParts())
      .ReturnsAsync(mockPartsService.GetPartsDto());
      var result = await controller.PartProdPlanAssociation(id);
      Assert.NotNull(result);
    }

    [Fact]
    public async Task PartsGetDependency_ReturnsPartsDto()
    {   
      var mockPartsService = new MockPartsService();
      var controller = new PartsController(partsServiceMock.Object, blankInfoServiceMock.Object, importPartDataService.Object, usersHelper.Object);
      partsServiceMock.Setup(repo => repo.GetParts())
      .ReturnsAsync(mockPartsService.GetPartsDto());
      var result = await controller.PartsGetDependency(id);
      Assert.NotNull(result);
    }

    [Fact]
    public async Task PutPart_ReturnsPartsDto()
    {
      var mockPartsService = new MockPartsService();
      var part = mockPartsService.GetPart();
      var controller = new PartsController(partsServiceMock.Object, blankInfoServiceMock.Object, importPartDataService.Object, usersHelper.Object);
      partsServiceMock.Setup(repo => repo.GetParts())
      .ReturnsAsync(mockPartsService.GetPartsDto());
      var result = await controller.PutPart(id, part);
      Assert.NotNull(result);
    }

    [Fact]
    public async Task PostPart_ReturnsPartsDto()
    {
      var mockPartsService = new MockPartsService();
      var part = mockPartsService.GetPart();
      var controller = new PartsController(partsServiceMock.Object, blankInfoServiceMock.Object, importPartDataService.Object, usersHelper.Object);
      partsServiceMock.Setup(repo => repo.GetParts())
      .ReturnsAsync(mockPartsService.GetPartsDto());
      var result = await controller.PostPart(part);
      Assert.NotNull(result);
    }

    [Fact]
    public async Task DisablePart_ReturnsPartsDto()
    {
      var mockPartsService = new MockPartsService();
      var part = mockPartsService.GetPart();
      var controller = new PartsController(partsServiceMock.Object, blankInfoServiceMock.Object, importPartDataService.Object, usersHelper.Object);
      partsServiceMock.Setup(repo => repo.GetParts())
      .ReturnsAsync(mockPartsService.GetPartsDto());
      var result = await controller.DisablePart(id,true);
      Assert.NotNull(result);
    }

    [Fact]
    public async Task CheckEdit_ReturnsPartsDto()
    {
      var mockPartsService = new MockPartsService();
      var part = mockPartsService.GetPart();
      var controller = new PartsController(partsServiceMock.Object, blankInfoServiceMock.Object, importPartDataService.Object, usersHelper.Object);
      partsServiceMock.Setup(repo => repo.GetParts())
      .ReturnsAsync(mockPartsService.GetPartsDto());
      var result = await controller.CheckEdit(id,part);
      Assert.NotNull(result);
    }

    [Fact]
    public async Task GetAutoCompleteData_ReturnsPartsDto()
    {
      int lineId = 12;
      string partnumber = "533";
      var mockPartsService = new MockPartsService();
      var part = mockPartsService.GetPart();
      var controller = new PartsController(partsServiceMock.Object, blankInfoServiceMock.Object, importPartDataService.Object, usersHelper.Object);
      partsServiceMock.Setup(repo => repo.GetParts())
      .ReturnsAsync(mockPartsService.GetPartsDto());
      var result = await controller.GetAutoCompleteData(partnumber,lineId);
      Assert.NotNull(result);
    }

    [Fact]
    public async Task DeletePart_ReturnsPartsDto()
    {
      int PId = 25;
      var mockPartsService = new MockPartsService();
      var part = mockPartsService.GetPart();
      var controller = new PartsController(partsServiceMock.Object, blankInfoServiceMock.Object, importPartDataService.Object, usersHelper.Object);
      partsServiceMock.Setup(repo => repo.GetParts())
      .ReturnsAsync(mockPartsService.GetPartsDto());
      var result = await controller.DeletePart(PId);
      Assert.NotNull(result);
    }

    [Fact]
    public async Task ChangeModels_ReturnsPartsDto()
    {
      dynamic data = new JObject();
      data.Id = 26;
      data.Models = null;

      var mockPartsService = new MockPartsService();
      var part = mockPartsService.GetPart();
      var controller = new PartsController(partsServiceMock.Object, blankInfoServiceMock.Object, importPartDataService.Object, usersHelper.Object);
      partsServiceMock.Setup(repo => repo.GetParts())
      .ReturnsAsync(mockPartsService.GetPartsDto());
      var result = await controller.ChangeModels(data);
      Assert.NotNull(result);
    }



  }
}
