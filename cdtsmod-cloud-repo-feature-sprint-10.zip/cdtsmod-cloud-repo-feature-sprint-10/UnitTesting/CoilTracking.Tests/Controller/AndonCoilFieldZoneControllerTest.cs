using CoilTracking.Business.Interfaces;
using CoilTracking.WebAPI.Controllers;
using Moq;
using Xunit;

namespace CoilTracking.Tests
{
  public class AndonCoilFieldZoneControllerTest
  {

    private readonly Mock<IAndonService> _AndonServiceMock;

    public AndonCoilFieldZoneControllerTest()
    {

      _AndonServiceMock = new Mock<IAndonService>();

    }

    /// <summary>
    /// AndonCCoilsFeildsByZoneId testing
    /// </summary>
    [Fact]
    public void AndonCoilsFeildsByZoneId_ReturnZones()
    {

      var _service = new Mock<IAndonService>();
      var _controller = new AndonCoilFieldZoneController(_AndonServiceMock.Object);
      _service.Setup(x => x.GetCoilsFeildsByZoneId(It.IsAny<int>())).Returns(MockAndonService.Get_Success());
      var response = _controller.Get();

      //_AndonServiceMock.Setup(repo => repo.GetCoilsFeildsByZoneId(ZoneId))
      //.Returns(_mockLineService.GetCoilsFeildsByZoneId(ZoneId));
      //var result = controller.Get(0);

      Assert.Null(response);
    }
  }
}
