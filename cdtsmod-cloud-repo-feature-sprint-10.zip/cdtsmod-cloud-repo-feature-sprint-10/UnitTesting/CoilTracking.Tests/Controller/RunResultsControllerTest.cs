using CoilTracking.Business.Interfaces;
using CoilTracking.Data.Models;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using CoilTracking.WebAPI.Controllers;
using Moq;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using Xunit;

namespace CoilTracking.Tests.Controller
{
  public class RunResultsControllerTest
  {
    private readonly Mock<IRunResultService> runResultServiceMock;

    public RunResultsControllerTest()
    {

      runResultServiceMock = new Mock<IRunResultService>();
    }

    [Fact]
    public void GetRunResults_ReturnsRunResult()
    {
      var _mockLineService = new MockRunService();
      var controller = new RunResultsController(runResultServiceMock.Object);
      runResultServiceMock.Setup(repo => repo.GetRunResults())
      .ReturnsAsync(_mockLineService.GetRunResultsdto());
      var result = controller.GetRunResults();
      Assert.NotNull(result);
    }

    [Fact]
    public void GetLatestRunResult_Latest_ReturnsRunResults()
    {
      var _mockLineService = new MockRunService();
      var controller = new RunResultsController(runResultServiceMock.Object);
      runResultServiceMock.Setup(repo => repo.GetLatestRunResult())
      .ReturnsAsync(_mockLineService.GetRunResultsdtos());
      var result = controller.GetLatestRunResult();
      Assert.NotNull(result);
    }

    [Fact]
    public void GetRunCoilsToBeWeighed_ReturnsCoilToBeWeighed()
    {
      var _mockLineService = new MockRunService();
      var controller = new RunResultsController(runResultServiceMock.Object);
      runResultServiceMock.Setup(repo => repo.GetRunCoilsToBeWeighed())
      .Returns(_mockLineService.GetRunCoilsToBeWeighed());
      var result = controller.GetCoilsToBeWeighed();
      Assert.NotNull(result);
    }

    [Fact]
    public void GetCoilByFTZToBeWeighed_ReturnsCoilToBeWeighed()
    {
      String ftz = "56";
      var _mockLineService = new MockRunService();
      var controller = new RunResultsController(runResultServiceMock.Object);
      //runResultServiceMock.Setup(repo => repo.GetCoilByFTZToBeWeighed(ftz))
      //.Returns(_mockLineService.GetCoilByFTZToBeWeighed());
      var result = controller.GetCoilByFTZToBeWeighed(ftz);
      Assert.NotNull(result);
    }

    [Fact]
    public void GetCurrentStackSize_StackSize_ReturnsCurrentStackSize()
    {
      int num = 4;
      var _mockLineService = new MockRunService();
      var controller = new RunResultsController(runResultServiceMock.Object);
      runResultServiceMock.Setup(repo => repo.GetCurrentStackSize(num))
      .Returns(_mockLineService.GetCurrentStackSize());
      var result = controller.GetCurrentStackSize(num);
      Assert.NotNull(result);
    }

    [Fact]
    public void GetCurrentStackSize_ReturnsThrowsNullReferencException()
    {
      int num = 0;
      var _mockLineService = new MockRunService();
      var controller = new RunResultsController(runResultServiceMock.Object);
      runResultServiceMock.Setup(repo => repo.GetCurrentStackSize(num))
      .Returns(_mockLineService.GetCurrentStackSize());
      var result = controller.GetCurrentStackSize(num);
      Assert.NotNull(result);
    }

    [Fact]
    public void GetRunResultById_ReturnsRunResultById()
    {
      int num = 4;
      var _mockLineService = new MockRunService();
      var controller = new RunResultsController(runResultServiceMock.Object);
      runResultServiceMock.Setup(repo => repo.GetRunResultById(num))
      .ReturnsAsync(_mockLineService.GetRunResultsdtosid());
      var result = controller.GetRunResult(num);
      Assert.NotNull(result);
    }

    [Fact]
    public void GetRunResultForEditByID_ReturnRunResultById()
    {
      int num = 4;
      var _mockLineService = new MockRunService();
      var controller = new RunResultsController(runResultServiceMock.Object);
      runResultServiceMock.Setup(repo => repo.GetRunResultForEditByID(num))
      .ReturnsAsync(_mockLineService.GetRunResultForEditByID());
      var result = controller.GetRunResultForEdit(num);
      Assert.NotNull(result);
    }
    [Fact]
    public void GetRunResultForEditByID_ReturnThrowsNullReferencException()
    {
      int num = 0;
      var _mockLineService = new MockRunService();
      var controller = new RunResultsController(runResultServiceMock.Object);
      runResultServiceMock.Setup(repo => repo.GetRunResultForEditByID(num))
      .ReturnsAsync(_mockLineService.GetRunResultForEditByID());
      var result = controller.GetRunResultForEdit(num);
      Assert.NotNull(result);
    }

    [Fact]
    public void GetRunResultsSearch_ReturnSearchRunResultsInfo()
    {
      DateTime startTime = DateTime.Now;
      DateTime endTime = DateTime.Now;
      string partNum = "test";
      int? dataNum = 1;
      string coilType = "1-3";
      int? lineId = 4;
      int? shiftId = 8;
      string ftz = "test";
      var _mockLineService = new MockRunService();
      var controller = new RunResultsController(runResultServiceMock.Object);
      runResultServiceMock.Setup(repo => repo.GetRunResultsSearch(startTime, endTime, partNum, dataNum, coilType, lineId, shiftId, ftz))
      .Returns(_mockLineService.GetRunResultsSearch());
      var result = controller.Search(startTime, endTime, partNum, dataNum, coilType, lineId, shiftId, ftz);
      Assert.NotNull(result);
    }

    [Fact]
    public void GetScrapResults_ScrapResults_ReturnScrapResults()
    {
      DateTime startTime = DateTime.Now;
      DateTime endTime = DateTime.Now;
      string partNum = "test";
      int? dataNum = 1;
      string coilType = "1-3";
      int? lineId = 4;
      int? shiftId = 8;
      string ftz = "test";
      var _mockLineService = new MockRunService();
      var controller = new RunResultsController(runResultServiceMock.Object);
      runResultServiceMock.Setup(repo => repo.GetRunResultsSearch(startTime, endTime, partNum, dataNum, coilType, lineId, shiftId, ftz))
      .Returns(_mockLineService.GetRunResultsSearch());
      runResultServiceMock.Setup(repo => repo.GetScrapResults(startTime, endTime, partNum, dataNum, coilType, lineId, shiftId, ftz))
      .Returns(_mockLineService.GetScrapResults());
      var result = controller.GetScrapResults(startTime, endTime, partNum, dataNum, coilType, lineId, shiftId, ftz);
      Assert.NotNull(result);
    }

    [Fact]
    public void SaveReturnWeight_ReturnsResponseOk()
    {
      List<CoilToBeWeighed> CoilToBeWeighed = new List<CoilToBeWeighed>();
      {
        CoilToBeWeighed.Add(new CoilToBeWeighed()
        {
          RunResultId = 1,
          RunOrderListId = 1,
          CoilId = 1,
          FTZ = "a",
          CoilType = "a",
          YNA = "a",
          OriginalWeight = 1,
          Zone = "a",
          CoilLocation = "a",
          NewWeight = 1,
          AttachedToRunResult = true,
          CoilTypeName = "a",
          CoilStatusName = "a",
          CoilFieldLocationName = "a"
        });

      }
      var controller = new RunResultsController(runResultServiceMock.Object);
      runResultServiceMock.Setup(repo => repo.SaveReturnWeight(CoilToBeWeighed));
      var result = controller.SaveReturnWeight(CoilToBeWeighed);
      Assert.NotNull(result);
    }

    [Fact]
    public void UpdateCurrentWeight_ReturnsResponseOk()
    {

      dynamic data = new JObject();
      data.id = 1;
      data.partial = JObject.Parse(@"{ ""RunResultId"":1,""RunOrderListId"":1, ""CoilId"":1,""FTZ"":""56"", ""CoilType"":""CC"", ""YNA"":""896"", ""OriginalWeight"":1,""Zone"":""a"", ""CoilLocation"":""A"", ""NewWeight"":1, ""AttachedToRunResult"":true,""CoilTypeName"":""CTN"", ""CoilStatusName"":""CS"", ""CoilFieldLocationName"":""B""}");

      CoilToBeWeighed coilToBeWeighed = new CoilToBeWeighed()
      {
        RunResultId = 1,
        RunOrderListId = 1,
        CoilId = 1,
        FTZ = "56",
        CoilType = "1-6-8",
        YNA = "3233",
        OriginalWeight = 1,
        Zone = "A1",
        CoilLocation = "S1",
        NewWeight = 1,
        AttachedToRunResult = true,
        CoilTypeName = "A-322",
        CoilStatusName = "A897",
        CoilFieldLocationName = "B4"
      };
      var _mockLineService = new MockRunService();
      var controller = new RunResultsController(runResultServiceMock.Object);
      runResultServiceMock.Setup(repo => repo.UpdateCurrentWeight(coilToBeWeighed));
      var result = controller.UpdateCurrentWeight(data);
      Assert.NotNull(result);
    }



    [Fact]
    public void PostRunResult_Insert_ReturnsResponseOk()
    {

      var runResults = new RunResult

      {
        Id = 1,
        AdcDt = 4,
        BlankCoilTypeName = "",
        Coil = new Coil()
        {
          Id = 7,
          OrderNo = 6,
          IsPriority = true,
          CheckInDate = DateTime.Now,
          SerialNum = "test",
          YNA = "c",
          FTZ = "te",
          OriginalWeight = 1,
          ReturnedToField = DateTime.Now,
          UnAccountedWeight = 9,

          CoilType = new CoilType() { Id = 7, Name = "test", NumCoils = 9 },
          CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white" }
        },
        DownTime = 5,
        DataNumber = 9,
        RunFinished = DateTime.Now,
        Comments = "test",
        ModifiedBy = "A",
        PartNumber = "3",
        RunOrderList = new RunOrderList() { Id = 8, Date = DateTime.Now, PatternLetter = "00", Line = new Line() { Id = 7, Disabled = true, LineName = "", LinePath = "", OPCServer_Id = 88, Plant_Id = 8, Subscribed = true, Tags = "tags", Plant = new Plant() { Id = 5, PlantName = "NAMC", TimeZone = new PlantTimeZone() { Id = 9, Name = "test", TimeZoneOffset = 0 }, } } }
      };
      var _mockLineService = new MockRunService();
      var controller = new RunResultsController(runResultServiceMock.Object);
      runResultServiceMock.Setup(repo => repo.ModifyRunResult(runResults))
           .ReturnsAsync(_mockLineService.RunResultModified(runResults));
      var result = controller.PostRunResult(runResults);
      Assert.NotNull(result);
    }


    [Fact]
    public void DeleteRunResult_Deletion_ReturnsResponseOk()
    {
      int id = 1;
      var _mockLineService = new MockRunService();
      var controller = new RunResultsController(runResultServiceMock.Object);
      runResultServiceMock.Setup(repo => repo.DeleteRunResult(id))
           .ReturnsAsync(_mockLineService.DeleteRunResult());
      var result = controller.DeleteRunResult(id);
      Assert.NotNull(result);
    }

    [Fact]
    public void PutRunResult_Insert_ReturnsResponseOk()
    {
      int id = 1;
      var runResults = new RunResult

      {
        Id = 1,
        AdcDt = 4,
        BlankCoilTypeName = "",
        Coil = new Coil()
        {
          Id = 7,
          OrderNo = 6,
          IsPriority = true,
          CheckInDate = DateTime.Now,
          SerialNum = "test",
          YNA = "c",
          FTZ = "te",
          OriginalWeight = 1,
          ReturnedToField = DateTime.Now,
          UnAccountedWeight = 9,

          CoilType = new CoilType() { Id = 7, Name = "test", NumCoils = 9 },
          CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white" }
        },
        DownTime = 5,
        DataNumber = 9,
        RunFinished = DateTime.Now,
        Comments = "test",
        ModifiedBy = "A",
        PartNumber = "3",
        RunOrderList = new RunOrderList() { Id = 8, Date = DateTime.Now, PatternLetter = "00", Line = new Line() { Id = 7, Disabled = true, LineName = "", LinePath = "", OPCServer_Id = 88, Plant_Id = 8, Subscribed = true, Tags = "tags", Plant = new Plant() { Id = 5, PlantName = "NAMC", TimeZone = new PlantTimeZone() { Id = 9, Name = "test", TimeZoneOffset = 0 }, } } }
      };
      var _mockLineService = new MockRunService();
      var controller = new RunResultsController(runResultServiceMock.Object);
      runResultServiceMock.Setup(repo => repo.ModifyRunResult(runResults))
           .ReturnsAsync(_mockLineService.RunResultModified(runResults));
      runResultServiceMock.Setup(repo => repo.IsRunResultExists(id))
           .Returns(_mockLineService.GetRunResultExists(id));
      var result = controller.PutRunResult(id, runResults);
      Assert.NotNull(result);
    }


    [Fact]
    public void PutRunResult_Insert_ReturnsResponseExpection()
    {
      int id = 0;
      var runResults = new RunResult

      {
        Id = 1,
        AdcDt = 4,
        BlankCoilTypeName = "",
        Coil = new Coil()
        {
          Id = 7,
          OrderNo = 6,
          IsPriority = true,
          CheckInDate = DateTime.Now,
          SerialNum = "test",
          YNA = "c",
          FTZ = "te",
          OriginalWeight = 1,
          ReturnedToField = DateTime.Now,
          UnAccountedWeight = 9,

          CoilType = new CoilType() { Id = 7, Name = "test", NumCoils = 9 },
          CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white" }
        },
        DownTime = 5,
        DataNumber = 9,
        RunFinished = DateTime.Now,
        Comments = "test",
        ModifiedBy = "A",
        PartNumber = "3",
        RunOrderList = new RunOrderList() { Id = 8, Date = DateTime.Now, PatternLetter = "00", Line = new Line() { Id = 7, Disabled = true, LineName = "", LinePath = "", OPCServer_Id = 88, Plant_Id = 8, Subscribed = true, Tags = "tags", Plant = new Plant() { Id = 5, PlantName = "NAMC", TimeZone = new PlantTimeZone() { Id = 9, Name = "test", TimeZoneOffset = 0 }, } } }
      };
      var _mockLineService = new MockRunService();
      var controller = new RunResultsController(runResultServiceMock.Object);
      runResultServiceMock.Setup(repo => repo.ModifyRunResult(runResults))
           .ReturnsAsync(_mockLineService.RunResultModified(runResults));
      runResultServiceMock.Setup(repo => repo.IsRunResultExists(id))
           .Returns(_mockLineService.GetRunResultExists(id));
      var result = controller.PutRunResult(id, runResults);
      Assert.NotNull(result);
    }
    [Fact]
    public void UpdateRunResult_RunResult_ReturnsResponseOk()
    {
      int id = 1;
      dynamic data = new JObject();
      data.runResult = JObject.Parse(@"{ ""RunResultId"":1,""RunOrderListId"":1, ""CoilId"":1,""FTZ"":""56"", ""CoilType"":""CC"", ""YNA"":""896"", ""OriginalWeight"":1,""Zone"":""a"", ""CoilLocation"":""A"", ""NewWeight"":1, ""AttachedToRunResult"":true,""CoilTypeName"":""CTN"", ""CoilStatusName"":""CS"", ""CoilFieldLocationName"":""B""}");
      var runResultDtos = new RunResultDto()

      {
        Id = 1,
        AdcDt = 4,
        DownTime = 5,
        DataNumber = 9,
        RunFinished = DateTime.Now,
        Comments = "test",
        ModifiedBy = "A",
        PartNumber = "3",
        Line = "A1",
        CoilCurrentWeight = decimal.Zero,
        BlankDieNo = decimal.One,
        CoilId = 9,
        CoilType = "",
        RunOrderListId = 1,
        Shift = "",
        BlankPitch = decimal.One,
        BlanksProduced = 8,
        WeightAfter = 9,
        WeightBefore = 88,
        ProdDt = 9,
        SchdDt = 99,
        FTZ = "test",
        BlanksRequested = 7,
        YNANumber = "",
        PressCount = 9,
        BlankStackSize = decimal.One,
        BlankWeight = decimal.One,
        BlankWidth = decimal.One,
        KanbanDt = 8,
        MaintDt = 9,
        MeasuredPitch = 8,
        MeasuredThickness = decimal.One,
        MeasuredWidth = 8,
        RunStarted = DateTime.Now,
        ToolDieDt = 9,
        TryoutDt = 8,
        WeightUsed = decimal.One,
      };
      var _mockLineService = new MockRunService();
      var controller = new RunResultsController(runResultServiceMock.Object);
      runResultServiceMock.Setup(repo => repo.UpdateRunResult(id, runResultDtos))
          .ReturnsAsync(_mockLineService.UpdateRunResult());
      var result = controller.UpdateRunResult(id, data);
      Assert.NotNull(result);
    }

    [Fact]
    public void SaveRunResult_RunResult_ReturnsResponseOk()
    {

      dynamic data = new JObject();
      data.runResult = JObject.Parse(@"{ ""RunResultId"":1,""RunOrderListId"":1, ""CoilId"":1,""FTZ"":""56"", ""CoilType"":""CC"", ""YNA"":""896"", ""OriginalWeight"":1,""Zone"":""a"", ""CoilLocation"":""A"", ""NewWeight"":1, ""AttachedToRunResult"":true,""CoilTypeName"":""CTN"", ""CoilStatusName"":""CS"", ""CoilFieldLocationName"":""B""}");
      var runResultDtos = new RunResultDto()

      {
        Id = 1,
        AdcDt = 4,
        DownTime = 5,
        DataNumber = 9,
        RunFinished = DateTime.Now,
        Comments = "test",
        ModifiedBy = "A",
        PartNumber = "3",
        Line = "A1",
        CoilCurrentWeight = decimal.Zero,
        BlankDieNo = decimal.One,
        CoilId = 9,
        CoilType = "",
        RunOrderListId = 1,
        Shift = "",
        BlankPitch = decimal.One,
        BlanksProduced = 8,
        WeightAfter = 9,
        WeightBefore = 88,
        ProdDt = 9,
        SchdDt = 99,
        FTZ = "test",
        BlanksRequested = 7,
        YNANumber = "",
        PressCount = 9,
        BlankStackSize = decimal.One,
        BlankWeight = decimal.One,
        BlankWidth = decimal.One,
        KanbanDt = 8,
        MaintDt = 9,
        MeasuredPitch = 8,
        MeasuredThickness = decimal.One,
        MeasuredWidth = 8,
        RunStarted = DateTime.Now,
        ToolDieDt = 9,
        TryoutDt = 8,
        WeightUsed = decimal.One,
      };
      var _mockLineService = new MockRunService();
      var controller = new RunResultsController(runResultServiceMock.Object);
      runResultServiceMock.Setup(repo => repo.InsertRunResult(runResultDtos))
          .ReturnsAsync(_mockLineService.SaveRunResult());
      var result = controller.SaveRunResult(data);
      Assert.NotNull(result);
    }





  }
}
