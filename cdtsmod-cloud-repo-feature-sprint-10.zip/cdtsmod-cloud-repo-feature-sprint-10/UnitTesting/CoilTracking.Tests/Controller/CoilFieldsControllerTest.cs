using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using CoilTracking.WebAPI.Controllers;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Collections.Generic;
using Xunit;

namespace CoilTracking.Tests.Controller
{
  public class CoilFieldsControllerTest
  {

    private readonly Mock<ICoilFieldsService> coilFieldService;

    public CoilFieldsControllerTest()
    {

      coilFieldService = new Mock<ICoilFieldsService>();
    }
    [Fact]
    public void GetCoilFields_ReturnsCoilFields()
    {
      var _mockCoilFieldsService = new MockCoilFieldService();
      var controller = new CoilFieldsController(coilFieldService.Object);
      coilFieldService.Setup(repo => repo.GetCoilFields())
      .Returns(_mockCoilFieldsService.GetCoilFields());

      var result = controller.GetCoilFields();
      Assert.NotNull(result);
    }

    [Fact]
    public void GetCoilField_id_ReturnsCoilField()
    {
      var _mockCoilFieldsService = new MockCoilFieldService();
      var controller = new CoilFieldsController(coilFieldService.Object);
      coilFieldService.Setup(repo => repo.GetCoilFieldById(1))
      .Returns(_mockCoilFieldsService.GetCoilFieldById(1));

      var result = controller.GetCoilField(1);
      Assert.NotNull(result);
    }
    [Fact]
    public void GetCoilField_id_ReturnsNotFound()
    {
      var _mockCoilFieldsService = new MockCoilFieldService();
      var controller = new CoilFieldsController(coilFieldService.Object);
      coilFieldService.Setup(repo => repo.GetCoilFieldById(2))
      .Returns(_mockCoilFieldsService.GetCoilFieldById(2));

      var result = controller.GetCoilField(2);
      Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public void GetCoilFieldForEdit_id_ReturnsNotFound()
    {
      var _mockCoilFieldsService = new MockCoilFieldService();
      var controller = new CoilFieldsController(coilFieldService.Object);
      coilFieldService.Setup(repo => repo.GetCoilFieldById(2))
      .Returns(_mockCoilFieldsService.GetCoilFieldById(2));

      var result = controller.GetCoilFieldForEdit(2);
      Assert.IsType<NotFoundResult>(result);
    }
    [Fact]
    public void GetCoilFieldForEdit_id_ReturnsCoilField()
    {
      var _mockCoilFieldsService = new MockCoilFieldService();
      var controller = new CoilFieldsController(coilFieldService.Object);
      coilFieldService.Setup(repo => repo.GetCoilFieldById(1))
      .Returns(_mockCoilFieldsService.GetCoilFieldById(1));

      var result = controller.GetCoilFieldForEdit(1);
      Assert.NotNull(result);
    }

    [Fact]
    public void GetCheckEdit_id_ReturnsNotFound()
    {
      string edited = null;
      var coilField = new CoilFieldDto()
      {
        Id = 1,
        Disabled = false,
        Name = "TMMI"
      };

      var controller = new CoilFieldsController(coilFieldService.Object);
      coilFieldService.Setup(repo => repo.CheckIfEdited(1, coilField))
      .Returns(edited);

      var result = controller.CheckEdit(1, coilField);
      Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public void GetCheckEdit_id_ReturnsBadRequest()
    {
      string edited = "editing";
      var coilField = new CoilFieldDto()
      {
        Id = 1,
        Disabled = false,
        Name = "TMMI"
      };
      var controller = new CoilFieldsController(coilFieldService.Object);
      coilFieldService.Setup(repo => repo.CheckIfEdited(1, coilField))
      .Returns(edited);

      var result = controller.CheckEdit(1, coilField);
      Assert.IsType<BadRequestResult>(result);
    }

    [Fact]
    public void GetAssociatedItemsCoilFieldsZone_id_ReturnsCoilField()
    {
      var _mockCoilFieldsService = new MockCoilFieldService();
      var controller = new CoilFieldsController(coilFieldService.Object);
      coilFieldService.Setup(repo => repo.GetCoilFieldsZoneByCoilFieldId(1))
      .Returns(_mockCoilFieldsService.GetCoilFieldZone());

      var result = controller.GetAssociatedItemsCoilFieldsZone(1);
      Assert.NotNull(result);
    }

    [Fact]
    public void GetCoilListByCoilField_id_ReturnsCoils()
    {
      var _mockCoilFieldsService = new MockMillService();
      var controller = new CoilFieldsController(coilFieldService.Object);
      coilFieldService.Setup(repo => repo.GetCoilsByCoilField(1))
      .Returns(_mockCoilFieldsService.GetCoilsList());

      var result = controller.GetCoilsByCoilField(1);
      Assert.NotNull(result);
    }

    [Fact]
    public void Checkdependency_id_ReturnsString()
    {
      var list = new List<string>()
      {
      "coilType"
      };
      var controller = new CoilFieldsController(coilFieldService.Object);
      coilFieldService.Setup(repo => repo.GetCoilsFieldAssociationType(1))
      .Returns(list);

      var result = controller.CheckDependency(1);
      Assert.NotNull(result);
    }




    [Fact]
    public void DisableCoilField_idAnddisable_ReturnsNotFound()
    {
      bool disable = true;
      var controller = new CoilFieldsController(coilFieldService.Object);
      coilFieldService.Setup(repo => repo.DisableCoilField(1, disable))
      .Returns(false);

      var result = controller.DisableCoilField(2, disable);
      Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public void DisableCoilField_idAnddisable_ReturnsNocontent()
    {
      bool disable = true;
      var controller = new CoilFieldsController(coilFieldService.Object);
      coilFieldService.Setup(repo => repo.DisableCoilField(1, disable))
      .Returns(true);

      var result = controller.DisableCoilField(2, disable);
      Assert.IsType<NotFoundResult>(result);
    }
    [Fact]
    public void UpdateCoilfield_idAndCoilFieldDto_ReturnsBadRequest()
    {

      var coilField = new CoilFieldDto()
      {
        Id = 1,
        Disabled = false,
        Name = "TMMI"
      };
      var controller = new CoilFieldsController(coilFieldService.Object);
      coilFieldService.Setup(repo => repo.UpdateCoilFieldDto(2, coilField))
      .Returns(true);

      var result = controller.UpdateCoilFieldDto(2, coilField);
      Assert.IsType<BadRequestResult>(result);
    }

    [Fact]
    public void UpdateCoilfield_idAndCoilFieldDto_ReturnsNoContent()
    {

      var coilField = new CoilFieldDto()
      {
        Id = 2,
        Disabled = false,
        Name = "TMMI"
      };
      var controller = new CoilFieldsController(coilFieldService.Object);
      coilFieldService.Setup(repo => repo.UpdateCoilFieldDto(2, coilField))
      .Returns(true);

      var result = controller.UpdateCoilFieldDto(2, coilField);
      Assert.IsType<NoContentResult>(result);
    }

    [Fact]
    public void UpdateCoilfield_idAndCoilFieldDto_ReturnsNotFound()
    {

      var coilField = new CoilFieldDto()
      {
        Id = 2,
        Disabled = false,
        Name = "TMMI"
      };
      var controller = new CoilFieldsController(coilFieldService.Object);
      coilFieldService.Setup(repo => repo.UpdateCoilFieldDto(2, coilField))
      .Returns(false);

      var result = controller.UpdateCoilFieldDto(2, coilField);
      Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public void SaveCoilfield_coilFieldDto_ReturnscoilField()
    {

      var coilField = new CoilFieldDto()
      {
        Id = 2,
        Disabled = false,
        Name = "TMMI"
      };
      var controller = new CoilFieldsController(coilFieldService.Object);
      coilFieldService.Setup(repo => repo.SaveCoilFieldDto(coilField))
      .Returns(true);

      var result = controller.SaveCoilFieldDto(coilField);
      Assert.NotNull(result);
    }

    [Fact]
    public void DeleteCoilfield_id_ReturnsCoilField()
    {

      var coilField = new CoilFieldDto()
      {
        Id = 2,
        Disabled = false,
        Name = "TMMI"
      };
      var controller = new CoilFieldsController(coilFieldService.Object);
      coilFieldService.Setup(repo => repo.DeleteCoilField(1))
      .Returns(coilField);

      var result = controller.DeleteCoilField(1);
      Assert.NotNull(result);
    }

    [Fact]
    public void DeleteCoilfield_id_ReturnsNotFound()
    {

      CoilFieldDto coilField = null;
      var controller = new CoilFieldsController(coilFieldService.Object);
      coilFieldService.Setup(repo => repo.DeleteCoilField(1))
      .Returns(coilField);

      var result = controller.DeleteCoilField(1);
      Assert.IsType<NotFoundResult>(result);
    }



  }
}
