using CoilTracking.Business.Interfaces;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Controllers;
using Moq;
using Xunit;

namespace CoilTracking.Tests.Controller
{
  public class ProdPlanControllerTest
  {
    private readonly Mock<IProdPlanService> mockProdPlanService;
    private readonly Mock<IImportProdPlan> mockImportProdPlan;
    private readonly Mock<IUserHelper> usersHelper;
    public ProdPlanControllerTest()
    {
      mockProdPlanService = new Mock<IProdPlanService>();
      mockImportProdPlan = new Mock<IImportProdPlan>();
      usersHelper = new Mock<IUserHelper>();
    }

    [Fact]
    public void GetProdPlans_ReturnsDto()
    {
      var controller = new ProdPlansController(mockProdPlanService.Object, mockImportProdPlan.Object, usersHelper.Object);
      var result = controller.GetProdPlan();
      Assert.NotNull(result);
    }

    [Fact]
    public void GetProdPlan_ReturnsDto()
    {
      var controller = new ProdPlansController(mockProdPlanService.Object, mockImportProdPlan.Object, usersHelper.Object);
      var result = controller.GetProdPlan(1);
      Assert.NotNull(result);
    }

    [Fact]
    public void PutProdPlan()
    {
      var prodPlan = new ProdPlanDto
      {
        Id = 1
      };
      var controller = new ProdPlansController(mockProdPlanService.Object, mockImportProdPlan.Object, usersHelper.Object);
      var result = controller.PutProdPlan(1, prodPlan);
      Assert.NotNull(result);
    }

    [Fact]
    public void PostProdPlan()
    {
      var prodPlan = new ProdPlanDto
      {
        Id = 1
      };
      var controller = new ProdPlansController(mockProdPlanService.Object, mockImportProdPlan.Object, usersHelper.Object);
      var result = controller.PostProdPlan(prodPlan);
      Assert.NotNull(result);
    }

    [Fact]
    public void UploadProdPlan()
    {
      var controller = new ProdPlansController(mockProdPlanService.Object, mockImportProdPlan.Object, usersHelper.Object);
      var result = controller.UploadProdPlan();
      Assert.NotNull(result);
    }

    [Fact]
    public void DeleteProdPlan()
    {
      var controller = new ProdPlansController(mockProdPlanService.Object, mockImportProdPlan.Object, usersHelper.Object);
      var result = controller.DeleteProdPlan(1);
      Assert.NotNull(result);
    }
  }
}
