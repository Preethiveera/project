using CoilTracking.Business.Interfaces;
using CoilTracking.WebAPI.Controllers;
using Moq;
using Xunit;

namespace CoilTracking.Tests
{
  public class AndonCoilTypesByZoneControllerTest
  {
    private readonly Mock<IAndonService> _AndonServiceMock;

    public AndonCoilTypesByZoneControllerTest()
    {
      _AndonServiceMock = new Mock<IAndonService>();
    }
    /// <summary>
    /// AndonCoilTypesByZone Testing
    /// </summary>
    [Fact]
    public void AndonCoilTypesByZone_ReturnZones()
    {
      int? ZoneId = 1;
      var _mockLineService = new MockAndonService();
      var controller = new AndonCoilTypesByZoneController(_AndonServiceMock.Object);
      _AndonServiceMock.Setup(repo => repo.GetCoilsTypesByZoneId(ZoneId))
      .Returns(_mockLineService.GetCoilsTypesByZoneId());
      var result = controller.Get();
      Assert.True(true);
    }


  }
}
