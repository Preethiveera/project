using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using CoilTracking.WebAPI.Controllers;
using Moq;
using System;
using System.Threading.Tasks;
using Xunit;

namespace CoilTracking.Tests.Controller
{
  public class PatternControllerTest
  {
    private readonly Mock<IPatternService> patternServiceMock;


    public PatternControllerTest()
    {
      patternServiceMock = new Mock<IPatternService>();
    }


    [Fact]
    public async Task GetPatternsTest_ReturnsPatternsDto()
    {
      var mockPatternService = new MockPatternService();

      var controller = new PatternsController(patternServiceMock.Object);

      patternServiceMock.Setup(service => service.GetPatterns())
        .ReturnsAsync(mockPatternService.GetPatternsDto());

      var result = await controller.GetPatterns();

      Assert.NotNull(result);
    }

    [Fact]
    public async Task GetPatternTest_Id_ReturnsPatternDto()
    {
      var id = 1;
      var mockPatternService = new MockPatternService();

      var controller = new PatternsController(patternServiceMock.Object);

      patternServiceMock.Setup(service => service.GetPattern(id))
        .ReturnsAsync(mockPatternService.GetPatternDto());

      var result = await controller.GetPattern(id);

      Assert.NotNull(result);
    }

    [Fact]
    public async Task GetPatternTest_LineId_PatternLetter_Year_Month_ReturnsPatternDto()
    {
      var lineId = 1;
      var patternLetter = "P";
      var month = 1;
      var year = 1;

      var mockPatternService = new MockPatternService();

      var controller = new PatternsController(patternServiceMock.Object);

      patternServiceMock.Setup(service => service.GetPattern(lineId, patternLetter, month, year))
        .ReturnsAsync(mockPatternService.GetPatternDto());

      var result = await controller.GetPattern(lineId, patternLetter, month, year);

      Assert.NotNull(result);
    }

    [Fact]
    public async Task PutPatternTest_Id_PatternDto_ReturnsTrue()
    {
      var id = 1;

      var mockPatternService = new MockPatternService();

      var controller = new PatternsController(patternServiceMock.Object);

      patternServiceMock.Setup(service => service.PutPattern(id, mockPatternService.GetPatternDto()))
        .ReturnsAsync(true);

      var result = await controller.PutPattern(id, mockPatternService.GetPatternDto());

      Assert.NotNull(result);
    }

    [Fact]
    public async Task AddPatternTest_PatternDto_ReturnsPatternDto()
    {
      var pattern = new PatternDto()
      {
        Name = "A",
        CreateDate = new DateTime()
      };


      var mockPatternService = new MockPatternService();

      var controller = new PatternsController(patternServiceMock.Object);

      patternServiceMock.Setup(service => service.PostPattern(pattern))
        .ReturnsAsync(mockPatternService.GetPatternDto());

      var result = await controller.PostPattern(pattern);

      Assert.NotNull(result);
    }

    [Fact]
    public async Task DeletePatternTest_Id_ReturnsPatternDto()
    {
      var id = 1;
      var mockPatternService = new MockPatternService();

      var controller = new PatternsController(patternServiceMock.Object);

      patternServiceMock.Setup(service => service.DeletePattern(id))
        .ReturnsAsync(mockPatternService.GetPatternDto());

      var result = await controller.DeletePattern(id);

      Assert.NotNull(result);
    }

  }
}
