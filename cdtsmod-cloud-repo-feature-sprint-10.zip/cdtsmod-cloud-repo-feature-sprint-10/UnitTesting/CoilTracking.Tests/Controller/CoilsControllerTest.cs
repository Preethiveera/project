using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Exception;
using CoilTracking.Data.Models;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using CoilTracking.WebAPI.Controllers;
using Moq;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using Xunit;

namespace CoilTracking.Tests.Controller
{
  public class CoilsControllerTest
  {
    private readonly Mock<ICoilsService> coilsServiceMock;
    public CoilsControllerTest()
    {
      coilsServiceMock = new Mock<ICoilsService>();
    }
    [Fact]
    public void GetCoilsTypes_ReturnsCoils()
    {
      var mockCoilService = new MockCoilsservice();
      var controller = new CoilsController(coilsServiceMock.Object);
      coilsServiceMock.Setup(repo => repo.GetCoils())
      .ReturnsAsync(mockCoilService.GetCoilsDto());
      var coil = controller.GetCoils();
      Assert.NotNull(coil);
    }
    [Fact]
    public void GetPlantCode_Returns_string()
    {
      var mockcoilervice = new MockCoilsservice();
      var controller = new CoilsController(coilsServiceMock.Object);
      coilsServiceMock.Setup(repo => repo.GetPlantCode())
      .ReturnsAsync("Ok");
      var coil = controller.GetNAMCinfo();
      Assert.NotNull(coil);
    }

    [Fact]
    public void Search_Returns_CoilDto()
    {
      DateTime startTime = DateTime.Now;
      DateTime endTime = DateTime.Now;
      string FilterByBornOnDate = "0";
      int? zoneId = null;
      string coilType = null;
      int? coilStatusId = null;
      var mockCoilService = new MockCoilsservice();
      var controller = new CoilsController(coilsServiceMock.Object);
      coilsServiceMock.Setup(repo => repo.SearchForCoils(startTime, endTime, coilType, coilStatusId, zoneId, FilterByBornOnDate))
      .ReturnsAsync(mockCoilService.GetCoilsDto());
      var coil = controller.Search();
      Assert.NotNull(coil);
    }

    [Fact]
    public void GetCoilInventory_ReturnsCoils()
    {
      var mockCoilService = new MockCoilsservice();
      var controller = new CoilsController(coilsServiceMock.Object);
      coilsServiceMock.Setup(repo => repo.GetCoils())
      .ReturnsAsync(mockCoilService.GetCoilsDto());
      var coil = controller.GetCoilInventory();
      Assert.NotNull(coil);
    }

    [Fact]
    public void GetCoilById_ReturnsCoils()
    {
      int id = 7;
      var mockCoilService = new MockCoilsservice();
      var controller = new CoilsController(coilsServiceMock.Object);
      coilsServiceMock.Setup(repo => repo.GetCoils())
      .ReturnsAsync(mockCoilService.GetCoilsDto());
      var coil = controller.GetCoilById(id);
      Assert.NotNull(coil);
    }

    [Fact]
    public void GetCoilByFTZ_ReturnsCoils()
    {
      string yna = "YNA458578";
      var mockCoilService = new MockCoilsservice();
      var controller = new CoilsController(coilsServiceMock.Object);
      coilsServiceMock.Setup(repo => repo.GetCoils())
      .ReturnsAsync(mockCoilService.GetCoilsDto());
      var coil = controller.GetCoilByFTZ(yna);
      Assert.NotNull(coil);
    }

    [Fact]
    public void GetCoilByLocationFullName_ReturnsCoils()
    {
      string Name = "4-B11";
      var mockCoilService = new MockCoilsservice();
      var controller = new CoilsController(coilsServiceMock.Object);
      coilsServiceMock.Setup(repo => repo.GetCoils())
      .ReturnsAsync(mockCoilService.GetCoilsDto());
      var coil = controller.GetCoilByLocationFullName(Name);
      Assert.NotNull(coil);
    }
    [Fact]
    public void GetCoilByLocationId_ReturnsCoils()
    {
      int id = 7;
      var mockCoilService = new MockCoilsservice();
      var controller = new CoilsController(coilsServiceMock.Object);
      coilsServiceMock.Setup(repo => repo.GetCoils())
      .ReturnsAsync(mockCoilService.GetCoilsDto());
      var coil = controller.GetCoilByLocationId(id);
      Assert.NotNull(coil);
    }

    [Fact]
    public void GetCoilForEdit_ReturnsCoils()
    {
      int id = 4;
      var mockCoilService = new MockCoilsservice();
      var controller = new CoilsController(coilsServiceMock.Object);
      coilsServiceMock.Setup(repo => repo.GetCoils())
      .ReturnsAsync(mockCoilService.GetCoilsDto());
      var coil = controller.GetCoilForEdit(id);
      Assert.NotNull(coil);
    }


    [Fact]
    public void GetCoilsToBeWeighed_ReturnsCoils()
    {
      var mockCoilService = new MockCoilsservice();
      var controller = new CoilsController(coilsServiceMock.Object);
      coilsServiceMock.Setup(repo => repo.GetCoils())
      .ReturnsAsync(mockCoilService.GetCoilsDto());
      var coil = controller.GetCoilsToBeWeighed();
      Assert.NotNull(coil);
    }

    [Fact]
    public void GetRemainingCoilWeight_ReturnsCoils()
    {
      int id = 4;
      var mockCoilService = new MockCoilsservice();
      var controller = new CoilsController(coilsServiceMock.Object);
      coilsServiceMock.Setup(repo => repo.GetCoils())
      .ReturnsAsync(mockCoilService.GetCoilsDto());
      var coil = controller.GetRemainingCoilWeight(id);
      Assert.NotNull(coil);
    }


    [Fact]
    public void GetMaterialTypeByYNA_ReturnsMaterialType()
    {
      string yna = "YNA458578";
      var mockCoilService = new MockCoilsservice();
      var controller = new CoilsController(coilsServiceMock.Object);
      coilsServiceMock.Setup(repo => repo.GetCoils())
      .ReturnsAsync(mockCoilService.GetCoilsDto());
      var coil = controller.MaterialTypeByYNA(yna);
      Assert.NotNull(coil);
    }

    [Fact]
    public void CheckDependency_Returnscoils()
    {
      int id = 25;
      var mockCoilService = new MockCoilsservice();
      var controller = new CoilsController(coilsServiceMock.Object);
      coilsServiceMock.Setup(repo => repo.GetCoils())
      .ReturnsAsync(mockCoilService.GetCoilsDto());
      var coil = controller.CheckDependency(id);
      Assert.NotNull(coil);
    }

    [Fact]
    public void PostCoil_Returnscoil()
    {
      Coil coil = new Coil
      {

        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,
        CoilRunHistory = new List<CoilRunHistory>(){ new CoilRunHistory() { Id = 2, Coil= new Coil {   Id = 7,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9 } }  },
        CoilStatus = new CoilStatus() { Id = 8, Name = "test", Color = "test", InInventory = true, IsUsable = true, TextColor = "white" },
        Mill = new Mill() { Id = 9, Name = "test", Disabled = true },
        CoilType = new CoilType() { Id = 7, Name = "test", CoilFieldZone = new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } },
        CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } } } } }


      };
      CoilDto coildto = new CoilDto()
      {

        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        CoilTypeId = 4,
        CoilRunHistory = new List<CoilRunHistoryDto>() { },
        CoilStatusId = 2,
        ZoneId = 1,
        CoilStatus = new CoilStatusDto() { },
        CoilFieldLocation = new CoilFieldLocationDto() { },
        CoilFieldLocationId = 2,
        CoilFieldLocationName = "Name",
        MillId = 2,
        Mill = new MillDto() { },
        OriginalWeight = 4000,
        MillName = "A",
        CoilStatusName = "AA",
        CoilType = new CoilTypeDto() { },
        CoilTypeName = "AA",
        CurrentWeight = 22
      };
      var controller = new CoilsController(coilsServiceMock.Object);
      coilsServiceMock.Setup(repo => repo.InsertCoil(coil))
      .ReturnsAsync(coildto);
      var coils = controller.PostCoil(coil);
      Assert.NotNull(coils);
    }

    [Fact]
    public void PutCoil_Returnscoilint()
    {
      int id = 80;
      Coil coil = new Coil
      {

        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,
        CoilRunHistory = new List<CoilRunHistory>(){ new CoilRunHistory() { Id = 2, Coil= new Coil {   Id = 7,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9 } }  },
        CoilStatus = new CoilStatus() { Id = 8, Name = "test", Color = "test", InInventory = true, IsUsable = true, TextColor = "white" },
        Mill = new Mill() { Id = 9, Name = "test", Disabled = true },
        CoilType = new CoilType() { Id = 7, Name = "test", CoilFieldZone = new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } },
        CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } } } } }


      };
      var controller = new CoilsController(coilsServiceMock.Object);
      coilsServiceMock.Setup(repo => repo.UpdateCoil(id, coil))
     .ReturnsAsync(id);
      coilsServiceMock.Setup(repo => repo.UpdateCoil(id, coil))
      .ReturnsAsync(id);
      var coils = controller.PutCoil(id, coil);
      Assert.NotNull(coils);
    }

    [Fact]
    public void AddUnAccountedWeight_ReturnsString()
    {
      int id = 80;
      var controller = new CoilsController(coilsServiceMock.Object);
      coilsServiceMock.Setup(repo => repo.UpdateUnAccountedWeight(id, id))
     .ReturnsAsync("complete");
      var coils = controller.AddUnAccountedWeight(id, id);
      Assert.NotNull(coils);
    }


    [Fact]
    public void DeleteCoil_ReturnsSuccess()
    {
      int id = 80;
      var controller = new CoilsController(coilsServiceMock.Object);
      var coils = controller.DeleteCoil(id);
      Assert.NotNull(coils);
    }


    [Fact]
    public void DeleteCoil_Returnsfail()
    {
      int id = 80;
      var mockCoilService = new MockCoilsservice();
      var controller = new CoilsController(coilsServiceMock.Object);
      coilsServiceMock.Setup(repo => repo.DeleteCoilById(id))
   .ReturnsAsync(mockCoilService.GetCoilDto);
      var coils = controller.DeleteCoil(id);
      Assert.NotNull(coils);
    }


    [Fact]
    public void CheckEdit_ReturnsListOfString()
    {
      CoilDto coildto = new CoilDto()
      {
        Id = 124,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        CoilTypeId = 4,
        CoilRunHistory = new List<CoilRunHistoryDto>() { },
        CoilStatusId = 2,
        ZoneId = 1,
        CoilStatus = new CoilStatusDto() { },
        CoilFieldLocation = new CoilFieldLocationDto() { },
        CoilFieldLocationId = 2,
        CoilFieldLocationName = "Name",
        MillId = 2,
        Mill = new MillDto() { },
        OriginalWeight = 4000,
        MillName = "A",
        CoilStatusName = "AA",
        CoilType = new CoilTypeDto() { },
        CoilTypeName = "AA",
        CurrentWeight = 22
      };
      int id = 80;
      List<string> check = new List<string>();
      var controller = new CoilsController(coilsServiceMock.Object);
      coilsServiceMock.Setup(repo => repo.CoilCheckEdit(id, coildto))
   .ReturnsAsync(check);
      var coils = controller.CheckEdit(id, coildto);
      Assert.NotNull(coils);
    }

    [Fact]
    public void CheckEdit_ReturnsFail()
    {
      CoilDto coildto = new CoilDto()
      {
        Id = 124,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        CoilTypeId = 4,
        CoilRunHistory = new List<CoilRunHistoryDto>() { },
        CoilStatusId = 2,
        ZoneId = 1,
        CoilStatus = new CoilStatusDto() { },
        CoilFieldLocation = new CoilFieldLocationDto() { },
        CoilFieldLocationId = 2,
        CoilFieldLocationName = "Name",
        MillId = 2,
        Mill = new MillDto() { },
        OriginalWeight = 4000,
        MillName = "A",
        CoilStatusName = "AA",
        CoilType = new CoilTypeDto() { },
        CoilTypeName = "AA",
        CurrentWeight = 22
      };
      int id = 80;
      List<string> check = null;
      var controller = new CoilsController(coilsServiceMock.Object);
      coilsServiceMock.Setup(repo => repo.CoilCheckEdit(id, coildto))
   .ReturnsAsync(check);
      var coils = controller.CheckEdit(id, coildto);
      Assert.NotNull(coils);
    }

    [Fact]
    public void CheckIn_ReturnsCoils()
    {
      CoilCheckIn coilCheckIn = new CoilCheckIn()
      {
        YNANo = "YNA0231512",
        Weight = 100,
        Width = 1370,
        Thickness = decimal.Zero,
        Location = "Test-Test",
        FTZ = "56",
        Mill = "USS",
        BornOnDate = null,
        IsPriorityCoil = false,
        SerialNum = "123"
      };
      var controller = new CoilsController(coilsServiceMock.Object);
      var coils = controller.CheckIn(coilCheckIn);
      Assert.NotNull(coils);
    }

    [Fact]
    public void CheckIn_ReturnsThrowsCoilTrackingException()
    {
      CoilCheckIn coilCheckIn = new CoilCheckIn()
      {
        YNANo = "YNA0231512",
        Weight = 100,
        Width = 1370,
        Thickness = decimal.Zero,
        Location = "Test-Test",
        FTZ = "56",
        Mill = "USS",
        BornOnDate = null,
        IsPriorityCoil = false,
        SerialNum = "123"
      };
      CoilDto coilDto = null;
      var controller = new CoilsController(coilsServiceMock.Object);
      coilsServiceMock.Setup(repo => repo.CoilsCheckIn(null))
   .ReturnsAsync(coilDto);
      Assert.ThrowsAsync<CoilTrackingException>(() => controller.CheckIn(coilCheckIn));
    }





    [Fact]
    public void CreateCoilRunHistory_ReturnsCoils()
    {
      dynamic data = new JObject();
      data.id = 125;
      data.runOrderListId = 12;
      data.weightUsed = 120;
      var controller = new CoilsController(coilsServiceMock.Object);
      var coils = controller.CreateCoilRunHistory(data);
      Assert.NotNull(coils);
    }

    [Fact]
    public void CreateCoilRunHistory_ReturnsThrowsCoilTrackingException()
    {
      dynamic data = new JObject();
      data.id = 125;
      data.runOrderListId = 12;
      data.weightUsed = 120;
      var controller = new CoilsController(coilsServiceMock.Object);
      Assert.ThrowsAsync<CoilTrackingException>(() => controller.CreateCoilRunHistory(data));
    }


    [Fact]
    public void MoveCoil_ReturnsThrowsCoilTrackingException()
    {
      int coilId = 125;
      string newLocation = "Test-Test";
      int newStatusId = 7;
      bool isPriorityCoil = false;
      int? lineId = null;
      var controller = new CoilsController(coilsServiceMock.Object);
      var coils = controller.MoveCoil(coilId, newLocation, newStatusId, isPriorityCoil, lineId);
      Assert.NotNull(coils);
    }

    [Fact]
    public void MoveCoil_ReturnsCoils()
    {
      int coilId = 0;
      string newLocation = null;
      int newStatusId = 7;
      bool isPriorityCoil = false;
      int? lineId = null;
      var controller = new CoilsController(coilsServiceMock.Object);
      Assert.ThrowsAsync<CoilTrackingException>(() => controller.MoveCoil(coilId, newLocation, newStatusId, isPriorityCoil, lineId));
    }




  }
}
