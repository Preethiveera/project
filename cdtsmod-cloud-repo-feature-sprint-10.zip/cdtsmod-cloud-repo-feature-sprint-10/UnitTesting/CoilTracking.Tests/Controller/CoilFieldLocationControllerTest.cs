using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Exception;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using CoilTracking.WebAPI.Controllers;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Threading.Tasks;
using Xunit;

namespace CoilTracking.Tests.Controller
{
  public class CoilFieldLocationControllerTest
  {
    private readonly Mock<ICoilFieldLocationsService> coilFieldLocationServiceMock;

    public CoilFieldLocationControllerTest()
    {
      coilFieldLocationServiceMock = new Mock<ICoilFieldLocationsService>();
    }

    [Fact]
    public void GetCoilFieldLocations()
    {
      var mockCoilFieldLocationService = new MockCoilFieldLocationService();
      var controller = new CoilFieldLocationsController(coilFieldLocationServiceMock.Object);
      coilFieldLocationServiceMock.Setup(repo => repo.GetCoilFieldLocations())
      .Returns(mockCoilFieldLocationService.GetCoilFieldLocations());
      var result = controller.GetCoilFieldLocations();
      Assert.NotNull(result);
    }

    [Fact]
    public void GetCoilFieldLocationById_ReturnsCoilFieldLocationDto()
    {
      int id = 1;
      var mockCoilFieldLocationService = new MockCoilFieldLocationService();
      var controller = new CoilFieldLocationsController(coilFieldLocationServiceMock.Object);
      coilFieldLocationServiceMock.Setup(repo => repo.GetCoilFieldLocationById(id))
      .Returns(mockCoilFieldLocationService.GetCoilFieldLocationById(id));
      var result = controller.GetCoilFieldLocation(id);
      Assert.NotNull(result);

    }


    [Fact]
    public void GetCoilFieldLocationById_ReturnsNotFound()
    {
      int id = 2;
      var mockCoilFieldLocationService = new MockCoilFieldLocationService();
      var controller = new CoilFieldLocationsController(coilFieldLocationServiceMock.Object);
      coilFieldLocationServiceMock.Setup(repo => repo.GetCoilFieldLocationById(id))
      .Returns(mockCoilFieldLocationService.GetCoilFieldLocationById(id));
      var result = controller.GetCoilFieldLocation(id);
      Assert.IsType<NotFoundResult>(result);

    }

    [Fact]
    public void GetCoilFieldLocationForEdit_ReturnsCoilFieldLocationDto()
    {
      int id = 1;
      var mockCoilFieldLocationService = new MockCoilFieldLocationService();
      var controller = new CoilFieldLocationsController(coilFieldLocationServiceMock.Object);
      coilFieldLocationServiceMock.Setup(repo => repo.GetCoilFieldLocationWithZone(id))
      .Returns(mockCoilFieldLocationService.GetCoilFieldLocationForEdit(id));
      var result = controller.GetCoilFieldLocationForEdit(id);
      Assert.NotNull(result);

    }

    [Fact]
    public void GetCoilFieldLocationByCoilId_ReturnsDto()
    {
      int id = 1;
      var mockCoilFieldLocationService = new MockCoilFieldLocationService();
      var controller = new CoilFieldLocationsController(coilFieldLocationServiceMock.Object);
      coilFieldLocationServiceMock.Setup(repo => repo.GetCoilFieldLocationByCoilId(id))
      .Returns(mockCoilFieldLocationService.GetCoilFieldLocationsByCoilId(id));
      var result = controller.GetLocationsByCoilId(id);
      Assert.NotNull(result);

    }

    [Fact]
    public void GetCoilFieldLocationByZonesId_ReturnsDto()
    {
      int id = 1;
      var mockCoilFieldLocationService = new MockCoilFieldLocationService();
      var controller = new CoilFieldLocationsController(coilFieldLocationServiceMock.Object);
      coilFieldLocationServiceMock.Setup(repo => repo.GetCoilFieldLocationByZoneId(id))
      .Returns(mockCoilFieldLocationService.GetCoilFieldLocationsByZoneId(id));
      var result = controller.GetLocationsByZoneId(id);
      Assert.NotNull(result);

    }

    [Fact]
    public void PutCoilFieldLocation_ReturnsBadRequest()
    {
      var coilFieldLocation = new CoilFieldLocationDto
      {
        Id = 1,
        Name = "Abc"
      };

      var mockCoilFieldLocationService = new MockCoilFieldLocationService();
      var controller = new CoilFieldLocationsController(coilFieldLocationServiceMock.Object);
      coilFieldLocationServiceMock.Setup(repo => repo.UpdateCoilFieldLocation(2, coilFieldLocation));

      var result = controller.PutCoilFieldLocation(2, coilFieldLocation);
      Assert.IsType<BadRequestResult>(result);
    }

    [Fact]
    public void PutCoilFieldLocation_ReturnsNoContent()
    {
      var coilFieldLocation = new CoilFieldLocationDto
      {
        Id = 1,
        Name = "Test"
      };

      var mockCoilFieldLocationService = new MockCoilFieldLocationService();
      var controller = new CoilFieldLocationsController(coilFieldLocationServiceMock.Object);
      coilFieldLocationServiceMock.Setup(repo => repo.UpdateCoilFieldLocation(1, coilFieldLocation));

      var result = controller.PutCoilFieldLocation(1, coilFieldLocation);
      Assert.IsType<NoContentResult>(result);
    }

    [Fact]

    public void DisableCoilFieldLocation_ReturnsNotNull()
    {
      var mockCoilFieldLocationService = new MockCoilFieldLocationService();
      var controller = new CoilFieldLocationsController(coilFieldLocationServiceMock.Object);
      coilFieldLocationServiceMock.Setup(repo => repo.DisableCoilFieldLocation(1, true))
        .Returns(Task.FromResult(ApplicationMessages.completed));

      var result = controller.DisableCoilFieldLocation(1, true);
      Assert.NotNull(result);
    }

    [Fact]
    public void UpdateCoilFieldLocation_ReturnsNotNull()
    {
      var coilFieldLocation = new CoilFieldLocationDto
      {
        Id = 1,
        Name = "Test"
      };

      var mockCoilFieldLocationService = new MockCoilFieldLocationService();
      var controller = new CoilFieldLocationsController(coilFieldLocationServiceMock.Object);
      coilFieldLocationServiceMock.Setup(repo => repo.UpdateCoilFieldLocationDto(1, coilFieldLocation));

      var result = controller.UpdateCoilFieldLocationDto(1, coilFieldLocation);
      Assert.NotNull(result);
    }

    [Fact]
    public void UpdateCoilFieldLocation_ReturnsBadRequest()
    {
      var coilFieldLocation = new CoilFieldLocationDto
      {
        Id = 1,
        Name = "Abc"
      };

      var mockCoilFieldLocationService = new MockCoilFieldLocationService();
      var controller = new CoilFieldLocationsController(coilFieldLocationServiceMock.Object);
      coilFieldLocationServiceMock.Setup(repo => repo.UpdateCoilFieldLocation(2, coilFieldLocation));

      var result = controller.PutCoilFieldLocation(2, coilFieldLocation);
      Assert.IsType<BadRequestResult>(result);
    }

    [Fact]
    public void PostCoilFieldLocation_ReturnsDto()
    {
      var coilFieldLocation = new CoilFieldLocationDto
      {
        Id = 1,
        Name = "Abc"
      };

      var mockCoilFieldLocationService = new MockCoilFieldLocationService();
      var controller = new CoilFieldLocationsController(coilFieldLocationServiceMock.Object);

      coilFieldLocationServiceMock.Setup(repo => repo.AddCoilFieldLocation(coilFieldLocation));

      var result = controller.PostCoilFieldLocation(coilFieldLocation);
      Assert.NotNull(result);
    }

    [Fact]
    public void SaveCoilFieldLocation_ReturnsDto()
    {
      var coilFieldLocation = new CoilFieldLocationDto
      {
        Id = 1,
        Name = "Abc"
      };

      var mockCoilFieldLocationService = new MockCoilFieldLocationService();
      var controller = new CoilFieldLocationsController(coilFieldLocationServiceMock.Object);

      coilFieldLocationServiceMock.Setup(repo => repo.AddCoilFieldLocation(coilFieldLocation));

      var result = controller.SaveCoilFieldLocationDto(coilFieldLocation);
      Assert.NotNull(result);
    }

    [Fact]
    public void DeleteCoilFieldLocation_ReturnsDto()
    {
      var mockCoilFieldLocationService = new MockCoilFieldLocationService();
      var controller = new CoilFieldLocationsController(coilFieldLocationServiceMock.Object);

      coilFieldLocationServiceMock.Setup(repo => repo.DeleteCoilFieldLocation(1));

      var result = controller.DeleteCoilFieldLocation(1);
      Assert.NotNull(result);
    }
  }
}
