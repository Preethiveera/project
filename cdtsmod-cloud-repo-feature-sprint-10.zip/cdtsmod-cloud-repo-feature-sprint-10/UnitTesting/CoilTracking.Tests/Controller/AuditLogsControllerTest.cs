using CoilTracking.Business.Interfaces;
using CoilTracking.Tests.Service;
using CoilTracking.WebAPI.Controllers;
using Moq;
using System;
using Xunit;

namespace CoilTracking.Tests.Controller
{
  public class AuditLogsControllerTest
  {

    private readonly Mock<IAuditLogsService> _auditLogsServiceMock;

    public AuditLogsControllerTest()
    {
      _auditLogsServiceMock = new Mock<IAuditLogsService>();
    }

    [Fact]
    public void AuditLogExists_Id_ReturnsAuditLogs()
    {
      var _mockAuditLogsService = new MockAuditLogsService();
      var controller = new AuditLogsController(_auditLogsServiceMock.Object);
      _auditLogsServiceMock.Setup(repo => repo.IsAuditLogExists(1))
      .Returns(_mockAuditLogsService.AuditLogExists());

      var result = controller.GetAuditLogs();
      Assert.NotNull(result);
    }

    [Fact]
    public void GetAuditLogs_ReturnsAuditLogs()
    {

      var _mockAuditLogsService = new MockAuditLogsService();
      var controller = new AuditLogsController(_auditLogsServiceMock.Object);
      _auditLogsServiceMock.Setup(repo => repo.GetAuditLogs())
      .Returns(_mockAuditLogsService.GetAuditLogs());

      var result = controller.GetAuditLogs();
      Assert.NotNull(result);
    }

    [Fact]
    public void Search_endTimeAndstartTimeAnduserNameAndActionTypeAndClassName_ReturnsAuditLogsDto()
    {
      DateTime endTime = DateTime.Now;
      DateTime startTime = DateTime.Now;
      string username = null;
      int? actionType = null;
      string className = null;
      var _mockAuditLogsService = new MockAuditLogsService();
      var controller = new AuditLogsController(_auditLogsServiceMock.Object);
      _auditLogsServiceMock.Setup(repo => repo.Search(startTime, endTime, username, actionType, className))
      .Returns(_mockAuditLogsService.GetAuditLogModel());

      controller.Search();
      Assert.NotNull(controller);


    }
  }
}
