using CoilTracking.Business.Interfaces;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using CoilTracking.WebAPI.Controllers;
using Moq;
using System.Collections.Generic;
using Xunit;

namespace CoilTracking.Tests.Controller
{
  public class CoilTypesControllerTest
  {
    private readonly Mock<ICoilTypeService> coilTypeServiceMock;
    private readonly Mock<IImportCoilTypeData> importCoilTypeDataService;
    private readonly Mock<IWebSocketClientService> webSocketClientService;
    private readonly Mock<IUserHelper> usersHelper;
    public CoilTypesControllerTest()
    {
      coilTypeServiceMock = new Mock<ICoilTypeService>();
      importCoilTypeDataService = new Mock<IImportCoilTypeData>();
      webSocketClientService = new Mock<IWebSocketClientService>();
      usersHelper = new Mock<IUserHelper>();
    }
    [Fact]
    public void CheckDependency()
    {
      int id = 5;
      var mockCoilTypeService = new MockCoilTypeService();
      var controller = new CoilTypesController(coilTypeServiceMock.Object, importCoilTypeDataService.Object, webSocketClientService.Object, usersHelper.Object);
      coilTypeServiceMock.Setup(repo => repo.GetCoilsTypes())
      .ReturnsAsync(mockCoilTypeService.GetCoilsTypes());
      var coilTypes = controller.CheckDependency(id);
      Assert.NotNull(coilTypes);
    }
    [Fact]
    public void CheckEditReturnsCoilType_ReturnsCoilType()
    {
      int id = 1;
      CoilTypeDto coilTypeDto = new CoilTypeDto() { Id = 1, NAMC = "", Yield = decimal.Zero, Name = "T", Width = 1, Spec = "A", Thickness = decimal.One, MinWidth = decimal.One, NumCoils = 104, MinThickness = decimal.One, MaxWidth = decimal.One, MaterialTypeName = "A", MaxThickness = decimal.Zero, CoilFieldZone = new CoilFieldZoneDto() { Id = 1, Name = "A", Color = "S", Disabled = true, TextColor = "W", CoilFieldId = 1, Locations = new List<CoilFieldLocationDto>() { } } };

      var mockCoilTypeService = new MockCoilTypeService();
      var controller = new CoilTypesController(coilTypeServiceMock.Object, importCoilTypeDataService.Object, webSocketClientService.Object, usersHelper.Object);
      coilTypeServiceMock.Setup(repo => repo.GetCoilsTypes())
      .ReturnsAsync(mockCoilTypeService.GetCoilsTypes());
      var coilTypes = controller.CheckEdit(id, coilTypeDto);
      Assert.NotNull(coilTypes);
    }
    [Fact]
    public void DeleteCoilTypeById__ReturnsCoilType()
    {
      int id = 0;
      var mockCoilTypeService = new MockCoilTypeService();
      var controller = new CoilTypesController(coilTypeServiceMock.Object, importCoilTypeDataService.Object, webSocketClientService.Object, usersHelper.Object);
      coilTypeServiceMock.Setup(repo => repo.GetCoilsTypes())
      .ReturnsAsync(mockCoilTypeService.GetCoilsTypes());
      var coilTypes = controller.DeleteCoilType(id);
      Assert.NotNull(coilTypes);
    }
    [Fact]
    public void DisableCoilType_ReturnsCoilType()
    {
      int id = 4;
      var mockCoilTypeService = new MockCoilTypeService();
      var controller = new CoilTypesController(coilTypeServiceMock.Object, importCoilTypeDataService.Object, webSocketClientService.Object, usersHelper.Object);
      coilTypeServiceMock.Setup(repo => repo.GetCoilsTypes())
      .ReturnsAsync(mockCoilTypeService.GetCoilsTypes());
      var coilTypes = controller.DisableCoilType(id, true);
      Assert.NotNull(coilTypes);
    }
    [Fact]
    public void GetCoilsByCoilTypeId_ReturnsCoilType()
    {
      int id = 5;
      var mockCoilTypeService = new MockCoilTypeService();
      var controller = new CoilTypesController(coilTypeServiceMock.Object, importCoilTypeDataService.Object, webSocketClientService.Object, usersHelper.Object);
      coilTypeServiceMock.Setup(repo => repo.GetCoilsTypes())
      .ReturnsAsync(mockCoilTypeService.GetCoilsTypes());
      var coilTypes = controller.GetAssociatedItemsCoilTypes(id);
      Assert.NotNull(coilTypes);
    }
    [Fact]
    public void GetCoilsLoadedForCoilType_ReturnsCoilType()
    {
      int id = 5;
      var mockCoilTypeService = new MockCoilTypeService();
      var controller = new CoilTypesController(coilTypeServiceMock.Object, importCoilTypeDataService.Object, webSocketClientService.Object, usersHelper.Object);
      coilTypeServiceMock.Setup(repo => repo.GetCoilsTypes())
      .ReturnsAsync(mockCoilTypeService.GetCoilsTypes());
      var coilTypes = controller.GetCoilsLoadedForCoilType(id);
      Assert.NotNull(coilTypes);
    }
    [Fact]
    public void GetCoilsTypes_ReturnsCoilType()
    {
      var mockCoilTypeService = new MockCoilTypeService();
      var controller = new CoilTypesController(coilTypeServiceMock.Object, importCoilTypeDataService.Object, webSocketClientService.Object, usersHelper.Object);
      coilTypeServiceMock.Setup(repo => repo.GetCoilsTypes())
      .ReturnsAsync(mockCoilTypeService.GetCoilsTypes());
      var coilTypes = controller.GetCoilTypeDtos();
      Assert.NotNull(coilTypes);
    }
    [Fact]
    public void GetCoilTypes_ReturnsCoilType()
    {
      var mockCoilTypeService = new MockCoilTypeService();
      var controller = new CoilTypesController(coilTypeServiceMock.Object, importCoilTypeDataService.Object, webSocketClientService.Object, usersHelper.Object);
      coilTypeServiceMock.Setup(repo => repo.GetCoilsTypes())
      .ReturnsAsync(mockCoilTypeService.GetCoilsTypes());
      var coilTypes = controller.GetCoilTypes();
      Assert.NotNull(coilTypes);
    }
    [Fact]
    public void GetCoilTypesById_ReturnsCoilType()
    {
      int id = 5;
      var mockCoilTypeService = new MockCoilTypeService();
      var controller = new CoilTypesController(coilTypeServiceMock.Object, importCoilTypeDataService.Object, webSocketClientService.Object, usersHelper.Object);
      coilTypeServiceMock.Setup(repo => repo.GetCoilsTypes())
      .ReturnsAsync(mockCoilTypeService.GetCoilsTypes());
      var coilTypes = controller.GetCoilType(id);
      Assert.NotNull(coilTypes);
    }
    [Fact]
    public void GetMaterialTypes_ReturnsCoilType()
    {

      var mockCoilTypeService = new MockCoilTypeService();
      var controller = new CoilTypesController(coilTypeServiceMock.Object, importCoilTypeDataService.Object, webSocketClientService.Object, usersHelper.Object);
      coilTypeServiceMock.Setup(repo => repo.GetCoilsTypes())
      .ReturnsAsync(mockCoilTypeService.GetCoilsTypes());
      var coilTypes = controller.GetMaterialTypes();
      Assert.NotNull(coilTypes);
    }
    [Fact]
    public void InsertCoilType_ReturnsCoilType()
    {
      CoilTypeDto coilTypeDto = new CoilTypeDto() { Id = 1, NAMC = "", Yield = decimal.Zero, Name = "T", Width = 1, Spec = "A", Thickness = decimal.One, MinWidth = decimal.One, NumCoils = 104, MinThickness = decimal.One, MaxWidth = decimal.One, MaterialTypeName = "A", MaxThickness = decimal.Zero, CoilFieldZone = new CoilFieldZoneDto() { Id = 1, Name = "A", Color = "S", Disabled = true, TextColor = "W", CoilFieldId = 1, Locations = new List<CoilFieldLocationDto>() { } } };

      var mockCoilTypeService = new MockCoilTypeService();
      var controller = new CoilTypesController(coilTypeServiceMock.Object, importCoilTypeDataService.Object, webSocketClientService.Object, usersHelper.Object);
      coilTypeServiceMock.Setup(repo => repo.GetCoilsTypes())
      .ReturnsAsync(mockCoilTypeService.GetCoilsTypes());
      var coilTypes = controller.PostCoilType(coilTypeDto);
      Assert.NotNull(coilTypes);
    }
    [Fact]
    public void UpdateCoilType_ReturnsCoilType()
    {
      int id = 1;
      CoilTypeDto coilTypeDto = new CoilTypeDto() { Id = 1, NAMC = "", Yield = decimal.Zero, Name = "T", Width = 1, Spec = "A", Thickness = decimal.One, MinWidth = decimal.One, NumCoils = 104, MinThickness = decimal.One, MaxWidth = decimal.One, MaterialTypeName = "A", MaxThickness = decimal.Zero, CoilFieldZone = new CoilFieldZoneDto() { Id = 1, Name = "A", Color = "S", Disabled = true, TextColor = "W", CoilFieldId = 1, Locations = new List<CoilFieldLocationDto>() { } } };
      var mockCoilTypeService = new MockCoilTypeService();
      var controller = new CoilTypesController(coilTypeServiceMock.Object, importCoilTypeDataService.Object, webSocketClientService.Object, usersHelper.Object);
      coilTypeServiceMock.Setup(repo => repo.GetCoilsTypes())
      .ReturnsAsync(mockCoilTypeService.GetCoilsTypes());
      var coilTypes = controller.PutCoilType(id, coilTypeDto);
      Assert.NotNull(coilTypes);
    }
  }
}
