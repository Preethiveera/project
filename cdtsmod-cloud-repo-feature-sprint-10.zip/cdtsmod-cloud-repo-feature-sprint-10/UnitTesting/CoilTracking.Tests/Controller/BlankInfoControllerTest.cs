using CoilTracking.Business.Interfaces;
using CoilTracking.Business.Interfaces.BlockingDiagrams;
using CoilTracking.Common.Logging;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data.Models;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using CoilTracking.WebAPI.Controllers;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace CoilTracking.Tests.Controller
{
  public class BlankInfoControllerTest
  {
    private readonly Mock<IApplicationLogger<BlankInfoController>> logger;
    private readonly Mock<IBlankInfoService> _blankInfoServiceMock;
    private readonly Mock<IImportBlankData> _importBlankInfoService;
    private readonly Mock<IUserHelper> usersHelper;
    private readonly Mock<IAWSS3BucketHelper> aWSS3BucketHelper;
    public BlankInfoControllerTest()
    {
      _blankInfoServiceMock = new Mock<IBlankInfoService>();
      _importBlankInfoService = new Mock<IImportBlankData>();
      usersHelper = new Mock<IUserHelper>();
      logger = new Mock<IApplicationLogger<BlankInfoController>>();
      aWSS3BucketHelper = new Mock<IAWSS3BucketHelper>();
    }


    /// <summary>
    /// to get the blankInfoes
    /// </summary>
    /// <returns></returns>
    [Fact]
    public void GetDatas()
    {
      var data = new List<BlankInfo>
      {
        new BlankInfo
        {
          Id=1
        }
      };
      var controller = new BlankInfoController(_blankInfoServiceMock.Object, _importBlankInfoService.Object,usersHelper.Object, logger.Object, aWSS3BucketHelper.Object);
      _blankInfoServiceMock.Setup(repo => repo.GetAllBlankInfo())
      .Returns(data.AsQueryable);
      var result = controller.GetDatas();
      Assert.NotNull(result);

    }

    [Fact]
    public void GetBlankInfoById_BlankInfoDto_ReturnsBlankInfoById()
    {
      int id = 1;
      var _mockblankInfoService = new MockBlankInfoService();
      var controller = new BlankInfoController(_blankInfoServiceMock.Object, _importBlankInfoService.Object,usersHelper.Object, logger.Object, aWSS3BucketHelper.Object);
      _blankInfoServiceMock.Setup(repo => repo.GetBlankInfoById(id))
      .Returns(_mockblankInfoService.GetBlankInfoById(id));
      var result = controller.GetBlankInfo(id);
      Assert.NotNull(result);

    }


    [Fact]
    public void GetBlankInfoById_BlankInfoDto_ReturnsNotFound()
    {

      int id = 2;
      var _mockblankInfoService = new MockBlankInfoService();
      var controller = new BlankInfoController(_blankInfoServiceMock.Object, _importBlankInfoService.Object,usersHelper.Object, logger.Object, aWSS3BucketHelper.Object);
      _blankInfoServiceMock.Setup(repo => repo.GetBlankInfoById(id))
      .Returns(_mockblankInfoService.GetBlankInfoById(id));
      var result = controller.GetBlankInfo(id);
      Assert.IsType<NotFoundResult>(result);

    }

    [Fact]
    public void GetNAMCinfo_ReturnsNAMCCode()
    {
      var _mockblankInfoService = new MockBlankInfoService();
      var controller = new BlankInfoController(_blankInfoServiceMock.Object, _importBlankInfoService.Object,usersHelper.Object, logger.Object, aWSS3BucketHelper.Object);
      _blankInfoServiceMock.Setup(repo => repo.GetNAMCinfo())
      .Returns(_mockblankInfoService.GetNAMCinfo());
      var result = controller.GetNAMCinfo();
      Assert.NotNull(result);
    }
    [Fact]
    public void GetNAMCinfo_ReturnsNA()
    {
      var _mockblankInfoService = new MockBlankInfoService();
      var controller = new BlankInfoController(_blankInfoServiceMock.Object, _importBlankInfoService.Object,usersHelper.Object, logger.Object, aWSS3BucketHelper.Object);
      _blankInfoServiceMock.Setup(repo => repo.GetNAMCinfo())
      .Returns(_mockblankInfoService.GetNAMCinfoReturnsNA());
      var result = controller.GetNAMCinfo();
      Assert.NotNull(result);
    }

    [Fact]
    public void GetBlankInfoForEdit_BlankInfoDto_ReturnsBlankInfoById()
    {
      int id = 1;
      var _mockblankInfoService = new MockBlankInfoService();
      var controller = new BlankInfoController(_blankInfoServiceMock.Object, _importBlankInfoService.Object,usersHelper.Object, logger.Object, aWSS3BucketHelper.Object);
      _blankInfoServiceMock.Setup(repo => repo.GetBlankInfoById(id))
      .Returns(_mockblankInfoService.GetBlankInfoById(id));
      var result = controller.GetBlankInfoForEdit(id);
      Assert.NotNull(result);

    }


    [Fact]
    public void GetBlankInfoForEdit_BlankInfoDto_ReturnsNotFound()
    {

      int id = 2;
      var _mockblankInfoService = new MockBlankInfoService();
      var controller = new BlankInfoController(_blankInfoServiceMock.Object, _importBlankInfoService.Object,usersHelper.Object, logger.Object, aWSS3BucketHelper.Object);
      _blankInfoServiceMock.Setup(repo => repo.GetBlankInfoById(id))
      .Returns(_mockblankInfoService.GetBlankInfoById(id));
      var result = controller.GetBlankInfoForEdit(id);
      Assert.IsType<NotFoundResult>(result);

    }

    [Fact]
    public void GetBlankInfoFromDataNumber_DataNumandLineId_ReturnsBlankInfoDto()
    {
      int dataNum = 1;
      int lineId = 1;
      var _mockblankInfoService = new MockBlankInfoService();
      var controller = new BlankInfoController(_blankInfoServiceMock.Object, _importBlankInfoService.Object,usersHelper.Object, logger.Object, aWSS3BucketHelper.Object);
      _blankInfoServiceMock.Setup(repo => repo.GetBlankInfoByDataNumAndLineId(dataNum, lineId))
      .Returns(_mockblankInfoService.GetBlankInfoByIdModel(lineId));
      var result = controller.GetBlankInfoFromDataNumber(dataNum, lineId);
      Assert.NotNull(result);
    }
    [Fact]
    public void GetBlankInfoFromDataNumber_DataNumandLineId_ReturnsNotFound()
    {
      int dataNum = 1;
      int lineId = 3;
      var _mockblankInfoService = new MockBlankInfoService();
      var controller = new BlankInfoController(_blankInfoServiceMock.Object, _importBlankInfoService.Object,usersHelper.Object, logger.Object, aWSS3BucketHelper.Object);
      _blankInfoServiceMock.Setup(repo => repo.GetBlankInfoByDataNumAndLineId(dataNum, lineId))
      .Returns(_mockblankInfoService.GetBlankInfoByIdModel(lineId));
      var result = controller.GetBlankInfoFromDataNumber(dataNum, lineId);
      Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public void CheckDependency_id_ReturnsStringlist()
    {

      int id = 1;

      var controller = new BlankInfoController(_blankInfoServiceMock.Object, _importBlankInfoService.Object,usersHelper.Object, logger.Object, aWSS3BucketHelper.Object);
      _blankInfoServiceMock.Setup(repo => repo.IsBlankInfoDependent(id))
      .Returns(true);
      var result = controller.CheckDependency(id);
      Assert.NotNull(result);
    }

    [Fact]
    public void PostBlankInfo_BlankInfoDto_Returnsblankinfo()
    {

      var blankInfo =
    new BlankInfoDto()
    {
      Id = 1,
      LineId = 1,
      MaxPitch = 12,
      MaxWidth = 22,
      MinPitch = 11,
      PartId = 1,
      Pitch = 12,
      StackSize = 345,
      Weight = 1234,
      Width = 123,
      Disabled = false,
      DieNo = 2,
      DataNumber = 1,
      CoilTypeId = 2,
      RewindWeight = 10,

    };

      var controller = new BlankInfoController(_blankInfoServiceMock.Object, _importBlankInfoService.Object,usersHelper.Object, logger.Object, aWSS3BucketHelper.Object);
      _blankInfoServiceMock.Setup(repo => repo.AddNewBlankInfo(blankInfo))
      .ReturnsAsync(true);
      var result = controller.PostBlankInfo(blankInfo);
      Assert.NotNull(result);
    }
    [Fact]
    public void SaveInfoDto_BlankInfoDto_Returnsblankinfo()
    {

      var blankInfo =
    new BlankInfoDto()
    {
      Id = 1,
      LineId = 1,
      MaxPitch = 12,
      MaxWidth = 22,
      MinPitch = 11,
      PartId = 1,
      Pitch = 12,
      StackSize = 345,
      Weight = 1234,
      Width = 123,
      Disabled = false,
      DieNo = 2,
      DataNumber = 1,
      CoilTypeId = 2,
      RewindWeight = 10,

    };
      var controller = new BlankInfoController(_blankInfoServiceMock.Object, _importBlankInfoService.Object,usersHelper.Object, logger.Object, aWSS3BucketHelper.Object);
      _blankInfoServiceMock.Setup(repo => repo.AddNewBlankInfo(blankInfo))
      .ReturnsAsync(true);
      var result = controller.SaveBlankInfoDto(blankInfo);
      Assert.NotNull(result);
    }

    [Fact]
    public void CheckEdit_idandDto_ReturnsNotFound()
    {
      var dto =
   new BlankInfoDto()
   {
     Id = 1,
     LineId = 1,
     MaxPitch = 12,
     MaxWidth = 22,
     MinPitch = 11,
     PartId = 1,
     Pitch = 12,
     StackSize = 345,
     Weight = 1234,
     Width = 123,
     Disabled = false,
     DieNo = 2,
     DataNumber = 1,
     CoilTypeId = 2,
     RewindWeight = 10,

   };

      int id = 1;
      var controller = new BlankInfoController(_blankInfoServiceMock.Object, _importBlankInfoService.Object,usersHelper.Object, logger.Object, aWSS3BucketHelper.Object);
      _blankInfoServiceMock.Setup(repo => repo.CheckEdit(id, dto))
      .ReturnsAsync(true);
      var result = controller.CheckEdit(id, dto).Result;
      Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public void CheckEdit_idandDto_ReturnsBadRequest()
    {
      var dto =
   new BlankInfoDto()
   {
     Id = 1,
     LineId = 1,
     MaxPitch = 12,
     MaxWidth = 22,
     MinPitch = 11,
     PartId = 1,
     Pitch = 12,
     StackSize = 345,
     Weight = 1234,
     Width = 123,
     Disabled = false,
     DieNo = 2,
     DataNumber = 1,
     CoilTypeId = 2,
     RewindWeight = 10,

   };

      int id = 1;

      var controller = new BlankInfoController(_blankInfoServiceMock.Object, _importBlankInfoService.Object,usersHelper.Object, logger.Object, aWSS3BucketHelper.Object);
      _blankInfoServiceMock.Setup(repo => repo.CheckEdit(id, dto))
      .ReturnsAsync(false);
      var result = controller.CheckEdit(id, dto).Result;
      Assert.IsType<BadRequestResult>(result);
    }
    [Fact]
    public void UpdateBlankInfoDto_idAndDto_ReturnsBadRequest()
    {
      var dto =
  new BlankInfoDto()
  {
    Id = 1,
    LineId = 1,
    MaxPitch = 12,
    MaxWidth = 22,
    MinPitch = 11,
    PartId = 1,
    Pitch = 12,
    StackSize = 345,
    Weight = 1234,
    Width = 123,
    Disabled = false,
    DieNo = 2,
    DataNumber = 1,
    CoilTypeId = 2,
    RewindWeight = 10,

  };

      int id = 3;
      var controller = new BlankInfoController(_blankInfoServiceMock.Object, _importBlankInfoService.Object,usersHelper.Object, logger.Object, aWSS3BucketHelper.Object);
      var result = controller.UpdateBlankInfoDto(id, dto);
      Assert.IsType<BadRequestResult>(result);

    }

    [Fact]
    public void UpdateBlankInfoDto_idAndDto_ReturnsNoContent()
    {

      var dto =
  new BlankInfoDto()
  {
    Id = 1,
    LineId = 1,
    MaxPitch = 12,
    MaxWidth = 22,
    MinPitch = 11,
    PartId = 1,
    Pitch = 12,
    StackSize = 345,
    Weight = 1234,
    Width = 123,
    Disabled = false,
    DieNo = 2,
    DataNumber = 1,
    CoilTypeId = 2,
    RewindWeight = 10,

  };

      int id = 1;
      var controller = new BlankInfoController(_blankInfoServiceMock.Object, _importBlankInfoService.Object,usersHelper.Object, logger.Object, aWSS3BucketHelper.Object);

      var result = controller.UpdateBlankInfoDto(id, dto);
      Assert.IsType<NoContentResult>(result);

    }

    [Fact]
    public void DisableBlank_idAndDisable_ReturnsNocontent()
    {
      bool disable = true;
      int id = 1;
      var controller = new BlankInfoController(_blankInfoServiceMock.Object, _importBlankInfoService.Object,usersHelper.Object, logger.Object, aWSS3BucketHelper.Object);

      var result = controller.DisableBlank(id, disable);
      Assert.IsType<NoContentResult>(result);
    }

    [Fact]
    public void DeleteBlankInfo()
    {
      var blankInfo =
     new BlankInfoDto()
     {
       Id = 1,
       LineId = 1,
       MaxPitch = 12,
       MaxWidth = 22,
       MinPitch = 11,
       PartId = 1,
       Pitch = 12,
       StackSize = 345,
       Weight = 1234,
       Width = 123,
       Disabled = false,
       DieNo = 2,
       DataNumber = 1,
       CoilTypeId = 2,
       RewindWeight = 10,

     };
      int id = 1;
      var controller = new BlankInfoController(_blankInfoServiceMock.Object, _importBlankInfoService.Object,usersHelper.Object, logger.Object, aWSS3BucketHelper.Object);
      _blankInfoServiceMock.Setup(repo => repo.DeleteBlankInfo(id))
      .Returns(blankInfo);
      var result = controller.DeleteBlankInfo(id);
      Assert.NotNull(result);
    }
  }
}
