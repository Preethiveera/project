using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Controllers;
using Moq;
using Xunit;

namespace CoilTracking.Tests.Controller
{
  public class ShiftControllerTest
  {
    private readonly Mock<IShiftService> mockShiftService;

    public ShiftControllerTest()
    {
      mockShiftService = new Mock<IShiftService>();
    }

    [Fact]
    public void GetShifts_ReturnsDto()
    {
      var controller = new ShiftsController(mockShiftService.Object);
      var result = controller.GetShifts();
      Assert.NotNull(result);
    }

    [Fact]
    public void GetShiftById_ReturnsDto()
    {
      var controller = new ShiftsController(mockShiftService.Object);
      var result = controller.GetShift(1);
      Assert.NotNull(result);
    }

    [Fact]
    public void GetCurrentShift_ReturnsDto()
    {
      var controller = new ShiftsController(mockShiftService.Object);
      var result = controller.GetCurrentShift(1);
      Assert.NotNull(result);
    }

    [Fact]
    public void GetNextShift_ReturnsDto()
    {
      var controller = new ShiftsController(mockShiftService.Object);
      var result = controller.GetNextShift(1);
      Assert.NotNull(result);
    }

    [Fact]
    public void PutShift_ReturnsDto()
    {
      var shift = new ShiftDto
      {
        Id = 1
      };
      var controller = new ShiftsController(mockShiftService.Object);
      var result = controller.PutShift(1, shift);
      Assert.NotNull(result);
    }

    [Fact]
    public void DisableShift_ReturnsDto()
    {
      var controller = new ShiftsController(mockShiftService.Object);
      var result = controller.DisableShift(1, true);
      Assert.NotNull(result);
    }

    [Fact]
    public void PostShift_ReturnsDto()
    {
      var shift = new ShiftDto
      {
        Id = 1
      };
      var controller = new ShiftsController(mockShiftService.Object);
      var result = controller.PostShift(shift);
      Assert.NotNull(result);
    }

    [Fact]
    public void DeleteShift_ReturnsDto()
    {
      var controller = new ShiftsController(mockShiftService.Object);
      var result = controller.DeleteShift(1);
      Assert.NotNull(result);
    }
  }
}
