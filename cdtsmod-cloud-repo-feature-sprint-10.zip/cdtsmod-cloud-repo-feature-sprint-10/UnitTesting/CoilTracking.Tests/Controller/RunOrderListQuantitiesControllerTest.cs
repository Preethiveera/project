using CoilTracking.Business.Interfaces;
using CoilTracking.Data.Models;
using CoilTracking.Tests.Service;
using CoilTracking.WebAPI.Controllers;
using Moq;
using System.Linq;
using Xunit;

namespace CoilTracking.Tests.Controller
{
  public class RunOrderListQuantitiesControllerTest
  {
    private readonly Mock<IRunOrderListQuantityService> runOrderListQuantityServiceMock;
    public RunOrderListQuantitiesControllerTest()
    {
      runOrderListQuantityServiceMock = new Mock<IRunOrderListQuantityService>();
    }
    [Fact]
    public void GetRunOrderListQuantities_ReturnRunOrderListQuantities()
    {
      var _MockRunOrderListQuantitiesService = new MockRunOrderListQuantitiesService();
      var controller = new RunOrderListQuantitiesController(runOrderListQuantityServiceMock.Object);
      runOrderListQuantityServiceMock.Setup(repo => repo.GetRunOrderListQuantities().Result)
      .Returns(_MockRunOrderListQuantitiesService.GetRunOrderListQuantities().ToList());
      var result = controller.GetRunOrderListQuantities();
      Assert.NotNull(result);
    }
    [Fact]
    public void GetRunOrderListQuantity_ReturnRunOrderListQuantities()
    {
      int id = 3;
      var _MockRunOrderListQuantitiesService = new MockRunOrderListQuantitiesService();
      var controller = new RunOrderListQuantitiesController(runOrderListQuantityServiceMock.Object);
      runOrderListQuantityServiceMock.Setup(repo => repo.GetRunOrderListQuantity(id))
      .Returns(_MockRunOrderListQuantitiesService.GetRunOrderListQuantity());
      var result = controller.GetRunOrderListQuantity(id);
      Assert.NotNull(result);
    }

    [Fact]
    public void GetRunOrderItem_ReturnRunOrderItemForCreate()
    {
      int lineid = 3;
      string partnumber = "82378-SDF";
      int sortorder = 2;
      var _MockRunOrderListQuantitiesService = new MockRunOrderListQuantitiesService();
      var controller = new RunOrderListQuantitiesController(runOrderListQuantityServiceMock.Object);
      runOrderListQuantityServiceMock.Setup(repo => repo.GetRunOrderItem(lineid, partnumber, sortorder))
      .Returns(_MockRunOrderListQuantitiesService.GetRunOrderItem());
      var result = controller.GetRunOrderItem(lineid, partnumber, sortorder);
      Assert.NotNull(result);
    }


    [Fact]
    public void PutRunOrderListQuantity_Returns_Success()
    {
      int id = 3;
      RunOrderListQuantity runOrderListQuantity = new RunOrderListQuantity()
      {
        Id = 3,
        BlankInfo = new BlankInfo() { CoilType = new CoilType() { Name = "A1" }, Id = 1, DataNumber = 1, DieNo = 6, Disabled = true },
        Incomplete = true,
        OverrideQty = 1,
        Quantity = 1,
        Part = new Part() { },
        RunOrderList = new RunOrderList() { },
        SortOrder = 1
      };
      var _MockRunOrderListQuantitiesService = new MockRunOrderListQuantitiesService();
      var controller = new RunOrderListQuantitiesController(runOrderListQuantityServiceMock.Object);
      runOrderListQuantityServiceMock.Setup(repo => repo.UpdateRunOrderListQuantity(id, runOrderListQuantity));
      var result = controller.PutRunOrderListQuantity(id, runOrderListQuantity);
      Assert.NotNull(result);
    }
    [Fact]
    public void PostRunOrderListQuantity_Returns_Success()
    {
      RunOrderListQuantity runOrderListQuantity = new RunOrderListQuantity()
      {
        Id = 3,
        BlankInfo = new BlankInfo() { CoilType = new CoilType() { Name = "A1" }, Id = 1, DataNumber = 1, DieNo = 6, Disabled = true },
        Incomplete = true,
        OverrideQty = 1,
        Quantity = 1,
        Part = new Part() { },
        RunOrderList = new RunOrderList() { },
        SortOrder = 1
      };
      var _MockRunOrderListQuantitiesService = new MockRunOrderListQuantitiesService();
      var controller = new RunOrderListQuantitiesController(runOrderListQuantityServiceMock.Object);
      runOrderListQuantityServiceMock.Setup(repo => repo.InsertRunOrderListQuantity(runOrderListQuantity));
      var result = controller.PostRunOrderListQuantity(runOrderListQuantity);
      Assert.NotNull(result);
    }

    [Fact]
    public void DeleteRunOrderListQuantity_Returns_Success()
    {
      int id = 0;
      var _MockRunOrderListQuantitiesService = new MockRunOrderListQuantitiesService();
      var controller = new RunOrderListQuantitiesController(runOrderListQuantityServiceMock.Object);
      runOrderListQuantityServiceMock.Setup(repo => repo.DeleteRunOrderListQuantity(id));
      var result = controller.DeleteRunOrderListQuantity(id);
      Assert.NotNull(result);
    }
  }
}
