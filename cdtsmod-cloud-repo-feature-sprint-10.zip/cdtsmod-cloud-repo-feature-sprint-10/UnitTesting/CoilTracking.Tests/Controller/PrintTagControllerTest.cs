using CoilTracking.Business.Interfaces;
using CoilTracking.WebAPI.Controllers;
using Moq;
using Newtonsoft.Json.Linq;
using Xunit;

namespace CoilTracking.Tests.Controller
{
  public class PrintTagControllerTest
  {
    private readonly Mock<IPrintTagService> service;

    public PrintTagControllerTest()
    {
      service = new Mock<IPrintTagService>();
    }

    [Fact]
    public void GetCurrentRunList_ReturnsDto()
    {
      var controller = new PrintTagController(service.Object);
      var result = controller.GetCurrentRunList();
      Assert.NotNull(result);
    }

    [Fact]
    public void PrintBlankTag()
    {
      string printType = "Automatic";
      var data = new JObject();
      var controller = new PrintTagController(service.Object);
      var result = controller.PrintBlankTag(printType, data);
      Assert.NotNull(result);
    }

    [Fact]
    public void PrintBlankTagTest()
    {
      var controller = new PrintTagController(service.Object);
      controller.PrintBlankTagTest();
      Assert.NotNull(controller);
    }
  }
}
