using CoilTracking.Business.Interfaces;
using CoilTracking.Tests.Service;
using CoilTracking.WebAPI.Controllers;
using Moq;
using Xunit;

namespace CoilTracking.Tests.Controller
{
  public class AdminInfoControllerTest
  {

    private readonly Mock<IAdminInfoService> _adminInfoServiceMock;

    public AdminInfoControllerTest()
    {

      _adminInfoServiceMock = new Mock<IAdminInfoService>();
    }

    [Fact]
    public void GetDashboardCounts()
    {

      var _mockAdminInfoService = new MockAdminInfoService();
      var controller = new AdminInfoController(_adminInfoServiceMock.Object);
      _adminInfoServiceMock.Setup(repo => repo.GetDashboardCounts())
      .Returns(_mockAdminInfoService.GetDashboardCounts());

      var result = controller.GetDashboardCounts();
      Assert.NotNull(result);
    }
  }
}
