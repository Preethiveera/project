using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using CoilTracking.WebAPI.Controllers;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Collections.Generic;
using Xunit;

namespace CoilTracking.Tests.Controller
{
  public class MillsControllerTest
  {
    private readonly Mock<IMillService> millService;

    public MillsControllerTest()
    {

      millService = new Mock<IMillService>();
    }

    [Fact]
    public void GetMills_ReturnsMills()
    {
      var _mockMillsService = new MockMillService();
      var controller = new MillsController(millService.Object);
      millService.Setup(repo => repo.GetMills())
      .Returns(_mockMillsService.GetMills());

      var result = controller.GetMills();
      Assert.NotNull(result);
    }


    [Fact]
    public void GetMillsById_Id_ReturnsMills()
    {
      var _mockMillsService = new MockMillService();
      var controller = new MillsController(millService.Object);
      millService.Setup(repo => repo.GetMillById(1))
      .Returns(_mockMillsService.GetMillsById(1));

      var result = controller.GetMill(1);
      Assert.NotNull(result);
    }

    [Fact]
    public void GetMillsById_Id_ReturnsNull()
    {
      var _mockMillsService = new MockMillService();
      var controller = new MillsController(millService.Object);
      millService.Setup(repo => repo.GetMillById(1))
      .Returns(_mockMillsService.GetMillsById(2));

      var result = controller.GetMill(1);
      Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public void GetAssociatedItemsMills_Id_ReturnsCoils()
    {
      var _mockMillsService = new MockMillService();
      var controller = new MillsController(millService.Object);
      millService.Setup(repo => repo.GetAssociatedItemsMills(1))
      .Returns(_mockMillsService.GetCoilsList());

      var result = controller.GetAssociatedItemsMills(1);
      Assert.NotNull(result);
    }

    [Fact]
    public void GetLoadedCoilsById_Id_ReturnsCoils()
    {
      var _mockMillsService = new MockMillService();
      var controller = new MillsController(millService.Object);
      millService.Setup(repo => repo.GetLoadedCoilsById(1))
      .Returns(_mockMillsService.GetCoilsList());

      var result = controller.GetLoadedCoilsById(1);
      Assert.NotNull(result);
    }

    [Fact]
    public void CheckEdit_IdAndMill_ReturnsBadReq()
    {
      int id = 1;
      var mill = new MillDto()
      {
        Name = "Mittal",
        Disabled = false

      };

      var controller = new MillsController(millService.Object);
      millService.Setup(repo => repo.CheckIfEdited(id, mill))
      .Returns("edited");

      var result = controller.CheckEdit(id, mill);
      Assert.IsType<BadRequestResult>(result);
    }

    [Fact]
    public void CheckEdit_IdAndMill_ReturnsNotFound()
    {
      string res = null;
      int id = 1;
      var mill = new MillDto()
      {
        Name = "Mittal",
        Disabled = false

      };

      var controller = new MillsController(millService.Object);
      millService.Setup(repo => repo.CheckIfEdited(id, mill))
      .Returns(res);

      var result = controller.CheckEdit(id, mill);
      Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public void CheckDependency_IdAndMill_ReturnsStringList()
    {
      List<string> outList = new List<string>() { "loaded" };

      int id = 1;

      var controller = new MillsController(millService.Object);
      millService.Setup(repo => repo.CheckDependencyType(id))
      .Returns(outList);

      var result = controller.CheckDependency(id);
      Assert.NotNull(result);
    }

    [Fact]
    public void DisableMill_IdAnddisable_ReturnsActionResultOk()
    {
      bool disable = false;
      int id = 1;

      var controller = new MillsController(millService.Object);
      millService.Setup(repo => repo.DisableMill(id, disable))
      .Returns(true);

      var result = controller.DisableMill(id, disable);
      Assert.NotNull(result);
    }
    [Fact]
    public void DisableMill_IdAnddisable_ReturnsActionResultNotFound()
    {
      bool disable = false;
      int id = 1;

      var controller = new MillsController(millService.Object);
      millService.Setup(repo => repo.DisableMill(id, disable))
      .Returns(false);

      var result = controller.DisableMill(id, disable);
      Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public void InsertMill_Mill_ReturnsOk()
    {

      var mill = new MillDto()
      {
        Name = "Mittal",
        Disabled = false

      };
      var controller = new MillsController(millService.Object);
      millService.Setup(repo => repo.InsertMill(mill))
      .Returns(true);

      var result = controller.PostMill(mill);
      Assert.NotNull(result);
    }

    [Fact]
    public void DeleteMill_Id_Returnsmill()
    {
      int id = 1;
      var mill = new MillDto()
      {
        Name = "Mittal",
        Disabled = false

      };
      var controller = new MillsController(millService.Object);
      millService.Setup(repo => repo.DeleteMill(id))
      .Returns(mill);

      var result = controller.DeleteMill(id);
      Assert.NotNull(result);
    }

    [Fact]
    public void DeleteMill_Id_ReturnsNotFound()
    {
      int id = 1;
      MillDto mill = null;
      var controller = new MillsController(millService.Object);
      millService.Setup(repo => repo.DeleteMill(id))
      .Returns(mill);

      var result = controller.DeleteMill(id);
      Assert.IsType<NotFoundResult>(result);
    }
    [Fact]
    public void PutMill_IdAndMill_ReturnsNocontent()
    {
      int id = 1;
      var mill = new MillDto()
      {
        Name = "Mittal",
        Disabled = false

      };
      var controller = new MillsController(millService.Object);
      millService.Setup(repo => repo.UpdateMill(id, mill))
      .Returns(true);

      var result = controller.PutMill(id, mill);
      Assert.IsType<NoContentResult>(result);
    }

    [Fact]
    public void PutMill_IdAndMill_ReturnsNotFound()
    {
      int id = 1;
      var mill = new MillDto()
      {
        Name = "Mittal",
        Disabled = false

      };
      var controller = new MillsController(millService.Object);
      millService.Setup(repo => repo.UpdateMill(id, mill))
      .Returns(false);

      var result = controller.PutMill(id, mill);
      Assert.IsType<NotFoundResult>(result);
    }


  }

}
