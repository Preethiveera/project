
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.WebAPI.Controllers;
using Moq;
using Xunit;

namespace CoilTracking.Tests.Controller
{
  public class PressPatternImportControllerTest
  {
    private Mock<IImportPressPattern> mockImportPressPattern;
    private Mock<IUserHelper> mockUserHelper;

    public PressPatternImportControllerTest()
    {
      mockImportPressPattern = new Mock<IImportPressPattern>();
      mockUserHelper = new Mock<IUserHelper>();
    }

    [Fact]
    public void UploadPressPattern()
    {
      var controller = new PressPatternImportController(mockImportPressPattern.Object, mockUserHelper.Object);
      var result = controller.UploadPressPattern();
      Assert.NotNull(result);
    }
  }
}
