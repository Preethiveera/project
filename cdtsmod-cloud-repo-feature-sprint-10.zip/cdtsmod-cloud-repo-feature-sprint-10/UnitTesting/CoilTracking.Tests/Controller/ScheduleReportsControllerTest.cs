using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.Tests.Service;
using CoilTracking.WebAPI.Controllers;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

namespace CoilTracking.Tests.Controller
{
  public class ScheduleReportsControllerTest
  {
    private readonly Mock<IScheduleReportService> scheduleReportServiceMock;

    public ScheduleReportsControllerTest()
    {
      scheduleReportServiceMock = new Mock<IScheduleReportService>();
    }

    [Fact]
    public void GetScheduleReportTest()
    {

      var _mockScheduleReportService = new MockScheduleReportService();
      var controller = new ScheduleReportsController(scheduleReportServiceMock.Object);
      scheduleReportServiceMock.Setup(repo => repo.GetScheduleReport())
      .Returns(_mockScheduleReportService.GetScheduleReport());
      var result = controller.Get();
      Assert.NotNull(result);
    }

    [Fact]
    public void GetScheduleReportForEditTest()
    {
      var _mockScheduleReportService = new MockScheduleReportService();
      var controller = new ScheduleReportsController(scheduleReportServiceMock.Object);
      scheduleReportServiceMock.Setup(repo => repo.GetScheduleReportById(1))
      .Returns(_mockScheduleReportService.GetScheduleReportById());
      var result = controller.GetScheduleReportForEdit(1);
      Assert.NotNull(result);
    }
    [Fact]
    public void GetScheduleReportForEditReturnsBadRequest()
    {
      var _mockScheduleReportService = new MockScheduleReportService();
      var controller = new ScheduleReportsController(scheduleReportServiceMock.Object);
      scheduleReportServiceMock.Setup(repo => repo.GetScheduleReportById(100))
      .Returns(_mockScheduleReportService.GetScheduleReportByIdReturnsbadRequest(100));
      var result = controller.GetScheduleReportForEdit(100);
      Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public void AddReportEmail()
    {
      var scheduleReport = new ScheduleReportDto
      {
        Id = 1,
        Email = "pritam.mondal@toyota.com",
        CoilReport = true,
        RunReport = false,
        ScrapReport = false,
      };

      var _mockScheduleReportService = new MockScheduleReportService();
      var controller = new ScheduleReportsController(scheduleReportServiceMock.Object);
      scheduleReportServiceMock.Setup(repo => repo.PostScheduleReport(scheduleReport))
      .Returns(_mockScheduleReportService.PostScheduleReport(scheduleReport));
      var result = controller.AddReportEmail(scheduleReport);
      Assert.NotNull(result);
    }



    [Fact]
    public void EditReportEmailReturnsNocontent()
    {
      int id = 1;
      var scheduleReport = new ScheduleReportDto
      {
        Id = 1,
        Email = "pritam.mondal@toyota.com",
        CoilReport = true,
        RunReport = false,
        ScrapReport = false,
      };

      var _mockScheduleReportService = new MockScheduleReportService();
      var controller = new ScheduleReportsController(scheduleReportServiceMock.Object);
      scheduleReportServiceMock.Setup(repo => repo.PutScheduleReport(id, scheduleReport))
      .Returns(_mockScheduleReportService.PutScheduleReport(id, scheduleReport));
      var result = controller.EditReportEmail(id, scheduleReport);
      Assert.IsType<NoContentResult>(result);
    }
  }
}
