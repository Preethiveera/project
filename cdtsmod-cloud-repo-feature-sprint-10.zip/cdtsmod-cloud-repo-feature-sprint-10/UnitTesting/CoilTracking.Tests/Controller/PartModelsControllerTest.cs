using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Controllers;
using Moq;
using Xunit;

namespace CoilTracking.Tests.Controller
{
  public class PartModelsControllerTest
  {
    private readonly Mock<IPartModelService> mockPartModelService;

    public PartModelsControllerTest()
    {
      mockPartModelService = new Mock<IPartModelService>();
    }

    [Fact]
    public void GetPartModels_ReturnsDto()
    {
      var controller = new PartModelsController(mockPartModelService.Object);
      var response = controller.GetPartModels();
      Assert.NotNull(response);
    }

    [Fact]
    public void GetPartModelById_ReturnsDto()
    {
      var controller = new PartModelsController(mockPartModelService.Object);
      var response = controller.GetPartModel(1);
      Assert.NotNull(response);
    }

    [Fact]
    public void PutPartModel()
    {
      var partModel = new PartModelDto
      {
        Id = 1
      };
      var controller = new PartModelsController(mockPartModelService.Object);
      var response = controller.PutPartModel(1, partModel);
      Assert.NotNull(response);
    }

    [Fact]
    public void PostPartModel()
    {
      var partModel = new PartModelDto
      {
        Id = 1
      };
      var controller = new PartModelsController(mockPartModelService.Object);
      var response = controller.PostPartModel(partModel);
      Assert.NotNull(response);
    }

    [Fact]
    public void DeletePartModel()
    {
      var controller = new PartModelsController(mockPartModelService.Object);
      var response = controller.DeletePartModel(1);
      Assert.NotNull(response);
    }
  }
}
