using CoilTracking.Business.Interfaces;
using CoilTracking.WebAPI.Controllers;
using Moq;
using Xunit;

namespace CoilTracking.Tests
{
  public class AndonBlankingLinesControllerTests
  {
    private readonly Mock<ILineService> _lineServiceMock;
    public AndonBlankingLinesControllerTests()
    {
      _lineServiceMock = new Mock<ILineService>();
    }
    /// <summary>
    /// 
    /// </summary>
    [Fact]
    public void Get_returns_string()
    {
      var _mockLineService = new MockLineService();
      _lineServiceMock.Setup(repo => repo.GetLinesForAndons())
      .Returns(_mockLineService.GetLinesForAndons());
      var controller = new AndonBlankingLinesController(_lineServiceMock.Object);

      var result = controller.Get();
      Assert.Single(result);
    }

  }
}
