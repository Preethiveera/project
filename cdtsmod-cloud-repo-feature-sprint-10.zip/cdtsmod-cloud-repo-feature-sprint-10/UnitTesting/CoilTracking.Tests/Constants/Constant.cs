using CoilTracking.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace CoilTracking.Tests.Constants
{
  public static class Constant
  {

    public static string connection = new ConfigurationBuilder().AddJsonFile("appsettings.development.json").Build().GetSection("ConnectionStrings")["CDTSConnectionString"];

    public static CoilTrackingContext _context;

 

  }
}
