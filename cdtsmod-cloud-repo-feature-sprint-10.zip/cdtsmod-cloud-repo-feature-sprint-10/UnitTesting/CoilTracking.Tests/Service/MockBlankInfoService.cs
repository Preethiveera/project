using CoilTracking.Data.Models;
using CoilTracking.DTO;
using System.Collections.Generic;
using System.Linq;
using static CoilTracking.Business.Implementation.ImportBlankData;

namespace CoilTracking.Tests.Service
{
  public class MockBlankInfoService
  {
    public IQueryable<BlankInfoDto> GetDatas()
    {
      var blankInfo = new List<BlankInfoDto>
            {
           new BlankInfoDto()
          {
            Id =1,
            LineId = 1,
            MaxPitch = 12,
            MaxWidth = 22,
            MinPitch = 11,
            PartId = 1,
            Pitch = 12,
            StackSize =345,
            Weight = 1234,
            Width = 123,
            Disabled = false,
            DieNo = 2,
            DataNumber = 1,
            CoilTypeId = 2,
            RewindWeight = 10,

           }
            };

      return blankInfo.AsQueryable();

    }

    public Line GetLines()
    {
      var line = new Line()
      {
        Id = 1

      };
      return line;
    }
    public List<Line> GetLinesList()
    {
      var line = new List<Line>
            { new Line()
            {
                Id = 1

            },
             new Line()
             {
                  Id = 2
             }


            };
      return line;
    }
    public Part GetPart()
    {
      var part = new Part()
      {
        Id = 1

      };
      return part;
    }
    public CoilType GetCoilType()
    {
      var part = new CoilType()
      {
        Id = 1

      };
      return part;
    }
    public IQueryable<BlankInfo> GetDatasReturnsmodel()
    {
      var blankInfo = new List<BlankInfo>
            {
           new BlankInfo()
          {
            Id =1,
            Line=new Line(){ Id=1},
            MaxPitch = 12,
            MaxWidth = 22,
            MinPitch = 11,
           Part = new Part(){Id=1 },
            Pitch = 12,
            StackSize =345,
            Weight = 1234,
            Width = 123,
            Disabled = false,
            DieNo = 2,
            DataNumber = 1,
           CoilType = new CoilType() { Id = 1, Name = "test" },
            RewindWeight = 10,

           }
            };

      return blankInfo.AsQueryable();

    }
    public BlankInfoDto GetBlankInfoById(int id)
    {

      var blankInfo =
     new BlankInfoDto()
     {
       Id = 1,
       LineId = 1,
       MaxPitch = 12,
       MaxWidth = 22,
       MinPitch = 11,
       PartId = 1,
       Pitch = 12,
       StackSize = 345,
       Weight = 1234,
       Width = 123,
       Disabled = false,
       DieNo = 2,
       DataNumber = 1,
       CoilTypeId = 2,
       RewindWeight = 10,

     };

      if (id == blankInfo.Id)
        return blankInfo;
      return null;


    }

    public BlankInfo GetBlankInfoByIdReturnsModel(int id)
    {

      var blankInfo =
     new BlankInfo()
     {
       Id = 1,
       Line = new Line() { Id = 1 },
       MaxPitch = 12,
       MaxWidth = 22,
       MinPitch = 11,
       Part = new Part() { Id = 1 },
       Pitch = 12,
       StackSize = 345,
       Weight = 1234,
       Width = 123,
       Disabled = false,
       DieNo = 2,
       DataNumber = 1,
       CoilType = new CoilType() { Id = 2 },
       RewindWeight = 10,

     };

      if (id == blankInfo.Id)
        return blankInfo;
      return null;


    }

    public string GetNAMCinfo()
    {
      var NAMCCode = "02";

      return NAMCCode;
    }
    public string GetNAMCinfoReturnsNA()
    {
      var NAMCCode = "01";

      return NAMCCode;
    }

    public List<IncompleteRunOrderItem> GetIncompleteRunOrderList()
    {
      var list = new List<IncompleteRunOrderItem> { new IncompleteRunOrderItem
            {
                Id=1,
                Quantity=22
            }
            };

      return list;
    }
    public List<IncompleteRunOrderItem> GetIncompleteRunOrderListReturnempty()
    {
      List<IncompleteRunOrderItem> list = new List<IncompleteRunOrderItem>();

      return list;
    }

    public BlankDataRecord GetRecords()
    {
      var record = new BlankDataRecord()
      {
        PartName = "61111-06190",
        LineName = "BL1",
        CoilTypeName = "1-1-A",
        PressName = "1A",
        DataNumber = 1990,
        Pitch = 1,
        StackSize = 234,
        Width = 9,
        Weight = 789,
        RewindWeight = 23,
        MinPitch = 87,
        MaxPitch = 99,
        MinWidth = 44,
        MaxWidth = 66,
        DieNo = 12
      };
      return record;

    }
    public BlankInfo GetBlankInfoByIdModel(int id)
    {

      var blankInfo =
     new BlankInfo()
     {
       Id = 1,
       Line=new Line { Id = 1 },
       MaxPitch = 12,
       MaxWidth = 22,
       MinPitch = 11,
       Part=new Part { Id = 1 },
       Pitch = 12,
       StackSize = 345,
       Weight = 1234,
       Width = 123,
       Disabled = false,
       DieNo = 2,
       DataNumber = 1,
       CoilType=new CoilType { Id = 2 },
       RewindWeight = 10,

     };

      if (id == blankInfo.Id)
        return blankInfo;
      return null;


    }

  }
}
