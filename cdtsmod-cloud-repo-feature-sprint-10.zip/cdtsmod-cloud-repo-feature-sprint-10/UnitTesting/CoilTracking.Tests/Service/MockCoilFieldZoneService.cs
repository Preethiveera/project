using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Tests.Service
{
  public class MockCoilFieldZoneService
  {
    public async Task<List<CoilFieldZoneDto>> GetCoilFieldZones()
    {

      var list = await Task.Run(() => new List<CoilFieldZoneDto> { new CoilFieldZoneDto()
      {
        Id = 1,
        Disabled = false,
        Name = "Test 1 Zone",
        CoilField = new CoilFieldDto(),
        Color = null,
        Locations = null,
        TextColor = "Red"
      }});

      return list;
    }


    public async Task<CoilFieldZoneDto> GetCoilFieldZone(int id)
    {
      var coilFieldZoneDto = await Task.Run(() => new CoilFieldZoneDto
      {
        Id = 1,
        Disabled = false,
        Name = "Test 1 Zone",
        CoilField = new CoilFieldDto(),
        Color = null,
        Locations = null,
        TextColor = "Red"
      });

      if (id != coilFieldZoneDto.Id)
      {
        return null;
      }

      return coilFieldZoneDto;
    }

    public async Task<CoilFieldZoneDto> GetCoilFieldZoneForEdit(int id)
    {
      var coilFieldZoneDto = await Task.Run(() => new CoilFieldZoneDto
      {
        Id = 1,
        Disabled = false,
        Name = "Test 1 Zone",
        CoilField = new CoilFieldDto(),
        Color = null,
        Locations = null,
        TextColor = "Red"
      });

      if (id != coilFieldZoneDto.Id)
      {
        return null;
      }
      return coilFieldZoneDto;
    }

    public async Task<List<CoilTypeDto>> GetAssociatedItemsCoilFieldsZone(int zoneId)
    {
      var coilTypeDtoList = await Task.Run(() => new List<CoilTypeDto> { new CoilTypeDto()
      {
        Id=1,
        Disabled=false,
        Name="Coil 1",
        CoilFieldZoneId = 1,
        CoilFieldZone = null,
        MaxWidth = 2,
        CoilTypeYNAs = null,
        MaxThickness = 2,
        MinThickness = 1,
        MinWidth = 1
      }});

      if (!coilTypeDtoList.Any(x => x.CoilFieldZoneId == zoneId))
      {
        return null;
      }

      return coilTypeDtoList;
    }

    public async Task<List<CoilDto>> GetCoilsByZoneId(int zoneId)
    {
      var coilDtoList = await Task.Run(() => new List<CoilDto> { new CoilDto()
      {
        Id=1,
        ZoneId = 1,
        BornOnDate = DateTime.Now.AddDays(-4),
        CheckInDate = DateTime.Now.AddDays(-2),
        CoilFieldLocation = null,
        OrderNo = 12,
        SerialNum = "123",
      }});

      if (!coilDtoList.Any(x => x.ZoneId == zoneId))
      {
        return null;
      }
      return coilDtoList;
    }

    public async Task<List<string>> CheckDependencyByZoneId(int zoneId)
    {
      List<string> fieldZoneAssociation = new List<string>();
      await Task.Run(() => fieldZoneAssociation.Add("coilzone"));
      return fieldZoneAssociation;

    }
  }
}
