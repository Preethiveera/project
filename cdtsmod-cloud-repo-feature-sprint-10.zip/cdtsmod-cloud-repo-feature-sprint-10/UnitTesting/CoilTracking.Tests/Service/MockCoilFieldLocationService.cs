using CoilTracking.Data.Models;
using CoilTracking.DTO;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Tests.Service
{
  public class MockCoilFieldLocationService
  {
    public IQueryable<CoilFieldLocationDto> GetCoilFieldLocations()
    {
      var coilFieldLocations = new List<CoilFieldLocationDto>
      {
        new CoilFieldLocationDto()
        {
          Id = 1,
          IsEmpty = true,
          Column = 1,
          Disabled = false,
          Name = "Test",
          Row = 1,
          ZoneId = 1
        }
      };

      return coilFieldLocations.AsQueryable();
    }

    public CoilFieldLocationDto GetCoilFieldLocationById(int id)
    {
      var coilFieldLocation = new CoilFieldLocationDto()
      {
        Id = 1,
        IsEmpty = true,
        Column = 1,
        Disabled = false,
        Name = "Test",
        Row = 1,
        ZoneId = 1
      };

      if (coilFieldLocation.Id == id)
      {
        return coilFieldLocation;
      }

      return null;
    }

    public Task<CoilFieldLocationDto> GetCoilFieldLocationForEdit(int id)
    {
      var coilFieldLocation = new CoilFieldLocationDto()
      {
        Id = 1,
        IsEmpty = true,
        Column = 1,
        Disabled = false,
        Name = "Test",
        Row = 1,
        ZoneId = 1,
      };

      if (coilFieldLocation.Id == id)
      {
        return Task.FromResult(coilFieldLocation);
      }

      return null;
    }

    public List<CoilFieldLocationDto> GetCoilFieldLocationsByCoilId(int coilId)
    {
      var coilFieldLocations = new List<CoilFieldLocationDto>
      {
        new CoilFieldLocationDto()
        {
          Id = 1,
          IsEmpty = true,
          Column = 1,
          Disabled = false,
          Name = "Test",
          Row = 1,
          ZoneId = 1,
          Zone = new CoilFieldZoneDto
          {
            CoilFieldId = 1,
          }
        }
      };

      return coilFieldLocations;
    }

    public List<CoilFieldLocationDto> GetCoilFieldLocationsByZoneId(int zoneId)
    {
      var coilFieldLocations = new List<CoilFieldLocationDto>
      {
        new CoilFieldLocationDto()
        {
          Id = 1,
          IsEmpty = true,
          Column = 1,
          Disabled = false,
          Name = "Test",
          Row = 1,
          ZoneId = 1,
          Zone = new CoilFieldZoneDto
          {
            CoilFieldId = 1,
            Id = 1
          }
        }
      };

      return coilFieldLocations;
    }

    public IQueryable<CoilFieldLocation> GetCoilFieldLocationsList()
    {
      var coilFieldLocations = new List<CoilFieldLocation>
      {
        new CoilFieldLocation()
        {
          Id = 1,
          IsEmpty = true,
          Column = 1,
          Disabled = false,
          Name = "Test",
          Row = 1
        }
      };

      return coilFieldLocations.AsQueryable();
    }
  }
}
