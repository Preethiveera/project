using CoilTracking.Data.Models;
using CoilTracking.DTO;
using System.Collections.Generic;
using System.Linq;

namespace CoilTracking.Tests
{
  public class MockAndonService
  {
    /// <summary>
    /// 
    /// </summary>
    /// <param name="zoneId"></param>
    /// <returns></returns>

    public static AndonCoilFieldZoneDisplayObject Get_Success()
    {
      AndonCoilFieldZoneDisplayObject AndonCoilFieldZoneDisplayObject = new AndonCoilFieldZoneDisplayObject()
      {
        TotalZoneColumns = 0,
        Zones = new List<AndonCoilFieldZone>()
                {
                    new AndonCoilFieldZone()
                    {
                        BackgroundColor = "", Columns = 0, Name = "", Rows = 0, TextColor = "",
                        Locations = new List<AndonCoilFieldZoneLocation>()
                        {
                            new AndonCoilFieldZoneLocation()
                            {
                                BackgroundColor = "", TextColor = "", Name = "", Column = 1, CoilType = "",
                                IsEmpty = true, Row = 0
                            }
                        }
                    }
                }

      };
      return AndonCoilFieldZoneDisplayObject;
    }



    /// <summary>
    /// 
    /// </summary>
    /// <param name="zoneId"></param>
    /// <returns></returns>
    public AndonCoilTypesByZoneDisplayObject GetCoilsTypesByZoneId()
    {
      AndonCoilTypesByZoneDisplayObject andonDisplayObject = new AndonCoilTypesByZoneDisplayObject
      {
        Zones = new List<AndonZone>
            {
                new AndonZone
                {
                    Name = "",
                    LocationsCount = 4,
                    LocationsUsedCount = 4,
                    MaxCoilColumns = 1,
                    BackgroundColor = "white",
                    TextColor = "blue",
                    CoilTypes = new List<AndonCoilType>(),
                    OpenPositions = new List<string>()

                }
            }
      };
      return andonDisplayObject;
    }


    public List<AndonCoilTypeLocation> GetCoilLocationsInOrders(CoilFieldZone dbLocationId, List<Data.Models.Coil> coilsOnHand)
    {


      var CoilTypeId = coilsOnHand.Select(k => k.CoilType.Id).ToList();
      var AndonCoilType = coilsOnHand.Where(c => CoilTypeId.Contains(c.CoilType.Id) && (c.CoilFieldLocation != null && c.CoilFieldLocation.Zone.Id == dbLocationId.Id))
          .OrderBy(c => c.IsPriority)
                                                                        //First order by if it is priority coil or not, then by checkin date
                                                                        .ThenByDescending(c => c.CheckInDate).Select(c => new AndonCoilTypeLocation()

                                                                        {
                                                                          Name = c.CoilFieldLocation.Name,
                                                                          CoilId = c.Id,
                                                                          BackgroundColor = c.CoilStatus.Color,
                                                                          TextColor = c.CoilStatus.TextColor
                                                                        }).ToList();
      //Andon logic is backwards, we want newest first to the left, oldest to the right



      return AndonCoilType;





    }

  }
}
