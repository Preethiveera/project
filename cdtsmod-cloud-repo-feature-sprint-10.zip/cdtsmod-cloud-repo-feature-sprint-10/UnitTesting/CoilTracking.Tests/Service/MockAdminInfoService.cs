﻿namespace CoilTracking.Tests.Service
{
  public class MockAdminInfoService
  {
    public object GetDashboardCounts()
    {
      return new
      {
        coil = 8,
        blank = 6,
        line = 4,
        coiltype = 8,
        coilField = 166,
        coilFieldZone = 6,
        coilFieldLocation = 171,
        parts = 191,
        kepServer = 2,
        mills = 7,
        model = 42,
        shift = 2
      };
    }
  }
}
