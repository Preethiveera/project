using CoilTracking.Data.Models;
using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CoilTracking.Tests.Service
{
  class MockCoilTypeService
  {
    public List<CoilMoveRequest> GetCoilMoverequest()
    {
      List<CoilMoveRequest> coilMoveRequests = new List<CoilMoveRequest>();
      {
        coilMoveRequests.Add(new CoilMoveRequest()
        {
          Id = 1,
          IsCancelled = true,
          Coil = new Coil()
          {
            Id = 7,
            OrderNo = 6,
            IsPriority = true,
            CheckInDate = DateTime.Now,
            SerialNum = "test",
            YNA = "c",
            FTZ = "te",
            OriginalWeight = 1,
            ReturnedToField = DateTime.Now,
            UnAccountedWeight = 9,
            CoilRunHistory = new List<CoilRunHistory>(){ new CoilRunHistory() { Id = 2, Coil= new Coil {   Id = 7,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9 } }  },
            CoilStatus = new CoilStatus() { Id = 8, Name = "test", Color = "test", InInventory = true, IsUsable = true, TextColor = "white" },
            Mill = new Mill() { Id = 9, Name = "test", Disabled = true },
            CoilType = new CoilType() { Id = 7, Name = "test", CoilFieldZone = new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } },
            CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } } } } }

          },
          Fulfilled = DateTime.Now,
          Requested = DateTime.Now,
          RequestType = new CoilMoveRequestType() { },
          Line = new Line() { Id = 1, LineName = "A", Plant = new Plant() { Id = 1, PlantName = "TMMI", NAMCCode = "EEE", TimeZone = new PlantTimeZone() { Id = 1, Name = "A" } } }
        });
      }
      return coilMoveRequests;
    }
    public List<Coil> GetCoilsByCoilTypeId()
    {
      List<Coil> coil = new List<Coil>
            {
                new Coil()
                {
                    Id = 7,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9,
                     CoilRunHistory = new List<CoilRunHistory>(){ new CoilRunHistory() { Id = 2, Coil= new Coil {   Id = 7,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9 } }  },CoilStatus = new CoilStatus() { Id=8, Name="test", Color="test", InInventory=true, IsUsable=true, TextColor="white" }, Mill = new Mill(){ Id=9, Name="test", Disabled=true },
                    CoilType = new CoilType() { Id = 7, Name = "test" , CoilFieldZone = new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } },
                   CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } } } } }

                }
            };

      return coil;
    }
    public List<CoilTypeDto> GetCoilsTypes()
    {
      List<CoilTypeDto> coilTypeDtos = new List<CoilTypeDto>();
      {
        coilTypeDtos.Add(new CoilTypeDto() { Id = 1, NAMC = "", Yield = decimal.Zero, Name = "T", Width = 1, Spec = "A", Thickness = decimal.One, MinWidth = decimal.One, NumCoils = 104, MinThickness = decimal.One, MaxWidth = decimal.One, MaterialTypeName = "A", MaxThickness = decimal.Zero, CoilTypeYNAsCSVString = "D", CoilFieldZoneName = "A1", Disabled = true, CoilTypeYNAs = new List<CoilTypeYNADto>() { }, CoilFieldZone = new CoilFieldZoneDto() { Id = 1, Name = "T", CoilFieldId = 1, Locations = new List<CoilFieldLocationDto>() { } }, CoilFieldZoneId = 1 });
      }
      return coilTypeDtos;
    }

    public IQueryable<CoilType> GetMaterialCoilsTypes()
    {
      var CoilType = new List<CoilType>()
            {
           new CoilType()
          {
             Id = 7, Name = "test", NumCoils = 9 , CoilTypeYNAs = new List<CoilTypeYNA>{ new CoilTypeYNA() { Id=1, YNA= "YNA0011171", CoilType = new CoilType() { }, MaterialType = new MaterialType() { Name="YAS" } } } , CoilFieldZone = new CoilFieldZone(){ Id=1, CoilField = new CoilField(){ Id=1, Disabled=true, Name="A", Zones = new List<CoilFieldZone>(){ } }
              }
            } };
      var coilTypes = CoilType.ToList();
      return coilTypes.AsQueryable();
    }

    public CoilType GetCoilsType()
    {
      var coilType = new CoilType

      {
        Id = 7,
        Name = "test",
        NumCoils = 9,
        CoilTypeYNAs = new List<CoilTypeYNA> { new CoilTypeYNA() { Id = 1, YNA = "YNA0011171", CoilType = new CoilType() { }, MaterialType = new MaterialType() { Name = "YAS" } } },
        CoilFieldZone = new CoilFieldZone()
        {
          Id = 1,
          CoilField = new CoilField() { Id = 1, Disabled = true, Name = "A", Zones = new List<CoilFieldZone>() { } }
        }
      };

      return coilType;
    }


    public CoilFieldZone GetCoilFeildZone()
    {
      var coilFieldZone = new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true, CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() { new CoilFieldZone() { Name = "test", Id = 9, Color = "", Disabled = true } } } };

      return coilFieldZone;
    }




    public List<MaterialTypeDto> GetMaterialTypes()
    {
      List<MaterialTypeDto> materialTypeDtos = new List<MaterialTypeDto>();
      {
        materialTypeDtos.Add(new MaterialTypeDto() { Id = 1, Description = "v", Name = "name" });
      }
      return materialTypeDtos;
    }

    public List<MaterialType> GetCoilsMaterialTypes()
    {
      List<MaterialType> materialType = new List<MaterialType>();
      {
        materialType.Add(new MaterialType() { Id = 1, Description = "v", Name = "name" });
      }
      return materialType;
    }

    public MaterialType GetMaterialsTypes()
    {
      MaterialType materialType = new MaterialType()
      {
        Id = 1,
        Description = "v",
        Name = "name"
      };
      return materialType;
    }



  }
}
