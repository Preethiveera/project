using CoilTracking.Data.Models;
using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CoilTracking.Tests.Service
{
  public class MockCoilMoveRequestService
  {
    public IQueryable<CoilMoveRequestDto> GetCoilMoveRequests()
    {
      var moveRequest = new List<CoilMoveRequestDto>
      {
        new CoilMoveRequestDto()
        {
          Id = 1,
        }
      };

      return moveRequest.AsQueryable();
    }

    public CoilMoveRequestDto GetCoilMoveRequestById(int id)
    {
      var moveRequest = new CoilMoveRequestDto
      {
        Id = 1
      };

      if (moveRequest.Id == id)
      {
        return moveRequest;
      }

      return null;
    }

    public List<CoilDto> GetLoadedCoils()
    {
      var moveRequest = new List<CoilDto>
      {
        new CoilDto()
        {
          Id = 1,
        }
      };

      return moveRequest;
    }

    public IQueryable<CoilMoveRequest> GetCoilMoveRequestsData()
    {
      var moveRequest = new List<CoilMoveRequest>
      {
        new CoilMoveRequest()
        {
          Id = 1,
        }
      };

      return moveRequest.AsQueryable();
    }

    public CoilMoveRequest FindCoilMoveRequest(int id)
    {
      var moveRequest = new CoilMoveRequest
      {
        Id = 1,
        RequestType = CoilMoveRequestType.CoilRequest,
        Coil = new Coil
        {
          Id = 1,
          CoilStatus = new CoilStatus
          {
            Id = 1,
            Name = ""
          },
          CoilFieldLocation = null
        }
      };

      if (moveRequest.Id == id)
      {
        return moveRequest;
      }

      return null;
    }

    public List<CoilStatus> GetCoilStatus()
    {
      var coilStatus = new List<CoilStatus>
      {
        new CoilStatus()
        {
          Id = 1,
        }
      };

      return coilStatus;
    }

    public Line GetLine(int id)
    {
      var line = new Line
      {
        Id = 1,
        Plant = new Plant
        {
          Id = 1,
          TimeZone = new PlantTimeZone
          {
            Id = 1,
            Name = ""
          }
        }
      };

      if (line.Id == id)
      {
        return line;
      }

      return null;
    }

    public CoilType GetCoilType(int id)
    {
      var coilType = new CoilType
      {
        Id = 1,
        Name = ""
      };

      if (coilType.Id == id)
      {
        return coilType;
      }

      return null;
    }

    public List<int> GetCoilIds()
    {
      var coilIds = new List<int>();
      coilIds.Add(1);
      return coilIds;
    }
    public List<Coil> GetCoils()
    {
      var coilStatus = new List<Coil>
      {
        new Coil()
        {
          Id = 1,
        }
      };

      return coilStatus;
    }

    public Shift GetShift()
    {
      var shift = new Shift
      {
        Id = 1,
        Start = TimeSpan.FromDays(1),
        Finish = TimeSpan.FromDays(5)
      };

      return shift;
    }
  }
}
