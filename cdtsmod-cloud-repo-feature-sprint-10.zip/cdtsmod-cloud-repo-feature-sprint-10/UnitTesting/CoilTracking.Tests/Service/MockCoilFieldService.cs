using CoilTracking.DTO;
using System.Collections.Generic;

namespace CoilTracking.Tests.Service
{
  public class MockCoilFieldService
  {
    public List<CoilFieldDto> GetCoilFields()
    {
      var list = new List<CoilFieldDto> { new CoilFieldDto()
      {
        Id=1,
        Disabled=false,
        Name="TMMI"
      } };
      return list;
    }

    public CoilFieldDto GetCoilFieldById(int id)
    {
      var coilField = new CoilFieldDto()
      {
        Id = 1,
        Disabled = false,
        Name = "TMMI"
      };
      if (id != coilField.Id)
      {
        return null;
      }
      return coilField;
    }

    public List<CoilFieldZoneDto> GetCoilFieldZone()
    {
      var zones = new List<CoilFieldZoneDto> {
        new CoilFieldZoneDto{
          Id=1,
          Name="A1"
        } };
      return zones;
    }
  }
}
