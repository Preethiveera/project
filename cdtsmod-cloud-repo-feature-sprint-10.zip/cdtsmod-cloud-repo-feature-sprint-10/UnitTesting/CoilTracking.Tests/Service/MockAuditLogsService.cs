using CoilTracking.Data.Models;
using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CoilTracking.Tests.Service
{
  public class MockAuditLogsService
  {

    public IQueryable<AuditLogsDto> GetAuditLogs()
    {
      var logs = new List<AuditLogsDto> {
              new   AuditLogsDto(){
                  Id= 1882,
        UserName= "37ba35fa-6e26-41df-bb1e-f9c5759045d3",
        ActionTime= DateTime.Now,
        Log= "{\"ClassName\":\"CoilField\",\"Before\":null,\"After\":\"{\\\"Id\\\":0,\\\"Name\\\":\\\"vishwas\\\",\\\"Zones\\\":null,\\\"Disabled\\\":true}\"}",
        ActionType=(AuditActionTypeDto)11

                } };
      return logs.AsQueryable();
    }
    public List<AuditLog> GetAuditLogModel()
    {
      var logs = new List<AuditLog> {
              new   AuditLog(){
                  Id= 1882,
        UserName= "37ba35fa-6e26-41df-bb1e-f9c5759045d3",
        ActionTime= DateTime.Now,
        Log= "{\"ClassName\":\"CoilField\",\"Before\":null,\"After\":\"{\\\"Id\\\":0,\\\"Name\\\":\\\"vishwas\\\",\\\"Zones\\\":null,\\\"Disabled\\\":true}\"}",
        ActionType=(AuditActionType)11

                } };
      return logs;
    }
    public List<AuditLog> GetAuditLogs_Model()
    {
      var logs = new List<AuditLog> {
              new   AuditLog(){
                  Id= 1882,
        UserName= "37ba35fa-6e26-41df-bb1e-f9c5759045d3",
        ActionTime= DateTime.Now,
        Log= "{\"ClassName\":\"CoilField\",\"Before\":null,\"After\":\"{\\\"Id\\\":0,\\\"Name\\\":\\\"vishwas\\\",\\\"Zones\\\":null,\\\"Disabled\\\":true}\"}",
        ActionType=(AuditActionType)11

                } };
      return logs;
    }
    public AuditLog AuditLogExists()
    {
      var logs = new AuditLog()
      {
        Id = 1882,
        UserName = "37ba35fa-6e26-41df-bb1e-f9c5759045d3",
        ActionTime = DateTime.Now,
        Log = "{\"ClassName\":\"CoilField\",\"Before\":null,\"After\":\"{\\\"Id\\\":0,\\\"Name\\\":\\\"vishwas\\\",\\\"Zones\\\":null,\\\"Disabled\\\":true}\"}",
        ActionType = (AuditActionType)11

      };
      return logs;

    }
  }
}
