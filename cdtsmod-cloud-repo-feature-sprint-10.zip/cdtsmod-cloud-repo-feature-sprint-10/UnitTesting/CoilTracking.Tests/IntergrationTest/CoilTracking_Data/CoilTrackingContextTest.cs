//using CoilTracking.Data;
//using CoilTracking.Data.Models;
//using CoilTracking.Tests.Constants;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.Extensions.DependencyInjection;
//using System;
//using System.Threading;
//using Xunit;

//namespace CoilTracking.Tests.CoilTracking_Data
//{
//  public class CoilTrackingContextTest : DbContext
//  {
//    public readonly CoilTrackingContext context;
//    //Create In Memory Database
//    public static DbContextOptions<CoilTrackingContext> options = new DbContextOptionsBuilder<CoilTrackingContext>()
//    .UseInMemoryDatabase(databaseName: "CoilTrackingDataBase1")
//    .Options;
//    public CoilTrackingContextTest()
//    {
//      if (context == null)
//        using (var context = new CoilTrackingContext(options,httpContextAccessor,usersHelper))
//        {
//          if (context.AuditLogs.CountAsync().Result == 0)
//          {
//            context.AuditLogs.Add(new AuditLog
//            {
//              Id = 8,
//              UserName = "User"

//            });

//            context.AuditLogs.Add(new AuditLog
//            {
//              Id = 7,
//              UserName = "test",

//            });


//            context.SaveChanges();
//          }
//        }

//    }

//    /// <summary>
//    /// CoilTrackingSaveChangesAsync
//    /// </summary>
//    [Fact]
//    public void CoilTrackingSaveChangesAsync()
//    {
//      string user = "37ba35fa-6e26-41df-bb1e-f9c5759045d3";
//      using (var context = new CoilTrackingContext(options,httpContextAccessor,usersHelper))
//      {
//        var token = context.SaveChangesAsync(user, AuditActionType.ModifyEntity);
//        Assert.True(true, token.IsCompletedSuccessfully.ToString());
//      }
//    }

//    [Fact]
//    public void CoilTrackingSaveChangesAsyncFail()
//    {
//      string user = null;
//      //Execute the query
//      using (var context = new CoilTrackingContext(options,httpContextAccessor,usersHelper))
//      {
//        var token = context.SaveChangesAsync(user, AuditActionType.ModifyEntity);
//        Assert.True(true, token.IsCompletedSuccessfully.ToString());
//      }
//    }
//    /// <summary>
//    /// CoilTrackingSaveChanges
//    /// </summary>
//    [Fact]
//    public void CoilTrackingSaveChanges()
//    {
//      string user = "ABCDEF";
//      using (var context = new CoilTrackingContext(options,httpContextAccessor,usersHelper))
//      {
//       var token = context.SaveChanges(user, 0);
//        Assert.True(true, token.ToString());
//      }

//      //Verify the results
     
//    }

//    /// <summary>
//    /// CoilTrackingSaveChangestoken
//    /// </summary>
//    [Fact]
//    public void CoilTrackingSaveChangestoken()
//    {
//      string user = "37ba35fa-6e26-41df-bb1e-f9c5759045d3";
//      using (var context = new CoilTrackingContext(options,httpContextAccessor,usersHelper))
//      {
//        var token = context.SaveChangesAsync(user, AuditActionType.EnableDisable);
//        Assert.True(true, token.IsCompletedSuccessfully.ToString());
//      }
//    }

//    [Fact]
//    public void CoilTrackingSaveChangestokenFail()
//    {
//      string user = null;    
//      using (var context = new CoilTrackingContext(options,httpContextAccessor,usersHelper))
//      {
//        context.SaveChangesAsync(CancellationToken.None, user, 0);
//        var token = context.SaveChangesAsync(user, AuditActionType.EnableDisable);
//        Assert.True(true, token.IsCompletedSuccessfully.ToString());
//      }
//    }


//  }


//}
