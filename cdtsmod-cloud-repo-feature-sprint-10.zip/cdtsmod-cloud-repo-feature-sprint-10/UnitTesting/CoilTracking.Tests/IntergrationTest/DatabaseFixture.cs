using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;

namespace CoilTracking.Tests.IntergrationTest
{
  public class DatabaseFixture : IDatabaseSetup
  {
    private readonly IHttpContextAccessor httpContextAccessor;
    private readonly Random _random = new Random();

    public CoilTrackingContext GetDatabaseFixture()
    {
      var userHelper = new Mock<IUserHelper>();
      var randomNumber = _random.Next(100, 1000);

      var serviceProvider = new ServiceCollection()
                .AddEntityFrameworkInMemoryDatabase()
                .BuildServiceProvider();

      var option = new DbContextOptionsBuilder<CoilTrackingContext>().UseInMemoryDatabase(databaseName: "Test_Database_{randomNumber}").UseInternalServiceProvider(serviceProvider)
.Options;

      var context = new CoilTrackingContext(option,httpContextAccessor,userHelper.Object);
      if (context != null)
      {
        context.Database.EnsureDeleted();
        context.Database.EnsureCreated();
      }

      return context;
    }


  }
}
