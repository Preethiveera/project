using CoilTracking.Data;


namespace CoilTracking.Tests.IntergrationTest
{
  public interface IDatabaseSetup
  {
    public CoilTrackingContext GetDatabaseFixture();

  }
}
