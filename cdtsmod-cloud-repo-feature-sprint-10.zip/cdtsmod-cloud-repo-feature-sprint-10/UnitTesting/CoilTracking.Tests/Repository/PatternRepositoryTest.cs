using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.Tests.IntergrationTest;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using System;
using System.Threading.Tasks;
using Xunit;

namespace CoilTracking.Tests.Repository
{
  public class PatternRepositoryTest
  {
    readonly IDatabaseSetup DatabaseFixture;
    public readonly IUserHelper usersHelper;
    public PatternRepositoryTest()
    {
      DatabaseFixture = new DatabaseFixture();
      
    }

    [Fact]
    public void GetPatternLetter()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Pattern 
      {
        Id = 1,
        Name = "P",
        CreateDate = DateTime.Today.Date,
        Line = new Line
        {
          Id = 5,
          Plant = new Plant
          {
            Id = 1,
            NAMCCode = "A",
            PlantName = "P",
            TimeZone = new PlantTimeZone
            {
              Id = 1,
              Name = "J",
              TimeZoneOffset = 2
            }
          },
          Plant_Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1,
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          OPCServer_Id = 1,
          LinePath = "-",
          Tags = "-,-,-,-,-,-,-,-,-,-,-,-,-,-",
          Subscribed = false,
          Disabled = false
        }
      };
      context.Patterns.Add(post);
      context.SaveChanges();
      var PatternRepo = new PatternsRepository(context,usersHelper);

        var patternLetter = PatternRepo.GetPatterns();
        Assert.NotNull(patternLetter);
      
    }


    [Fact]
    public void GetPatternByLineId()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Pattern
      {
        Id = 1,
        Name = "P",
        CreateDate = DateTime.Today.Date,
        Line = new Line
        {
          Id = 5,
          Plant = new Plant
          {
            Id = 1,
            NAMCCode = "A",
            PlantName = "P",
            TimeZone = new PlantTimeZone
            {
              Id = 1,
              Name = "J",
              TimeZoneOffset = 2
            }
          },
          Plant_Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1,
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          OPCServer_Id = 1,
          LinePath = "-",
          Tags = "-,-,-,-,-,-,-,-,-,-,-,-,-,-",
          Subscribed = false,
          Disabled = false
        }
      };
      context.Patterns.Add(post);
      context.SaveChanges();
      var PatternRepo = new PatternsRepository(context, usersHelper);

      var patternLetter = PatternRepo.GetPatternByLineId(post.Id);
      Assert.NotNull(patternLetter);

    }

    [Fact]
    public void GetPatternByMonthAndYear()
    {
      int id = 1;
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Pattern
      {
        Id = 1,
        Name = "P",
        CreateDate = DateTime.Today.Date,
        Line = new Line
        {
          Id = 5,
          Plant = new Plant
          {
            Id = 1,
            NAMCCode = "A",
            PlantName = "P",
            TimeZone = new PlantTimeZone
            {
              Id = 1,
              Name = "J",
              TimeZoneOffset = 2
            }
          },
          Plant_Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1,
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          OPCServer_Id = 1,
          LinePath = "-",
          Tags = "-,-,-,-,-,-,-,-,-,-,-,-,-,-",
          Subscribed = false,
          Disabled = false
        }
      };
      context.Patterns.Add(post);
      context.SaveChanges();
      var PatternRepo = new PatternsRepository(context, usersHelper);

      var patternLetter = PatternRepo.GetPatternByMonthAndYear(id,id);
      Assert.NotNull(patternLetter);

    }


    [Fact]
    public void GetPatternByLineId_PatternLetter_Year_Month()
    {
      int id = 1;
      string nam = "test";
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Pattern
      {
        Id = 1,
        Name = "P",
        CreateDate = DateTime.Today.Date,
        Line = new Line
        {
          Id = 5,
          Plant = new Plant
          {
            Id = 1,
            NAMCCode = "A",
            PlantName = "P",
            TimeZone = new PlantTimeZone
            {
              Id = 1,
              Name = "J",
              TimeZoneOffset = 2
            }
          },
          Plant_Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1,
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          OPCServer_Id = 1,
          LinePath = "-",
          Tags = "-,-,-,-,-,-,-,-,-,-,-,-,-,-",
          Subscribed = false,
          Disabled = false
        }
      };
      context.Patterns.Add(post);
      context.SaveChanges();
      var PatternRepo = new PatternsRepository(context, usersHelper);

      var patternLetter = PatternRepo.GetPatternByLineId_PatternLetter_Year_Month(id,nam, id,id);
      Assert.NotNull(patternLetter);

    }

    [Fact]
    public void GetPatternsByLineIdPatternLetterAndDate()
    {
      int id = 1;
      string entry = "cal";
      DateTime dt  = DateTime.Now;
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Pattern
      {
        Id = 1,
        Name = "P",
        CreateDate = DateTime.Today.Date,
        Line = new Line
        {
          Id = 5,
          Plant = new Plant
          {
            Id = 1,
            NAMCCode = "A",
            PlantName = "P",
            TimeZone = new PlantTimeZone
            {
              Id = 1,
              Name = "J",
              TimeZoneOffset = 2
            }
          },
          Plant_Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1,
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          OPCServer_Id = 1,
          LinePath = "-",
          Tags = "-,-,-,-,-,-,-,-,-,-,-,-,-,-",
          Subscribed = false,
          Disabled = false
        }
      };
      context.Patterns.Add(post);
      context.SaveChanges();
      var PatternRepo = new PatternsRepository(context, usersHelper);

      var patternLetter = PatternRepo.GetPatternsByLineIdPatternLetterAndDate(id, entry, dt);
      Assert.NotNull(patternLetter);

    }



    [Fact]
    public void GetPatternById()
    {
      int id = 1;
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Pattern
      {
        Id = 1,
        Name = "P",
        CreateDate = DateTime.Today.Date,
        Line = new Line
        {
          Id = 5,
          Plant = new Plant
          {
            Id = 1,
            NAMCCode = "A",
            PlantName = "P",
            TimeZone = new PlantTimeZone
            {
              Id = 1,
              Name = "J",
              TimeZoneOffset = 2
            }
          },
          Plant_Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1,
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          OPCServer_Id = 1,
          LinePath = "-",
          Tags = "-,-,-,-,-,-,-,-,-,-,-,-,-,-",
          Subscribed = false,
          Disabled = false
        }
      };
      context.Patterns.Add(post);
      context.SaveChanges();
      var PatternRepo = new PatternsRepository(context,usersHelper);

        var pattern = PatternRepo.GetPatternById(id);
        Assert.NotNull(pattern);
      
    }

    //[Fact]
    //public async Task GetPatternByLineId_PatternLetter_Year_Month()
    //{
    //  var patternLetter = "P";
    //  var lineId = 5;
    //  var date = DateTime.Today.Date;

    //  using (var context = new CoilTrackingContext(options,httpContextAccessor,usersHelper))
    //  {
    //    var PatternRepo = new PatternsRepository(context,usersHelper);

    //    var pattern = await PatternRepo.GetPatternByLineId_PatternLetter_Year_Month(lineId, patternLetter, date.Year, date.Month);
    //    Assert.NotNull(pattern);
    //  }
    //}

    [Fact]
    public void GetPatternsItems_Id()
    {
      int id = 1;
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Pattern
      {
        Id = 1,
        Name = "P",
        CreateDate = DateTime.Today.Date,
        Line = new Line
        {
          Id = 5,
          Plant = new Plant
          {
            Id = 1,
            NAMCCode = "A",
            PlantName = "P",
            TimeZone = new PlantTimeZone
            {
              Id = 1,
              Name = "J",
              TimeZoneOffset = 2
            }
          },
          Plant_Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1,
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          OPCServer_Id = 1,
          LinePath = "-",
          Tags = "-,-,-,-,-,-,-,-,-,-,-,-,-,-",
          Subscribed = false,
          Disabled = false
        }
      };
      context.Patterns.Add(post);
      context.SaveChanges();
      var PatternRepo = new PatternsRepository(context,usersHelper);

        var patternsItems = PatternRepo.GetPatternsItems(id);
        Assert.NotNull(patternsItems);
      
    }

    [Fact]
    public async Task UpdatePattern_ReturnsTrue()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Pattern
      {
        Id = 1,
        Name = "P",
        CreateDate = DateTime.Today.Date,
        Line = new Line
        {
          Id = 5,
          Plant = new Plant
          {
            Id = 1,
            NAMCCode = "A",
            PlantName = "P",
            TimeZone = new PlantTimeZone
            {
              Id = 1,
              Name = "J",
              TimeZoneOffset = 2
            }
          },
          Plant_Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1,
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          OPCServer_Id = 1,
          LinePath = "-",
          Tags = "-,-,-,-,-,-,-,-,-,-,-,-,-,-",
          Subscribed = false,
          Disabled = false
        }
      };
      context.Patterns.Add(post);
      context.SaveChanges();
      var PatternRepo = new PatternsRepository(context,usersHelper);

        var result = PatternRepo.UpdatePattern(post);
        Assert.True(result);
      
    }

    //[Fact]
    //public async Task AddPattern_ReturnsTrue()
    //{
    //  var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
    //  var contexts = new DefaultHttpContext();
    //  var fakeTenantId = "abcd";
    //  contexts.Request.Headers["Tenant-ID"] = fakeTenantId;
    //  mockHttpContextAccessor.Setup(_ => _.HttpContext).Returns(contexts);
    //  //Mock HeaderConfiguration
    //  var mockHeaderConfiguration = new Mock<IUserHelper>();
    //  mockHeaderConfiguration
    //      .Setup(_ => _.GetSubject())
    //      .Returns(fakeTenantId);
    //  var pattern = new Pattern()
    //  {
    //    Name = "P",
    //    Line = new Line
    //    {
    //      //Id = 1,
    //      Plant = new Plant
    //      {
    //        //Id = 1,
    //        NAMCCode = "A",
    //        PlantName = "P",
    //        TimeZone = new PlantTimeZone
    //        {
    //          //Id = 1,
    //          Name = "J",
    //          TimeZoneOffset = 2
    //        }
    //      },
    //      Plant_Id = 1,
    //      LineName = "BL1",
    //      OPCServer = new OPCConfig
    //      {
    //        //Id = 1,
    //        ServerName = "s",
    //        Disabled = false,
    //        InstanceName = "I"
    //      },
    //      OPCServer_Id = 1,
    //      LinePath = "-",
    //      Tags = "-,-,-,-,-,-,-,-,-,-,-,-,-,-",
    //      Subscribed = false,
    //      Disabled = false
    //    }
    //  };

    //  var context = DatabaseFixture.GetDatabaseFixture();
    //    var PatternRepo = new PatternsRepository(context,mockHeaderConfiguration.Object);

    //    var result = await PatternRepo.AddPattern(pattern);
    //    Assert.NotNull(result);
      
    //}

    [Fact]
    public async Task DeletePattern_ReturnsTrue()
    {
      var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
      var contexts = new DefaultHttpContext();
      var fakeTenantId = "abcd";
      contexts.Request.Headers["Tenant-ID"] = fakeTenantId;
      mockHttpContextAccessor.Setup(_ => _.HttpContext).Returns(contexts);
      //Mock HeaderConfiguration
      var mockHeaderConfiguration = new Mock<IUserHelper>();
      mockHeaderConfiguration
          .Setup(_ => _.GetSubject())
          .Returns(fakeTenantId);
      var pattern = new Pattern()
      {
        Id = 1,
        Name = "P",
        Line = new Line
        {
          Id = 5,
          Plant = new Plant
          {
            Id = 1,
            NAMCCode = "A",
            PlantName = "P",
            TimeZone = new PlantTimeZone
            {
              Id = 1,
              Name = "J",
              TimeZoneOffset = 2
            }
          },
          Plant_Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1,
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          OPCServer_Id = 1,
          LinePath = "-",
          Tags = "-,-,-,-,-,-,-,-,-,-,-,-,-,-",
          Subscribed = false,
          Disabled = false
        }
      };
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Patterns.Add(pattern);
      context.SaveChanges();
      var PatternRepo = new PatternsRepository(context, mockHeaderConfiguration.Object);

        var result = await PatternRepo.RemovePattern(pattern);
        Assert.True(result);
      
    }
  }
}
