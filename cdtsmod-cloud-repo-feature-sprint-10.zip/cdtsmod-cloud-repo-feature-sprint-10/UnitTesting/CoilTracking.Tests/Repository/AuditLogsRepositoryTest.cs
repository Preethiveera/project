using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.Tests.Constants;
using CoilTracking.Tests.IntergrationTest;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Globalization;
using Xunit;

namespace CoilTracking.Tests.Repository
{
  public class AuditLogsRepositoryTest
  {
    readonly IDatabaseSetup DatabaseFixture;

    public AuditLogsRepositoryTest()
    {
      DatabaseFixture = new DatabaseFixture();
    }
    [Fact]
    public void GetAuditLogs_ReturnsAuditLogs()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new AuditLog
      {
        Id = 7,
        UserName = "test",
      };
      context.AuditLogs.Add(post);
      context.SaveChanges();
      AuditLogsRepository logsRepository = new AuditLogsRepository(context);
      var logs = logsRepository.GetAuditLogs();
      Assert.NotNull(logs);
    }
    [Fact]
    public void Search_ReturnsAuditLogs()
    {
      string username = "User";
      int? actionType = null;
      string className = null;

      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new AuditLog
      {
        Id = 7,
        UserName = "test",
      };
      context.AuditLogs.Add(post);
      context.SaveChanges();
      AuditLogsRepository logsRepository = new AuditLogsRepository(context);
      var logs = logsRepository.Search(null, null, username, actionType, className);
      Assert.NotNull(logs);



    }

    [Fact]
    public void AuditLogExist_Id_ReturnsAuditLog()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new AuditLog
      {
        Id = 8,
        UserName = "test67",
      };
      context.AuditLogs.Add(post);
      context.SaveChanges();
      AuditLogsRepository logsRepository = new AuditLogsRepository(context);
      logsRepository.AuditLogExist(8);
      Assert.NotNull(logsRepository);


    }
  }
}
