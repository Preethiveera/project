using CoilTracking.Common.Exception;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.Tests.Constants;
using CoilTracking.Tests.IntergrationTest;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using Xunit;

namespace CoilTracking.Tests.Repository
{

  public class CoilFeildRepositoryTest
  {
   
    readonly IDatabaseSetup DatabaseFixture;
    public readonly Mock<IUserHelper> usersHelper;
    public CoilFeildRepositoryTest()
    {
      DatabaseFixture = new DatabaseFixture();
    }

    [Fact]
    public void GetCountOfCoilField()
    {
      var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
      var contexts = new DefaultHttpContext();
      var fakeTenantId = "abcd";
      contexts.Request.Headers["Tenant-ID"] = fakeTenantId;
      mockHttpContextAccessor.Setup(_ => _.HttpContext).Returns(contexts);
      //Mock HeaderConfiguration
      var mockHeaderConfiguration = new Mock<IUserHelper>();
      mockHeaderConfiguration
          .Setup(_ => _.GetSubject())
          .Returns(fakeTenantId);
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilField
      {
        Id = 1,
        Name = "1-1-A",
        Disabled = false,
        Zones = new System.Collections.Generic.List<CoilFieldZone>
              {
                new CoilFieldZone
                {
                  Id=1,
                  Name="east",
                  CoilField=new CoilField{Id=1, Zones=new System.Collections.Generic.List<CoilFieldZone>{ new CoilFieldZone { Id = 1 } } },
                  Locations=new System.Collections.Generic.List<CoilFieldLocation>
                  {
                    new CoilFieldLocation
                    {
                      Id=1,
                      Zone=new CoilFieldZone{Id=1}
                    }
                  }
                }

              }

      };
      context.CoilFields.Add(post);
      context.SaveChanges();
      CoilFieldRepository coilFieldRepository = new CoilFieldRepository(context,mockHeaderConfiguration.Object);
      var coilFields = coilFieldRepository.GetCountOfCoilField();
      Assert.Equal(coilFields, coilFields);


    }

    [Fact]
    public void GetCoilFieldsById_Id_ReturnsCoilFields()
    {
      var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
      var contexts = new DefaultHttpContext();
      var fakeTenantId = "abcd";
      contexts.Request.Headers["Tenant-ID"] = fakeTenantId;
      mockHttpContextAccessor.Setup(_ => _.HttpContext).Returns(contexts);
      //Mock HeaderConfiguration
      var mockHeaderConfiguration = new Mock<IUserHelper>();
      mockHeaderConfiguration
          .Setup(_ => _.GetSubject())
          .Returns(fakeTenantId);
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilField
      {
        Id = 1,
        Name = "1-1-A",
        Disabled = false,
        Zones = new System.Collections.Generic.List<CoilFieldZone>
              {
                new CoilFieldZone
                {
                  Id=200,
                  Name="eastTMMK",
                  CoilField=new CoilField{Id=1, Zones=new System.Collections.Generic.List<CoilFieldZone>{ new CoilFieldZone { Id = 1 } } },
                  Locations=new System.Collections.Generic.List<CoilFieldLocation>
                  {
                    new CoilFieldLocation
                    {
                      Id=1,
                      Zone=new CoilFieldZone{Id=1}
                    }
                  }
                }

              }

      };
      context.CoilFields.Add(post);
      context.SaveChanges();
      CoilFieldRepository coilFieldRepository = new CoilFieldRepository(context,mockHeaderConfiguration.Object);
      coilFieldRepository.GetCoilFieldById(200);
      Assert.NotNull(coilFieldRepository);

    }
    [Fact]
    public void GetCoilFields_ReturnsCoilFields()
    {
      var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
      var contexts = new DefaultHttpContext();
      var fakeTenantId = "abcd";
      contexts.Request.Headers["Tenant-ID"] = fakeTenantId;
      mockHttpContextAccessor.Setup(_ => _.HttpContext).Returns(contexts);
      //Mock HeaderConfiguration
      var mockHeaderConfiguration = new Mock<IUserHelper>();
      mockHeaderConfiguration
          .Setup(_ => _.GetSubject())
          .Returns(fakeTenantId);
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilField
      {
        Id = 1,
        Name = "1-1-A",
        Disabled = false,
        Zones = new System.Collections.Generic.List<CoilFieldZone>
              {
                new CoilFieldZone
                {
                  Id=1,
                  Name="east",
                  CoilField=new CoilField{Id=1, Zones=new System.Collections.Generic.List<CoilFieldZone>{ new CoilFieldZone { Id = 1 } } },
                  Locations=new System.Collections.Generic.List<CoilFieldLocation>
                  {
                    new CoilFieldLocation
                    {
                      Id=1,
                      Zone=new CoilFieldZone{Id=1}
                    }
                  }
                }

              }

      };
      context.CoilFields.Add(post);
      context.SaveChanges();
      CoilFieldRepository coilFieldRepository = new CoilFieldRepository(context, mockHeaderConfiguration.Object);
      var coilFields = coilFieldRepository.GetCoilFields();
      Assert.NotNull(coilFields);

    }



    [Fact]
    public void DisableCoilField_IdAnddisable_Returnsbool()
    {
      var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
      var contexts = new DefaultHttpContext();
      var fakeTenantId = "abcd";
      contexts.Request.Headers["Tenant-ID"] = fakeTenantId;
      mockHttpContextAccessor.Setup(_ => _.HttpContext).Returns(contexts);
      //Mock HeaderConfiguration
      var mockHeaderConfiguration = new Mock<IUserHelper>();
      mockHeaderConfiguration
          .Setup(_ => _.GetSubject())
          .Returns(fakeTenantId);
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilField
      {
        Id = 1,
        Name = "1-1-A",
        Disabled = false,
        Zones = new System.Collections.Generic.List<CoilFieldZone>
              {
                new CoilFieldZone
                {
                  Id=1,
                  Name="east",
                  CoilField=new CoilField{Id=1, Zones=new System.Collections.Generic.List<CoilFieldZone>{ new CoilFieldZone { Id = 1 } } },
                  Locations=new System.Collections.Generic.List<CoilFieldLocation>
                  {
                    new CoilFieldLocation
                    {
                      Id=1,
                      Zone=new CoilFieldZone{Id=1}
                    }
                  }
                }

              }

      };
      context.CoilFields.Add(post);
      context.SaveChanges();

      CoilFieldRepository coilFieldRepository = new CoilFieldRepository(context, mockHeaderConfiguration.Object);
      var coilFields = coilFieldRepository.DisableCoilField(1, false);
      Assert.True(coilFields);

    }

  }
}
