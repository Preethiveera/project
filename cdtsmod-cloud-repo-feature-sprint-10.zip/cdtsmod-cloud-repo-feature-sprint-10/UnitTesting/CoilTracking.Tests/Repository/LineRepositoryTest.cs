using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess;
using CoilTracking.Tests.Constants;
using CoilTracking.Tests.IntergrationTest;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System.Collections.Generic;
using Xunit;

namespace CoilTracking.Tests.Repository
{
  
  public class LineRepositoryTest
  {
    public readonly IUserHelper usersHelper;
    readonly IDatabaseSetup DatabaseFixture;
    public LineRepositoryTest()
    {
      DatabaseFixture = new DatabaseFixture();
    }


    /// <summary>
    /// 
    /// </summary>
    [Fact]
    public void GetLinesTest()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Line
      {
        Id = 1,
        LineName = "BL1",
        OPCServer = new OPCConfig { Id = 1 }
      };
      context.Lines.Add(post);
      context.SaveChanges();
      var repo = new LineRepository(context,usersHelper);
      var response = repo.GetLines();
      Assert.NotNull(response);

    }

    /// 
    /// </summary>
    [Fact]
    public void GetLineByLineID_Lines_ReturnsLinesById()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Line
      {
        Id = 2,
        LineName = "BL2",
        OPCServer = new OPCConfig { Id = 1 }
      };
      context.Lines.Add(post);
      context.SaveChanges();
      var repo = new LineRepository(context,usersHelper);
      var response = repo.GetLineByLineID(2);
      Assert.NotNull(repo);
      context.Database.EnsureDeleted();
    }


    [Fact]
    public void GetLineByLineIDAsync_ReturnsLinesById()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Line
      {
        Id = 2,
        LineName = "BL2",
        OPCServer = new OPCConfig { Id = 1 }
      };
      context.Lines.Add(post);
      context.SaveChanges();
      var repo = new LineRepository(context, usersHelper);
      var response = repo.GetLineByLineIDAsync(2);
      Assert.NotNull(repo);
      context.Database.EnsureDeleted();
    }


    [Fact]
    public void GetLineWithPlantDetails_ReturnsLinesById()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Line
      {
        Id = 2,
        LineName = "BL2",
        OPCServer = new OPCConfig { Id = 1 }
      };
      context.Lines.Add(post);
      context.SaveChanges();
      var repo = new LineRepository(context, usersHelper);
      var response = repo.GetLineWithPlantDetails(2);
      Assert.NotNull(response);
      context.Database.EnsureDeleted();
    }

    [Fact]
    public void GetCount()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Line
      {
        Id = 1,
        LineName = "BL1",
        OPCServer = new OPCConfig { Id = 1 }
      };
      context.Lines.Add(post);
      context.SaveChanges();
      var repo = new LineRepository(context,usersHelper);
      var response = repo.GetCountOfLines();
      Assert.Equal(response, response);

    }

    [Fact]
    public void GetLines()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Line
      {
        Id = 4,
        LineName = "BL4",
        OPCServer = new OPCConfig { Id = 1 }
      };
      context.Lines.Add(post);
      context.SaveChanges();
      var repo = new LineRepository(context,usersHelper);
      var response = repo.GetLinesAsync();
      Assert.NotNull(response);

    }

    [Fact]
    public void GetAllLines()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Line
      {
        Id = 4,
        LineName = "BL4",
        OPCServer = new OPCConfig { Id = 1 }
      };
      context.Lines.Add(post);
      context.SaveChanges();
      var repo = new LineRepository(context, usersHelper);
      var response = repo.GetAllLines();
      Assert.NotNull(response);

    }

    [Fact]
    public void GetLineWithTimeZoneOpcServer()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Line
      {
        Id = 4,
        LineName = "BL4",
        OPCServer = new OPCConfig { Id = 1 }
      };
      context.Lines.Add(post);
      context.SaveChanges();
      var repo = new LineRepository(context, usersHelper);
      var response = repo.GetLineWithTimeZoneOpcServer(post.Id);
      Assert.NotNull(response);

    }

    [Fact]
    public void CheckEdit()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Line
      {
        Id = 4,
        LineName = "BL4",
        OPCServer = new OPCConfig { Id = 1 }
      };
      context.Lines.Add(post);
      context.SaveChanges();
      var repo = new LineRepository(context, usersHelper);
      var response = repo.CheckEdit(post.Id);
      Assert.NotNull(response);

    }



    [Fact]
    public void GetIncompleteRunOrderItem()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Line
      {
        Id = 4,
        LineName = "BL4",
        OPCServer = new OPCConfig { Id = 1 }
      };
      context.Lines.Add(post);
      context.SaveChanges();
      var repo = new LineRepository(context, usersHelper);
      var response = repo.GetIncompleteRunOrderItem(post.Id);
      Assert.NotNull(response);

    }

    [Fact]
    public void GetLineById()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Line
      {
        Id = 11,
        LineName = "BL11",
        OPCServer = new OPCConfig { Id = 1 }
      };
      context.Lines.Add(post);
      context.SaveChanges();
      var repo = new LineRepository(context,usersHelper);
      var response = repo.GetLineByIdAsync(11);
      Assert.NotNull(response);

    }

    [Fact]
    public void UpdateLineSubscription()
    {
      var service = new MockLineService();
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Line
      {
        Id = 1,
        LineName = "BL1",
        OPCServer = new OPCConfig { Id = 1 }
      };
      context.Lines.Add(post);
      context.SaveChanges();
      var repo = new LineRepository(context,usersHelper);
      var response = repo.UpdateLineSubscription(service.GetLine());
      Assert.NotNull(response);

    }

    [Fact]
    public void SaveChanges()
    {
      var context = DatabaseFixture.GetDatabaseFixture();

      var repo = new LineRepository(context,usersHelper);
      var response = repo.SaveChanges(AuditActionType.ModifyEntity);
      Assert.NotNull(response);

    }

    [Fact]
    public void GetSubscribedLines()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Line
      {
        Id = 14,
        LineName = "BL35",
        OPCServer = new OPCConfig { Id = 1 }
      };
      context.Lines.Add(post);
      context.SaveChanges();
      var repo = new LineRepository(context,usersHelper);
      var response = repo.GetSubscribedLines("");
      Assert.NotNull(response);

    }

    [Fact]
    public void DisableLine()
    {
      var service = new MockLineService();
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Line
      {
        Id = 100,
        LineName = "BL100",
        OPCServer = new OPCConfig { Id = 10 },
        Disabled = false
      };
      context.Lines.Add(post);
      context.SaveChanges();
      var repo = new LineRepository(context,usersHelper);
      repo.DisableLine(post);
      Assert.NotNull(repo);

    }

    [Fact]
    public void PutLine()
    {
      var service = new MockLineService();
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Line
      {
        Id = 18,
        LineName = "BL18",
        OPCServer = new OPCConfig { Id = 1 }
      };
      context.Lines.Add(post);
      context.SaveChanges();
      var repo = new LineRepository(context,usersHelper);
      var response = repo.PutLine(post);
      Assert.NotNull(response);

    }

    [Fact]
    public void AddLine()
    {
      var service = new MockLineService();
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Line
      {

        LineName = "BL1",
        OPCServer = new OPCConfig { Id = 1 }
      };

      var repo = new LineRepository(context,usersHelper);
      var response = repo.AddLine(post);
      Assert.NotNull(response);

    }

    [Fact]
    public void AddPlantAndOPCServerData()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Line
      {
        Id = 19,
        LineName = "BL19",
        OPCServer = new OPCConfig { Id = 19 },
        Plant = new Plant { Id = 1 }

      };

      var repo = new LineRepository(context,usersHelper);
      repo.AddPlantAndOPCServerData(post);
      Assert.NotNull(repo);

    }

    [Fact]
    public void GetLineDataByLineId()
    {

      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new LineData { Id = 1 };
      var repo = new LineRepository(context,usersHelper);
      var response = repo.GetLineDataByLineId(post);
      Assert.NotNull(response);

    }

    [Fact]
    public void UpdateLineData()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new LineData
      {
        Id = 11,
        LineId = 1
      };
      context.LineDatas.Add(post);
      context.SaveChanges();
      var repo = new LineRepository(context,usersHelper);
      repo.UpdateLineData(post);
      Assert.NotNull(repo);

    }

    [Fact]
    public void AddLineData()
    {
      var service = new MockLineService();
      var context = DatabaseFixture.GetDatabaseFixture();

      var repo = new LineRepository(context,usersHelper);
      var response = repo.AddLineData(service.GetLineData());
      Assert.NotNull(response);

    }


    [Fact]
    public void GetLinesByOPcConfigId()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Line
      {
        Id = 190,
        LineName = "BL1",
        OPCServer = new OPCConfig { Id = 2 }
      };
      context.Lines.Add(post);
      context.SaveChanges();
      var repo = new LineRepository(context,usersHelper);
      var response = repo.GetLinesByOPcConfigId(2);
      Assert.NotNull(response);

    }
    [Fact]
    public void GetIncompleteRunLinesByLineList()
    {
      var service = new MockLineService();
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new List<Line>{ new Line
      {
        Id = 1,
        LineName = "BL1",
        OPCServer = new OPCConfig { Id = 1 }
      }
      };
      context.Lines.AddRange(post);
      context.SaveChanges();
      var repo = new LineRepository(context,usersHelper);
      var response = repo.GetIncompleteRunLinesByLineList(service.GetLinesList());
      Assert.NotNull(response);

    }
  }
}
