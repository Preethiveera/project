using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.Tests.Constants;
using CoilTracking.Tests.IntergrationTest;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using Xunit;

namespace CoilTracking.Tests.Repository
{
  public class ShiftRepositoryTest
  {

    public readonly IUserHelper usersHelper;
    readonly IDatabaseSetup DatabaseFixture;
    private readonly IHttpContextAccessor httpContextAccessor;
    public ShiftRepositoryTest()
    {
      DatabaseFixture = new DatabaseFixture();
      //if (context == null)
      //  using (var context = new CoilTrackingContext(options,httpContextAccessor,usersHelper))
      //  {
      //    if (context.Shifts.CountAsync().Result == 0)
      //    {
      //      context.Shifts.Add(new Shift
      //      {
      //        Id = 1,
      //      });

      //      context.SaveChanges();
      //    }
      //  }
    }

    [Fact]
    public void GetCountOfShifts()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Shift
      {
        Id = 1,
        Name = "blue",
        Disabled = false,
        BackgroundColor = "red",
        TextColor = "black"
      };
      context.Shifts.Add(post);
      context.SaveChanges();
        var repo = new ShiftRepository(context,usersHelper);
        var response = repo.GetCountofShifts();
        Assert.Equal(response, response);
      

    }

    [Fact]
    public void GetShiftByIdAsync()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Shift
      {
        Id = 1,
        Name = "blue",
        Disabled = false,
        BackgroundColor = "red",
        TextColor = "black"
      };
      context.Shifts.Add(post);
      context.SaveChanges();
      var repo = new ShiftRepository(context,usersHelper);
        var response = repo.GetShiftByIdAsync(1);
        Assert.NotNull(response);
      
    }

    [Fact]
    public void GetShifts()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Shift
      {
        Id = 1,
        Name = "blue",
        Disabled = false,
        BackgroundColor = "red",
        TextColor = "black"
      };
      context.Shifts.Add(post);
      context.SaveChanges();
      var repo = new ShiftRepository(context,usersHelper);
        var response = repo.GetShifts();
        Assert.NotNull(response);
      
    }

    [Fact]
    public void GetCurrentShift()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Shift
      {
        Id = 1,
        Name = "blue",
        Disabled = false,
        BackgroundColor = "red",
        TextColor = "black"
      };
      context.Shifts.Add(post);
      context.SaveChanges();
      var repo = new ShiftRepository(context,usersHelper);
        var response = repo.GetCurrentShift(TimeSpan.FromSeconds(1));
        Assert.NotNull(response);
      
    }

    [Fact]
    public void GetLateNightShift()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Shift
      {
        Id = 1,
        Name = "blue",
        Disabled = false,
        BackgroundColor = "red",
        TextColor = "black"
      };
      context.Shifts.Add(post);
      context.SaveChanges();
      var repo = new ShiftRepository(context,usersHelper);
        var response = repo.GetLateNightShift();
        Assert.NotNull(response);
      
    }

    [Fact]
    public void GetOrderedCurrentShift()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Shift
      {
        Id = 1,
        Name = "blue",
        Disabled = false,
        BackgroundColor = "red",
        TextColor = "black"
      };
      context.Shifts.Add(post);
      context.SaveChanges();
      var repo = new ShiftRepository(context,usersHelper);
        var response = repo.GetOrderedCurrentShift(TimeSpan.FromSeconds(1));
        Assert.NotNull(response);
      
    }

    [Fact]
    public void GetNextShiftByCurrentTime()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Shift
      {
        Id = 1,
        Name = "blue",
        Disabled = false,
        BackgroundColor = "red",
        TextColor = "black"
      };
      context.Shifts.Add(post);
      context.SaveChanges();
      var repo = new ShiftRepository(context,usersHelper);
        var response = repo.GetNextShiftByCurrentTime(TimeSpan.FromSeconds(1));
        Assert.NotNull(response);
      
    }

    [Fact]
    public void GetNextShift()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Shift
      {
        Id = 1,
        Name = "blue",
        Disabled = false,
        BackgroundColor = "red",
        TextColor = "black"
      };
      context.Shifts.Add(post);
      context.SaveChanges();
      var repo = new ShiftRepository(context,usersHelper);
        var response = repo.GetNextShift();
        Assert.NotNull(response);
      
    }

    [Fact]
    public void SaveChanges()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Shift
      {
        Id = 1,
        Name = "blue",
        Disabled = false,
        BackgroundColor = "red",
        TextColor = "black"
      };
      context.Shifts.Add(post);
      context.SaveChanges();
      var repo = new ShiftRepository(context,usersHelper);
        var response = repo.SaveChanges(AuditActionType.ModifyEntity);
        Assert.NotNull(response);
      
    }

    [Fact]
    public void UpdateShift()
    {
      
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Shift
      {
        Id = 1,
        Name = "blue",
        Disabled = false,
        BackgroundColor = "red",
        TextColor = "black"
      };
      context.Shifts.Add(post);
      context.SaveChanges();
      var repo = new ShiftRepository(context,usersHelper);
        var response = repo.UpdateShift(post, AuditActionType.ModifyEntity);
        Assert.NotNull(response);
      
    }

    [Fact]
    public void AddShift()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Shift
      {
        Id = 11,
        Name = "blue12",
        Disabled = false,
        BackgroundColor = "red",
        TextColor = "black"
      };
      
      var repo = new ShiftRepository(context,usersHelper);
        var response = repo.AddShift(post);
        Assert.NotNull(response);
      
    }

    [Fact]
    public void DeleteShift()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Shift
      {
        Id = 2,
        Name = "blue",
        Disabled = false,
        BackgroundColor = "red",
        TextColor = "black"
      };
      context.Shifts.Add(post);
      context.SaveChanges();
      var repo = new ShiftRepository(context,usersHelper);
        var response = repo.DeleteShift(post);
        Assert.NotNull(response);
      
    }
  }
}
