using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.Tests.Constants;
using CoilTracking.Tests.IntergrationTest;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System.Collections.Generic;
using Xunit;

namespace CoilTracking.Tests.Repository
{
  public class ProdPlanRepositoryTest
  {
    readonly IDatabaseSetup DatabaseFixture;
    public readonly IUserHelper usersHelper;
   
    private readonly IHttpContextAccessor httpContextAccessor;
    public ProdPlanRepositoryTest()
    {
      DatabaseFixture = new DatabaseFixture();
    }

    [Fact]
    public void GetProdPlans()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new ProdPlan { Id = 1, LotSize = 1 };
      context.Add(post);
      context.SaveChanges();
        var repo = new ProdPlanRepository(context,usersHelper);
        var response = repo.GetProdPlans();
        Assert.NotNull(response);
      
    }

    [Fact]
    public void GetProdPlanById()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new ProdPlan { Id = 1, LotSize = 1 };
      context.Add(post);
      context.SaveChanges();
      var repo = new ProdPlanRepository(context,usersHelper);
        var response = repo.GetProdPlanById(1);
        Assert.NotNull(response);
      
    }

    [Fact]
    public void PutProdPlan()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new ProdPlan { Id = 1, LotSize = 1 };
      context.Add(post);
      context.SaveChanges();
      var repo = new ProdPlanRepository(context,usersHelper);
        var response = repo.PutProdPlan(post);
        Assert.NotNull(response);
      
    }

    [Fact]
    public void SaveChanges()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new ProdPlan { Id = 1, LotSize = 1 };
      context.Add(post);
      context.SaveChanges();
      var repo = new ProdPlanRepository(context,usersHelper);
        var response = repo.SaveChanges(AuditActionType.ModifyEntity);
        Assert.NotNull(response);
      
    }

    [Fact]
    public void AddProdPlan()
    {
      var prodPlan = new ProdPlan
      {
        LotSize = 1
      };
      var context = DatabaseFixture.GetDatabaseFixture();
        var repo = new ProdPlanRepository(context,usersHelper);
        var response = repo.AddProdPlan(prodPlan);
        Assert.NotNull(response);
      
    }

    [Fact]
    public void GetProdPlanEntry()
    {
      var partNumber = new List<string>();
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new ProdPlan { Id = 1, LotSize = 1 };
      context.Add(post);
      context.SaveChanges();
      var repo = new ProdPlanRepository(context,usersHelper);
        var response = repo.GetProdPlanEntry(partNumber);
        Assert.NotNull(response);
      
    }

    [Fact]
    public void AddProdPlantEntry()
    {
      var prodPlan = new ProdPlan
      {
        LotSize = 1
      };
      var context = DatabaseFixture.GetDatabaseFixture();
        var repo = new ProdPlanRepository(context,usersHelper);
        var response = repo.AddProdPlantEntry(prodPlan);
        Assert.NotNull(response);
      
    }

    [Fact]
    public void RemoveProdPlantEntry()
    {
      
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new ProdPlan { Id = 1, LotSize = 1 };
      context.Add(post);
      context.SaveChanges();
      var repo = new ProdPlanRepository(context,usersHelper);
        repo.RemoveProdPlantEntry(post);
        Assert.NotNull(repo);
      
    }

    [Fact]
    public void UpdateProdPlantEntry()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new ProdPlan { Id = 1, LotSize = 1 };
      context.Add(post);
      context.SaveChanges();
      var repo = new ProdPlanRepository(context,usersHelper);
        var response = repo.UpdateProdPlantEntry(post);
        Assert.NotNull(response);
      
    }

    [Fact]
    public void UpdateProdPlantState()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new ProdPlan { Id = 1, LotSize = 1 };
      context.Add(post);
      context.SaveChanges();
      var repo = new ProdPlanRepository(context,usersHelper);
        repo.UpdateProdPlantState(post);
        Assert.NotNull(repo);
      
    }

    [Fact]
    public void RemoveProdPlan()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new ProdPlan { Id = 1, LotSize = 1 };
      context.Add(post);
      context.SaveChanges();
      var repo = new ProdPlanRepository(context,usersHelper);
        var response = repo.RemoveProdPlan(post);
        Assert.NotNull(response);
      
    }
  }
}
