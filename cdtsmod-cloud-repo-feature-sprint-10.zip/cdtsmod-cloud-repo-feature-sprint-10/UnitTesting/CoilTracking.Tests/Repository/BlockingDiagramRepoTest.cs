using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.Tests.IntergrationTest;
using Xunit;

namespace CoilTracking.Tests.Repository
{
  public class BlockingDiagramRepoTest
  {
    public static CoilTrackingContext context;
    public readonly IUserHelper usersHelper;
    readonly IDatabaseSetup DatabaseFixture;

    public BlockingDiagramRepoTest()
    {
      DatabaseFixture = new DatabaseFixture();
    }

    [Fact]
    public void GetBlankingDiagramByDataNum_Returns_BlockingDiagram()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new BlockingDiagrams
      {
        Id = 1,
        DataNumber = 1,
        ImagePath = "1"
      };
      context.BlockingDiagrams.Add(post);
      context.SaveChanges();
      BlockingDiagramRepository repo = new BlockingDiagramRepository(context,usersHelper);
      var result = repo.GetBlockingDiagramByDataNum(1);
      Assert.NotNull(result);

    }

    [Fact]
    public void GetBlankingDiagramById_Returns_BlockingDiagram()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new BlockingDiagrams
      {
        Id = 1,
        DataNumber = 1,
        ImagePath = "1"
      };
      context.BlockingDiagrams.Add(post);
      context.SaveChanges();
      BlockingDiagramRepository repo = new BlockingDiagramRepository(context,usersHelper);
      var result = repo.GetBlockingDiagramById(1);
      Assert.NotNull(result);

    }

    [Fact]
    public void GetBlankingDiagrams_Returns_BlockingDiagram()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new BlockingDiagrams
      {
        Id = 1,
        DataNumber = 1,
        ImagePath = "1"
      };
      context.BlockingDiagrams.Add(post);
      context.SaveChanges();
      BlockingDiagramRepository repo = new BlockingDiagramRepository(context,usersHelper);
      var result = repo.GetBlockingDiagrams();
      Assert.NotNull(result);

    }
    [Fact]
    public void UpdateBlankingDiagram()
    {
      var data = new BlockingDiagrams
      {
        Id = 2,
        DataNumber = 2,
        ImagePath = "1"
      };
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new BlockingDiagrams
      {
        Id = 2,
        DataNumber = 2,
        ImagePath = "1"
      };
      context.BlockingDiagrams.Add(post);
      context.SaveChanges();
      BlockingDiagramRepository repo = new BlockingDiagramRepository(context,usersHelper);
      var result = repo.UpdateBlockingDiagram(data);
      Assert.NotNull(result);

    }

    [Fact]
    public void InsertBlankingDiagram()
    {
      var data = new BlockingDiagrams
      {

        DataNumber = 3,
        ImagePath = "3"
      };
      var context = DatabaseFixture.GetDatabaseFixture();

      BlockingDiagramRepository repo = new BlockingDiagramRepository(context,usersHelper);
      var result = repo.InsertBlockingDiagram(data);
      Assert.NotNull(result);

    }

    [Fact]
    public void DeleteBlankingDiagram()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new BlockingDiagrams
      {
        Id = 5,
        DataNumber = 5,
        ImagePath = "1"
      };
      context.BlockingDiagrams.Add(post);
      context.SaveChanges();
      BlockingDiagramRepository repo = new BlockingDiagramRepository(context,usersHelper);
      var result = repo.DeleteBlockingDiagram(5);
      Assert.NotNull(result);

    }
  }
}
