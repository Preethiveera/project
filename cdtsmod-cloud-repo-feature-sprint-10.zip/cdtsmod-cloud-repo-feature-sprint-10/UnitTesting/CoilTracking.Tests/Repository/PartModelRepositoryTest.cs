using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.Tests.Constants;
using CoilTracking.Tests.IntergrationTest;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace CoilTracking.Tests.Repository
{
  public class PartModelRepositoryTest
  {

    public readonly IUserHelper usersHelper;
    readonly IDatabaseSetup DatabaseFixture;
    public PartModelRepositoryTest()
    {
      DatabaseFixture = new DatabaseFixture();
    }

    [Fact]
    public void GetPartModels()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PartModel
      {
        Id = 1,
        Model = new Model { Id = 2, ModelNumber = "2c", Disabled = false, Name = "test" },
        Part = new Part { Id = 1 }
      };
      context.PartModels.Add(post);
      context.SaveChanges();
      var repo = new PartModelsRepository(context,usersHelper);
        var response = repo.GetPartModels();
        Assert.NotNull(response);
      
    }

    [Fact]
    public void GetPartModel()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PartModel
      {
        Id = 1,
        Model = new Model { Id = 2, ModelNumber = "2c", Disabled = false, Name = "test" },
        Part = new Part { Id = 1 }
      };
      context.PartModels.Add(post);
      context.SaveChanges();
      var repo = new PartModelsRepository(context,usersHelper);
        var response = repo.GetPartModel(1);
        Assert.NotNull(response);
      
    }

    [Fact]
    public void GetPartsRelatedToModels()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PartModel
      {
        Id = 1,
        Model = new Model { Id = 2, ModelNumber = "2c", Disabled = false, Name = "test" },
        Part = new Part { Id = 1 }
      };
      context.PartModels.Add(post);
      context.SaveChanges();
      var repo = new PartModelsRepository(context,usersHelper);
        var response = repo.GetPartsRelatedToModels(1);
        Assert.NotNull(response);
      
    }

    [Fact]
    public void GetPartModelByPartIdsAndModelId()
    {
      var partIds = new int[2];
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PartModel
      {
        Id = 1,
        Model = new Model { Id = 2, ModelNumber = "2c", Disabled = false, Name = "test" },
        Part = new Part { Id = 2 }
      };
      context.PartModels.Add(post);
      context.SaveChanges();
      var repo = new PartModelsRepository(context,usersHelper);
        var response = repo.GetPartModelByPartIdsAndModelId(partIds,1);
        Assert.NotNull(response);
      
    }

    [Fact]
    public void UpdatePartModel()
    {
      
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PartModel
      {
        Id = 1,
        Model = new Model { Id = 2, ModelNumber = "2c", Disabled = false, Name = "test" },
        Part = new Part { Id = 1 }
      };
      context.PartModels.Add(post);
      context.SaveChanges();
      var repo = new PartModelsRepository(context,usersHelper);
        repo.UpdatePartModel(post);
        Assert.NotNull(repo);
      
    }

    [Fact]
    public void UnchangedPartModel()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PartModel
      {
        Id = 1,
        Model = new Model { Id = 2, ModelNumber = "2c", Disabled = false, Name = "test" },
        Part = new Part { Id = 1 }
      };
      context.PartModels.Add(post);
      context.SaveChanges();
      var repo = new PartModelsRepository(context,usersHelper);
        var response = repo.UnchangedPartModel(post);
        Assert.NotNull(repo);
      
    }

    [Fact]
    public void RemovePartModel()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PartModel
      {
        Id = 11,
        Model = new Model { Id = 2, ModelNumber = "2c", Disabled = false, Name = "test" },
        Part = new Part { Id = 1 }
      };
      context.PartModels.Add(post);
      context.SaveChanges();
      var repo = new PartModelsRepository(context,usersHelper);
        var response = repo.RemovePartModel(post);
        Assert.NotNull(repo);
      
    }

    [Fact]
    public void UpdatePartModelSaveAsync()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PartModel
      {
        Id = 1,
        Model = new Model { Id = 2, ModelNumber = "2c", Disabled = false, Name = "test" },
        Part = new Part { Id = 1 }
      };
      context.PartModels.Add(post);
      context.SaveChanges();
      var repo = new PartModelsRepository(context,usersHelper);
        var response = repo.UpdatePartModelSaveAsync(post);
        Assert.NotNull(response);
      
    }

    [Fact]
    public void GetPartmodelsByPartnumber()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PartModel
      {
        Id = 1,
        Model = new Model { Id = 2, ModelNumber = "2c", Disabled = false, Name = "test" },
        Part = new Part { Id = 1 }
      };
      context.PartModels.Add(post);
      context.SaveChanges();
      var repo = new PartModelsRepository(context,usersHelper);
        var response = repo.GetPartmodelsByPartnumber("");
        Assert.NotNull(response);
      
    }

    [Fact]
    public void GetPartmodelsByPartId()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PartModel
      {
        Id = 1,
        Model = new Model { Id = 2, ModelNumber = "2c", Disabled = false, Name = "test" },
        Part = new Part { Id = 1 }
      };
      context.PartModels.Add(post);
      context.SaveChanges();
      var repo = new PartModelsRepository(context,usersHelper);
        var response = repo.GetPartmodelsByPartId(1);
        Assert.NotNull(response);
      
    }

    [Fact]
    public void GetPartModelByPartId()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PartModel
      {
        Id = 1,
        Model = new Model { Id = 2, ModelNumber = "2c", Disabled = false, Name = "test" },
        Part = new Part { Id = 1 }
      };
      context.PartModels.Add(post);
      context.SaveChanges();
      var repo = new PartModelsRepository(context,usersHelper);
        var response = repo.GetPartModelByPartId(1);
        Assert.NotNull(response);
      
    }

    [Fact]
    public void InsertPartModelsSavechanges()
    {
      var partModels = new List<PartModel>
      {
        new PartModel
        {
          Id = 1
        }
      };
      var context = DatabaseFixture.GetDatabaseFixture();
        var repo = new PartModelsRepository(context,usersHelper);
        var response = repo.InsertPartModelsSavechanges(partModels);
        Assert.NotNull(response);
      
    }

    [Fact]
    public void PartModelsSavechanges()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PartModel
      {
        Id = 1,
        Model = new Model { Id = 2, ModelNumber = "2c", Disabled = false, Name = "test" },
        Part = new Part { Id = 1 }
      };
      context.PartModels.Add(post);
      context.SaveChanges();
      var repo = new PartModelsRepository(context,usersHelper);
        var response = repo.PartModelsSavechanges();
        Assert.NotNull(response);
      
    }

    [Fact]
    public void GetPartModelById()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PartModel
      {
        Id = 1,
        Model = new Model { Id = 2, ModelNumber = "2c", Disabled = false, Name = "test" },
        Part = new Part { Id = 1 }
      };
      context.PartModels.Add(post);
      context.SaveChanges();
      var repo = new PartModelsRepository(context,usersHelper);
        var response = repo.GetPartModelById(1);
        Assert.NotNull(response);
      
    }

    [Fact]
    public void GetPartModelsAsync()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PartModel
      {
        Id = 1,
        Model = new Model { Id = 2, ModelNumber = "2c", Disabled = false, Name = "test" },
        Part = new Part { Id = 1 }
      };
      context.PartModels.Add(post);
      context.SaveChanges();
      var repo = new PartModelsRepository(context,usersHelper);
        var response = repo.GetPartModelsAsync();
        Assert.NotNull(response);
      
    }

    [Fact]
    public void SaveChanges()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PartModel
      {
        Id = 1,
        Model = new Model { Id = 2, ModelNumber = "2c", Disabled = false, Name = "test" },
        Part = new Part { Id = 1 }
      };
      context.PartModels.Add(post);
      context.SaveChanges();
      var repo = new PartModelsRepository(context,usersHelper);
        var response = repo.SaveChanges(AuditActionType.ModifyEntity);
        Assert.NotNull(response);
      
    }

    [Fact]
    public void UpdatePartModelAsync()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PartModel
      {
        Id = 1,
        Model = new Model { Id = 2, ModelNumber = "2c", Disabled = false, Name = "test" },
        Part = new Part { Id = 1 }
      };
      context.PartModels.Add(post);
      context.SaveChanges();
      var repo = new PartModelsRepository(context,usersHelper);
        var response = repo.UpdatePartModelAsync(post);
        Assert.NotNull(response);
      
    }

    [Fact]
    public void AddPartModelAsync()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PartModel
      {
        Id = 1,
        Model = new Model { Id = 2, ModelNumber = "2c", Disabled = false, Name = "test" },
        Part = new Part { Id = 1 }
      };
      
      var repo = new PartModelsRepository(context,usersHelper);
        var response = repo.AddPartModelAsync(post);
        Assert.NotNull(response);
      
    }

    [Fact]
    public void DeletePartModelAsync()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PartModel
      {
        Id = 100,
        Model = new Model { Id = 2, ModelNumber = "2c", Disabled = false, Name = "test" },
        Part = new Part { Id = 1 }
      };
      context.PartModels.Add(post);
      context.SaveChanges();
      var repo = new PartModelsRepository(context,usersHelper);
        var response = repo.DeletePartModelAsync(post);
        Assert.NotNull(response);
      
    }
  }
}
