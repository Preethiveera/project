using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.Tests.IntergrationTest;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace CoilTracking.Tests.Repository
{
  public class CoilMoveRequestRepositoryTest
  {
    public readonly IUserHelper usersHelper;
    readonly IDatabaseSetup DatabaseFixture;

    public CoilMoveRequestRepositoryTest()
    {
      DatabaseFixture = new DatabaseFixture();
    }

    [Fact]
    public void GetAllCoilMoveRequest()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilMoveRequest
      {
        Id = 1
      };
      context.CoilMoveRequests.Add(post);
      context.SaveChanges();

      var repo = new CoilMoveRequestsRepository(context,usersHelper);
      var response = repo.GetAllCoilMoveRequest();
      Assert.NotNull(response);

    }

    [Fact]
    public void GetPendingRequestByLine()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilMoveRequest
      {
        Id = 3,
        Line = new Line { Id = 1 }
      };
      context.CoilMoveRequests.Add(post);
      context.SaveChanges();

      var repo = new CoilMoveRequestsRepository(context,usersHelper);
      var response = repo.GetPendingRequestByLine(1);
      Assert.NotNull(response);

    }

    [Fact]
    public void GetUnfulfilledCoilMoveRequests()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilMoveRequest
      {
        Id = 2,

      };
      context.CoilMoveRequests.Add(post);
      context.SaveChanges();

      var repo = new CoilMoveRequestsRepository(context,usersHelper);
      var response = repo.GetUnfulfilledCoilMoveRequests();
      Assert.NotNull(response);

    }

    [Fact]
    public void GetMoveRequestById()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilMoveRequest
      {
        Id = 1
      };
      context.CoilMoveRequests.Add(post);
      context.SaveChanges();

      var repo = new CoilMoveRequestsRepository(context,usersHelper);
      var response = repo.GetMoveRequestById(1);
      Assert.NotNull(response);

    }

    [Fact]
    public void SaveChanges()
    {
      var context = DatabaseFixture.GetDatabaseFixture();

      var repo = new CoilMoveRequestsRepository(context,usersHelper);
      var response = repo.SaveChanges(AuditActionType.ModifyEntity);
      Assert.NotNull(response);

    }

    [Fact]
    public void AddCoilMoveRequest()
    {
      var coilMoveRequest = new CoilMoveRequest
      {
        IsCancelled = true
      };
      var context = DatabaseFixture.GetDatabaseFixture();

      var repo = new CoilMoveRequestsRepository(context,usersHelper);
      var response = repo.AddCoilMoveRequest(coilMoveRequest);
      Assert.NotNull(response);

    }

    [Fact]
    public void GetCoilMoveRequestWithCoilData()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilMoveRequest
      {
        Id = 11,
        Coil = new Coil { Id = 2 }
      };
      context.CoilMoveRequests.Add(post);
      context.SaveChanges();

      var repo = new CoilMoveRequestsRepository(context,usersHelper);
      var response = repo.GetCoilMoveRequestWithCoilData(1);
      Assert.NotNull(response);

    }

    [Fact]
    public void FindCoilMoveRequestAsync()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilMoveRequest
      {
        Id = 13
      };
      context.CoilMoveRequests.Add(post);
      context.SaveChangesAsync();

      var repo = new CoilMoveRequestsRepository(context,usersHelper);
      var response = repo.FindCoilMoveRequestAsync(1);
      Assert.NotNull(response);

    }

    [Fact]
    public void DeleteCoilMoveRequest()
    {
      var coilMoveRequest = new CoilMoveRequest
      {
        IsCancelled = true
      };
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilMoveRequest
      {
        Id = 1
      };
      context.CoilMoveRequests.Add(post);
      context.SaveChanges();

      var repo = new CoilMoveRequestsRepository(context,usersHelper);
      var response = repo.DeleteCoilMoveRequest(coilMoveRequest);
      Assert.NotNull(response);

    }

    [Fact]
    public void GetCoilsLoadedByCoilStatusName()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilMoveRequest
      {
        Id = 15,

      };
      context.CoilMoveRequests.Add(post);
      context.SaveChanges();

      var repo = new CoilMoveRequestsRepository(context,usersHelper);
      var response = repo.GetCoilsLoadedByCoilStatusName("");
      Assert.NotNull(response);

    }

    [Fact]
    public void GetReturnRequests()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilMoveRequest
      {
        Id = 1
      };
      context.CoilMoveRequests.Add(post);
      context.SaveChanges();

      var repo = new CoilMoveRequestsRepository(context,usersHelper);
      var response = repo.GetReturnRequests();
      Assert.NotNull(response);

    }
  }
}
