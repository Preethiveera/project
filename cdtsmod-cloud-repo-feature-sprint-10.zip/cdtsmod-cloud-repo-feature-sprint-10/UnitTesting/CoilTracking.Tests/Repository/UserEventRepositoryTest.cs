using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.Tests.IntergrationTest;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace CoilTracking.Tests.Repository
{
  public class UserEventRepositoryTest
  {
    public readonly Mock<IUserHelper> usersHelper;
    readonly IDatabaseSetup DatabaseFixture;
    public UserEventRepositoryTest()
    {
      usersHelper = new Mock<IUserHelper>(); 
      DatabaseFixture = new DatabaseFixture();
    }

    [Fact]
    public async Task GetUserEvents_ReturnsEvents()
    {

      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new UserEvent { Id = 2, UserName = "test" };
      context.UserEvents.Add(post);
      context.SaveChanges();
      UserEventRepository repo = new UserEventRepository(context, usersHelper.Object);
      await repo.GetUserEvents();
      Assert.NotNull(post);

    }
    [Fact]
    public async Task GetUserEventsBetween_ReturnsEvents()
    {

      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new UserEvent { Id = 12, UserName = "test1" };
      context.UserEvents.Add(post);
      context.SaveChanges();
      UserEventRepository repo = new UserEventRepository(context, usersHelper.Object);
      await repo.GetUserEventsBetween(null, null, "test1");
      Assert.NotNull(post);


    }
    [Fact]
    public async Task GetUserEventsBYId_ReturnsEvents()
    {

      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new UserEvent { Id = 112, UserName = "test12" };
      context.UserEvents.Add(post);
      context.SaveChanges();
      UserEventRepository repo = new UserEventRepository(context, usersHelper.Object);
      await repo.GetUserEventById(112);
      Assert.NotNull(post);

    }
    [Fact]
    public void UpdateUserEvents_ReturnsEvents()
    {

      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new UserEvent { Id = 2, UserName = "test2" };
      context.UserEvents.Add(post);
      context.SaveChanges();
      UserEventRepository repo = new UserEventRepository(context, usersHelper.Object);
       repo.UpdateUserEvent(2, post);
      Assert.NotNull(post);

    }
    [Fact]
    public async Task InsertUserEvents_ReturnsEvents()
    {

      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new UserEvent { Id = 123, UserName = "test13" };
      
      UserEventRepository repo = new UserEventRepository(context, usersHelper.Object);
      await repo.InsertUserEvent(post);
      Assert.NotNull(post);

    }
    
  }
}
