using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.DTO;
using CoilTracking.Tests.Constants;
using CoilTracking.Tests.IntergrationTest;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace CoilTracking.Tests.Repository
{
 public class CoilTypeYNARepositoryTest
  {

    public readonly Mock<IUserHelper> usersHelper;
    readonly IDatabaseSetup DatabaseFixture;
    public CoilTypeYNARepositoryTest()
    {
      usersHelper = new Mock<IUserHelper>();
      DatabaseFixture = new DatabaseFixture();
    }


    [Fact]
    public void GetCoilTypeYNAByNumberWithcoilTypeName_RetunsCoils()
    {
      string  yna = "test";
      var context = DatabaseFixture.GetDatabaseFixture();
      var CoilTypeYNAs = new CoilTypeYNA() { Id = 1, YNA = "YNA0011171", CoilType = new CoilType() { }, MaterialType = new MaterialType() { Name = "YAS" } };
      //Act    
      context.CoilTypeYNAs.Add(CoilTypeYNAs);
      context.SaveChanges();
      var repo = new CoilTypeYNARepository(context);
    repo.GetCoilTypeYNAByNumberWithcoilTypeName(yna,yna);
      Assert.True(true);

    }


    [Fact]
    public void GetcoilTypeYNAAlreadyExistsDiffCoilType_RetunsCoils()
    {
      string yna = "test";
      var context = DatabaseFixture.GetDatabaseFixture();
      var CoilTypeYNAs = new CoilTypeYNA() { Id = 1, YNA = "YNA0011171", CoilType = new CoilType() { }, MaterialType = new MaterialType() { Name = "YAS" } };
      //Act    
      context.CoilTypeYNAs.Add(CoilTypeYNAs);
      context.SaveChanges();
      var repo = new CoilTypeYNARepository(context);
       repo.GetcoilTypeYNAAlreadyExistsDiffCoilType(yna, yna);
      Assert.True(true);

    }

    
    [Fact]
    public void GetCoilTypeByRecordNumber_RetunsCoils()
    {
      string yna = "test";
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilType()
      {
        Id = 8,
        Name = "3-1-T",
        Width = 1380,
        Thickness = decimal.Parse("0.70"),
        Spec = "SCGA270D 45V",
        NumCoils = 1,
        Disabled = false,
        Yield = 0,
        MinThickness = 0,
        MaxThickness = 0,
        MinWidth = 0,
        MaxWidth = 0
      };
      //Act    
      context.CoilTypes.Add(post);
      context.SaveChanges();
      var repo = new CoilTypeYNARepository(context);
    repo.GetCoilTypeByRecordNumber(yna);
      Assert.True(true);

    }


    [Fact]
    public void GetMaterialTypeByYNA_RetunsCoils()
    {
      string yna = "test";
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilType()
      {
        Id = 8,
        Name = "3-1-T",
        Width = 1380,
        Thickness = decimal.Parse("0.70"),
        Spec = "SCGA270D 45V",
        NumCoils = 1,
        Disabled = false,
        Yield = 0,
        MinThickness = 0,
        MaxThickness = 0,
        MinWidth = 0,
        MaxWidth = 0
      };
      //Act    
      context.CoilTypes.Add(post);
      context.SaveChanges();
      var repo = new CoilTypeYNARepository(context);
      var response = repo.GetMaterialTypeByYNA(yna);
      Assert.NotNull(response);

    }

    [Fact]
    public void GetcoilTypeYNAsByYNANo_RetunsCoils()
    {
      string yna = "test";
      var context = DatabaseFixture.GetDatabaseFixture();
      var CoilTypeYNAs =  new CoilTypeYNA() { Id = 1, YNA = "YNA0011171", CoilType = new CoilType() { }, MaterialType = new MaterialType() { Name = "YAS" } };
      //Act    
      context.CoilTypeYNAs.Add(CoilTypeYNAs);
      context.SaveChanges();
      var repo = new CoilTypeYNARepository(context);
      repo.GetcoilTypeYNAsByYNANo(yna);
      Assert.True(true);

    }


    [Fact]
    public void IscoilTypeYNAsByYNANo_RetunsCoils()
    {
      string yna = "test";
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilType()
      {
        Id = 8,
        Name = "3-1-T",
        Width = 1380,
        Thickness = decimal.Parse("0.70"),
        Spec = "SCGA270D 45V",
        NumCoils = 1,
        Disabled = false,
        Yield = 0,
        MinThickness = 0,
        MaxThickness = 0,
        MinWidth = 0,
        MaxWidth = 0
      };
      //Act    
      context.CoilTypes.Add(post);
      context.SaveChanges();
      var repo = new CoilTypeYNARepository(context);
    repo.IscoilTypeYNAsByYNANo(yna);
      Assert.True(true);

    }


  }
}
