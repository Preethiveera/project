using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.Tests.Constants;
using CoilTracking.Tests.IntergrationTest;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading.Tasks;
using Xunit;

namespace CoilTracking.Tests.Repository
{
  public class RunOrderRepositoryTest
  {

    public readonly IUserHelper usersHelper;
    readonly IDatabaseSetup DatabaseFixture;
    public RunOrderRepositoryTest()
    {
      DatabaseFixture = new DatabaseFixture();

    }
    [Fact]
    public void GetRunOrderListId_RunOrderList_ReturnsRunOrderLists()
    {
      var post = new RunOrderList
      {
        Id = 1,
        Date = DateTime.Now,
        Line = new Line
        {
          Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1
          },
          Plant = new Plant { Id = 1 }
        },
        Quantities = new List<RunOrderListQuantity>
              {
                new RunOrderListQuantity
                {
                  Id=1,
                  BlankInfo=new BlankInfo
                  {
                    Id=1, DataNumber=1
                  },
                  Part=new Part{Id=1, PartName="61631-02170" , PartNumber="61631-02170"},
                  OverrideQty=1,
                  SortOrder=0,
                  Incomplete= false,
                  RunOrderList=new RunOrderList
                  {
                    Id=1,
                    Line=new Line{Id=1},
                    PatternLetter="A",
                    Shift=new Shift{Id=1}

                  },

                }
              }

      };

      var context = DatabaseFixture.GetDatabaseFixture();
      context.RunOrderLists.Add(new RunOrderList { Id=22,
        PatternLetter="A"});
      context.SaveChanges();
        RunOrderRepository runRepository = new RunOrderRepository(context,usersHelper);
        var result = runRepository.GetRunOrderListId(22);
        Assert.NotNull(result);

      

    }

    [Fact]
    public void GetRunOrderListIds_RunOrderList_ReturnsRunOrderLists()
    {
      var post = new RunOrderList
      {
        Id = 1,
        Date = DateTime.Now,
        Line = new Line
        {
          Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1
          },
          Plant = new Plant { Id = 1 }
        },
        Quantities = new List<RunOrderListQuantity>
              {
                new RunOrderListQuantity
                {
                  Id=1,
                  BlankInfo=new BlankInfo
                  {
                    Id=1, DataNumber=1
                  },
                  Part=new Part{Id=1, PartName="61631-02170" , PartNumber="61631-02170"},
                  OverrideQty=1,
                  SortOrder=0,
                  Incomplete= false,
                  RunOrderList=new RunOrderList
                  {
                    Id=1,
                    Line=new Line{Id=1},
                    PatternLetter="A",
                    Shift=new Shift{Id=1}

                  },

                }
              }

      };
      var context = DatabaseFixture.GetDatabaseFixture();
      context.RunOrderLists.Add(post);
      context.SaveChanges();
      List<int> list = new List<int> { 1 };
        RunOrderRepository runRepository = new RunOrderRepository(context,usersHelper);
        var result = runRepository.GetRunOrderListByPartialIds(list);
        Assert.NotNull(result);

      

    }

    [Fact]
    public void IsScheduledOnRunOrder_Id_Returnsbool()
    {
      var post = new RunOrderList
      {
        Id = 1,
        Date = DateTime.Now,
        Line = new Line
        {
          Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1
          },
          Plant = new Plant { Id = 1 }
        },
        Quantities = new List<RunOrderListQuantity>
              {
                new RunOrderListQuantity
                {
                  Id=1,
                  BlankInfo=new BlankInfo
                  {
                    Id=1, DataNumber=1
                  },
                  Part=new Part{Id=1, PartName="61631-02170" , PartNumber="61631-02170"},
                  OverrideQty=1,
                  SortOrder=0,
                  Incomplete= false,
                  RunOrderList=new RunOrderList
                  {
                    Id=1,
                    Line=new Line{Id=1},
                    PatternLetter="A",
                    Shift=new Shift{Id=1}

                  },

                }
              }

      };
      var context = DatabaseFixture.GetDatabaseFixture();
      context.RunOrderLists.Add(post);
      context.SaveChanges();
      RunOrderRepository runRepository = new RunOrderRepository(context,usersHelper);
        var result = runRepository.IsScheduledOnRunOrder(1);
        Assert.True(true);

      

    }
    [Fact]
    public void GetRunOrderListByIdAsync_Id_ReturnsRunOrderList()
    {
      var post = new RunOrderList
      {
        Id = 1,
        Date = DateTime.Now,
        Line = new Line
        {
          Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1
          },
          Plant = new Plant { Id = 1 }
        },
        Quantities = new List<RunOrderListQuantity>
              {
                new RunOrderListQuantity
                {
                  Id=1,
                  BlankInfo=new BlankInfo
                  {
                    Id=1, DataNumber=1
                  },
                  Part=new Part{Id=1, PartName="61631-02170" , PartNumber="61631-02170"},
                  OverrideQty=1,
                  SortOrder=0,
                  Incomplete= false,
                  RunOrderList=new RunOrderList
                  {
                    Id=1,
                    Line=new Line{Id=1},
                    PatternLetter="A",
                    Shift=new Shift{Id=1}

                  },

                }
              }

      };
      var context = DatabaseFixture.GetDatabaseFixture();
      context.RunOrderLists.Add(post);
      context.SaveChanges();
      RunOrderRepository runRepository = new RunOrderRepository(context,usersHelper);
        var result = runRepository.GetRunOrderListByIdAsync(1);
        Assert.NotNull(result);

      

    }

    [Fact]
    public void GetRunOrderListAsync_ReturnsRunOrderList()
    {
      var post = new RunOrderList
      {
        Id = 1,
        Date = DateTime.Now,
        Line = new Line
        {
          Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1
          },
          Plant = new Plant { Id = 1 }
        },
        Quantities = new List<RunOrderListQuantity>
              {
                new RunOrderListQuantity
                {
                  Id=1,
                  BlankInfo=new BlankInfo
                  {
                    Id=1, DataNumber=1
                  },
                  Part=new Part{Id=1, PartName="61631-02170" , PartNumber="61631-02170"},
                  OverrideQty=1,
                  SortOrder=0,
                  Incomplete= false,
                  RunOrderList=new RunOrderList
                  {
                    Id=1,
                    Line=new Line{Id=1},
                    PatternLetter="A",
                    Shift=new Shift{Id=1}

                  },

                }
              }

      };
      var context = DatabaseFixture.GetDatabaseFixture();
      context.RunOrderLists.Add(post);
      context.SaveChanges();
      RunOrderRepository runRepository = new RunOrderRepository(context,usersHelper);
        var result = runRepository.GetRunOrderListsAsync();
        Assert.NotNull(result);

      

    }
    [Fact]
    public void RunOrderListExist_Id_Returnsbool()
    {
      var post = new RunOrderList
      {
        Id = 1,
        Date = DateTime.Now,
        Line = new Line
        {
          Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1
          },
          Plant = new Plant { Id = 1 }
        },
        Quantities = new List<RunOrderListQuantity>
              {
                new RunOrderListQuantity
                {
                  Id=1,
                  BlankInfo=new BlankInfo
                  {
                    Id=1, DataNumber=1
                  },
                  Part=new Part{Id=1, PartName="61631-02170" , PartNumber="61631-02170"},
                  OverrideQty=1,
                  SortOrder=0,
                  Incomplete= false,
                  RunOrderList=new RunOrderList
                  {
                    Id=1,
                    Line=new Line{Id=1},
                    PatternLetter="A",
                    Shift=new Shift{Id=1}

                  },

                }
              }

      };
      var context = DatabaseFixture.GetDatabaseFixture();
      context.RunOrderLists.Add(post);
      context.SaveChanges();
      RunOrderRepository runRepository = new RunOrderRepository(context,usersHelper);
       runRepository.RunOrderListExists(1);
        Assert.True(true);

    }
    [Fact]
    public void GetIncompleteRunOrderItemsByLineId_Id_ReturnsIncompleteRunOrderList()
    {
      var post = new RunOrderList
      {
        Id = 1,
        Date = DateTime.Now,
        Line = new Line
        {
          Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1
          },
          Plant = new Plant { Id = 1 }
        },
        Quantities = new List<RunOrderListQuantity>
              {
                new RunOrderListQuantity
                {
                  Id=1,
                  BlankInfo=new BlankInfo
                  {
                    Id=1, DataNumber=1
                  },
                  Part=new Part{Id=1, PartName="61631-02170" , PartNumber="61631-02170"},
                  OverrideQty=1,
                  SortOrder=0,
                  Incomplete= false,
                  RunOrderList=new RunOrderList
                  {
                    Id=1,
                    Line=new Line{Id=1},
                    PatternLetter="A",
                    Shift=new Shift{Id=1}

                  },

                }
              }

      };
      var context = DatabaseFixture.GetDatabaseFixture();
      context.RunOrderLists.Add(post);
      context.SaveChanges();
      RunOrderRepository runRepository = new RunOrderRepository(context,usersHelper);
        var result = runRepository.GetIncompleteRunItemByLineId(1);
        Assert.NotNull(result);

    }

    [Fact]
    public void GetIncompleteRunOrderItemsWithShiftLine_Id_ReturnsIncompleteRunOrderList()
    {
      var post = new RunOrderList
      {
        Id = 1,
        Date = DateTime.Now,
        Line = new Line
        {
          Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1
          },
          Plant = new Plant { Id = 1 }
        },
        Quantities = new List<RunOrderListQuantity>
              {
                new RunOrderListQuantity
                {
                  Id=1,
                  BlankInfo=new BlankInfo
                  {
                    Id=1, DataNumber=1
                  },
                  Part=new Part{Id=1, PartName="61631-02170" , PartNumber="61631-02170"},
                  OverrideQty=1,
                  SortOrder=0,
                  Incomplete= false,
                  RunOrderList=new RunOrderList
                  {
                    Id=1,
                    Line=new Line{Id=1},
                    PatternLetter="A",
                    Shift=new Shift{Id=1}

                  },

                }
              }

      };
      var context = DatabaseFixture.GetDatabaseFixture();
      context.RunOrderLists.Add(post);
      context.SaveChanges();
      RunOrderRepository runRepository = new RunOrderRepository(context,usersHelper);
        var result = runRepository.GetIncompleteItemsWithShiftLinePart(1);
        Assert.NotNull(result);

    }


    [Fact]
    public async Task GetListByDateLineIdAndShift_Id_ReturnsRunOrderList()
    {
      var post = new RunOrderList
      {
        Id = 1,
        Date = DateTime.Now,
        Line = new Line
        {
          Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1
          },
          Plant = new Plant { Id = 1 }
        },
        Quantities = new List<RunOrderListQuantity>
              {
                new RunOrderListQuantity
                {
                  Id=1,
                  BlankInfo=new BlankInfo
                  {
                    Id=1, DataNumber=1
                  },
                  Part=new Part{Id=1, PartName="61631-02170" , PartNumber="61631-02170"},
                  OverrideQty=1,
                  SortOrder=0,
                  Incomplete= false,
                  RunOrderList=new RunOrderList
                  {
                    Id=1,
                    Line=new Line{Id=1},
                    PatternLetter="A",
                    Shift=new Shift{Id=1}

                  },

                }
              }

      };
      var context = DatabaseFixture.GetDatabaseFixture();
      context.RunOrderLists.Add(post);
      context.SaveChanges();
      var date = DateTime.Now;
        RunOrderRepository runRepository = new RunOrderRepository(context,usersHelper);
        var result = runRepository.GetListByDateLineIdAndShift(date, 1,1);
        Assert.NotNull(result);

    }


    [Fact]
    public async Task GetListWithQuantitiesAndShifts_IdDateLineId_ReturnsRunOrderList()
    {
      CultureInfo ci = CultureInfo.InvariantCulture;
      DateTime date = DateTime.ParseExact("12/25/2008", "MM/dd/yyyy", ci);

      var context = DatabaseFixture.GetDatabaseFixture();
        context.RunOrderListQuantities.Add(new RunOrderListQuantity
        {
          Id = 11,
          BlankInfo = new BlankInfo { Id = 10 },
          Incomplete = false,
          Part = new Part { Id = 23 },
          SortOrder = 0
        });
      context.SaveChanges();
        RunOrderRepository runRepository = new RunOrderRepository(context,usersHelper);
       await runRepository.GetListWithQuantitiesAndShifts(date, 3, 10);
        Assert.NotNull(runRepository);

      

    }


    [Fact]
    public async Task GetListByIdWithLineQuantity_Id_ReturnsRunOrderList()
    {
      var post = new RunOrderList
      {
        Id = 1,
        Date = DateTime.Now,
        Line = new Line
        {
          Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1
          },
          Plant = new Plant { Id = 1 }
        },
        Quantities = new List<RunOrderListQuantity>
              {
                new RunOrderListQuantity
                {
                  Id=1,
                  BlankInfo=new BlankInfo
                  {
                    Id=1, DataNumber=1
                  },
                  Part=new Part{Id=1, PartName="61631-02170" , PartNumber="61631-02170"},
                  OverrideQty=1,
                  SortOrder=0,
                  Incomplete= false,
                  RunOrderList=new RunOrderList
                  {
                    Id=1,
                    Line=new Line{Id=1},
                    PatternLetter="A",
                    Shift=new Shift{Id=1}

                  },

                }
              }

      };
      var context = DatabaseFixture.GetDatabaseFixture();
      context.RunOrderLists.Add(post);
      context.SaveChanges();

      RunOrderRepository runRepository = new RunOrderRepository(context,usersHelper);
        var result = runRepository.GetListByIdWithLineQuantity( 1);
        Assert.NotNull(result);

    }

    [Fact]
    public void GetIncompleteItemByStatusAndPart_PartNumsLineId_ReturnsIncompleteRunOrderList()
    {
      var post = new RunOrderList
      {
        Id = 1,
        Date = DateTime.Now,
        Line = new Line
        {
          Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1
          },
          Plant = new Plant { Id = 1 }
        },
        Quantities = new List<RunOrderListQuantity>
              {
                new RunOrderListQuantity
                {
                  Id=1,
                  BlankInfo=new BlankInfo
                  {
                    Id=1, DataNumber=1
                  },
                  Part=new Part{Id=1, PartName="61631-02170" , PartNumber="61631-02170"},
                  OverrideQty=1,
                  SortOrder=0,
                  Incomplete= false,
                  RunOrderList=new RunOrderList
                  {
                    Id=1,
                    Line=new Line{Id=1},
                    PatternLetter="A",
                    Shift=new Shift{Id=1}

                  },

                }
              }

      };
      var context = DatabaseFixture.GetDatabaseFixture();
      context.RunOrderLists.Add(post);
      context.SaveChanges();
      var partNums = new List<string> { "61631-02170" };
        RunOrderRepository runRepository = new RunOrderRepository(context,usersHelper);
        var result = runRepository.GetIncompleteItemByStatusAndPart(partNums,1);
        Assert.NotNull(result);

    }


    [Fact]
    public void GetIncompleteRunItemByLineId_LineId_ReturnsIncompleteRunOrderList()
    {
      var post = new RunOrderList
      {
        Id = 1,
        Date = DateTime.Now,
        Line = new Line
        {
          Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1
          },
          Plant = new Plant { Id = 1 }
        },
        Quantities = new List<RunOrderListQuantity>
              {
                new RunOrderListQuantity
                {
                  Id=1,
                  BlankInfo=new BlankInfo
                  {
                    Id=1, DataNumber=1
                  },
                  Part=new Part{Id=1, PartName="61631-02170" , PartNumber="61631-02170"},
                  OverrideQty=1,
                  SortOrder=0,
                  Incomplete= false,
                  RunOrderList=new RunOrderList
                  {
                    Id=1,
                    Line=new Line{Id=1},
                    PatternLetter="A",
                    Shift=new Shift{Id=1}

                  },

                }
              }

      };
      var context = DatabaseFixture.GetDatabaseFixture();
      context.RunOrderLists.Add(post);
      context.SaveChanges();
      RunOrderRepository runRepository = new RunOrderRepository(context,usersHelper);
        var result = runRepository.GetIncompleteRunItemByLineId( 1);
        Assert.NotNull(result);


    }
  }
}
