using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.Tests.Constants;
using CoilTracking.Tests.IntergrationTest;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace CoilTracking.Tests.Repository
{
  public class PatternLetterRepositoryTest
  {
    readonly IDatabaseSetup DatabaseFixture;
    public readonly IUserHelper usersHelper;
    public PatternLetterRepositoryTest()
    {
      DatabaseFixture = new DatabaseFixture();
    }

    [Fact]
    public void GetPatternLetter()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PatternLetter
      {
        Id = 1,
        Name = "A",
        Disabled = false,
        Desc = "test",
        Plant_Id = 1,
        Plant = new Plant { Id = 1 }
      };
      context.PatternLetters.Add(post);
      context.SaveChanges();

        PatternLetterRepository patternletterRepository = new PatternLetterRepository(context);
        var result = patternletterRepository.GetPatternLetter();
        Assert.NotNull(result);

      

    }

    [Fact]
    public void GetPatternLetterById()
    {
      int id = 1;
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PatternLetter
      {
        Id = 1,
        Name = "A",
        Disabled = false,
        Desc = "test",
        Plant_Id = 1,
        Plant = new Plant { Id = 1 }
      };
      context.PatternLetters.Add(post);
      context.SaveChanges();


      PatternLetterRepository patternletterRepository = new PatternLetterRepository(context);
        patternletterRepository.GetPatternLetterById(id);
        Assert.True(true);

      

    }

    [Fact]
    public void PatternLetterExists()
    {
      int id = 1;
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PatternLetter
      {
        Id = 1,
        Name = "A",
        Disabled = false,
        Desc = "test",
        Plant_Id = 1,
        Plant = new Plant { Id = 1 }
      };
      context.PatternLetters.Add(post);
      context.SaveChanges();

      PatternLetterRepository patternletterRepository = new PatternLetterRepository(context);
        var result = patternletterRepository.PatternLetterExists(id);
        Assert.True(true);

      

    }

    [Fact]
    public void CheckEdit()
    {
      int id = 1;

      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PatternLetter
      {
        Id = 1,
        Name = "A",
        Disabled = false,
        Desc = "test1",
        Plant_Id = 1,
        Plant = new Plant { Id = 1 }
      };
      context.PatternLetters.Add(post);
      context.SaveChanges();


      PatternLetterRepository patternletterRepository = new PatternLetterRepository(context);
        patternletterRepository.CheckEdit(id);
        Assert.NotNull(patternletterRepository);

      

    }

    [Fact]
    public void GetPatternLetterByName()
    {
      string name = "A";
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PatternLetter
      {
        Id = 1,
        Name = "A",
        Disabled = false,
        Desc = "test",
        Plant_Id = 1,
        Plant = new Plant { Id = 1 }
      };
      context.PatternLetters.Add(post);
      context.SaveChanges();


      PatternLetterRepository patternletterRepository = new PatternLetterRepository(context);
        var result = patternletterRepository.GetPatternLetterByName(name);
        Assert.NotNull(patternletterRepository);

      

    }

    [Fact]
    public void PostPatternLetter()
    {
      var patternLetter = new PatternLetter()
      {
        Name = "E",
        Desc = "test",
        Disabled = false
      };
      var context = DatabaseFixture.GetDatabaseFixture();

        PatternLetterRepository patternletterRepository = new PatternLetterRepository(context);
        var result = patternletterRepository.PostPatternLetter(patternLetter);
        Assert.NotNull(result);

      

    }
    [Fact]
    public void DisablePatternLetter()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PatternLetter
      {
        Id = 1,
        Name = "A",
        Disabled = false,
        Desc = "test",
        Plant_Id = 1,
        Plant = new Plant { Id = 1 }
      };
      context.PatternLetters.Add(post);
      context.SaveChanges();


      PatternLetterRepository patternletterRepository = new PatternLetterRepository(context);
        var result = patternletterRepository.DisablePatternLetter(1, false);
        Assert.True(result);

      

    }
    [Fact]
    public void PutPatternLetter()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PatternLetter
      {
        Id = 1,
        Name = "A",
        Disabled = false,
        Desc = "test",
        Plant_Id = 1,
        Plant = new Plant { Id = 1 }
      };
      context.PatternLetters.Add(post);
      context.SaveChanges();


      PatternLetterRepository patternletterRepository = new PatternLetterRepository(context);
        var result = patternletterRepository.PutPatternLetter(1, post);
        Assert.True(result);

      

    }
    [Fact]
    public void DeletePatternLetter()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PatternLetter
      {
        Id = 11,
        Name = "B",
        Disabled = false,
        Desc = "test",
        Plant_Id = 1,
        Plant = new Plant { Id = 1 }
      };
      context.PatternLetters.Add(post);
      context.SaveChanges();

      PatternLetterRepository patternletterRepository = new PatternLetterRepository(context);
        var result = patternletterRepository.DeletePatternLetter(11);
        Assert.True(result);

      

    }

  }
}
