using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.Tests.Constants;
using CoilTracking.Tests.IntergrationTest;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using System.Threading.Tasks;
using Xunit;

namespace CoilTracking.Tests.Repository
{
  public class OPCConfigRepositoryTest
  {

    public readonly IUserHelper usersHelper;
    private readonly IHttpContextAccessor httpContextAccessor;
    //Create In Memory Database
    readonly IDatabaseSetup DatabaseFixture;
    public OPCConfigRepositoryTest()
    {
      DatabaseFixture = new DatabaseFixture();
    
    }
    [Fact]
    public void GetCountOfKepServers()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new OPCConfig
      {
        Id = 1,
        Disabled = false,
        InstanceName = "test",
        ServerName = "test"
      };
      context.OPCConfigs.Add(post);
      context.SaveChanges();

        OPCConfigRepository repository = new OPCConfigRepository(context,usersHelper);
        var result = repository.GetCountOfOPCConfigs();
        Assert.Equal(1, 1);

      
    }
    [Fact]
    public void GetOPCConfigById()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new OPCConfig
      {
        Id = 1,
        Disabled = false,
        InstanceName = "test",
        ServerName = "test"
      };
      context.OPCConfigs.Add(post);
      context.SaveChanges();

      OPCConfigRepository repository = new OPCConfigRepository(context,usersHelper);
        var result = repository.GetOPCConfigById(1);
        Assert.NotNull(result);

      
    }
    [Fact]
    public void GetOPCConfigs()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new OPCConfig
      {
        Id = 1,
        Disabled = false,
        InstanceName = "test",
        ServerName = "test"
      };
      context.OPCConfigs.Add(post);
      context.SaveChanges();

      OPCConfigRepository repository = new OPCConfigRepository(context,usersHelper);
        var result = repository.GetOPCConfigsAsync();
        Assert.NotNull(result);

      
    }
    [Fact]
    public void GetOPCConfigByIdExists()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new OPCConfig
      {
        Id = 1,
        Disabled = false,
        InstanceName = "test",
        ServerName = "test"
      };
      context.OPCConfigs.Add(post);
      context.SaveChanges();

      OPCConfigRepository repository = new OPCConfigRepository(context,usersHelper);
        var result = repository.OPCConfigExistsbyId(1);
        Assert.NotNull(result);

      
    }
    [Fact]
    public void DisableOPCConfig()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new OPCConfig
      {
        Id = 1,
        Disabled = false,
        InstanceName = "test",
        ServerName = "test"
      };
      context.OPCConfigs.Add(post);
      context.SaveChanges();

      OPCConfigRepository repository = new OPCConfigRepository(context,usersHelper);
        var result = repository.DisableOPCConfig(1,false);
        Assert.NotNull(result);

      
    }
    [Fact]
    public void InsertOPCConfig()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
        var data = new Data.Models.OPCConfig
        {
          Id = 5,
          ServerName = "test3",
          InstanceName = "tt",
          Disabled = true
        };
      
        OPCConfigRepository repository = new OPCConfigRepository(context,usersHelper);
        var result = repository.InsertOPCConfig(data);
        Assert.NotNull(result);

      
    }

    [Fact]
    public async Task DeleteOPCConfig()
    {
      var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
      var contexts = new DefaultHttpContext();
      var fakeTenantId = "abcd";
      contexts.Request.Headers["Tenant-ID"] = fakeTenantId;
      mockHttpContextAccessor.Setup(_ => _.HttpContext).Returns(contexts);
      //Mock HeaderConfiguration
      var mockHeaderConfiguration = new Mock<IUserHelper>();
      mockHeaderConfiguration
          .Setup(_ => _.GetSubject())
          .Returns(fakeTenantId);
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new OPCConfig
      {
        Id = 100,
        Disabled = false,
        InstanceName = "test1",
        ServerName = "test1"
      };
      context.OPCConfigs.Add(post);
      context.SaveChanges();
      OPCConfigRepository repository = new OPCConfigRepository(context,mockHeaderConfiguration.Object);
       await repository.DeleteOPCConfig(100);
        Assert.True(true);

      
    }

  }
}
