using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Implementation;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace CoilTracking.Tests.Repository
{
  public class IncompleteRunOrderItemsRepositoryTest
  {
    public static CoilTrackingContext context;

    //Create In Memory Database
    public static DbContextOptions<CoilTrackingContext> options = new DbContextOptionsBuilder<CoilTrackingContext>()
    .UseInMemoryDatabase(databaseName: "CoilTrackingDataBase")
    .Options;
    public readonly IHttpContextAccessor httpContextAccessor;
    public readonly IUserHelper userHelper;
    public IncompleteRunOrderItemsRepositoryTest()
    {
      var userHelper = new Mock<IUserHelper>();
      if (context == null)
        using (var context = new CoilTrackingContext(options, httpContextAccessor,userHelper.Object))
        {
          if (context.IncompleteRunOrderItems.CountAsync().Result == 0)
          {
            context.IncompleteRunOrderItems.Add(new IncompleteRunOrderItem
            {
              Id = 1,
            });

            context.SaveChanges();
          }
        }
    }

    [Fact]
    public void GetIncompleteRunOrderItemsByStatus()
    {
      using (var context = new CoilTrackingContext(options, httpContextAccessor, userHelper))
      {
        var repo = new IncompleteRunOrderItemsRepository(context);
        var response = repo.GetIncompleteRunOrderItemsByStatus(RunOrderItemStatus.Completed);
        Assert.NotNull(response);
      }
    }

    [Fact]
    public void GetIncompleteRunOrderItemsById()
    {
      using (var context = new CoilTrackingContext(options, httpContextAccessor, userHelper))
      {
        var repo = new IncompleteRunOrderItemsRepository(context);
        var response = repo.GetIncompleteRunOrderItemsById(1);
        Assert.NotNull(response);
      }
    }

    [Fact]
    public void GetCompletedRunOrderItemsByIdAndStatus()
    {
      var runs = new List<int>();
      using (var context = new CoilTrackingContext(options,httpContextAccessor,userHelper))
      {
        var repo = new IncompleteRunOrderItemsRepository(context);
        var response = repo.GetCompletedRunOrderItemsByIdAndStatus(runs, RunOrderItemStatus.Completed);
        Assert.NotNull(response);
      }
    }

    [Fact]
    public void GetFTZAsync()
    {
      var runs = new List<int>();
      using (var context = new CoilTrackingContext(options, httpContextAccessor, userHelper))
      {
        var repo = new IncompleteRunOrderItemsRepository(context);
        var response = repo.GetFTZAsync(1);
        Assert.NotNull(response);
      }
    }

    [Fact]
    public void GetPrinterConfigAsync()
    {
      var runs = new List<int>();
      using (var context = new CoilTrackingContext(options, httpContextAccessor, userHelper))
      {
        var repo = new IncompleteRunOrderItemsRepository(context);
        var response = repo.GetPrinterConfigAsync("");
        Assert.NotNull(response);
      }
    }

    [Fact]
    public void GetPrinterConfigDto()
    {
      var runs = new List<int>();
      using (var context = new CoilTrackingContext(options, httpContextAccessor, userHelper))
      {
        var repo = new IncompleteRunOrderItemsRepository(context);
        var response = repo.GetPrinterConfigDto("","");
        Assert.NotNull(response);
      }
    }

    [Fact]
    public void IsTagsPrintedfromAutoPrint()
    {
      var runs = new List<int>();
      using (var context = new CoilTrackingContext(options, httpContextAccessor, userHelper))
      {
        var repo = new IncompleteRunOrderItemsRepository(context);
        var response = repo.IsTagsPrintedfromAutoPrint(1);
        Assert.NotNull(response);
      }
    }

    [Fact]
    public void GetMaxBkankPalet()
    {
      var runs = new List<int>();
      using (var context = new CoilTrackingContext(options, httpContextAccessor, userHelper))
      {
        var repo = new IncompleteRunOrderItemsRepository(context);
        var response = repo.GetMaxBkankPalet();
        Assert.NotNull(repo);
      }
    }

    [Fact]
    public void GetSerialNumbers()
    {
      var runs = new List<int>();
      using (var context = new CoilTrackingContext(options, httpContextAccessor, userHelper))
      {
        var repo = new IncompleteRunOrderItemsRepository(context);
        var response = repo.GetSerialNumbers("","","");
        Assert.NotNull(repo);
      }
    }

    [Fact]
    public void AddPallet()
    {
      var pallet = new PalletTag
      {
        NAMCCode = ""
      };
      var runs = new List<int>();
      using (var context = new CoilTrackingContext(options, httpContextAccessor, userHelper))
      {
        var repo = new IncompleteRunOrderItemsRepository(context);
        var response = repo.AddPallet(pallet);
        Assert.NotNull(response);
      }
    }

    [Fact]
    public void IncompleteRunOrderItemsExists()
    {
      var runs = new List<int>();
      using (var context = new CoilTrackingContext(options, httpContextAccessor, userHelper))
      {
        var repo = new IncompleteRunOrderItemsRepository(context);
        var response = repo.IncompleteRunOrderItemsExists(1);
        Assert.NotNull(response);
      }
    }
  }
}
