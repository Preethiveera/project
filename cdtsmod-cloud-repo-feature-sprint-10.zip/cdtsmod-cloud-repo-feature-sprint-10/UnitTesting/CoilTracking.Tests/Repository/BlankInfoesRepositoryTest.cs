using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.Tests.IntergrationTest;
using System.Collections.Generic;
using Xunit;
namespace CoilTracking.Tests.Repository

{
  public class BlankInfoesRepositoryTest : IClassFixture<DatabaseFixture>
  {
    public static CoilTrackingContext context;
    public readonly IUserHelper usersHelper;
    readonly IDatabaseSetup DatabaseFixture;

    public BlankInfoesRepositoryTest()
    {
      DatabaseFixture = new DatabaseFixture();
    }
    [Fact]
    public void GetDatas_ReturnsBlankInfo()
    {

      //Get the instance of DBContext  
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new BlankInfo()
      {
        Id = 1,
        DataNumber = 12,
        CoilType = new CoilType
        {
          Id = 1,
          CoilFieldZone = new CoilFieldZone
          {
            Id = 1,
            Locations = new List<CoilFieldLocation> { new CoilFieldLocation { Id = 1, Name = "test" } }
          }
        },
        Line = new Line { Id = 1, Plant = new Plant { Id = 1, TimeZone = new PlantTimeZone { Id = 1 } }, OPCServer = new OPCConfig { Id = 1 }, },
        Line_Id = 1,
        Part = new Part { Id = 1 }
      };

      //Act    
      context.BlankInfoes.Add(post);
      context.SaveChanges();

      //Assert    
      //Get the post count
      BlankInfoesRepository blankRepo = new BlankInfoesRepository(context, usersHelper);
      var blanks = blankRepo.GetAllBlankInfo();
      Assert.NotNull(blanks);
      context.Database.EnsureDeleted();
      
    }

    [Fact]
    public void BlankInfoes_BlankInfo_ReturnBlankInfoes()
    {
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new BlankInfo()
      {
        Id = 176,
        DataNumber = 12,
        CoilType = new CoilType
        {
          Id = 1,
          CoilFieldZone = new CoilFieldZone
          {
            Id = 1,
            Locations = new List<CoilFieldLocation> { new CoilFieldLocation { Id = 1, Name = "test" } }
          }
        },
        Line = new Line { Id = 1, Plant = new Plant { Id = 1, TimeZone = new PlantTimeZone { Id = 1 } }, OPCServer = new OPCConfig { Id = 1 }, },
        Line_Id = 1,
        Part = new Part { Id = 1 }
      };

      //Act    
      context.BlankInfoes.Add(post);
      context.SaveChanges();


      List<CoilFieldLocation> location = new List<CoilFieldLocation>
        {
          new CoilFieldLocation{Id=1, Name="test"}
        };
      BlankInfoesRepository blankRepo = new BlankInfoesRepository(context,usersHelper);
      var blanks = blankRepo.GetdieNo(location);
      Assert.NotNull(blanks);

    }


    [Fact]
    public void BlankInfoesdieno_dieno_ReturnBlankInfoes()
    {
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new BlankInfo()
      {
        Id = 1,
        DataNumber = 12,
        CoilType = new CoilType
        {
          Id = 1,
          CoilFieldZone = new CoilFieldZone
          {
            Id = 1,
            Locations = new List<CoilFieldLocation> { new CoilFieldLocation { Id = 1, Name = "test" } }
          }
        },
        Line = new Line { Id = 1, Plant = new Plant { Id = 1, TimeZone = new PlantTimeZone { Id = 1 } }, OPCServer = new OPCConfig { Id = 1 }, },
        Line_Id = 1,
        Part = new Part { Id = 1 }
      };

      //Act    
      context.BlankInfoes.Add(post);
      context.SaveChanges();


      List<Coil> coils = new List<Coil>
        {
          new Coil{Id=1, FTZ="test", CoilType = new CoilType{ Id=22 } }
        };
      BlankInfoesRepository blankRepo = new BlankInfoesRepository(context,usersHelper);
      var blanks = blankRepo.GetdieNos(coils);
      Assert.NotNull(blanks);

      
    }


    [Fact]
    public void GetDatas_ReturnsBlankInfos12()
    {
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new BlankInfo()
      {
        Id = 1,
        DataNumber = 12,
        CoilType = new CoilType
        {
          Id = 1,
          CoilFieldZone = new CoilFieldZone
          {
            Id = 1,
            Locations = new List<CoilFieldLocation> { new CoilFieldLocation { Id = 1, Name = "test" } }
          }
        },
        Line = new Line { Id = 1, Plant = new Plant { Id = 1, TimeZone = new PlantTimeZone { Id = 1 } }, OPCServer = new OPCConfig { Id = 1 }, },
        Line_Id = 1,
        Part = new Part { Id = 1 }
      };

      //Act    
      context.BlankInfoes.Add(post);
      context.SaveChanges();


      BlankInfoesRepository blankRepo = new BlankInfoesRepository(context,usersHelper);
      var blanks = blankRepo.GetAllBlankInfo();
      Assert.NotNull(blanks);
      

    }
    [Fact]
    public void GetBlankInfoById_ReturnsBlankInfo()
    {
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new BlankInfo()
      {
        Id = 1,
        DataNumber = 12,
        CoilType = new CoilType
        {
          Id = 1,
          CoilFieldZone = new CoilFieldZone
          {
            Id = 1,
            Locations = new List<CoilFieldLocation> { new CoilFieldLocation { Id = 1, Name = "test" } }
          }
        },
        Line = new Line { Id = 1, Plant = new Plant { Id = 1, TimeZone = new PlantTimeZone { Id = 1 } }, OPCServer = new OPCConfig { Id = 1 }, },
        Line_Id = 1,
        Part = new Part { Id = 1 }
      };

      //Act    
      context.BlankInfoes.Add(post);
      context.SaveChanges();


      BlankInfoesRepository blankRepo = new BlankInfoesRepository(context,usersHelper);
      blankRepo.GetBlankInfoById(1);
      Assert.NotNull(blankRepo);
      

    }


    [Fact]
    public void GetCurrentStackSize_ReturnsBlankInfo()
    {
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new BlankInfo()
      {
        Id = 1,
        DataNumber = 12,
        CoilType = new CoilType
        {
          Id = 1,
          CoilFieldZone = new CoilFieldZone
          {
            Id = 1,
            Locations = new List<CoilFieldLocation> { new CoilFieldLocation { Id = 1, Name = "test" } }
          }
        },
        Line = new Line { Id = 1, Plant = new Plant { Id = 1, TimeZone = new PlantTimeZone { Id = 1 } }, OPCServer = new OPCConfig { Id = 1 }, },
        Line_Id = 1,
        Part = new Part { Id = 1 }
      };

      //Act    
      context.BlankInfoes.Add(post);
      context.SaveChanges();


      BlankInfoesRepository blankRepo = new BlankInfoesRepository(context, usersHelper);
      blankRepo.GetCurrentStackSize(12);
      Assert.NotNull(blankRepo);


    }

    [Fact]
    public void GetListWithPlantsAndTimeZones_ReturnsBlankInfo()
    {
      List<int> id = new List<int>();
      {
        id.Add(1);
      }
      int lineid = 1;
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new BlankInfo()
      {
        Id = 1,
        DataNumber = 12,
        CoilType = new CoilType
        {
          Id = 1,
          CoilFieldZone = new CoilFieldZone
          {
            Id = 1,
            Locations = new List<CoilFieldLocation> { new CoilFieldLocation { Id = 1, Name = "test" } }
          }
        },
        Line = new Line { Id = 1, Plant = new Plant { Id = 1, TimeZone = new PlantTimeZone { Id = 1 } }, OPCServer = new OPCConfig { Id = 1 }, },
        Line_Id = 1,
        Part = new Part { Id = 1 }
      };

      //Act    
      context.BlankInfoes.Add(post);
      context.SaveChanges();


      BlankInfoesRepository blankRepo = new BlankInfoesRepository(context, usersHelper);
      blankRepo.GetListWithPlantsAndTimeZones(id,lineid);
      Assert.NotNull(blankRepo);


    }

    [Fact]
    public void GetBlankInfoByPartnumberLineIds_ReturnsBlankInfo()
    {
      string id = "test";
      int lineid = 1;
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new BlankInfo()
      {
        Id = 1,
        DataNumber = 12,
        CoilType = new CoilType
        {
          Id = 1,
          CoilFieldZone = new CoilFieldZone
          {
            Id = 1,
            Locations = new List<CoilFieldLocation> { new CoilFieldLocation { Id = 1, Name = "test" } }
          }
        },
        Line = new Line { Id = 1, Plant = new Plant { Id = 1, TimeZone = new PlantTimeZone { Id = 1 } }, OPCServer = new OPCConfig { Id = 1 }, },
        Line_Id = 1,
        Part = new Part { Id = 1 }
      };

      //Act    
      context.BlankInfoes.Add(post);
      context.SaveChanges();


      BlankInfoesRepository blankRepo = new BlankInfoesRepository(context, usersHelper);
      blankRepo.GetBlankInfoByPartnumberLineIds(id, lineid);
      Assert.NotNull(blankRepo);


    }


    [Fact]
    public void GetListByPartnumberLineIds_ReturnsBlankInfo()
    {
      List<string> id = new List<string>();
      int lineid = 1;
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new BlankInfo()
      {
        Id = 1,
        DataNumber = 12,
        CoilType = new CoilType
        {
          Id = 1,
          CoilFieldZone = new CoilFieldZone
          {
            Id = 1,
            Locations = new List<CoilFieldLocation> { new CoilFieldLocation { Id = 1, Name = "test" } }
          }
        },
        Line = new Line { Id = 1, Plant = new Plant { Id = 1, TimeZone = new PlantTimeZone { Id = 1 } }, OPCServer = new OPCConfig { Id = 1 }, },
        Line_Id = 1,
        Part = new Part { Id = 1 }
      };

      //Act    
      context.BlankInfoes.Add(post);
      context.SaveChanges();


      BlankInfoesRepository blankRepo = new BlankInfoesRepository(context, usersHelper);
      blankRepo.GetListByPartnumberLineIds(id, lineid);
      Assert.NotNull(blankRepo);


    }


    [Fact]
    public void GetListWithPlantTimeZonePart_ReturnsBlankInfo()
    {
      List<string> id = new List<string>();
      int lineid = 1;
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new BlankInfo()
      {
        Id = 1,
        DataNumber = 12,
        CoilType = new CoilType
        {
          Id = 1,
          CoilFieldZone = new CoilFieldZone
          {
            Id = 1,
            Locations = new List<CoilFieldLocation> { new CoilFieldLocation { Id = 1, Name = "test" } }
          }
        },
        Line = new Line { Id = 1, Plant = new Plant { Id = 1, TimeZone = new PlantTimeZone { Id = 1 } }, OPCServer = new OPCConfig { Id = 1 }, },
        Line_Id = 1,
        Part = new Part { Id = 1 }
      };

      //Act    
      context.BlankInfoes.Add(post);
      context.SaveChanges();


      BlankInfoesRepository blankRepo = new BlankInfoesRepository(context, usersHelper);
     var r =  blankRepo.GetListWithPlantTimeZonePart(id, lineid);
      Assert.NotNull(r);


    }

    [Fact]
    public void GetBlankInfoByLineIdAndPartNumber_ReturnsBlankInfo()
    {
      List<string> id = new List<string>();
      int lineid = 1;
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new BlankInfo()
      {
        Id = 1,
        DataNumber = 12,
        CoilType = new CoilType
        {
          Id = 1,
          CoilFieldZone = new CoilFieldZone
          {
            Id = 1,
            Locations = new List<CoilFieldLocation> { new CoilFieldLocation { Id = 1, Name = "test" } }
          }
        },
        Line = new Line { Id = 1, Plant = new Plant { Id = 1, TimeZone = new PlantTimeZone { Id = 1 } }, OPCServer = new OPCConfig { Id = 1 }, },
        Line_Id = 1,
        Part = new Part { Id = 1 }
      };

      //Act    
      context.BlankInfoes.Add(post);
      context.SaveChanges();


      BlankInfoesRepository blankRepo = new BlankInfoesRepository(context, usersHelper);
      var r = blankRepo.GetBlankInfoByLineIdAndPartNumber(lineid,id);
      Assert.NotNull(r);


    }



    [Fact]
    public void GetBlanksByDataIdLists_ReturnsBlankInfo()
    {
      List<int> id = new List<int>();
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new BlankInfo()
      {
        Id = 1,
        DataNumber = 12,
        CoilType = new CoilType
        {
          Id = 1,
          CoilFieldZone = new CoilFieldZone
          {
            Id = 1,
            Locations = new List<CoilFieldLocation> { new CoilFieldLocation { Id = 1, Name = "test" } }
          }
        },
        Line = new Line { Id = 1, Plant = new Plant { Id = 1, TimeZone = new PlantTimeZone { Id = 1 } }, OPCServer = new OPCConfig { Id = 1 }, },
        Line_Id = 1,
        Part = new Part { Id = 1 }
      };

      //Act    
      context.BlankInfoes.Add(post);
      context.SaveChanges();


      BlankInfoesRepository blankRepo = new BlankInfoesRepository(context, usersHelper);
      blankRepo.GetBlanksByDataIdList(id);
      Assert.NotNull(blankRepo);


    }

    [Fact]
    public void GetBlankInfoByDataNumber_ReturnsBlankInfo()
    {
      List<int> id = new List<int>();
      {
        id.Add(1);
      }
      int lineid = 1;
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new BlankInfo()
      {
        Id = 1,
        DataNumber = 12,
        CoilType = new CoilType
        {
          Id = 1,
          CoilFieldZone = new CoilFieldZone
          {
            Id = 1,
            Locations = new List<CoilFieldLocation> { new CoilFieldLocation { Id = 1, Name = "test" } }
          }
        },
        Line = new Line { Id = 1, Plant = new Plant { Id = 1, TimeZone = new PlantTimeZone { Id = 1 } }, OPCServer = new OPCConfig { Id = 1 }, },
        Line_Id = 1,
        Part = new Part { Id = 1 }
      };

      //Act    
      context.BlankInfoes.Add(post);
      context.SaveChanges();


      BlankInfoesRepository blankRepo = new BlankInfoesRepository(context, usersHelper);
      blankRepo.GetBlankInfoByDataNumber(lineid);
      Assert.NotNull(blankRepo);


    }

    [Fact]
    public void GetBlanksByDataIdList_ReturnsBlankInfo()
    {
      List<int> id = new List<int>();
      {
        id.Add(1);
      }
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new BlankInfo()
      {
        Id = 1,
        DataNumber = 12,
        CoilType = new CoilType
        {
          Id = 1,
          CoilFieldZone = new CoilFieldZone
          {
            Id = 1,
            Locations = new List<CoilFieldLocation> { new CoilFieldLocation { Id = 1, Name = "test" } }
          }
        },
        Line = new Line { Id = 1, Plant = new Plant { Id = 1, TimeZone = new PlantTimeZone { Id = 1 } }, OPCServer = new OPCConfig { Id = 1 }, },
        Line_Id = 1,
        Part = new Part { Id = 1 }
      };

      //Act    
      context.BlankInfoes.Add(post);
      context.SaveChanges();


      BlankInfoesRepository blankRepo = new BlankInfoesRepository(context, usersHelper);
      blankRepo.GetBlanksByDataIdList(id);
      Assert.NotNull(blankRepo);


    }


    [Fact]
    public void GetBlankInfoByPartId_ReturnsBlankInfo()
    {
      int id = 1;
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new BlankInfo()
      {
        Id = 1,
        DataNumber = 12,
        CoilType = new CoilType
        {
          Id = 1,
          CoilFieldZone = new CoilFieldZone
          {
            Id = 1,
            Locations = new List<CoilFieldLocation> { new CoilFieldLocation { Id = 1, Name = "test" } }
          }
        },
        Line = new Line { Id = 1, Plant = new Plant { Id = 1, TimeZone = new PlantTimeZone { Id = 1 } }, OPCServer = new OPCConfig { Id = 1 }, },
        Line_Id = 1,
        Part = new Part { Id = 1 }
      };

      //Act    
      context.BlankInfoes.Add(post);
      context.SaveChanges();


      BlankInfoesRepository blankRepo = new BlankInfoesRepository(context, usersHelper);
      blankRepo.GetBlankInfoByPartId(id);
      Assert.NotNull(blankRepo);


    }


    [Fact]
    public void GetBlankInfoByDataNumbers_ReturnsBlankInfo()
    {
      List<int> id = new List<int>();
      {
        id.Add(1);
      }
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new BlankInfo()
      {
        Id = 1,
        DataNumber = 12,
        CoilType = new CoilType
        {
          Id = 1,
          CoilFieldZone = new CoilFieldZone
          {
            Id = 1,
            Locations = new List<CoilFieldLocation> { new CoilFieldLocation { Id = 1, Name = "test" } }
          }
        },
        Line = new Line { Id = 1, Plant = new Plant { Id = 1, TimeZone = new PlantTimeZone { Id = 1 } }, OPCServer = new OPCConfig { Id = 1 }, },
        Line_Id = 1,
        Part = new Part { Id = 1 }
      };

      //Act    
      context.BlankInfoes.Add(post);
      context.SaveChanges();


      BlankInfoesRepository blankRepo = new BlankInfoesRepository(context, usersHelper);
     var r = blankRepo.GetBlankInfoByDataNumbers(id);
      Assert.NotNull(r);


    }

    [Fact]
    public void GetBlankInfoByListOfDataNumAndLineId_ReturnsBlankInfo()
    {
      List<int> id = new List<int>();
      {
        id.Add(1);
      }
      int lineid = 1;
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new BlankInfo()
      {
        Id = 1,
        DataNumber = 12,
        CoilType = new CoilType
        {
          Id = 1,
          CoilFieldZone = new CoilFieldZone
          {
            Id = 1,
            Locations = new List<CoilFieldLocation> { new CoilFieldLocation { Id = 1, Name = "test" } }
          }
        },
        Line = new Line { Id = 1, Plant = new Plant { Id = 1, TimeZone = new PlantTimeZone { Id = 1 } }, OPCServer = new OPCConfig { Id = 1 }, },
        Line_Id = 1,
        Part = new Part { Id = 1 }
      };

      //Act    
      context.BlankInfoes.Add(post);
      context.SaveChanges();


      BlankInfoesRepository blankRepo = new BlankInfoesRepository(context, usersHelper);
      blankRepo.GetBlankInfoByListOfDataNumAndLineId(id,lineid);
      Assert.NotNull(blankRepo);


    }

    [Fact]
    public void GetBlankInfoByDataNumAndId_ReturnsBlankInfo()
    {
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new BlankInfo()
      {
        Id = 1,
        DataNumber = 12,
        CoilType = new CoilType
        {
          Id = 1,
          CoilFieldZone = new CoilFieldZone
          {
            Id = 1,
            Locations = new List<CoilFieldLocation> { new CoilFieldLocation { Id = 1, Name = "test" } }
          }
        },
        Line = new Line { Id = 1, Plant = new Plant { Id = 1, TimeZone = new PlantTimeZone { Id = 1 } }, OPCServer = new OPCConfig { Id = 1 }, },
        Line_Id = 1,
        Part = new Part { Id = 1 }
      };

      //Act    
      context.BlankInfoes.Add(post);
      context.SaveChanges();


      BlankInfoesRepository blankRepo = new BlankInfoesRepository(context,usersHelper);
      var blanks = blankRepo.GetBlankInforByDataNumAndLineId(12, 1);
      Assert.NotNull(blankRepo);
      context.Database.EnsureDeleted();

    }

    [Fact]
    public void GetDependencyForBlankInfo_ReturnsTrue()
    {
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new BlankInfo()
      {
        Id = 1,
        DataNumber = 12,
        CoilType = new CoilType
        {
          Id = 1,
          CoilFieldZone = new CoilFieldZone
          {
            Id = 1,
            Locations = new List<CoilFieldLocation> { new CoilFieldLocation { Id = 1, Name = "test" } }
          }
        },
        Line = new Line { Id = 1, Plant = new Plant { Id = 1, TimeZone = new PlantTimeZone { Id = 1 } }, OPCServer = new OPCConfig { Id = 1 }, },
        Line_Id = 1,
        Part = new Part { Id = 1 }
      };

      //Act    
      context.BlankInfoes.Add(post);
      context.SaveChanges();


      BlankInfoesRepository blankRepo = new BlankInfoesRepository(context,usersHelper);
      var blanks = blankRepo.GetDependencyForBlankInfo(101);
      Assert.NotNull(blanks);
     

    }

    [Fact]
    public void GetDependencyForBlankInfo_ReturnsFalse()
    {
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new BlankInfo()
      {
        Id = 1,
        DataNumber = 12,
        CoilType = new CoilType
        {
          Id = 1,
          CoilFieldZone = new CoilFieldZone
          {
            Id = 1,
            Locations = new List<CoilFieldLocation> { new CoilFieldLocation { Id = 1, Name = "test" } }
          }
        },
        Line = new Line { Id = 1, Plant = new Plant { Id = 1, TimeZone = new PlantTimeZone { Id = 1 } }, OPCServer = new OPCConfig { Id = 1 }, },
        Line_Id = 1,
        Part = new Part { Id = 1 }
      };

      //Act    
      context.BlankInfoes.Add(post);
      //context.SaveChanges();
      BlankInfoesRepository blankRepo = new BlankInfoesRepository(context,usersHelper);
      blankRepo.GetDependencyForBlankInfo(100);
      Assert.NotNull(blankRepo);

     
    }

  }

}



