using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.DTO;
using CoilTracking.Tests.Constants;
using CoilTracking.Tests.IntergrationTest;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace CoilTracking.Tests.Repository
{
  public class CoilTypeRepositoryTest
  {
    public readonly IUserHelper usersHelper;
    readonly IDatabaseSetup DatabaseFixture;

    public CoilTypeRepositoryTest()
    {

      DatabaseFixture = new DatabaseFixture();
    }



    [Fact]
    public void GetCoilTypeById_Returns_CoilType()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilType()
      {
        Id = 8,
        Name = "3-1-T",
        Width = 1380,
        Thickness = decimal.Parse("0.70"),
        Spec = "SCGA270D 45V",
        NumCoils = 1,
        Disabled = false,
        Yield = 0,
        MinThickness = 0,
        MaxThickness = 0,
        MinWidth = 0,
        MaxWidth = 0
      };
      //Act    
      context.CoilTypes.Add(post);
      context.SaveChanges();

      CoilTypeRepository coilTypeRepo = new CoilTypeRepository(context,usersHelper);
      var coilType = coilTypeRepo.GetCoilTypeById(8);
      Assert.NotNull(coilType);
    }
    [Fact]
    public void GetCoilTypeByName_Returns_CoilType()
    {
      string name = "3-1-T";
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilType()
      {
        Id = 8,
        Name = "3-1-T",
        Width = 1380,
        Thickness = decimal.Parse("0.70"),
        Spec = "SCGA270D 45V",
        NumCoils = 1,
        Disabled = false,
        Yield = 0,
        MinThickness = 0,
        MaxThickness = 0,
        MinWidth = 0,
        MaxWidth = 0
      };
      //Act    
      context.CoilTypes.Add(post);
      context.SaveChanges();
      CoilTypeRepository coilTypeRepo = new CoilTypeRepository(context,usersHelper);

      coilTypeRepo.GetCoilTypeByName(name);

      Assert.NotNull(name);
      context.Database.EnsureDeleted();
    }
    [Fact]
    public void GetCoilTypes_Returns_CoilType()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilType()
      {
        Id = 8,
        Name = "3-1-T",
        Width = 1380,
        Thickness = decimal.Parse("0.70"),
        Spec = "SCGA270D 45V",
        NumCoils = 1,
        Disabled = false,
        Yield = 0,
        MinThickness = 0,
        MaxThickness = 0,
        MinWidth = 0,
        MaxWidth = 0
      };
      //Act    
      context.CoilTypes.Add(post);
      context.SaveChanges();
      CoilTypeRepository coilTypeRepo = new CoilTypeRepository(context,usersHelper);
      var coilTypes = coilTypeRepo.GetCoilTypes();

      Assert.NotNull(coilTypes);


    }


    [Fact]
    public void GetCoilTypesWithAllPartNums_Returns_CoilType()
    {
      var context = DatabaseFixture.GetDatabaseFixture();

      List<CoilTypePartModel> coilTypePartModels = new List<CoilTypePartModel>();
      {
        coilTypePartModels.Add(new CoilTypePartModel() { CoilTypeId = 4, Models = "FS", PartNumber = "RR", Parts = new Part() { Id = 2, PartName = "test", Disabled = true, PartNumber = "433", StrokeCount = 1 } });
      }
      var post = new CoilType()
      {
        Id = 8,
        Name = "3-1-T",
        Width = 1380,
        Thickness = decimal.Parse("0.70"),
        Spec = "SCGA270D 45V",
        NumCoils = 1,
        Disabled = false,
        Yield = 0,
        MinThickness = 0,
        MaxThickness = 0,
        MinWidth = 0,
        MaxWidth = 0
      };
      //Act    
      context.CoilTypes.Add(post);
      context.SaveChanges();
      CoilTypeRepository coilTypeRepo = new CoilTypeRepository(context, usersHelper);
      var coilTypes = coilTypeRepo.GetCoilTypesWithAllPartNums();

      Assert.NotNull(coilTypes);


    }



    [Fact]
    public void GetCoilTypes_CoilTypes_ReturnsCoilTypes()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilType()
      {
        Id = 8,
        Name = "3-1-T",
        Width = 1380,
        Thickness = decimal.Parse("0.70"),
        Spec = "SCGA270D 45V",
        NumCoils = 1,
        Disabled = false,
        Yield = 0,
        MinThickness = 0,
        MaxThickness = 0,
        MinWidth = 0,
        MaxWidth = 0
      };
      //Act    
      context.CoilTypes.Add(post);
      context.SaveChanges();
      CoilTypeRepository coilTypeRepo = new CoilTypeRepository(context,usersHelper);
      var coilTypes = coilTypeRepo.GetCoilTypes();

      Assert.NotNull(coilTypes);

    }


    [Fact]
    public void GetMaterialCoilType_CoilType__Returns_CoilType()
    {
      int id = 8;
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilType()
      {
        Id = 8,
        Name = "3-1-T",
        Width = 1380,
        Thickness = decimal.Parse("0.70"),
        Spec = "SCGA270D 45V",
        NumCoils = 1,
        Disabled = false,
        Yield = 0,
        MinThickness = 0,
        MaxThickness = 0,
        MinWidth = 0,
        MaxWidth = 0
      };
      //Act    
      context.CoilTypes.Add(post);
      context.SaveChanges();
      CoilTypeRepository coilTypeRepo = new CoilTypeRepository(context,usersHelper);
      var coilTypes = coilTypeRepo.GetMaterialCoilTypeById(id);

      Assert.NotNull(coilTypes);

    }
    [Fact]
    public void GetMaterialCoilTypes_returns_CoilType()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilType()
      {
        Id = 8,
        Name = "3-1-T",
        Width = 1380,
        Thickness = decimal.Parse("0.70"),
        Spec = "SCGA270D 45V",
        NumCoils = 1,
        Disabled = false,
        Yield = 0,
        MinThickness = 0,
        MaxThickness = 0,
        MinWidth = 0,
        MaxWidth = 0
      };
      //Act    
      context.CoilTypes.Add(post);
      context.SaveChanges();
      CoilTypeRepository coilTypeRepo = new CoilTypeRepository(context,usersHelper);
      var coilTypes = coilTypeRepo.GetMaterialCoilTypes();

      Assert.NotNull(coilTypes);

    }
    [Fact]
    public void GetoriginalCoilTypeById_ReturnsCoilTypes()
    {
      CoilTypeDto coilTypeDto = new CoilTypeDto()
      {
        Id = 8,
        Name = "3-1-T",
        Width = 1380,
        Thickness = decimal.Parse("0.70"),
        Spec = "SCGA270D 45V",
        NumCoils = 1,
        Disabled = false,
        Yield = 0,
        MinThickness = 0,
        MaxThickness = 0,
        MinWidth = 0,
        MaxWidth = 0
      };
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilType()
      {
        Id = 8,
        Name = "3-1-T",
        Width = 1380,
        Thickness = decimal.Parse("0.70"),
        Spec = "SCGA270D 45V",
        NumCoils = 1,
        Disabled = false,
        Yield = 0,
        MinThickness = 0,
        MaxThickness = 0,
        MinWidth = 0,
        MaxWidth = 0
      };
      //Act    
      context.CoilTypes.Add(post);
      context.SaveChanges();
      CoilTypeRepository coilTypeRepo = new CoilTypeRepository(context,usersHelper);
      coilTypeRepo.GetoriginalCoilTypeById(coilTypeDto);

      Assert.NotNull(coilTypeRepo);
      context.Database.EnsureDeleted();
    }

    [Fact]
    public void IsCoilTypeByName_Returns_CoilType()
    {
      string Name = "3-1-T";
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilType()
      {
        Id = 8,
        Name = "3-1-T",
        Width = 1380,
        Thickness = decimal.Parse("0.70"),
        Spec = "SCGA270D 45V",
        NumCoils = 1,
        Disabled = false,
        Yield = 0,
        MinThickness = 0,
        MaxThickness = 0,
        MinWidth = 0,
        MaxWidth = 0
      };
      //Act    
      context.CoilTypes.Add(post);
      context.SaveChanges();
      CoilTypeRepository coilTypeRepo = new CoilTypeRepository(context,usersHelper);
      coilTypeRepo.IsCoilTypeByName(Name);

      Assert.False(false);

    }


    [Fact]
    public async Task GetAssociatedItemsByCoilFieldZone_RetunsCoilType()
    {

      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilType()
      {
        Id = 9,
        Name = "test",
        NumCoils = 9,
        CoilTypeYNAs = new List<CoilTypeYNA> { new CoilTypeYNA() { Id = 1, YNA = "YNA0011171", CoilType = new CoilType() { }, MaterialType = new MaterialType() { Name = "YAS" } } },
        CoilFieldZone = new CoilFieldZone()
        {
          Id = 2,
          CoilField = new CoilField()
          {
            Id = 2,
            Disabled = true,
            Name = "A",
            Zones = new List<CoilFieldZone>() { new CoilFieldZone { Id = 1 } }
          }
        }
      };
      //Act    
      var data = context.CoilTypes.Add(post);
      context.SaveChanges();

      CoilTypeRepository coilTypeRepo = new CoilTypeRepository(context,usersHelper);
      var result = coilTypeRepo.GetAssociatedItemsByCoilFieldZone(1);

      Assert.NotNull(result);

    }
  }
}
