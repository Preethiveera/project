using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.Tests.Constants;
using CoilTracking.Tests.IntergrationTest;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using Xunit;

namespace CoilTracking.Tests.Repository
{
  public class RunOrderListQuantityRepositoryTest
  {
    readonly IDatabaseSetup DatabaseFixture;
    public readonly IUserHelper usersHelper;
    public RunOrderListQuantityRepositoryTest()
    {
      DatabaseFixture = new DatabaseFixture();

    }
    [Fact]
    public void GetRunOrderListQuantities_ReturnsRunOrderListQuantity()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new RunOrderListQuantity
      {

        Id = 3,
        BlankInfo = new BlankInfo() { CoilType = new CoilType() { Id = 1, Name = "A1" }, Id = 1, DataNumber = 1, DieNo = 6, Disabled = true },
        Incomplete = true,
        OverrideQty = 1,
        Quantity = 1,
        Part = new Part() { Id = 1 },
        RunOrderList = new RunOrderList() { Id = 5 },
        SortOrder = 1



      };

      context.RunOrderListQuantities.Add(post);
      context.SaveChanges();


      RunOrderListQuantityRepository repository = new RunOrderListQuantityRepository(context,usersHelper);
        var result = repository.GetRunOrderListQuantities();
        Assert.NotNull(result);

      

    }
    [Fact]
    public void GetRunOrderListQuantityById_ReturnsRunOrderListQuantity()
    {
      int id = 8;
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new RunOrderListQuantity
      {

        Id = 3,
        BlankInfo = new BlankInfo() { CoilType = new CoilType() { Id = 1, Name = "A1" }, Id = 1, DataNumber = 1, DieNo = 6, Disabled = true },
        Incomplete = true,
        OverrideQty = 1,
        Quantity = 1,
        Part = new Part() { Id = 1 },
        RunOrderList = new RunOrderList() { Id = 5 },
        SortOrder = 1



      };

      context.RunOrderListQuantities.Add(post);
      context.SaveChanges();

      var repo = new RunOrderListQuantityRepository(context,usersHelper);
        var response = repo.GetRunOrderListQuantityById(id);
        Assert.NotNull(repo);
      
    }
    //[Fact]
    //public void InsertRunOrderListQuantity_ReturnsRunOrderListQuantity()
    //{


    //  var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
    //  var context = new DefaultHttpContext();
    //  var fakeTenantId = "abcd";
    //  context.Request.Headers["Tenant-ID"] = fakeTenantId;
    //  mockHttpContextAccessor.Setup(_ => _.HttpContext).Returns(context);
    //  //Mock HeaderConfiguration
    //  var mockHeaderConfiguration = new Mock<IUserHelper>();
    //  mockHeaderConfiguration
    //      .Setup(_ => _.GetSubject())
    //      .Returns(fakeTenantId);
    //  var runorderlist = new RunOrderListQuantity()
    //  {
    //    Id = 12,
    //    BlankInfo = new BlankInfo() { CoilType = new CoilType() { Name = "A1", Spec = "7326" }, Part = new Part() { PartName = "test", PartNumber = "74" }, DataNumber = 1, Line_Id = 9, DieNo = 6, Disabled = true },
    //    Incomplete = true,
    //    OverrideQty = 1,
    //    Quantity = 1,
    //    Part = new Part() { PartName = "vishwas", PartNumber = "74" },
    //    RunOrderList = new RunOrderList() { Shift = new Shift() { Name = "me" }, Line = new Line() { LineName = "vish", Plant_Id = 4, LinePath = "test", Tags = "tags", OPCServer_Id = 9, OPCServer = new OPCConfig() { InstanceName = "test", ServerName = "t" } } },
    //    SortOrder = 1
    //  };
    //  var contexts = DatabaseFixture.GetDatabaseFixture();
    //    var repo = new RunOrderListQuantityRepository(contexts, mockHeaderConfiguration.Object);
    //    repo.InsertRunOrderListQuantity(runorderlist);
    //    Assert.True(true);
      
    //}
    [Fact]
    public void IsRunOrderListQuantityExists_ReturnsRunOrderListQuantity()
    {
      int id = 3;
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new RunOrderListQuantity
      {

        Id = 3,
        BlankInfo = new BlankInfo() { CoilType = new CoilType() { Id = 1, Name = "A1" }, Id = 1, DataNumber = 1, DieNo = 6, Disabled = true },
        Incomplete = true,
        OverrideQty = 1,
        Quantity = 1,
        Part = new Part() { Id = 1 },
        RunOrderList = new RunOrderList() { Id = 5 },
        SortOrder = 1



      };

      context.RunOrderListQuantities.Add(post);
      context.SaveChanges();

      var repo = new RunOrderListQuantityRepository(context,usersHelper);
         repo.IsRunOrderListQuantityExists(id);
        Assert.True(true);
      
    }
    [Fact]
    public void ModifyRunOrderListQuantity_ReturnsRunOrderListQuantity()
    {
      var runorderlist = new RunOrderListQuantity()
      {
        Id = 3,
        BlankInfo = new BlankInfo() { CoilType = new CoilType() { Name = "A1" }, Id = 1, DataNumber = 1, DieNo = 6, Disabled = true },
        Incomplete = true,
        OverrideQty = 1,
        Quantity = 1,
        Part = new Part() { },
        RunOrderList = new RunOrderList() { },
        SortOrder = 1
      };
      var context = DatabaseFixture.GetDatabaseFixture();
      context.RunOrderListQuantities.Add(runorderlist);
      context.SaveChanges();
        var repo = new RunOrderListQuantityRepository(context,usersHelper);
        repo.ModifyRunOrderListQuantity(runorderlist);
        Assert.True(true);
      
    }
    [Fact]
    public void RunOrderListQuantitySaveChanges_SaveChanges()
    {
      var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
      var context = new DefaultHttpContext();
      var fakeTenantId = "abcd";
      context.Request.Headers["Tenant-ID"] = fakeTenantId;
      mockHttpContextAccessor.Setup(_ => _.HttpContext).Returns(context);
      //Mock HeaderConfiguration
      var mockHeaderConfiguration = new Mock<IUserHelper>();
      mockHeaderConfiguration
          .Setup(_ => _.GetSubject())
          .Returns(fakeTenantId);
      var contexts = DatabaseFixture.GetDatabaseFixture();

      var repo = new RunOrderListQuantityRepository(contexts, mockHeaderConfiguration.Object);
        repo.RunOrderListQuantitySaveChanges();
        Assert.True(true);
      
    }
  }
}
