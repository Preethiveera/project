using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.Tests.Constants;
using CoilTracking.Tests.IntergrationTest;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace CoilTracking.Tests.Repository
{
  public class CoilRepositoryTest
  {
    public readonly Mock<IUserHelper> usersHelper;
    readonly IDatabaseSetup DatabaseFixture;
    public CoilRepositoryTest()
    {
      usersHelper = new Mock<IUserHelper>();
      DatabaseFixture = new DatabaseFixture();
    }
    /// <summary>
    /// 
    /// </summary>
    [Fact]
    public void GetCoilsFeildsByZoneId_RetunsCoils()
    {
      int Zoneid = 1;
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation()
        {
          Id = 7,
          Name = "white",
          Column = 9,
          Zone = new CoilFieldZone
          {
            Id = 1,
            Disabled = true,
            Name = "test",
            Color = "red",
            TextColor = "black",
            CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() }
          }
        }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context,usersHelper.Object);
      var response = repo.GetCoilsFeildsByZoneId(Zoneid);
      Assert.NotNull(response);

    }

    [Fact]
    public void GetCoilsList_RetunsCoils()
    {
      List<int> id = new List<int>();
      {
        id.Add(1);
        id.Add(22);
      }
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation()
        {
          Id = 7,
          Name = "white",
          Column = 9,
          Zone = new CoilFieldZone
          {
            Id = 1,
            Disabled = true,
            Name = "test",
            Color = "red",
            TextColor = "black",
            CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() }
          }
        }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context, usersHelper.Object);
      var response = repo.GetCoilsList(id);
      Assert.NotNull(response);

    }


    [Fact]
    public void GetCoilTypeByBlanks_RetunsCoils()
    {
      var blankInfo = new List<BlankInfo>
            {
           new BlankInfo()
          {
            Id =1,
            Line=new Line(){ Id=1},
            MaxPitch = 12,
            MaxWidth = 22,
            MinPitch = 11,
           Part = new Part(){Id=1 },
            Pitch = 12,
            StackSize =345,
            Weight = 1234,
            Width = 123,
            Disabled = false,
            DieNo = 2,
            DataNumber = 1,
           CoilType = new CoilType() { Id = 1, Name = "test" },
            RewindWeight = 10,

           }
            };
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation()
        {
          Id = 7,
          Name = "white",
          Column = 9,
          Zone = new CoilFieldZone
          {
            Id = 1,
            Disabled = true,
            Name = "test",
            Color = "red",
            TextColor = "black",
            CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() }
          }
        }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context, usersHelper.Object);
      var response = repo.GetCoilTypeByBlanks(blankInfo);
      Assert.NotNull(response);

    }


    [Fact]
    public void GetCoilsByMillId_RetunsCoils()
    {
      int id = 22;
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation()
        {
          Id = 7,
          Name = "white",
          Column = 9,
          Zone = new CoilFieldZone
          {
            Id = 1,
            Disabled = true,
            Name = "test",
            Color = "red",
            TextColor = "black",
            CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() }
          }
        }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context, usersHelper.Object);
      var response = repo.GetCoilsByMillId(id);
      Assert.NotNull(response);

    }

    [Fact]
    public void GetCoilsByCoilField_RetunsCoils()
    {
      int id = 22;
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation()
        {
          Id = 7,
          Name = "white",
          Column = 9,
          Zone = new CoilFieldZone
          {
            Id = 1,
            Disabled = true,
            Name = "test",
            Color = "red",
            TextColor = "black",
            CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() }
          }
        }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context, usersHelper.Object);
      var response = repo.GetCoilsByCoilField(id);
      Assert.NotNull(response);

    }

    [Fact]
    public void GetCoilsByCoilTypeId_RetunsCoils()
    {
      int id = 22;
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation()
        {
          Id = 7,
          Name = "white",
          Column = 9,
          Zone = new CoilFieldZone
          {
            Id = 1,
            Disabled = true,
            Name = "test",
            Color = "red",
            TextColor = "black",
            CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() }
          }
        }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context, usersHelper.Object);
      var response = repo.GetCoilsByCoilTypeId(id);
      Assert.NotNull(response);

    }

    [Fact]
    public void GetCoilsLoadedById_RetunsCoils()
    {
      int id = 22;
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation()
        {
          Id = 7,
          Name = "white",
          Column = 9,
          Zone = new CoilFieldZone
          {
            Id = 1,
            Disabled = true,
            Name = "test",
            Color = "red",
            TextColor = "black",
            CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() }
          }
        }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context, usersHelper.Object);
      var response = repo.GetCoilsLoadedById(id);
      Assert.NotNull(response);

    }


    [Fact]
    public void GetCoilWithCoilField_RetunsCoils()
    {
      int id = 22;
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation()
        {
          Id = 7,
          Name = "white",
          Column = 9,
          Zone = new CoilFieldZone
          {
            Id = 1,
            Disabled = true,
            Name = "test",
            Color = "red",
            TextColor = "black",
            CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() }
          }
        }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context, usersHelper.Object);
      var response = repo.GetCoilWithCoilField(id);
      Assert.NotNull(response);

    }


    [Fact]
    public void GetCoilByLocationId_RetunsCoils()
    {
      int id = 22;
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation()
        {
          Id = 7,
          Name = "white",
          Column = 9,
          Zone = new CoilFieldZone
          {
            Id = 1,
            Disabled = true,
            Name = "test",
            Color = "red",
            TextColor = "black",
            CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() }
          }
        }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context, usersHelper.Object);
      var response = repo.GetCoilByLocationId(id);
      Assert.NotNull(response);

    }


    [Fact]
    public void GetCoils_RetunsCoils()
    {
   
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation()
        {
          Id = 7,
          Name = "white",
          Column = 9,
          Zone = new CoilFieldZone
          {
            Id = 1,
            Disabled = true,
            Name = "test",
            Color = "red",
            TextColor = "black",
            CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() }
          }
        }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context, usersHelper.Object);
      var response = repo.GetCoils();
      Assert.NotNull(response);

    }


    [Fact]
    public void GetCoilsByInInventory_RetunsCoils()
    {

      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation()
        {
          Id = 7,
          Name = "white",
          Column = 9,
          Zone = new CoilFieldZone
          {
            Id = 1,
            Disabled = true,
            Name = "test",
            Color = "red",
            TextColor = "black",
            CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() }
          }
        }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context, usersHelper.Object);
      var response = repo.GetCoilsByInInventory();
      Assert.NotNull(response);

    }


    [Fact]
    public void GetCoilsToMove_RetunsCoils()
    {
      int id = 22;
      List<int> ids = new List<int>();
      {
        ids.Add(12);
      }
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation()
        {
          Id = 7,
          Name = "white",
          Column = 9,
          Zone = new CoilFieldZone
          {
            Id = 1,
            Disabled = true,
            Name = "test",
            Color = "red",
            TextColor = "black",
            CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() }
          }
        }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context, usersHelper.Object);
      var response = repo.GetCoilsToMove(id,ids);
      Assert.NotNull(response);

    }

    [Fact]
    public void IsmillIdPresentInCoilMoveRequest_RetunsBool()
    {
      int id = 22;
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation()
        {
          Id = 7,
          Name = "white",
          Column = 9,
          Zone = new CoilFieldZone
          {
            Id = 1,
            Disabled = true,
            Name = "test",
            Color = "red",
            TextColor = "black",
            CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() }
          }
        }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context, usersHelper.Object);
     repo.IsmillIdPresentInCoilMoveRequest(id);
      Assert.True(true);

    }

    [Fact]
    public void GetLoadedCoilsById_RetunsCoils()
    {
      int id = 22;
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation()
        {
          Id = 7,
          Name = "white",
          Column = 9,
          Zone = new CoilFieldZone
          {
            Id = 1,
            Disabled = true,
            Name = "test",
            Color = "red",
            TextColor = "black",
            CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() }
          }
        }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context, usersHelper.Object);
      var response = repo.GetLoadedCoilsById(id);
      Assert.NotNull(response);

    }

    [Fact]
    public void GetCoilsByIdWithTypeRunHistory_RetunsCoils()
    {
      int id = 22;
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation()
        {
          Id = 7,
          Name = "white",
          Column = 9,
          Zone = new CoilFieldZone
          {
            Id = 1,
            Disabled = true,
            Name = "test",
            Color = "red",
            TextColor = "black",
            CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() }
          }
        }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context, usersHelper.Object);
      var response = repo.GetCoilsByIdWithTypeRunHistory(id);
      Assert.NotNull(response);

    }



    [Fact]
    public void GetCoilsByFTZ_RetunsCoils()
    {
      string ftz = "TM12345";
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation()
        {
          Id = 7,
          Name = "white",
          Column = 9,
          Zone = new CoilFieldZone
          {
            Id = 1,
            Disabled = true,
            Name = "test",
            Color = "red",
            TextColor = "black",
            CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() }
          }
        }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context, usersHelper.Object);
      var response = repo.GetCoilsByFTZ(ftz);
      Assert.NotNull(response);

    }


    [Fact]
    public void GetRunResultCoilsByFtz_RetunsCoils()
    {
      string ftz = "TM12345";
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation()
        {
          Id = 7,
          Name = "white",
          Column = 9,
          Zone = new CoilFieldZone
          {
            Id = 1,
            Disabled = true,
            Name = "test",
            Color = "red",
            TextColor = "black",
            CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() }
          }
        }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context, usersHelper.Object);
      var response = repo.GetRunResultCoilsByFtz(ftz);
      Assert.NotNull(response);

    }


    [Fact]
    public void GetCoilsByPrefixFtz_RetunsCoils()
    {
      string ftz = "TM12345";
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation()
        {
          Id = 7,
          Name = "white",
          Column = 9,
          Zone = new CoilFieldZone
          {
            Id = 1,
            Disabled = true,
            Name = "test",
            Color = "red",
            TextColor = "black",
            CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() }
          }
        }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context, usersHelper.Object);
      var response = repo.GetCoilsByPrefixFtz(ftz,ftz);
      Assert.NotNull(response);

    }


    [Fact]
    public void GetRunResultCoilsByPrefixFtz_RetunsCoils()
    {
      string ftz = "TM12345";
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation()
        {
          Id = 7,
          Name = "white",
          Column = 9,
          Zone = new CoilFieldZone
          {
            Id = 1,
            Disabled = true,
            Name = "test",
            Color = "red",
            TextColor = "black",
            CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() }
          }
        }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context, usersHelper.Object);
      var response = repo.GetRunResultCoilsByPrefixFtz(ftz, ftz);
      Assert.NotNull(response);

    }


    [Fact]
    public void GetCoilToMoveByCoilId_RetunsCoils()
    {
      int id = 22;
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation()
        {
          Id = 7,
          Name = "white",
          Column = 9,
          Zone = new CoilFieldZone
          {
            Id = 1,
            Disabled = true,
            Name = "test",
            Color = "red",
            TextColor = "black",
            CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() }
          }
        }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context, usersHelper.Object);
      var response = repo.GetCoilToMoveByCoilId(id);
      Assert.NotNull(response);

    }

    [Fact]
    public void GetCoilsByLocationId_RetunsCoils()
    {
      int id = 22;
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation()
        {
          Id = 7,
          Name = "white",
          Column = 9,
          Zone = new CoilFieldZone
          {
            Id = 1,
            Disabled = true,
            Name = "test",
            Color = "red",
            TextColor = "black",
            CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() }
          }
        }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context, usersHelper.Object);
      var response = repo.GetCoilsByLocationId(id);
      Assert.NotNull(response);

    }



    [Fact]
    public void GetCoilsById_RetunsCoils()
    {
      int id = 22;
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation()
        {
          Id = 7,
          Name = "white",
          Column = 9,
          Zone = new CoilFieldZone
          {
            Id = 1,
            Disabled = true,
            Name = "test",
            Color = "red",
            TextColor = "black",
            CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() }
          }
        }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context, usersHelper.Object);
      var response = repo.GetCoilsById(id);
      Assert.NotNull(response);

    }



    [Fact]
    public void GetCoilsIds_RetunsCoils()
    {
      int id = 22;
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation()
        {
          Id = 7,
          Name = "white",
          Column = 9,
          Zone = new CoilFieldZone
          {
            Id = 1,
            Disabled = true,
            Name = "test",
            Color = "red",
            TextColor = "black",
            CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() }
          }
        }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context, usersHelper.Object);
      var response = repo.GetCoilsIds(id);
      Assert.NotNull(response);

    }


    [Fact]
    public void GetCoilsByCoilStatusName_RetunsCoils()
    {
      string name = "me";
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation()
        {
          Id = 7,
          Name = "white",
          Column = 9,
          Zone = new CoilFieldZone
          {
            Id = 1,
            Disabled = true,
            Name = "test",
            Color = "red",
            TextColor = "black",
            CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() }
          }
        }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context, usersHelper.Object);
      var response = repo.GetCoilsByCoilStatusName(name);
      Assert.NotNull(response);

    }



    [Fact]
    public void CoilsInventoryBYTypeId_RetunsCoils()
    {
      int id = 22;
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation()
        {
          Id = 7,
          Name = "white",
          Column = 9,
          Zone = new CoilFieldZone
          {
            Id = 1,
            Disabled = true,
            Name = "test",
            Color = "red",
            TextColor = "black",
            CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() }
          }
        }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context, usersHelper.Object);
      var response = repo.CoilsInventoryBYTypeId(id);
      Assert.NotNull(response);

    }




    [Fact]
    public void GetCoilStatusByCoilId_RetunsCoils()
    {
      int id = 22;
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation()
        {
          Id = 7,
          Name = "white",
          Column = 9,
          Zone = new CoilFieldZone
          {
            Id = 1,
            Disabled = true,
            Name = "test",
            Color = "red",
            TextColor = "black",
            CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() }
          }
        }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context, usersHelper.Object);
      var response = repo.GetCoilStatusByCoilId(id);
      Assert.NotNull(response);

    }


    [Fact]
    public void GetCoilsForSearch_RetunsCoils()
    {
      
      DateTime startTime = DateTime.Now;
      DateTime endTime = DateTime.Now;
      int? coilStatusId = 1;
      string coilType = "1-3";
      int? zoneId = 4;
      string FilterByBornOnDate = "0";
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation()
        {
          Id = 7,
          Name = "white",
          Column = 9,
          Zone = new CoilFieldZone
          {
            Id = 1,
            Disabled = true,
            Name = "test",
            Color = "red",
            TextColor = "black",
            CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() }
          }
        }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context, usersHelper.Object);
      var response = repo.GetCoilsForSearch(startTime, endTime, coilType, coilStatusId, zoneId, FilterByBornOnDate);
      Assert.NotNull(response);

    }

    /// <summary>
    /// 
    /// </summary>
    [Fact]
    public void GetCoilLocationsInOrder_RetunscoilsInField()
    {
      List<Coil> coil = new List<Coil>
            {
                new Coil()
                {
                    Id = 2212,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9,

                    CoilType = new CoilType() { Id = 17, Name = "test" },
                    CoilFieldLocation = new CoilFieldLocation() { Id = 17, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 17, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 19, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() } } }

                }
            };
      CoilFieldZone CoilField = new CoilFieldZone
      {
        Id = 2,
        Name = "test",
        Disabled = true,
        Color = "white",
        TextColor = "white",
        CoilField = new CoilField { Id = 7, Name = "1-8", Disabled = true, Zones = new List<CoilFieldZone>() }
      };
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil()
      {
        Id = 2212,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 17, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation() { Id = 17, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 17, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 19, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() } } }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context,usersHelper.Object);
      repo.GetCoilLocationsInOrder(CoilField, coil);
      Assert.NotNull(repo);

    }

    /// <summary>
    /// 
    /// </summary>
    [Fact]
    public void GetCoilFieldLocation_RetunsCoilFieldLocation()
    {
      List<Coil> coil = new List<Coil>
            {
                new Coil()
                {
                    Id = 7,
                    OrderNo = 6,
                    IsPriority = true,
                    CheckInDate = DateTime.Now,
                    SerialNum = "test",
                    YNA = "c",
                    FTZ = "te",
                    OriginalWeight = 1,
                    ReturnedToField = DateTime.Now,
                    UnAccountedWeight = 9,

                    CoilType = new CoilType() { Id = 7, Name = "test" },
                    CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() } } }

                }
            };

      CoilFieldLocation CoilFieldLocation = new CoilFieldLocation() { Id = 7, Zone = new CoilFieldZone(), Name = "test", Disabled = true, IsEmpty = true, Column = 9, Row = 8 };
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil()
      {
        Id = 7,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() } } }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context,usersHelper.Object);
      var response = repo.CoilFieldLocation(CoilFieldLocation, coil);
      Assert.NotNull(response);

    }

    /// <summary>
    /// 
    /// </summary>
    [Fact]
    public void GetKanCoils_ReturnsCoilStatus()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil()
      {
        Id = 7,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() } } }

      });
      context.SaveChanges();

      var repo = new CoilRepository(context,usersHelper.Object);
      var response = repo.GetKanCoils();
      Assert.NotNull(response);

    }

    [Fact]
    public void GetPartialsCoils_ReturnsPartialsCoils()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil()
      {
        Id = 7,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() } } }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context,usersHelper.Object);
      var response = repo.GetPartialsCoils();
      Assert.NotNull(response);

    }


    [Fact]
    public void GetCoilId_ReturnsCoilId_Coils_ReturnstCoilIds()
    {
      int id = 22;
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil()
      {
        Id = 22,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() } } }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context,usersHelper.Object);
      var response = repo.GetCoilId(id);
      Assert.NotNull(response);

    }

    [Fact]
    public void GetCurrentWeightCoilsbyCoilId_Coils_returnsCurrentWeightCoils()
    {
      int id = 125;
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil()
      {
        Id = 125,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() } } }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context,usersHelper.Object);
      var response = repo.GetCoilsWithAllInfo(id);
      Assert.Null(response);

    }
    [Fact]
    public void GetCoilRunHistoryIds_Coils_returnsCoilRunHistory()
    {
      List<int> ids = new List<int>() { 2 };
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil()
      {
        Id = 7,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() } } }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context,usersHelper.Object);
      var response = repo.GetCoilRunHistoryByIds(ids);
      Assert.NotNull(response);

    }
    [Fact]
    public async Task GetCoilsByZoneId_RetunsCoils()
    {
      var ZoneId = 1;
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Coils.Add(new Coil()
      {
        Id = 7,
        OrderNo = 6,
        IsPriority = true,
        CheckInDate = DateTime.Now,
        SerialNum = "test",
        YNA = "c",
        FTZ = "te",
        OriginalWeight = 1,
        ReturnedToField = DateTime.Now,
        UnAccountedWeight = 9,

        CoilType = new CoilType() { Id = 7, Name = "test" },
        CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white", Column = 9, Zone = new CoilFieldZone { Id = 7, Disabled = true, Name = "test", Color = "red", TextColor = "black", CoilField = new CoilField { Id = 9, Name = "test", Disabled = true, Zones = new List<CoilFieldZone>() } } }

      });
      context.SaveChanges();
      var repo = new CoilRepository(context,usersHelper.Object);
      var response = await repo.GetCoilsByZoneId(ZoneId);
      Assert.NotNull(response);

    }
  }
}
