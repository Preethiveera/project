using CoilTracking.Data;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.Tests.Constants;
using CoilTracking.Tests.IntergrationTest;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace CoilTracking.Tests.Repository
{
  public class PlantsRepositoryTest
  {
    readonly IDatabaseSetup DatabaseFixture;
    public PlantsRepositoryTest()
    {
      DatabaseFixture = new DatabaseFixture();
    }

    [Fact]
    public void GetPlantName_Names_ReturnsPlantNames()
    {

      var context = DatabaseFixture.GetDatabaseFixture();
      context.Plants.Add(new Data.Models.Plant
      {
        Id = 1,
        NAMCCode = "02",
        PlantName = "TMMI",
        TimeZone = new Data.Models.PlantTimeZone { Id = 2, Name = "N" }

      });
      context.SaveChanges();
      var repo = new PlantsRepository(context);
      var response = repo.GetPlantName();
      Assert.NotNull(response);

    }
  }
}
