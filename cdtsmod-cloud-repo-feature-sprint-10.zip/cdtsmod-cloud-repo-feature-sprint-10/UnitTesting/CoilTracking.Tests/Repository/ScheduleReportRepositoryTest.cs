using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.Tests.Constants;
using CoilTracking.Tests.IntergrationTest;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace CoilTracking.Tests.Repository
{
  public class ScheduleReportRepositoryTest
  {

    public readonly IUserHelper usersHelper;
    //Create In Memory Database
    readonly IDatabaseSetup DatabaseFixture;
    private readonly IHttpContextAccessor httpContextAccessor;
    public ScheduleReportRepositoryTest()
    {
      DatabaseFixture = new DatabaseFixture();
    }

    [Fact]
    public void Get()
    {
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new ScheduledReportEmail
      {
        Id = 1,
        Email = "d@toyota.com",
        RunReport = true,
        CoilReport = true,
        ScrapReport = false

      };
      context.ScheduledReportEmails.Add(post);
      context.SaveChanges();

        ScheduleReportRepository repository = new ScheduleReportRepository(context,usersHelper);
        var result = repository.Get();
        Assert.NotNull(repository);

      

    }

    [Fact]
    public void GetScheduleReportByID()
    {
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new ScheduledReportEmail
      {
        Id = 1,
        Email = "d@toyota.com",
        RunReport = true,
        CoilReport = true,
        ScrapReport = false

      };
      context.ScheduledReportEmails.Add(post);
      context.SaveChanges();


      ScheduleReportRepository repository = new ScheduleReportRepository(context,usersHelper);
        var result = repository.GetScheduleReportByID(1);
        Assert.NotNull(repository);

      
    }

    [Fact]
    public void ScheduleReportExists()
    {
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new ScheduledReportEmail
      {
        Id = 2,
        Email = "d@toyota.com",
        RunReport = true,
        CoilReport = true,
        ScrapReport = false

      };
      context.ScheduledReportEmails.Add(post);
      context.SaveChanges();

      ScheduleReportRepository repository = new ScheduleReportRepository(context,usersHelper);
        var result = repository.ScheduleReportExists(2);
        Assert.NotNull(repository);

      
    }
    [Fact]
    public void ScheduleReportByEmail()
    {
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new ScheduledReportEmail
      {
        Id = 1,
        Email = "d@toyota.com",
        RunReport = true,
        CoilReport = true,
        ScrapReport = false

      };
      context.ScheduledReportEmails.Add(post);
      context.SaveChanges();

      string Email = "d@toyota.com";
        ScheduleReportRepository repository = new ScheduleReportRepository(context,usersHelper);
        var result = repository.GetScheduleReportByEmail(Email);
        Assert.NotNull(repository);

      
    }
    [Fact]
    public void DeleteReportByEmail()
    {
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new ScheduledReportEmail
      {
        Id = 3,
        Email = "d@toyota.com",
        RunReport = true,
        CoilReport = true,
        ScrapReport = false

      };
      context.ScheduledReportEmails.Add(post);
      context.SaveChanges();

      ScheduleReportRepository repository = new ScheduleReportRepository(context,usersHelper);
        var result = repository.DeleteScheduleReport(3);
        Assert.NotNull(repository);

      
    }


    [Fact]
    public void PostScheduleReport()
    {
      var scheduledReport = new ScheduledReportEmail()
      {
        Id = 13,
        Email = "hrvez@toyota.com",
        CoilReport = true,
        RunReport = false,
        ScrapReport = false,
      };
      var context = DatabaseFixture.GetDatabaseFixture();

        ScheduleReportRepository repository = new ScheduleReportRepository(context,usersHelper);
        var result = repository.PostScheduleReport(scheduledReport);
        Assert.NotNull(repository);

      
    }
  }
}
