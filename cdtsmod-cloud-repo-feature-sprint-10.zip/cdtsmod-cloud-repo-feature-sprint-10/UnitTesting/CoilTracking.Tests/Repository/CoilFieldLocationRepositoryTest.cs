using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.Tests.IntergrationTest;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Moq;
using Xunit;

namespace CoilTracking.Tests.Repository
{
  public class CoilFieldLocationRepositoryTest
  {
    public readonly IUserHelper usersHelper;
    readonly IDatabaseSetup DatabaseFixture;
    public CoilFieldLocationRepositoryTest()
    {
      DatabaseFixture = new DatabaseFixture();
    }

    [Fact]
    public void GetCountofCoilfieldlocation()
    {
      //Get the instance of DBContext  
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new CoilFieldLocation()
      {
        Id = 1,
        Name = "Test",
        Zone = new CoilFieldZone
        {
          Name = "Test",
          CoilField = new CoilField
          {
            Name = "Test"
          }
        }
      };

      //Act    
      context.CoilFieldLocations.Add(post);
      context.SaveChanges();

      var repo = new CoilFieldLocationRepository(context,usersHelper);
      var response = repo.GetCountOfCoilFieldLocation();
      Assert.Equal(response, response);

    }

    [Fact]
    public void GetAllCoilFieldLocations()
    {
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new CoilFieldLocation()
      {
        Id = 1,
        Name = "Test",
        Zone = new CoilFieldZone
        {
          Id = 1,
          Name = "Test",
          CoilField = new CoilField
          {
            Name = "Test"
          }
        }
      };

      //Act    
      context.CoilFieldLocations.Add(post);
      context.SaveChanges();
      var repo = new CoilFieldLocationRepository(context,usersHelper);
      var response = repo.GetAllCoilFieldLocations();
      Assert.NotNull(response);

    }

    [Fact]
    public void GetCoilFieldLocationById()
    {
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new CoilFieldLocation()
      {
        Id = 1,
        Name = "Test",
        Zone = new CoilFieldZone
        {
          Id = 1,
          Name = "Test",
          CoilField = new CoilField
          {
            Name = "Test"
          }
        }
      };

      //Act    
      context.CoilFieldLocations.Add(post);
      context.SaveChanges();
      CoilFieldLocationRepository repo = new CoilFieldLocationRepository(context,usersHelper);
      var response = repo.GetCoilFieldLocationById(1);
      Assert.True(true);

    }

    [Fact]
    public void GetCoilFieldLocationWithZone()
    {
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new CoilFieldLocation()
      {
        Id = 1,
        Name = "Test",
        Zone = new CoilFieldZone
        {
          Id = 1,
          Name = "Test",
          CoilField = new CoilField
          {
            Name = "Test"
          }
        }
      };

      //Act    
      context.CoilFieldLocations.Add(post);
      context.SaveChanges();
      var repo = new CoilFieldLocationRepository(context,usersHelper);
      var response = repo.GetCoilFieldLocationWithZone(1);
      Assert.NotNull(repo);

    }



    [Fact]
    public void AddCoilFieldLocation()
    {
      var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
      var contexts = new DefaultHttpContext();
      var fakeTenantId = "abcd";
      contexts.Request.Headers["Tenant-ID"] = fakeTenantId;
      mockHttpContextAccessor.Setup(_ => _.HttpContext).Returns(contexts);
      //Mock HeaderConfiguration
      var mockHeaderConfiguration = new Mock<IUserHelper>();
      mockHeaderConfiguration
          .Setup(_ => _.GetSubject())
          .Returns(fakeTenantId);
      var coilFieldLocation = new CoilFieldLocation
      {
        Id = 3001,
        Name = "Test12300",
        Zone = new CoilFieldZone
        {
          Name = "Test12",
          CoilField = new CoilField
          {
            Name = "Test12"
          }
        }
      };
      var context = DatabaseFixture.GetDatabaseFixture();

      var repo = new CoilFieldLocationRepository(context,mockHeaderConfiguration.Object);
      repo.AddCoilFieldLocation(coilFieldLocation);
      Assert.NotNull(repo);
      context.Database.EnsureDeleted();
    }

    [Fact]
    public void DeleteCoilFieldLocation()
    {
      var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
      var contexts = new DefaultHttpContext();
      var fakeTenantId = "abcd";
      contexts.Request.Headers["Tenant-ID"] = fakeTenantId;
      mockHttpContextAccessor.Setup(_ => _.HttpContext).Returns(contexts);
      //Mock HeaderConfiguration
      var mockHeaderConfiguration = new Mock<IUserHelper>();
      mockHeaderConfiguration
          .Setup(_ => _.GetSubject())
          .Returns(fakeTenantId);
      var coilFieldLocation = new CoilFieldLocation
      {
        Id = 130,
        Name = "Test12",
        Zone = new CoilFieldZone
        {
          Name = "Test12",
          CoilField = new CoilField
          {
            Name = "Test12"
          }
        }
      };
      var context = DatabaseFixture.GetDatabaseFixture();
      context.CoilFieldLocations.Add(coilFieldLocation);

      context.SaveChanges();

      var repo = new CoilFieldLocationRepository(context,mockHeaderConfiguration.Object);
      repo.DeleteCoilFieldLocation(coilFieldLocation);
      Assert.NotNull(repo);
      context.Database.EnsureDeleted();
    }

    [Fact]
    public void SaveChanges()
    {
      var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
      var contexts = new DefaultHttpContext();
      var fakeTenantId = "abcd";
      contexts.Request.Headers["Tenant-ID"] = fakeTenantId;
      mockHttpContextAccessor.Setup(_ => _.HttpContext).Returns(contexts);
      //Mock HeaderConfiguration
      var mockHeaderConfiguration = new Mock<IUserHelper>();
      mockHeaderConfiguration
          .Setup(_ => _.GetSubject())
          .Returns(fakeTenantId);
      var context = DatabaseFixture.GetDatabaseFixture();


      var repo = new CoilFieldLocationRepository(context,mockHeaderConfiguration.Object);
      repo.SaveChanges(AuditActionType.ModifyEntity);
      Assert.NotNull(repo);

    }

    [Fact]
    public void GetFreeLocations()
    {
      var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
      var contexts = new DefaultHttpContext();
      var fakeTenantId = "abcd";
      contexts.Request.Headers["Tenant-ID"] = fakeTenantId;
      mockHttpContextAccessor.Setup(_ => _.HttpContext).Returns(contexts);
      //Mock HeaderConfiguration
      var mockHeaderConfiguration = new Mock<IUserHelper>();
      mockHeaderConfiguration
          .Setup(_ => _.GetSubject())
          .Returns(fakeTenantId);
      var context = DatabaseFixture.GetDatabaseFixture();

      var post = new CoilFieldLocation()
      {
        Id = 1,
        Name = "Test",
        Zone = new CoilFieldZone
        {
          Id = 1,
          Name = "Test",
          CoilField = new CoilField
          {
            Name = "Test"
          }
        }
      };

      //Act    
      context.CoilFieldLocations.Add(post);
      context.SaveChanges();
      var repo = new CoilFieldLocationRepository(context,mockHeaderConfiguration.Object);
      var response = repo.GetFreeLocations();
      Assert.NotNull(response);

    }
  }
}
