using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.Tests.IntergrationTest;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Moq;
using Xunit;

namespace CoilTracking.Tests.Repository
{
  public class MillsRepositoryTest
  {
    public readonly IUserHelper usersHelper;
    readonly IDatabaseSetup DatabaseFixture;
    public MillsRepositoryTest()
    {

      DatabaseFixture = new DatabaseFixture();
    }
    [Fact]
    public void GetCountOfMills()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Mill
      {
        Id = 1,
        Name = "USS",
        Disabled = false
      };
      context.Mills.Add(post);
      context.SaveChanges();
      MillsRepository millsRepository = new MillsRepository(context,usersHelper);
      millsRepository.GetCountOfMills();
      Assert.Equal(1, 1);

    }
    [Fact]
    public void GetMillById_Id_ReturnsMills()
    {

      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Mill { Id = 2, Name = "test" };
      context.Mills.Add(post);
      context.SaveChanges();
      MillsRepository millsRepository = new MillsRepository(context,usersHelper);
            millsRepository.GetMillById(2);
      Assert.NotNull(post);

    }
    [Fact]
    public void GetMills_ReturnsMills()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Mill
      {
        Id = 3,
        Name = "USS",
        Disabled = false
      };
      context.Mills.Add(post);
      context.SaveChanges();
      MillsRepository millsRepository = new MillsRepository(context,usersHelper);
      var mills = millsRepository.GetMills();
      Assert.NotNull(mills);

    }

    [Fact]
    public void CheckIfEdited_Id_ReturnsFalse()
    {
      var mill = new Mill
      {
        Id = 11,
        Name = "test",

      };
      var context = DatabaseFixture.GetDatabaseFixture();
      context.Mills.Add(new Mill { Id = 11, Name = "test" });
      context.SaveChanges();
      MillsRepository millsRepository = new MillsRepository(context,usersHelper);
      var mills = millsRepository.CheckIfEdited(11, mill);
      Assert.False(mills);

    }
    [Fact]
    public void CheckIfEdited_Id_ReturnsTrue()
    {
      var mill = new Mill
      {
        Id = 8,
        Name = "MITTAL1",
        Disabled = false
      };
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Mill
      {
        Id = 8,
        Name = "MITTAL1",
        Disabled = false
      };
      context.Mills.Add(post);
      context.SaveChanges();
      MillsRepository millsRepository = new MillsRepository(context,usersHelper);
      millsRepository.CheckIfEdited(8, mill);
      Assert.True(true);


    }

    [Fact]
    public void DisableMill_IdandDisable()
    {
      var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
      var contexts = new DefaultHttpContext();
      var fakeTenantId = "abcd";
      contexts.Request.Headers["Tenant-ID"] = fakeTenantId;
      mockHttpContextAccessor.Setup(_ => _.HttpContext).Returns(contexts);
      //Mock HeaderConfiguration
      var mockHeaderConfiguration = new Mock<IUserHelper>();
      mockHeaderConfiguration
          .Setup(_ => _.GetSubject())
          .Returns(fakeTenantId);
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Mill
      {
        Id = 8,
        Name = "MITTAL1",
        Disabled = false
      };
      context.Mills.Add(post);
      context.SaveChanges();

      MillsRepository millsRepository = new MillsRepository(context,mockHeaderConfiguration.Object);
      millsRepository.DisableMill(8, false);
      Assert.NotNull(millsRepository);


    }



    [Fact]
    public void UpdateMill_IdAndMill_ReturnsTrue()
    {
      var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
      var contexts = new DefaultHttpContext();
      var fakeTenantId = "abcd";
      contexts.Request.Headers["Tenant-ID"] = fakeTenantId;
      mockHttpContextAccessor.Setup(_ => _.HttpContext).Returns(contexts);
      //Mock HeaderConfiguration
      var mockHeaderConfiguration = new Mock<IUserHelper>();
      mockHeaderConfiguration
          .Setup(_ => _.GetSubject())
          .Returns(fakeTenantId);
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Mill
      {
        Id = 18,
        Name = "MITTAL1",
        Disabled = false
      };
      context.Mills.Add(post);
      context.SaveChanges();
      MillsRepository millsRepository = new MillsRepository(context,mockHeaderConfiguration.Object);
      var mills = millsRepository.UpdateMill(post);
      Assert.True(mills);


    }


  }
}
