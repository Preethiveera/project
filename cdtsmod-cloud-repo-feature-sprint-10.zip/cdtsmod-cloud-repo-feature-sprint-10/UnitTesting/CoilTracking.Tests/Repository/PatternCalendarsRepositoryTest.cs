using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.Tests.IntergrationTest;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using System;
using System.Globalization;
using System.Threading.Tasks;
using Xunit;

namespace CoilTracking.Tests.Repository
{
  public class PatternCalendarsRepositoryTest
  {

    public readonly IUserHelper usersHelper;
    readonly IDatabaseSetup DatabaseFixture;

    public PatternCalendarsRepositoryTest()
    {
      DatabaseFixture = new DatabaseFixture();
    }


    [Fact]
    public void GetPatternLetterReturnsTrue()
    {
      CultureInfo ci = CultureInfo.InvariantCulture;
      var patternLetter = new PatternLetter()
      {
        Id = 2,
        Name = "Z",
        Desc = "test",
        Disabled = false
      };
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PatternCalendar
      {
        Id = 1,
        Date = DateTime.ParseExact("12/25/2008", "MM/dd/yyyy", ci),
        //DateTime.Today.Date,
        Shift = new Shift
        {
          Id = 2,
          Name = "RED",

        },
        PatternLetter = "Z",
        Line = new Line
        {
          Id = 5,
          Plant = new Plant
          {
            Id = 1,
            NAMCCode = "A",
            PlantName = "P",
            TimeZone = new PlantTimeZone
            {
              Id = 1,
              Name = "J",
              TimeZoneOffset = 2

            }
          },
          Plant_Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 1,
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          OPCServer_Id = 1,
          LinePath = "-",
          Tags = "-,-,-,-,-,-,-,-,-,-,-,-,-,-",
          Subscribed = false,
          Disabled = false
        }
      };
      context.PatternCalendars.Add(post);
      context.SaveChanges();
        var PatterCalendarRepo = new PatternCalendarRepository(context,usersHelper);

      var getPatternLetter = PatterCalendarRepo.GetPatternLetterAssociation(patternLetter);
      Assert.True(true);

    }

    [Fact]
    public void GetPatternLetterReturnsFalse()
    {
      var patternLetter = new PatternLetter()
      {
        Id = 2,
        Name = "G",
        Desc = "test",
        Disabled = false
      };
      CultureInfo ci = CultureInfo.InvariantCulture;
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PatternCalendar
      {
        Id = 2,
        Date = DateTime.ParseExact("12/25/2008", "MM/dd/yyyy", ci),
        //DateTime.Today.Date,
        Shift = new Shift
        {
          Id = 12,
          Name = "RED",

        },
        PatternLetter = "G",
        Line = new Line
        {
          Id = 15,
          Plant = new Plant
          {
            Id = 1,
            NAMCCode = "A",
            PlantName = "P",
            TimeZone = new PlantTimeZone
            {
              Id = 10,
              Name = "J",
              TimeZoneOffset = 2

            }
          },
          Plant_Id = 17,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 11,
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          OPCServer_Id = 11,
          LinePath = "-",
          Tags = "-,-,-,-,-,-,-,-,-,-,-,-,-,-",
          Subscribed = false,
          Disabled = false
        }
      };
      context.PatternCalendars.Add(post);
      context.SaveChanges();
      var PatterCalendarRepo = new PatternCalendarRepository(context,usersHelper);

      var getPatternLetter = PatterCalendarRepo.GetPatternLetterAssociation(patternLetter);
      Assert.True(true);

    }

    //[Fact]
    //public async Task GetPatternCalendarByDateLineIdAndShiftIdReturnsPatternCalendar()
    //{
    //  int shiftId = 2;
    //  int lineId = 1;

    //  using (var context = new CoilTrackingContext(options,httpContextAccessor))
    //  {
    //    var PatterCalendarRepo = new PatternCalendarRepository(context,usersHelper);

    //    var patterncalendar = await PatterCalendarRepo.GetPatternCalendarByDateLineIdAndShiftId(DateTime.Today.Date, shiftId, lineId);
    //    Assert.NotNull(patterncalendar);
    //  }
    //}

    [Fact]
    public async Task GetPatternCalendarByDateLineIdAndShiftIdReturnsNull()
    {
      int shiftId = 2;
      int lineId = 5;
      CultureInfo ci = CultureInfo.InvariantCulture;
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PatternCalendar
      {
        Id = 2,
        Date = DateTime.ParseExact("12/25/2008", "MM/dd/yyyy", ci),
        //DateTime.Today.Date,
        Shift = new Shift
        {
          Id = 2,
          Name = "RED",

        },
        PatternLetter = "G",
        Line = new Line
        {
          Id = 5,
          Plant = new Plant
          {
            Id = 1,
            NAMCCode = "A",
            PlantName = "P",
            TimeZone = new PlantTimeZone
            {
              Id = 10,
              Name = "J",
              TimeZoneOffset = 2

            }
          },
          Plant_Id = 17,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 11,
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          OPCServer_Id = 11,
          LinePath = "-",
          Tags = "-,-,-,-,-,-,-,-,-,-,-,-,-,-",
          Subscribed = false,
          Disabled = false
        }
      };
      context.PatternCalendars.Add(post);
      context.SaveChanges();
      PatternCalendarRepository PatterCalendarRepo = new PatternCalendarRepository(context,usersHelper);
      var patterncalendar = await PatterCalendarRepo.GetPatternCalendarByDateLineIdAndShiftId(post.Date, lineId, shiftId);
      Assert.NotNull(PatterCalendarRepo);

    }

    [Fact]
    public async Task GetPatternCalendarByMonthAndYearReturnsPatternCalendars()
    {
      CultureInfo ci = CultureInfo.InvariantCulture;
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PatternCalendar
      {
        Id = 12,
        Date = DateTime.ParseExact("12/25/2008", "MM/dd/yyyy", ci),
        //DateTime.Today.Date,
        Shift = new Shift
        {
          Id = 120,
          Name = "RED",

        },
        PatternLetter = "T",
        Line = new Line
        {
          Id = 11,
          Plant = new Plant
          {
            Id = 1,
            NAMCCode = "A",
            PlantName = "P",
            TimeZone = new PlantTimeZone
            {
              Id = 10,
              Name = "J",
              TimeZoneOffset = 2

            }
          },
          Plant_Id = 11,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 11,
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          OPCServer_Id = 11,
          LinePath = "-",
          Tags = "-,-,-,-,-,-,-,-,-,-,-,-,-,-",
          Subscribed = false,
          Disabled = false
        }
      };
      context.PatternCalendars.Add(post);
      context.SaveChanges();
      var PatterCalendarRepo = new PatternCalendarRepository(context,usersHelper);

      var patternCalendars = await PatterCalendarRepo.GetPatternCalendarByMonthAndYear(post.Date.Month, post.Date.Year);
      Assert.NotNull(patternCalendars);
      //Assert.True(patternCalendars.Count > 0);

    }

    [Fact]
    public async Task GetPatternCalendarByMonthAndYearReturnsCountZero()
    {
      var date = new DateTime(2022, 12, 01);
      CultureInfo ci = CultureInfo.InvariantCulture;
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PatternCalendar
      {
        Id = 2,
        Date = DateTime.ParseExact("12/25/2008", "MM/dd/yyyy", ci),
        //DateTime.Today.Date,
        Shift = new Shift
        {
          Id = 12,
          Name = "RED",

        },
        PatternLetter = "G",
        Line = new Line
        {
          Id = 15,
          Plant = new Plant
          {
            Id = 1,
            NAMCCode = "A",
            PlantName = "P",
            TimeZone = new PlantTimeZone
            {
              Id = 10,
              Name = "J",
              TimeZoneOffset = 2

            }
          },
          Plant_Id = 17,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 11,
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          OPCServer_Id = 11,
          LinePath = "-",
          Tags = "-,-,-,-,-,-,-,-,-,-,-,-,-,-",
          Subscribed = false,
          Disabled = false
        }
      };
      context.PatternCalendars.Add(post);
      context.SaveChanges();
      var PatterCalendarRepo = new PatternCalendarRepository(context,usersHelper);

      var patternCalendars = await PatterCalendarRepo.GetPatternCalendarByMonthAndYear(date.Month, date.Year);
      Assert.NotNull(patternCalendars);
      Assert.True(patternCalendars.Count == 0);

    }

    [Fact]
    public async Task GetPatternCalendarByMonthYearShiftIdLineIdReturnsPatternCalendars()
    {
      var date = DateTime.Today;
      int shiftId = 2;
      int lineId = 5;
      CultureInfo ci = CultureInfo.InvariantCulture;
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PatternCalendar
      {
        Id = 2,
        Date = DateTime.ParseExact("12/25/2008", "MM/dd/yyyy", ci),
        //DateTime.Today.Date,
        Shift = new Shift
        {
          Id = 2,
          Name = "RED",

        },
        PatternLetter = "G",
        Line = new Line
        {
          Id = 5,
          Plant = new Plant
          {
            Id = 1,
            NAMCCode = "A",
            PlantName = "P",
            TimeZone = new PlantTimeZone
            {
              Id = 10,
              Name = "J",
              TimeZoneOffset = 2

            }
          },
          Plant_Id = 17,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 11,
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          OPCServer_Id = 11,
          LinePath = "-",
          Tags = "-,-,-,-,-,-,-,-,-,-,-,-,-,-",
          Subscribed = false,
          Disabled = false
        }
      };
      context.PatternCalendars.Add(post);
      context.SaveChanges();
      var PatterCalendarRepo = new PatternCalendarRepository(context,usersHelper);

      var patterncalendar = await PatterCalendarRepo.GetPatternCalendarByMonthYearShiftIdLineId(post.Date.Month, post.Date.Year, shiftId, lineId);
      Assert.NotNull(patterncalendar);


    }

    [Fact]
    public async Task GetPatternCalendarByMonthYearShiftIdLineIdReturnsReturnsCountZero()
    {
      var date = new DateTime(2022, 05, 01);
      int shiftId = 1;
      int lineId = 5;
      CultureInfo ci = CultureInfo.InvariantCulture;
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new PatternCalendar
      {
        Id = 2,
        Date = DateTime.ParseExact("12/25/2008", "MM/dd/yyyy", ci),
        //DateTime.Today.Date,
        Shift = new Shift
        {
          Id = 12,
          Name = "RED",

        },
        PatternLetter = "G",
        Line = new Line
        {
          Id = 15,
          Plant = new Plant
          {
            Id = 1,
            NAMCCode = "A",
            PlantName = "P",
            TimeZone = new PlantTimeZone
            {
              Id = 10,
              Name = "J",
              TimeZoneOffset = 2

            }
          },
          Plant_Id = 17,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            Id = 11,
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          OPCServer_Id = 11,
          LinePath = "-",
          Tags = "-,-,-,-,-,-,-,-,-,-,-,-,-,-",
          Subscribed = false,
          Disabled = false
        }
      };
      context.PatternCalendars.Add(post);
      context.SaveChanges();
      var PatterCalendarRepo = new PatternCalendarRepository(context,usersHelper);

      var patterncalendar = await PatterCalendarRepo.GetPatternCalendarByMonthYearShiftIdLineId(date.Month, date.Year, shiftId, lineId);
      Assert.NotNull(patterncalendar);
      Assert.True(patterncalendar.Count == 0);

    }


    [Fact]
    public async Task AddPatternCalendar_ReturnsPatternCalendar()
    {
      var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
      var contexts = new DefaultHttpContext();
      var fakeTenantId = "abcd";
      contexts.Request.Headers["Tenant-ID"] = fakeTenantId;
      mockHttpContextAccessor.Setup(_ => _.HttpContext).Returns(contexts);
      //Mock HeaderConfiguration
      var mockHeaderConfiguration = new Mock<IUserHelper>();
      mockHeaderConfiguration
          .Setup(_ => _.GetSubject())
          .Returns(fakeTenantId);
      var context = DatabaseFixture.GetDatabaseFixture();
      var patternCalendar = new PatternCalendar()
      {

        Date = DateTime.Now,
        Shift = new Shift
        {
          Name = "RED",
        },
        PatternLetter = "X",
        Line = new Line
        {
          Plant = new Plant
          {
            NAMCCode = "A",
            PlantName = "P",
            TimeZone = new PlantTimeZone
            {
              Name = "J",
              TimeZoneOffset = 2
            }
          },
          Plant_Id = 1,
          LineName = "BL1",
          OPCServer = new OPCConfig
          {
            ServerName = "s",
            Disabled = false,
            InstanceName = "I"
          },
          OPCServer_Id = 1,
          LinePath = "-",
          Tags = "-,-,-,-,-,-,-,-,-,-,-,-,-,-",
          Subscribed = false,
          Disabled = false
        }
      };

        var PatterCalendarRepo = new PatternCalendarRepository(context,mockHeaderConfiguration.Object);

      var result = await PatterCalendarRepo.AddPatternCalendar(patternCalendar);
      Assert.NotNull(result);
      Assert.True(result.Id > 0);

    }
  }
}
