using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.Tests.Constants;
using CoilTracking.Tests.IntergrationTest;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System.Collections.Generic;
using Xunit;

namespace CoilTracking.Tests.Repository
{
  public class PartRepositoryTest
  {
    public readonly IUserHelper usersHelper;
    readonly IDatabaseSetup DatabaseFixture;
    public PartRepositoryTest()
    {
      DatabaseFixture = new DatabaseFixture();
    }


    /// 
    /// </summary>
    [Fact]
    public void GetModels_Model_ReturnsModel()
    {
      int lineID = 1;
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Part
      {
        Id = 1,
        PartName = "3546",
        PartNumber = "45657",
        StrokeCount = 0,
        Disabled = false
      };
      context.Parts.Add(post);
      context.SaveChanges();
      var repo = new PartModelsRepository(context,usersHelper);
      var response = repo.GetPartModelByPartId(lineID);
      Assert.NotNull(response);

    }


    [Fact]
    public void GetPartmodelsByPartIdwithOut_ReturnsModel()
    {
      int lineID = 1;
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Part
      {
        Id = 1,
        PartName = "3546",
        PartNumber = "45657",
        StrokeCount = 0,
        Disabled = false
      };
      context.Parts.Add(post);
      context.SaveChanges();
      var repo = new PartModelsRepository(context, usersHelper);
      var response = repo.GetPartmodelsByPartIdwithOut(lineID);
      Assert.NotNull(response);

    }


    [Fact]
    public void GetModelList_ReturnsModel()
    {
      string  name = "test";
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Part
      {
        Id = 1,
        PartName = "3546",
        PartNumber = "45657",
        StrokeCount = 0,
        Disabled = false
      };
      context.Parts.Add(post);
      context.SaveChanges();
      var repo = new PartModelsRepository(context, usersHelper);
      var response = repo.GetModelList(name);
      Assert.NotNull(response);

    }
    /// 
    /// </summary>
    [Fact]
    public void GetModelList_returnsPart()
    {

      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Part
      {
        Id = 1,
        PartName = "3546",
        PartNumber = "45657",
        StrokeCount = 0,
        Disabled = false
      };
      context.Parts.Add(post);
      context.SaveChanges();

      var repo = new PartRepository(context,usersHelper);
      var response = repo.GetModelList(post.PartNumber);
      Assert.NotNull(response);

    }


    [Fact]
    public void GetPartModelsByPartNumberList_returnParts()
    {
      List<string> partnumberList = new List<string>();
      {
        partnumberList.Add("test");
      }
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Part
      {
        Id = 1,
        PartName = "3546",
        PartNumber = "45657",
        StrokeCount = 0,
        Disabled = false
      };
      context.Parts.Add(post);
      context.SaveChanges();

      var repo = new PartRepository(context, usersHelper);
      var response = repo.GetPartModelsByPartNumberList(partnumberList);
      Assert.NotNull(response);

    }



    [Fact]
    public void GetPartsListByPartNumberList_returnParts()
    {
      List<string> partnumberList = new List<string>();
      {
        partnumberList.Add("test");
      }
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Part
      {
        Id = 1,
        PartName = "3546",
        PartNumber = "45657",
        StrokeCount = 0,
        Disabled = false
      };
      context.Parts.Add(post);
      context.SaveChanges();

      var repo = new PartRepository(context, usersHelper);
      var response = repo.GetPartsListByPartNumberList(partnumberList);
      Assert.NotNull(response);

    }


    [Fact]
    public void GetPartByName_returnParts()
    {
      string partnumberList = "45657";
     
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Part
      {
        Id = 1,
        PartName = "3546",
        PartNumber = "45657",
        StrokeCount = 0,
        Disabled = false
      };
      context.Parts.Add(post);
      context.SaveChanges();

      var repo = new PartRepository(context, usersHelper);
      var response = repo.GetPartByName(partnumberList);
      Assert.NotNull(response);

    }


    [Fact]
    public void GetPartName_returnParts()
    {
      string partnumberList = "test";

      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Part
      {
        Id = 1,
        PartName = "3546",
        PartNumber = "45657",
        StrokeCount = 0,
        Disabled = false
      };
      context.Parts.Add(post);
      context.SaveChanges();

      var repo = new PartRepository(context, usersHelper);
      var response = repo.GetPartName(partnumberList);
      Assert.NotNull(response);

    }



    [Fact]
    public void GetPartById_returnParts()
    {
      int partnumberList = 1;

      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Part
      {
        Id = 1,
        PartName = "3546",
        PartNumber = "45657",
        StrokeCount = 0,
        Disabled = false
      };
      context.Parts.Add(post);
      context.SaveChanges();

      var repo = new PartRepository(context, usersHelper);
      var response = repo.GetPartById(partnumberList);
      Assert.NotNull(response);

    }

    [Fact]
    public void GetPartByIdAsync_returnParts()
    {
      int partnumberList = 22;

      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Part
      {
        Id = 1,
        PartName = "3546",
        PartNumber = "45657",
        StrokeCount = 0,
        Disabled = false
      };
      context.Parts.Add(post);
      context.SaveChanges();

      var repo = new PartRepository(context, usersHelper);
      var response = repo.GetPartByIdAsync(partnumberList);
      Assert.NotNull(response);

    }

    [Fact]
    public void GetPartsAsync_returnParts()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Part
      {
        Id = 1,
        PartName = "3546",
        PartNumber = "45657",
        StrokeCount = 0,
        Disabled = false
      };
      context.Parts.Add(post);
      context.SaveChanges();

      var repo = new PartRepository(context, usersHelper);
      var response = repo.GetPartsAsync();
      Assert.NotNull(response);

    }

    [Fact]
    public void GetCountOfParts()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Part
      {
        Id = 11,
        PartName = "3546",
        PartNumber = "45657",
        StrokeCount = 0,
        Disabled = false
      };
      context.Parts.Add(post);
      context.SaveChanges();

      var repo = new PartRepository(context,usersHelper);
      var response = repo.GetCountOfparts();
      Assert.Equal(response, response);


    }
  }
}
