using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.Tests.Constants;
using CoilTracking.Tests.IntergrationTest;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace CoilTracking.Tests.Repository
{

  public class CoilFieldZoneRepositoryTest
  {
    public readonly IUserHelper usersHelper;
    int Zoneid = 2;
    readonly IDatabaseSetup DatabaseFixture;
    public CoilFieldZoneRepositoryTest()
    {
      DatabaseFixture = new DatabaseFixture();
    }

    /// <summary>
    /// 
    /// </summary>
    [Fact]
    public void CoilFieldZoneRepo_RetunsCoilFieldZone()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilFieldZone
      {
        Id = 2,
        Disabled = true,
        Name = "test",
        Color = "red",
        TextColor = "black",
        CoilField = new CoilField
        {
          Id = 2,
          Name = "test",
          Disabled = true,
          Zones = new List<CoilFieldZone>()
          {
            new CoilFieldZone
            { Id = 4, Name = "Me" }
          }
        }

      };
      context.CoilFieldZones.Add(post);
      context.SaveChanges();
      var repo = new CoilFieldZoneRepository(context,usersHelper);
      var response = repo.GetCoilFieldZones(Zoneid);
      Assert.NotNull(response);
    }


    [Fact]
    public void GetCountOfZone()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilFieldZone
      {
        Id = 2,
        Disabled = true,
        Name = "test",
        Color = "red",
        TextColor = "black",
        CoilField = new CoilField
        {
          Id = 2,
          Name = "test",
          Disabled = true,
          Zones = new List<CoilFieldZone>()
          {
            new CoilFieldZone
            { Id = 4, Name = "Me" }
          }
        }

      };
      context.CoilFieldZones.Add(post);
      context.SaveChanges();
      var repo = new CoilFieldZoneRepository(context,usersHelper);
      var response = repo.GetCountOfCoilFieldZones();
      Assert.Equal(response, response);

    }

    [Fact]
    public void GetAssociatedItemsCoilFielsZone_Id_ReturnsCoilFieldzone()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilFieldZone
      {
        Id = 21,
        Disabled = true,
        Name = "test",
        Color = "red",
        TextColor = "black",
        CoilField = new CoilField
        {
          Id = 4,
          Name = "test1",
          Disabled = true,
          Zones = new List<CoilFieldZone>()
          {
            new CoilFieldZone
            { Id = 4, Name = "Me" }
          }
        }

      };
      context.CoilFieldZones.Add(post);
      context.SaveChanges();
      var repo = new CoilFieldZoneRepository(context,usersHelper);
      var response = repo.GetCoilFieldsZoneByCoilFieldId(4);
      Assert.NotNull(response);

    }

    [Fact]
    public async Task GetCoilFieldZones_RetunsCoilFieldZones()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilFieldZone
      {
        Id = 2,
        Disabled = true,
        Name = "test",
        Color = "red",
        TextColor = "black",
        CoilField = new CoilField
        {
          Id = 2,
          Name = "test",
          Disabled = true,
          Zones = new List<CoilFieldZone>()
          {

            new CoilFieldZone
            { Id = 4, Name = "Me" }
          }
        }

      };
      context.CoilFieldZones.Add(post);
      context.SaveChanges();
      var repo = new CoilFieldZoneRepository(context,usersHelper);
      var response = await repo.GetCoilFieldZones();
      Assert.NotNull(response);

    }

    [Fact]
    public async Task GetCoilFieldZonesById_RetunsCoilFieldZone()
    {
      var ZoneId = 6;
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilFieldZone
      {
        Id = 6,
        Disabled = true,
        Name = "test5",
        Color = "red",
        TextColor = "black",
        CoilField = new CoilField
        {
          Id = 2,
          Name = "test",
          Disabled = true,
          Zones = new List<CoilFieldZone>()
          {
            new CoilFieldZone
            { Id = 4, Name = "Me" }
          }
        }

      };
      context.CoilFieldZones.Add(post);
      context.SaveChanges();
      CoilFieldZoneRepository repo = new CoilFieldZoneRepository(context,usersHelper);
      var response = await repo.GetCoilFieldZoneById(ZoneId);
      Assert.NotNull(repo);

    }

    [Fact]
    public async Task PutCoilFieldZone_ReturnsTrue()
    {
      var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
      var contexts = new DefaultHttpContext();
      var fakeTenantId = "abcd";
      contexts.Request.Headers["Tenant-ID"] = fakeTenantId;
      mockHttpContextAccessor.Setup(_ => _.HttpContext).Returns(contexts);
      //Mock HeaderConfiguration
      var mockHeaderConfiguration = new Mock<IUserHelper>();
      mockHeaderConfiguration
          .Setup(_ => _.GetSubject())
          .Returns(fakeTenantId);
      CoilFieldZone coilFieldZone = new CoilFieldZone()
      {
        Id = 24,
        Name = "Coil Filed Zone Test 1",
        Disabled = false,
        Color="red",
        Plant_Id=1,
        TextColor="blue",
        CoilField = new CoilField()
        {
          Id = 2,
          Name = "Coil Field 1 Test 1",
          Zones = null,
          Disabled = false
        }
      };
      var context = DatabaseFixture.GetDatabaseFixture();
      context.CoilFieldZones.Add(coilFieldZone);
      context.SaveChanges();
      var repo = new CoilFieldZoneRepository(context,mockHeaderConfiguration.Object);
      var response = await repo.UpdateCoilFieldZone(coilFieldZone);
      Assert.True(response);

    }

    [Fact]
    public void DisableCoilFieldZone_IdAnddisable_Returnsbool()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilFieldZone
      {
        Id = 2,
        Name = "Coil Filed Zone Test 1",
        Disabled = false,
        CoilField = new CoilField()
        {
          Id = 2,
          Name = "Coil Field 1 Test 1",
          Zones = null,
          Disabled = false
        }

      };
      context.CoilFieldZones.Add(post);
      context.SaveChanges();
      var repo = new CoilFieldZoneRepository(context,usersHelper);
      var response = repo.DisableCoilFieldZone(2, true);
      Assert.NotNull(response);

    }

    [Fact]
    public async Task AddCoilFieldZone_ReturnsCoilFieldZone()
    {
      var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
      var contexts = new DefaultHttpContext();
      var fakeTenantId = "abcd";
      contexts.Request.Headers["Tenant-ID"] = fakeTenantId;
      mockHttpContextAccessor.Setup(_ => _.HttpContext).Returns(contexts);
      //Mock HeaderConfiguration
      var mockHeaderConfiguration = new Mock<IUserHelper>();
      mockHeaderConfiguration
          .Setup(_ => _.GetSubject())
          .Returns(fakeTenantId);
      CoilFieldZone coilFieldZone = new CoilFieldZone()
      {

        Name = "Coil Filed Zone Test 1",
        Disabled = false,
        CoilField = new CoilField()
        {

          Name = "Coil Field 1 Test 1",
          Zones = null,
          Disabled = false
        }
      };
      var context = DatabaseFixture.GetDatabaseFixture();

      var repo = new CoilFieldZoneRepository(context,mockHeaderConfiguration.Object);
      var response = await repo.AddCoilFieldZone(coilFieldZone);
      Assert.NotNull(response);
    }


  }
}
