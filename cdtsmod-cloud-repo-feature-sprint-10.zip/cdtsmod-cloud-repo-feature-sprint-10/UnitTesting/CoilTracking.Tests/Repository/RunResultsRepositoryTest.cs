using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.Tests.Constants;
using CoilTracking.Tests.IntergrationTest;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using Xunit;

namespace CoilTracking.Tests.Repository
{
  public class RunResultsRepositoryTest
  {
    public readonly IUserHelper usersHelper;
    readonly IDatabaseSetup DatabaseFixture;
    public RunResultsRepositoryTest()
    {
      DatabaseFixture = new DatabaseFixture();
    }


    [Fact]
    public void GetRunResults_RunResults_ReturnsRunResults()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new RunResult
      {
        Id = 1,
        AdcDt = 4,
        BlankCoilTypeName = "",
        Coil = new Coil()
        {
          Id = 7,
          OrderNo = 6,
          IsPriority = true,
          CheckInDate = DateTime.Now,
          SerialNum = "test",
          YNA = "c",
          FTZ = "te",
          OriginalWeight = 1,
          ReturnedToField = DateTime.Now,
          UnAccountedWeight = 9,

          CoilType = new CoilType() { Id = 7, Name = "test", NumCoils = 9 },
          CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white" }
        },
        DownTime = 5,
        DataNumber = 9,
        RunFinished = DateTime.Now,
        Comments = "test",
        ModifiedBy = "A",
        PartNumber = "3",
        RunOrderList = new RunOrderList() { Id = 8, Date = DateTime.Now, PatternLetter = "00", Line = new Line() { Id = 7, Disabled = true, LineName = "", LinePath = "", OPCServer_Id = 88, Plant_Id = 8, Subscribed = true, Tags = "tags", Plant = new Plant() { Id = 5, PlantName = "NAMC", TimeZone = new PlantTimeZone() { Id = 9, Name = "test", TimeZoneOffset = 0 }, } } }

      };
      context.RunResults.Add(post);
      context.SaveChanges();
      var repo = new RunResultsRepository(context,usersHelper);
      var response = repo.GetRunResults();
      Assert.NotNull(response);
      context.Database.EnsureDeleted();
    }

    [Fact]
    public void GetRunResultsByRunResultDtoId_RunResults_ReturnsRunResults()
    {
      int id = 21;
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new RunResult
      {
        Id = 1,
        AdcDt = 4,
        BlankCoilTypeName = "",
        Coil = new Coil()
        {
          Id = 7,
          OrderNo = 6,
          IsPriority = true,
          CheckInDate = DateTime.Now,
          SerialNum = "test",
          YNA = "c",
          FTZ = "te",
          OriginalWeight = 1,
          ReturnedToField = DateTime.Now,
          UnAccountedWeight = 9,

          CoilType = new CoilType() { Id = 7, Name = "test", NumCoils = 9 },
          CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white" }
        },
        DownTime = 5,
        DataNumber = 9,
        RunFinished = DateTime.Now,
        Comments = "test",
        ModifiedBy = "A",
        PartNumber = "3",
        RunOrderList = new RunOrderList() { Id = 8, Date = DateTime.Now, PatternLetter = "00", Line = new Line() { Id = 7, Disabled = true, LineName = "", LinePath = "", OPCServer_Id = 88, Plant_Id = 8, Subscribed = true, Tags = "tags", Plant = new Plant() { Id = 5, PlantName = "NAMC", TimeZone = new PlantTimeZone() { Id = 9, Name = "test", TimeZoneOffset = 0 }, } } }

      };
      context.RunResults.Add(post);
      context.SaveChanges();
      var repo = new RunResultsRepository(context,usersHelper);
      var response = repo.GetRunResultsById(id);
      Assert.NotNull(response);
      context.Database.EnsureDeleted();
    }

    [Fact]
    public void IsRunResultExists_RunResults_ReturnsIsBool()
    {
      int id = 11;
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new RunResult
      {
        Id = 2,
        AdcDt = 4,
        BlankCoilTypeName = "",
        Coil = new Coil()
        {
          Id = 7,
          OrderNo = 6,
          IsPriority = true,
          CheckInDate = DateTime.Now,
          SerialNum = "test",
          YNA = "c",
          FTZ = "te",
          OriginalWeight = 1,
          ReturnedToField = DateTime.Now,
          UnAccountedWeight = 9,

          CoilType = new CoilType() { Id = 7, Name = "test", NumCoils = 9 },
          CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white" }
        },
        DownTime = 5,
        DataNumber = 9,
        RunFinished = DateTime.Now,
        Comments = "test",
        ModifiedBy = "A",
        PartNumber = "3",
        RunOrderList = new RunOrderList() { Id = 8, Date = DateTime.Now, PatternLetter = "00", Line = new Line() { Id = 7, Disabled = true, LineName = "", LinePath = "", OPCServer_Id = 88, Plant_Id = 8, Subscribed = true, Tags = "tags", Plant = new Plant() { Id = 5, PlantName = "NAMC", TimeZone = new PlantTimeZone() { Id = 9, Name = "test", TimeZoneOffset = 0 }, } } },Plant_Id=1

      };
      context.RunResults.Add(post);
      context.SaveChanges();
      var repo = new RunResultsRepository(context,usersHelper);
      repo.IsRunResultExists(id);
      Assert.True(true);
      context.Database.EnsureDeleted();
    }

    [Fact]
    public void GetRunResults_RunResults_ReturnsRunResultsIds()
    {
      List<int> id = new List<int>() { 1 };
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new RunResult
      {
        Id = 1,
        AdcDt = 4,
        BlankCoilTypeName = "",
        Coil = new Coil()
        {
          Id = 7,
          OrderNo = 6,
          IsPriority = true,
          CheckInDate = DateTime.Now,
          SerialNum = "test",
          YNA = "c",
          FTZ = "te",
          OriginalWeight = 1,
          ReturnedToField = DateTime.Now,
          UnAccountedWeight = 9,

          CoilType = new CoilType() { Id = 7, Name = "test", NumCoils = 9 },
          CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white" }
        },
        DownTime = 5,
        DataNumber = 9,
        RunFinished = DateTime.Now,
        Comments = "test",
        ModifiedBy = "A",
        PartNumber = "3",
        RunOrderList = new RunOrderList() { Id = 8, Date = DateTime.Now, PatternLetter = "00", Line = new Line() { Id = 7, Disabled = true, LineName = "", LinePath = "", OPCServer_Id = 88, Plant_Id = 8, Subscribed = true, Tags = "tags", Plant = new Plant() { Id = 5, PlantName = "NAMC", TimeZone = new PlantTimeZone() { Id = 9, Name = "test", TimeZoneOffset = 0 }, } } }

      };
      context.RunResults.Add(post);
      context.SaveChanges();
      var repo = new RunResultsRepository(context,usersHelper);
      var response = repo.GetRunResultIds(id);
      Assert.NotNull(response);
      context.Database.EnsureDeleted();
    }

    [Fact]
    public void GetRunResultId_RunResults_ReturnsRunResultsId()
    {
      int id = 12;
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new RunResult
      {
        Id = 11,
        AdcDt = 4,
        BlankCoilTypeName = "",
        Coil = new Coil()
        {
          Id = 7,
          OrderNo = 6,
          IsPriority = true,
          CheckInDate = DateTime.Now,
          SerialNum = "test",
          YNA = "c",
          FTZ = "te",
          OriginalWeight = 1,
          ReturnedToField = DateTime.Now,
          UnAccountedWeight = 9,

          CoilType = new CoilType() { Id = 7, Name = "test", NumCoils = 9 },
          CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white" }
        },
        DownTime = 5,
        DataNumber = 9,
        RunFinished = DateTime.Now,
        Comments = "test",
        ModifiedBy = "A",
        PartNumber = "3",
        RunOrderList = new RunOrderList() { Id = 8, Date = DateTime.Now, PatternLetter = "00", Line = new Line() { Id = 7, Disabled = true, LineName = "", LinePath = "", OPCServer_Id = 88, Plant_Id = 8, Subscribed = true, Tags = "tags", Plant = new Plant() { Id = 5, PlantName = "NAMC", TimeZone = new PlantTimeZone() { Id = 9, Name = "test", TimeZoneOffset = 0 }, } } }

      };
      context.RunResults.Add(post);
      context.SaveChanges();
      var repo = new RunResultsRepository(context,usersHelper);
      var response = repo.GetRunResultId(id);
      Assert.Null(response);
      context.Database.EnsureDeleted();
    }

    [Fact]
    public void ModifyRunResult_RunResults_Returns()
    {
      var RunResults = new RunResult

      {
        Id = 1,
        AdcDt = 4,
        BlankCoilTypeName = "",
        Coil = new Coil()
        {
          Id = 7,
          OrderNo = 6,
          IsPriority = true,
          CheckInDate = DateTime.Now,
          SerialNum = "test",
          YNA = "c",
          FTZ = "te",
          OriginalWeight = 1,
          ReturnedToField = DateTime.Now,
          UnAccountedWeight = 9,

          CoilType = new CoilType() { Id = 7, Name = "test", NumCoils = 9 },
          CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white" }
        },
        DownTime = 5,
        DataNumber = 9,
        RunFinished = DateTime.Now,
        Comments = "test",
        ModifiedBy = "A",
        PartNumber = "3",
        RunOrderList = new RunOrderList() { Id = 8, Date = DateTime.Now, PatternLetter = "00", Line = new Line() { Id = 7, Disabled = true, LineName = "", LinePath = "", OPCServer_Id = 88, Plant_Id = 8, Subscribed = true, Tags = "tags", Plant = new Plant() { Id = 5, PlantName = "NAMC", TimeZone = new PlantTimeZone() { Id = 9, Name = "test", TimeZoneOffset = 0 }, } } }
      };
      var context = DatabaseFixture.GetDatabaseFixture();
      context.RunResults.Add(RunResults);
      context.SaveChanges();
      var repo = new RunResultsRepository(context,usersHelper);
      repo.ModifyRunResult(RunResults);
      Assert.True(true);
      context.Database.EnsureDeleted();
    }



    [Fact]
    public void SaveChangesRunResult_RunResults_Returns()
    {
      var RunResults = new RunResult
      {
        AdcDt = 4,
        BlankCoilTypeName = "",
        Coil = new Coil()
        {
          Id = 40,
          OrderNo = 6,
          IsPriority = true,
          CheckInDate = DateTime.Now,
          SerialNum = "test",
          YNA = "c",
          FTZ = "te",
          OriginalWeight = 1,
          ReturnedToField = DateTime.Now,
          UnAccountedWeight = 9,
          CoilType = new CoilType() { Name = "test", NumCoils = 6 },
          CoilFieldLocation = new CoilFieldLocation() { Name = "white" }
        },
        DownTime = 5,
        DataNumber = 6,
        RunFinished = DateTime.Now,
        Comments = "test",
        ModifiedBy = "A",
        PartNumber = "3",
        RunOrderList = new RunOrderList() { Id = 28, Date = DateTime.Now, PatternLetter = "00", Line = new Line() { Disabled = true, LineName = "", LinePath = "", OPCServer_Id = 88, Plant_Id = 8, Subscribed = true, Tags = "tags", Plant = new Plant() { PlantName = "NAMC", TimeZone = new PlantTimeZone() { Name = "test", TimeZoneOffset = 0 }, } } }
      };
      var context = DatabaseFixture.GetDatabaseFixture();

      var repo = new RunResultsRepository(context,usersHelper);
      repo.RunResultSaveChanges(RunResults);
      Assert.True(true);
      context.Database.EnsureDeleted();
    }

    [Fact]
    public void GetCoilsToBeWeighed_Coils_ReturnsCoilsToBeWeighed()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new RunResult
      {
        Id = 15,
        AdcDt = 4,
        BlankCoilTypeName = "",
        Coil = new Coil()
        {
          Id = 17,
          OrderNo = 6,
          IsPriority = true,
          CheckInDate = DateTime.Now,
          SerialNum = "test",
          YNA = "c",
          FTZ = "te",
          OriginalWeight = 1,
          ReturnedToField = DateTime.Now,
          UnAccountedWeight = 9,
           Plant_Id =1,
          CoilType = new CoilType() { Id = 7, Name = "test", NumCoils = 9, Plant_Id=1 },
          CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white" }
        },
        DownTime = 5,
        DataNumber = 9,
        RunFinished = DateTime.Now,
        Comments = "test",
        ModifiedBy = "A",
        PartNumber = "3",
        RunOrderList = new RunOrderList() { Id = 8, Plant_Id=1, Date = DateTime.Now, PatternLetter = "00", Line = new Line() { Id = 7, Disabled = true, LineName = "", LinePath = "", OPCServer_Id = 88, Plant_Id = 8, Subscribed = true, Tags = "tags", Plant = new Plant() { Id = 5, PlantName = "NAMC", TimeZone = new PlantTimeZone() { Id = 9, Name = "test", TimeZoneOffset = 0  }, } } }

      };
      context.RunResults.Add(post);
      context.SaveChanges();
      var repo = new RunResultsRepository(context,usersHelper);
      var response = repo.GetCoilsToBeWeighed();
      Assert.NotNull(response);
      context.Database.EnsureDeleted();
    }

    [Fact]
    public void GetRunResultsSearch_Search_ReturnsRunResults()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new RunResult
      {
        Id = 91,
        AdcDt = 4,
        BlankCoilTypeName = "",
        Coil = new Coil()
        {
          Id = 7,
          OrderNo = 6,
          IsPriority = true,
          CheckInDate = DateTime.Now,
          SerialNum = "test",
          YNA = "c",
          FTZ = "te",
          OriginalWeight = 1,
          ReturnedToField = DateTime.Now,
          UnAccountedWeight = 9,

          CoilType = new CoilType() { Id = 7, Name = "test", NumCoils = 9 },
          CoilFieldLocation = new CoilFieldLocation() { Id = 7, Name = "white" }
        },
        DownTime = 5,
        DataNumber = 9,
        RunFinished = DateTime.Now,
        Comments = "test",
        ModifiedBy = "A",
        PartNumber = "3",
        RunOrderList = new RunOrderList() { Id = 8, Date = DateTime.Now, PatternLetter = "00", Line = new Line() { Id = 7, Disabled = true, LineName = "", LinePath = "", OPCServer_Id = 88, Plant_Id = 8, Subscribed = true, Tags = "tags", Plant = new Plant() { Id = 5, PlantName = "NAMC", TimeZone = new PlantTimeZone() { Id = 9, Name = "test", TimeZoneOffset = 0 }, } } }

      };
      context.RunResults.Add(post);
      context.SaveChanges();
      var repo = new RunResultsRepository(context,usersHelper);
      var response = repo.GetRunResultsSearch();
      Assert.NotNull(response);
      context.Database.EnsureDeleted();
    }
  }
}
