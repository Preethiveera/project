
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.Tests.IntergrationTest;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Moq;
using System.Threading.Tasks;
using Xunit;

namespace CoilTracking.Tests.Repository
{
  public class ModelRepositoryTest
  {
    
    readonly IDatabaseSetup DatabaseFixture;
    public readonly IUserHelper usersHelper;
    public ModelRepositoryTest()
    {
      DatabaseFixture = new DatabaseFixture();

    }

    [Fact]
    public void GetCountOfModels()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Model
      {
        Id = 16,
        Name = "3-1-T",
        Disabled = false,
        ModelNumber = "792N"
      };
      context.Models.Add(post);
      context.SaveChanges();

      var modelRepo1 = new ModelRepository(context, usersHelper);

      var Result = modelRepo1.GetCountOfModels();
      Assert.Equal(Result, Result);

    }

    [Fact]
    public async Task GetModels()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Model
      {
        Id = 16,
        Name = "3-1-T",
        Disabled = false,
        ModelNumber = "792N"
      };
      context.Models.Add(post);
      context.SaveChanges();
      var modelRepo = new ModelRepository(context, usersHelper);

      var result = await modelRepo.GetModels();
      Assert.NotNull(result);
      Assert.True(result.Count > 0);

    }

    [Fact]
    public async Task GetModelById()
    {

      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Model
      {
        Id = 16,
        Name = "3-1-T",
        Disabled = false,
        ModelNumber = "792N"
      };
      context.Models.Add(post);
      context.SaveChanges();
      var modelRepo = new ModelRepository(context, usersHelper);

      var result = await modelRepo.GetModelById(16);
      Assert.NotNull(result);

    }

    [Fact]
    public async Task UpdateModel()
    {
      var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
      var contexts = new DefaultHttpContext();
      var fakeTenantId = "abcd";
      contexts.Request.Headers["Tenant-ID"] = fakeTenantId;
      mockHttpContextAccessor.Setup(_ => _.HttpContext).Returns(contexts);
      //Mock HeaderConfiguration
      var mockHeaderConfiguration = new Mock<IUserHelper>();
      mockHeaderConfiguration
          .Setup(_ => _.GetSubject())
          .Returns(fakeTenantId);
      //var model = new Model
      //{
      //  Id = 17,
      //  Name = "Test Model1",
      //  Disabled = false,
      //  ModelNumber = "792N"
      //};

      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Model
      {
        Id = 17,
        Name = "3-1-T",
        Disabled = false,
        ModelNumber = "792N"
      };
      context.Models.Add(post);
      context.SaveChanges();
      var modelRepo = new ModelRepository(context, mockHeaderConfiguration.Object);

      var result = await modelRepo.UpdateModel(post, AuditActionType.ModifyEntity);
      Assert.True(result);

    }

    [Fact]
    public async Task AddModel()
    {
      var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
      var contexts = new DefaultHttpContext();
      var fakeTenantId = "abcd";
      contexts.Request.Headers["Tenant-ID"] = fakeTenantId;
      mockHttpContextAccessor.Setup(_ => _.HttpContext).Returns(contexts);
      //Mock HeaderConfiguration
      var mockHeaderConfiguration = new Mock<IUserHelper>();
      mockHeaderConfiguration
          .Setup(_ => _.GetSubject())
          .Returns(fakeTenantId);
      var model = new Model
      {
        ModelNumber = "5",
        Disabled = false,
        Name = "Test Model Name"
      };
      var context = DatabaseFixture.GetDatabaseFixture();


      var modelRepo = new ModelRepository(context, mockHeaderConfiguration.Object);

      var result = await modelRepo.AddModel(model);
      Assert.True(result);

    }

    [Fact]
    public async Task GetModelByNumber()
    {
      var modelNumber = "792N";

      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new Model
      {
        Id = 16,
        Name = "3-1-T",
        Disabled = false,
        ModelNumber = "792N"
      };
      context.Models.Add(post);
      context.SaveChanges();
      var modelRepo = new ModelRepository(context, usersHelper);

      var result = await modelRepo.GetModelByModelNo(modelNumber);
      Assert.NotNull(result);

    }

    [Fact]
    public async Task DeleteModel()
    {
      var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
      var contexts = new DefaultHttpContext();
      var fakeTenantId = "abcd";
      contexts.Request.Headers["Tenant-ID"] = fakeTenantId;
      mockHttpContextAccessor.Setup(_ => _.HttpContext).Returns(contexts);
      //Mock HeaderConfiguration
      var mockHeaderConfiguration = new Mock<IUserHelper>();
      mockHeaderConfiguration
          .Setup(_ => _.GetSubject())
          .Returns(fakeTenantId);
      var model = new Model
      {
        Id = 900,
        ModelNumber = "792N",
        Disabled = false
      };

      var context = DatabaseFixture.GetDatabaseFixture();

      context.Models.Add(model);
      context.SaveChanges();
      var modelRepo = new ModelRepository(context, mockHeaderConfiguration.Object);
      //var results = await modelRepo.AddModel(model);
      var result = await modelRepo.DeleteModel(model);
      Assert.True(result);

    }
  }
}
