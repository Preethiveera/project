using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.Tests.Constants;
using CoilTracking.Tests.IntergrationTest;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace CoilTracking.Tests.Repository
{
  public class CoilStatusRepositoryTest
  {
    public readonly IUserHelper usersHelper;
    readonly IDatabaseSetup DatabaseFixture;

    public CoilStatusRepositoryTest()
    {
      DatabaseFixture = new DatabaseFixture();
    }



    [Fact]
    public void GetCoilStatus_ReturnsCoilStatuses()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilStatus
      {
        Id = 1,
        Color = "blue",
        Name = "New",
        TextColor = "black",
        InInventory = false,
        IsUsable = true
      };
      context.CoilStatus.Add(post);
      context.SaveChanges();
      CoilStatusRepository coilstatusRepository = new CoilStatusRepository(context,usersHelper);
      var coilstatus = coilstatusRepository.GetCoilStatuses();
      Assert.NotNull(coilstatus);

    }
    [Fact]
    public void GetCoilStatusById_Id_ReturnsCoilStatuses()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilStatus
      {
        Id = 2,
        Color = "blue",
        Name = "New",
        TextColor = "black",
        InInventory = false,
        IsUsable = true
      };
      context.CoilStatus.Add(post);
      context.SaveChanges();
      CoilStatusRepository coilstatusRepository = new CoilStatusRepository(context,usersHelper);
      coilstatusRepository.GetCoilStatusById(2);
      Assert.NotNull(coilstatusRepository);



    }
    [Fact]
    public void GetCoilStatusByIdAsync_Id_ReturnsCoilStatuses()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilStatus
      {
        Id = 3,
        Color = "blue",
        Name = "New",
        TextColor = "black",
        InInventory = false,
        IsUsable = true
      };
      context.CoilStatus.Add(post);
      context.SaveChangesAsync();
      CoilStatusRepository coilstatusRepository = new CoilStatusRepository(context,usersHelper);
      var coilstatus = coilstatusRepository.GetCoilStatusByIdAsync(3);
      Assert.NotNull(coilstatus);



    }
    [Fact]
    public void GetCoilStatusByName_Name_ReturnsCoilStatuses()
    {
      var context = DatabaseFixture.GetDatabaseFixture();
      var post = new CoilStatus
      {
        Id = 1,
        Color = "blue",
        Name = "New",
        TextColor = "black",
        InInventory = false,
        IsUsable = true
      };
      context.CoilStatus.Add(post);
      context.SaveChanges();
      CoilStatusRepository coilstatusRepository = new CoilStatusRepository(context,usersHelper);
      var coilstatus = coilstatusRepository.GetCoilStatusByName("New");
      Assert.NotNull(coilstatus);

    }
  }
}
