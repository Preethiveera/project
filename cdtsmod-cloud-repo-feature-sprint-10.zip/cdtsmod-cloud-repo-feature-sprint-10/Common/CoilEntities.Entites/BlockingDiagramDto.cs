namespace CoilTracking.DTO
{
  public class BlockingDiagramDto
  {
    public int Id { get; set; }
    public int DataNumber { get; set; }
    public string ImagePath { get; set; }
  }
}
