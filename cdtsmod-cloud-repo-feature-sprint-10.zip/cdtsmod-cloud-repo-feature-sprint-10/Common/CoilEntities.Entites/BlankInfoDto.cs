namespace CoilTracking.DTO
{
  public class BlankInfoDto
  {
    public int Id { get; set; }
    public int DataNumber { get; set; }
    public int LineId { get; set; }
    public int PartId { get; set; }
    public int CoilTypeId { get; set; }
    public decimal Pitch { get; set; }
    public int Width { get; set; }
    public decimal Weight { get; set; }
    public int DieNo { get; set; }
    public int StackSize { get; set; }
    public bool Disabled { get; set; }
    /// <summary>
    /// The min pitch allowed for the tolerance
    /// </summary>
    public decimal MinPitch { get; set; }

    /// <summary>
    /// The max pitch allowed for the tolerance
    /// </summary>
    public decimal MaxPitch { get; set; }

    /// <summary>
    /// The min width allowed for the tolerance
    /// </summary>
    public decimal MinWidth { get; set; }

    /// <summary>
    /// The max width allowed for the tolerance
    /// </summary>
    public decimal MaxWidth { get; set; }
    public decimal RewindWeight { get; set; }

    public PartDto part { get; set; }

    public CoilTypeDto CoilType { get; set; }

    public LineDto Line { get; set; }

    public PlantDto Plant { get; set; }
    public int Plant_Id { get; set; }
  }
}
