namespace CoilTracking.DTO
{
  public class PlantTimeZoneDto
  {
    public int Id { get; set; }

    public string Name { get; set; }

    public int TimeZoneOffset { get; set; }
  }
}
