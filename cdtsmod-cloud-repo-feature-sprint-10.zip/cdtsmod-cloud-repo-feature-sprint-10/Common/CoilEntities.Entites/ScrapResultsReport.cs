using System;
using System.ComponentModel.DataAnnotations;

namespace CoilTracking.DTO
{
  public class ScrapResultsReport
  {
    public DateTime Date { get; set; }
    public string Shift { get; set; }
    [Display(Name = "Data#/MSUS#")]
    public int DataNumber { get; set; }
    [Display(Name = "Part#")]
    public string PartNumber { get; set; }
    [Display(Name = "Coil Type")]
    public string CoilType { get; set; }
    [Display(Name = "YN#")]
    public string YNANumber { get; set; }
    [Display(Name = "Coil FTZ")]
    public string FTZ { get; set; }
    [Display(Name = "Blanks Requested")]
    public int BlanksRequested { get; set; }
    [Display(Name = "Strokes")]
    public int PressCount { get; set; }
    [Display(Name = "Blank Count")]
    public int BlanksProduced { get; set; }
    [Display(Name = "Blank Unit Weight")]
    public decimal BlankWeight { get; set; }
    [Display(Name = "Blank Total Weight")]
    public decimal TotalBlankWeight { get; set; }
    [Display(Name = "Coil Weight Before")]
    public decimal WeightBefore { get; set; }
    [Display(Name = "Coil Weight After")]
    public decimal WeightAfter { get; set; }
    [Display(Name = "Blank Scrap (kg)")]
    public decimal BlankScrap { get; set; }
    [Display(Name = "Head/Tail Scrap (kg)")]
    public decimal HeadAndTailScrap { get; set; }
    [Display(Name = "Total Scrap")]
    public decimal TotalScrap { get; set; }
    [Display(Name = "Yield(%)")]
    public decimal Yield { get; set; }
  }
}
