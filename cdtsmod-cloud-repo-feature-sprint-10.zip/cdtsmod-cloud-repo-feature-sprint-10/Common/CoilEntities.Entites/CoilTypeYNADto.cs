using System;

namespace CoilTracking.DTO
{
  public class CoilTypeYNADto
  {
    public int Id { get; set; }

    /// <summary>
    /// The YNA # for the coil type (Such as YNA0144774)
    /// </summary>
    public string YNA { get; set; }

    /// <summary>
    /// The date this YNA was added to the CoilType
    /// </summary>
    public DateTime DateAdded { get; set; }

    /// <summary>
    /// Rather this YNA is disabled or not
    /// </summary>
    public bool Disabled { get; set; }

    /// <summary>
    /// The MaterialType for the YNA
    /// </summary>
    public MaterialTypeDto MaterialType { get; set; }

    public int Plant_Id { get; set; }
  }
}
