using CoilTracking.Data.Models;
using System;

namespace CoilTracking.DTO
{
  public class CoilMoveRequestDto
  {
    public int Id { get; set; }

    public CoilMoveRequestType RequestType { get; set; }

    public LineDto Line { get; set; }

    public CoilDto Coil { get; set; }

    public DateTime Requested { get; set; }

    public DateTime? Fulfilled { get; set; }

    public bool IsCancelled { get; set; }
    public int Plant_Id { get; set; }
  }
}
