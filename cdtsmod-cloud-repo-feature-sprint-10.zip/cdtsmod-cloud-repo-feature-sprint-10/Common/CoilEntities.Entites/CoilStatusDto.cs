namespace CoilTracking.DTO
{
  public class CoilStatusDto
  {
    public int Id { get; set; }
    public string Name { get; set; }
    public string Color { get; set; }
    public string TextColor { get; set; }
    public bool IsUsable { get; set; }
    public bool InInventory { get; set; }
    public bool IsReject { get; set; }

    public int Plant_Id { get; set; }

  }
}
