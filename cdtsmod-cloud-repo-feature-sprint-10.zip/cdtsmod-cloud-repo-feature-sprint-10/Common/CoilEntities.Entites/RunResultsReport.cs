using System;
using System.ComponentModel.DataAnnotations;

namespace CoilTracking.DTO
{
  public class RunResultsReport
  {
    [Display(Name = "Run Start")]
    public DateTime RunStarted { get; set; }
    [Display(Name = "Data#/MSUS#")]
    public int DataNumber { get; set; }
    [Display(Name = "Part#")]
    public string PartNumber { get; set; }
    [Display(Name = "Blanks Requested")]
    public int BlanksRequested { get; set; }
    [Display(Name = "Coil Type")]
    public string CoilType { get; set; }
    [Display(Name = "YN#")]
    public string YNANumber { get; set; }
    [Display(Name = "Coil FTZ")]
    public string FTZ { get; set; }
    [Display(Name = "Thickness")]
    public decimal MeasuredThickness { get; set; }
    [Display(Name = "Width")]
    public int MeasuredWidth { get; set; }
    [Display(Name = "Pitch/Diag")]
    public int MeasuredPitch { get; set; }
    [Display(Name = "Strokes")]
    public int PressCount { get; set; }
    [Display(Name = "Blank Count")]
    public int BlanksProduced { get; set; }
    [Display(Name = "Down Time")]
    public int DownTime { get; set; }
    [Display(Name = "ADC Dt")]
    public int AdcDt { get; set; }
    [Display(Name = "Maintenance Dt")]
    public int MaintDt { get; set; }
    [Display(Name = "Scheduled Dt")]
    public int SchdDt { get; set; }
    [Display(Name = "Tool And Die Dt")]
    public int ToolDieDt { get; set; }
    [Display(Name = "Production Dt")]
    public int ProdDt { get; set; }
    [Display(Name = "Kanban Dt")]
    public int KanbanDt { get; set; }
    [Display(Name = "Tryout Dt")]
    public int TryoutDt { get; set; }
    [Display(Name = "Comments")]
    public string Comments { get; set; }
    [Display(Name = "Coil Weight Before")]
    public decimal WeightBefore { get; set; }
    [Display(Name = "Coil Weight After")]
    public decimal WeightAfter { get; set; }
    [Display(Name = "Run Finished")]
    public DateTime RunFinished { get; set; }
  }
}
