using System.ComponentModel.DataAnnotations;

namespace CoilTracking.DTO
{
  public class PrintResultDto
  {
    public string PalletID { get; set; }

    public int PrintedTagsCount { get; set; }

    [Required]
    public bool Printstatus { get; set; }

    [Required]
    public string Printinfo { get; set; }

    [Required]
    public string Errormessage { get; set; }

    public int TagCount { get; set; }
  }
}
