using System;

namespace CoilTracking.DTO
{
  public class PatternCalendarDto
  {

    public int Id { get; set; }

    public DateTime Date { get; set; }

    public ShiftDto Shift { get; set; }

    public string PatternLetter { get; set; }

    public LineDto Line { get; set; }
    public PlantDto Plant { get; set; }
    public int Plant_Id { get; set; }

  }
}
