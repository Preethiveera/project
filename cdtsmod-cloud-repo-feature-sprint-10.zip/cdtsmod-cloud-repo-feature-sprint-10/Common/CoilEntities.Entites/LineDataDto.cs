using System;
using System.Collections.Generic;

namespace CoilTracking.DTO
{
  public class LineDataDto
  {
    public int Id { get; set; }
    public int LineId { get; set; }
    public string DataUpdate { get; set; }
    public long UpdateTime { get; set; }
    public int Plant_Id { get; set; }
  }

  public class DataUpdateDto
  {
    public int Die { get; set; }
    public bool CoilODWarning { get; set; }
    public bool IsNew { get; set; }
    public Dictionary<string, StackerContainer> StackerVals { get; set; }
    public Dictionary<string, DownTimeContainer> DownTimeVals { get; set; }
  }

  public class StackerContainer
  {
    public string Tag { get; set; }
    public int CurVal { get; set; }
    public int PrevVal { get; set; }
    public int StartVal { get; set; }
  }

  public class DownTimeContainer
  {
    public string Tag { get; set; }
    public bool Flag { get; set; }
    public int Counter { get; set; }
  }
}
