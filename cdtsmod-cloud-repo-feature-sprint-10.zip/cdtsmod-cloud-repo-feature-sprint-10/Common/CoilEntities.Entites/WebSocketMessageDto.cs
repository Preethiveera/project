using System;
using System.Collections.Generic;
using System.Text;

namespace CoilTracking.DTO
{
  public class WebSocketMessageDto
  {
    public WebSocketMessageDto(string action, object payload)
    {
      Action = action;
      Payload = payload;
    }

    public string Action { get; set; }
    public object Payload { get; set; }
  }
}
