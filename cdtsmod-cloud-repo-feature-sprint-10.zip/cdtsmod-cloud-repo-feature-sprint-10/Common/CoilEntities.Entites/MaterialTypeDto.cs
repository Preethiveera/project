namespace CoilTracking.DTO
{
  public class MaterialTypeDto
  {
    public int Id;
    public string Name;
    public string Description;
  }
}
