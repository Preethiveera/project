using System.Collections.Generic;

namespace CoilTracking.DTO
{
  public class ExportDto
  {
    public string LineShift { get; set; }

    public string Shift { get; set; }

    public IEnumerable<string> Calendars { get; set; }

  }
}
