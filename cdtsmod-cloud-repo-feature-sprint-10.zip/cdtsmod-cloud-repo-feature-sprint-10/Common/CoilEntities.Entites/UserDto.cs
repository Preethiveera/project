﻿using System.Collections.Generic;

namespace CoilTracking.DTO
{
  public class UserDto
  {
    public string Subject { get; set; }

    public string Username { get; set; }

    public string Name { get; set; }

    /// <summary>
    /// Only used for updating/creating, not readable
    /// </summary>
    public string Password { get; set; }

    public string Email { get; set; }

    public string EmployeeId { get; set; }

    public string PIN { get; set; }

    public List<RoleDto> Roles { get; set; }

    /// <summary>
    /// Is login allowed
    /// </summary>
    public bool IsLoginAllowed { get; set; }
  }

  public class RoleDto
  {
    /// <summary>
    /// Subject, not there if looking at Roles list on the User
    /// </summary>
    public string Subject { get; set; }

    public string Name { get; set; }

    public bool Enabled { get; set; }
  }
}