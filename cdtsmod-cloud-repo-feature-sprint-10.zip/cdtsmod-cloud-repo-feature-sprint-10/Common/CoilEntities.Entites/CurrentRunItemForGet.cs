using System.Collections.Generic;

namespace CoilTracking.DTO
{
  public class CurrentRunItemForGet
  {
    public int Id { get; set; }
    public int LineId { get; set; }
    public string LineName { get; set; }
    public int SortOrder { get; set; }
    public string PartNumber { get; set; }
    public string YNA { get; set; }
    public string CoilType { get; set; }
    public int CoilTypeId { get; set; }
    public int Quantity { get; set; }
    public int DataNumber { get; set; }
    public int? StackSize { get; set; }
    public int blanksRequested { get; set; }
    public int tagsCount { get; set; }
    public string FTZ { get; set; }
    public List<string> FTZs { get; set; }
  }
}
