﻿namespace CoilTracking.DTO
{
  public class DataImportMessage
  {
    public enum MsgType
    {
      Error,
      Notification,
      ErrorDetails
    }

    public int RowNo { get; set; }

    public string Message { get; set; }

    public string Details { get; set; }

    public MsgType MessageType { get; set; }

    public DataImportMessage(int rowNo, string msg, MsgType type)
    {
      this.RowNo = rowNo;
      this.Message = msg;
      this.MessageType = type;
    }
  }
}
