using System;
using System.Collections.Generic;

namespace CoilTracking.DTO
{
  public class CoilDto
  {
    public int Id;
    public int CoilStatusId;
    public string CoilStatusName;
    public int Plant_Id { get; set; }
    public CoilStatusDto CoilStatus { get; set; }
    public int OrderNo;
    public int CoilTypeId;
    public string CoilTypeName;
    public CoilTypeDto CoilType { get; set; }
    public int ZoneId;
    public int MillId;
    public string MillName;
    public MillDto Mill { get; set; }
    public string SerialNum;
    public int OriginalWeight;
    public string FTZ;
    public string YNA;
    public int CoilFieldLocationId;
    public string CoilFieldLocationName;
    public CoilFieldLocationDto CoilFieldLocation { get; set; }
    public List<CoilRunHistoryDto> CoilRunHistory { get; set; }
    public int CurrentWeight;
    public DateTime CheckInDate;
    public DateTime? BornOnDate;
    public bool IsPriority;
    public int UnAccountedWeight { get; set; }

    public PlantDto Plant { get; set; }
  }
}
