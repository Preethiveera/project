using System;
using System.Collections.Generic;
using System.Text;

namespace CoilTracking.DTO
{
  public class ConnectionModelDto
  {
    public string Id { get; set; }
    public string Domain { get; set; }
    public string Stage { get; set; }
    public string QueryParameters { get; set; }
  }
}
