using System;
using System.Collections.Generic;

namespace CoilTracking.DTO
{
  public class RunOrderListForGet
  {
    public int Id;
    public int LineId;
    public string LineName;
    public int ShiftId;
    public string ShiftName;
    public string PatternLetter;
    public List<RunOrderItemForGet> RunOrderItems;

    //CCDTS-41 : Added date to compare if two run order lists are running on same date
    //to maintain selected runorder item even if blanking lines are changed.
    public DateTime Date;
  }

  public class RunOrderListDto
  {
    public int Id { get; set; }

    public DateTime Date { get; set; }

    public LineDto Line { get; set; }

    public ShiftDto Shift { get; set; }


    public string PatternLetter { get; set; }

    public List<RunOrderListQuantityDto> Quantities { get; set; }

    public PlantDto Plant { get; set; }
    public int Plant_Id { get; set; }
  }

  public class RunOrderItemForGet
  {
    public int Id;
    public int SortOrder;
    public string PartNumber;
    public string ModelList;
    public string YNA;
    public string CoilType;
    public int CoilTypeId;
    public int Quantity;
    public int DataNumber;
    public decimal CoilRemaining;
    public decimal BlankWeight;
    public int StackSize;
    public bool Incomplete;
    public int RequestQueueLength;
    public int StrokeCount; //hari added code on 09052018
    public int BlanksCutCount; //hari added code on 09052018
    public decimal RewindWeight;
    public int DieNo;
  }

  public class RunOrderListForCreate
  {
    public int Id;
    public DateTime Date;
    public int LineId;
    public int ShiftId;
    public string PatternLetter;
    public List<RunOrderItemForCreate> RunOrderItems;
  }

  public class RunOrderListForUpdate
  {
    public int Id;
    public DateTime Date;
    public int LineId;
    public int ShiftId;
    public string PatternLetter;
    public List<RunOrderItemForUpdate> RunOrderItems;
  }

  public class RunOrderItemForCreate
  {
    public int Id;
    public int SortOrder;
    public string PartNumber;
    public string PartName;
    public string ModelList;
    public int RequestQuantity;
    public int OverrideQuantity;
    public List<DataNumberDto> Blanks;
    public bool Incomplete;
    public PlantDto Plant { get; set; }
  }

  public class RunOrderItemDtoComparer : IComparer<RunOrderItemForCreate>
  {
    public int Compare(RunOrderItemForCreate x, RunOrderItemForCreate y)
    {
      if (x == null)
      {
        if (y == null)
        {
          return 0;
        }
        else
        {
          return -1;
        }
      }
      else
      {
        if (y == null)
        {
          return 1;
        }
        else
        {
          int retval = x.SortOrder.CompareTo(y.SortOrder);

          if (retval != 0)
          {
            return retval;
          }
          else
          {
            return x.SortOrder.CompareTo(y.SortOrder);
          }
        }
      }
    }
  }

  public class RunOrderItemForUpdate
  {
    public int Id;
    public int SortOrder;
    public string PartNumber;
    public string PartName;
    public string ModelList;
    public int RequestQuantity;
    public int OverrideQuantity;
    public int DataId;
    public bool Incomplete;
  }

  public class DataNumberDto
  {
    public int Id;
    public int DataNumber;
    public string CoilType;
    public int CoilTypeId;
    public decimal CoilRemaining;
    public decimal BlankWeight;
    public decimal RewindWeight;
    public int StackSize;
  }

  public class IncompleteRunOrderItemDto
  {
    public int Id;
    public int LineId;
    public int RunOrderListId;
    public int RunOrderItemId;
    public string PartNumber;
    public int DataNumber;
    public int SortOrder;
    public int Quantity;
    public int Plant_Id { get; set; }
  }

  public enum RunOrderItemStatusDto
  {
    New = 1,
    Completed = 2,
    Incomplete = 3,
    CarriedOver = 4,
    RunStarted = 5,
    Removed = 6
  }
}
