using System.ComponentModel.DataAnnotations;

namespace CoilTracking.DTO
{
  public class ModelDto
  {
    public int Id { get; set; }

    [Required, MaxLength(25)]
    public string ModelNumber { get; set; }

    [MaxLength(255)]
    public string Name { get; set; }

    public bool Disabled { get; set; }

    public int Plant_Id { get; set; }
  }
}
