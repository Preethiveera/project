namespace CoilTracking.DTO
{
  public class PartModelGroup
  {
    public string PartNumber { get; set; }
    public string ModelNumber { get; set; }
    public string DataNumber { get; set; }
    public string PartName { get; set; }
  }
}
