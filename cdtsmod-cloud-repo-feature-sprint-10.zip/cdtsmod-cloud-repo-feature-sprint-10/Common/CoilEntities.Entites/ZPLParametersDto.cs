namespace CoilTracking.DTO
{
  public class ZPLParametersDto
  {
    public string NamcCode { get; set; }
    public string PalletId { get; set; }
    public string CustomerPartNumber { get; set; }
    public string PartName { get; set; }
    public string Quantity { get; set; }
    public string Line { get; set; }
    public string StampLoc { get; set; }
    public string WeldLoc { get; set; }
    public string palletSequence { get; set; }
    public string TagSerialNumber { get; set; }
    public string HeatTreatDate { get; set; }
    public string HTDText { get; set; }
    public string TemplatesLocation { get; set; }
    public string MaterialType { get; set; }
    public string FTZ { get; set; }
    public int RunOrderItemId { get; set; }
  }
}
