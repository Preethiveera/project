using System;
using System.Collections.Generic;
using System.Text;

namespace CoilTracking.DTO
{
  public class TextMessageDto
  {
    public string ConnectionId { get; set; }
    public string Message { get; set; }
  }
}
