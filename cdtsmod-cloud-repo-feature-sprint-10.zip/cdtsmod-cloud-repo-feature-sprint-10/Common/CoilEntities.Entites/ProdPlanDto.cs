namespace CoilTracking.DTO
{
  public class ProdPlanDto
  {
    public int Id { get; set; }

    public PartDto Part { get; set; }

    public int LotSize { get; set; }

    public int Plant_Id { get; set; }
  }
}
