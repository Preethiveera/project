using System.Net.Mail;

namespace CoilTracking.DTO
{
  public class SendEmailModel
  {
    public MailMessage MailMessage { get; set; }

    public SmtpClient SmtpClient { get; set; }
  }
}
