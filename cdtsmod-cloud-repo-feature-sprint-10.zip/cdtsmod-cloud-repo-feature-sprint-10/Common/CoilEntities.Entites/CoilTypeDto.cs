using System.Collections.Generic;

namespace CoilTracking.DTO
{
  public class CoilTypeDto
  {
    public int Id { get; set; }

    public string Name { get; set; }
    /// <summary>
    /// The Theoretical Width of the coil type (measured in mm)
    /// </summary>
    public int Width { get; set; }

    /// <summary>
    /// The Theoretical Thickness of the coil type (measured in mm)
    /// </summary>
    public decimal Thickness { get; set; }

    /// <summary>
    /// From the BUS list, defines the coil metallurgy
    /// </summary>
    public string Spec { get; set; }

    /// <summary>
    /// The zone Id this CoilType will be placed in.
    /// </summary>
    public int CoilFieldZoneId { get; set; }
    public CoilFieldZoneDto CoilFieldZone { get; set; }
    /// <summary>
    /// The zone name this CoilType will be placed in.
    /// </summary>
    public string CoilFieldZoneName { get; set; }

    /// <summary>
    /// The desired number of coils of this type that should be in the zone at a time + a partial. Not a hard max, more could be placed there.
    /// </summary>
    public int NumCoils { get; set; }

    public bool Disabled { get; set; }

    public decimal Yield { get; set; }

    /// <summary>
    /// The min thickness allowed for the tolerance
    /// </summary>
    public decimal MinThickness { get; set; }

    /// <summary>
    /// The max thickness allowed for the tolerance
    /// </summary>
    public decimal MaxThickness { get; set; }

    /// <summary>
    /// The min width allowed for the tolerance
    /// </summary>
    public decimal MinWidth { get; set; }

    /// <summary>
    /// The max width allowed for the tolerance
    /// </summary>
    public decimal MaxWidth { get; set; }

    /// <summary>
    /// The list of Y #'s associated with this Coil Type
    /// </summary>
    public List<CoilTypeYNADto> CoilTypeYNAs { get; set; }

    /// <summary>
    /// A comma separated value list of YNAs for this coil type
    /// </summary>
    public string CoilTypeYNAsCSVString { get; set; }
    /// <summary>
    ///Material type Name for this coil type
    /// </summary>
    public string MaterialTypeName { get; set; }
    /// <summary>
    ///Material type Id for this coil type
    /// </summary>
    public int MaterialTypeId { get; set; }

    public string NAMC { get; set; }

    public int Plant_Id { get; set; }
  }
}
