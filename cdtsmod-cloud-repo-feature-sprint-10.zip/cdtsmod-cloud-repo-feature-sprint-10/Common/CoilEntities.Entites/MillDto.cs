namespace CoilTracking.DTO
{
  public class MillDto
  {
    public int Id;

    public string Name;

    public bool Disabled;

    public int Plant_Id { get; set; }
  }
}
