using System.Collections.Generic;
using System.Linq;

namespace CoilTracking.DTO
{
  public class PatternExportDto
  {
    public string PatternLetter { get; set; }

    public List<PatternItemDto> Items { get; set; }

    public List<string> ItemsText
    {
      get
      {
        return GetItemText();
      }
    }


    public List<string> GetItemText()
    {
      return Items.Select(pi => $"{pi.PartNumber} : {pi.DataNumber ?? "-"} : {pi.ModelNumber}").ToList();
    }

  }
}

