using System;
using System.ComponentModel.DataAnnotations;

namespace CoilTracking.DTO
{
  public class CoilInventoryReport
  {
    /// <summary>
    /// The CoilType.Name
    /// </summary>

    public string Type { get; set; }

    /// <summary>
    /// The YNA of the coil
    /// </summary>
    [Display(Name = "Y #")]
    public string YNA { get; set; }

    /// <summary>
    /// The CoilStatus.Name
    /// </summary>
    public string Status { get; set; }
    /// <summary>
    /// Part number(s) that this coil produces
    /// </summary>
    [Display(Name = "Part #")]
    public string PartNumbers { get; set; }

    /// <summary>
    /// Model number(s) that this coil produces
    /// </summary>
    [Display(Name = "Models")]
    public string ModelList { get; set; }

    /// <summary>
    /// The Zone-Location such as 1-A2
    /// </summary>
    public string Location { get; set; }

    /// <summary>
    /// The foreign trade zone #
    /// </summary>
    [Display(Name = "FTZ#/MaterialID")]
    public string FTZ { get; set; }

    /// <summary>
    /// The mill
    /// </summary>
    public string Mill { get; set; }

    /// <summary>
    /// The serial # of the coil
    /// </summary>
    [Display(Name = "Serial #")]
    public string Serial { get; set; }

    /// <summary>
    /// Original weight of the coil at checkin
    /// </summary>
    [Display(Name = "Original Weight")]
    public int OriginalWeight { get; set; }

    /// <summary>
    /// Current weight after subtracing run history
    /// </summary>
    [Display(Name = "Current Weight")]
    public int CurrentWeight { get; set; }

    /// <summary>
    /// Datetime of when the coil was checked in/received
    /// </summary>
    public DateTime Received { get; set; }

  }
}
