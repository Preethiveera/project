using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CoilTracking.DTO
{
  public class CoilFieldDto
  {
    public int Id { get; set; }
    public string Name { get; set; }
    public List<int> ZoneId { get; set; }
    public bool Disabled { get; set; }
    public List<CoilFieldZoneDto> Zones { get; set; }
    public int Plant_Id { get; set; }

  }

  public class CoilFieldZoneDto
  {
    public int Id { get; set; }

    [Required]
    [StringLength(25)]
    public string Name { get; set; }

    [StringLength(10)]
    public string Color { get; set; }

    [StringLength(10)]
    public string TextColor { get; set; }

    [Required]
    public int? CoilFieldId { get; set; }
    public List<int> LocationId { get; set; }

    
    public CoilFieldDto CoilField { get; set; }
    
    public List<CoilFieldLocationDto> Locations { get; set; }
    public bool Disabled { get; set; }

    public int Plant_Id { get; set; }
  }

  public class CoilFieldLocationDto
  {
    public int Id { get; set; }
    public string Name { get; set; }
    public int ZoneId { get; set; }
    public bool IsEmpty { get; set; }
    public int Row { get; set; }
    public int Column { get; set; }
    public bool Disabled { get; set; }
    public CoilFieldZoneDto Zone { get; set; }
    public int Plant_Id { get; set; }
  }
}
