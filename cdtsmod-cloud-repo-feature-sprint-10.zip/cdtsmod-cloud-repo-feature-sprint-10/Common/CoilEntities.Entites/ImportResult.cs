﻿using System.Collections.Generic;
using System.Net;

namespace CoilTracking.DTO
{
  public class ImportResult
  {
    public List<DataImportMessage> Messages { get; set; }
    public HttpStatusCode Status { get; set; }

    public ImportResult(List<DataImportMessage> messages, HttpStatusCode code)
    {
      this.Messages = messages;
      this.Status = code;
    }
  }
}