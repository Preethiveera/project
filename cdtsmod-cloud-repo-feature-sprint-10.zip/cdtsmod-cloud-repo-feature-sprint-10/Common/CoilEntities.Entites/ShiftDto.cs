using System;

namespace CoilTracking.DTO
{
  public class ShiftDto
  {
    public int Id { get; set; }
    public string Name { get; set; }
    public TimeSpan Start { get; set; }
    public TimeSpan Finish { get; set; }
    public bool Disabled { get; set; }
    public string BackgroundColor { get; set; }
    public string TextColor { get; set; }

    public int Plant_Id { get; set; }
  }
}
