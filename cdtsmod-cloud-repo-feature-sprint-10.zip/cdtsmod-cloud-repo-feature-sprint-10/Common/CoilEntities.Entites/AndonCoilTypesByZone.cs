﻿using System.Collections.Generic;

namespace CoilTracking.DTO
{
  /// <summary>
  /// The main object with the list of zones and the total columns
  /// </summary>
  public class AndonCoilTypesByZoneDisplayObject
  {
    public List<AndonZone> Zones;
    public int TotalColumns;
  }

  /// <summary>
  /// The individual zone object, with name and max # of coil columns, and the list of coiltypes in the zone
  /// </summary>
  public class AndonZone
  {
    public string Name;
    public int LocationsCount;
    public int LocationsUsedCount;
    public int MaxCoilColumns;
    public string BackgroundColor;
    public string TextColor;
    public List<AndonCoilType> CoilTypes;
    public List<string> OpenPositions;
  }

  /// <summary>
  /// The coil type object with the list of locations with the coil type
  /// </summary>
  public class AndonCoilType
  {
    public string Name;
    public int NumCoils;
    public List<AndonCoilTypeLocation> CoilLocationsInOrder;
    public bool WrongZone;
    public bool Kanban;
  }

  public class AndonCoilTypeLocation
  {
    public string Name;
    public string BackgroundColor;
    public string TextColor;
    public int CoilId;
  }
}