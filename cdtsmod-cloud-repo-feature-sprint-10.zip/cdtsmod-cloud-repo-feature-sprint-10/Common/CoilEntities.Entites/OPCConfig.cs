﻿namespace CoilTracking.DTO
{
  public class OPCConfigDTO
  {

    public int Id { get; set; }

    public string ServerName { get; set; }

    public string InstanceName { get; set; }

    public bool Disabled { get; set; }
  }
}
