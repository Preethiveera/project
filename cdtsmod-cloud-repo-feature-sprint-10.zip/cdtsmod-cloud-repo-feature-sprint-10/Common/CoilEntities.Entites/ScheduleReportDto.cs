﻿namespace CoilTracking.DTO
{
  public class ScheduleReportDto
  {
    public int Id { get; set; }
    public string Email { get; set; }
    public bool CoilReport { get; set; }
    public bool ScrapReport { get; set; }
    public bool RunReport { get; set; }
  }
}
