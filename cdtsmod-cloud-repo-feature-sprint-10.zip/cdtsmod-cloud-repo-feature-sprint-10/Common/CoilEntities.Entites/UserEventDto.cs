using System;
using System.Collections.Generic;
using System.Text;

namespace CoilTracking.DTO
{
  public class UserEventDto
  {
    public int Id { get; set; }

    public string UserName { get; set; }
    public DateTime EventDate { get; set; }

    public UserEventTypeDto EventType { get; set; }
    public int Plant_Id { get; set; }
  }

  /// <summary>
  /// The type of event
  /// </summary>
  public enum UserEventTypeDto
  {
    Login = 1,
    Logout = 2,
  }
}

