using System.Collections.Generic;

namespace CoilTracking.DTO
{
  public class CurrentRunListForGet
  {
    public List<CurrentRunItemForGet> RunOrderItems { get; set; }
  }
}
