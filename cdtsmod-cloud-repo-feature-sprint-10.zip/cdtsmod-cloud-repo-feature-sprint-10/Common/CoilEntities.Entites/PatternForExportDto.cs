using System.Collections.Generic;

namespace CoilTracking.DTO
{
  public class PatternForExportDto
  {
    public string LineName { get; set; }

    public List<PatternExportDto> Patterns { get; set; }

    public List<string> PatternLetters { get; set; }
  }
}
