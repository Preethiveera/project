using System;
using System.Collections.Generic;
using System.Text;

namespace CoilTracking.DTO
{
  public class UpdateDtDto
  {
    public int LineId { get; set; }
    public int DataNum { get; set; }
    public float Adc { get; set; }
    public float Maint { get; set; }
    public float Tooldie { get; set; }
    public float Prod { get; set; }
    public float Kanban { get; set; }
    public float Tryout { get; set; }
    public float Schd { get; set; }
  }
}
