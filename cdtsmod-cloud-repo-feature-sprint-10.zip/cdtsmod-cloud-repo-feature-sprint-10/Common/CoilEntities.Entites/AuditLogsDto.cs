﻿using System;

namespace CoilTracking.DTO
{
  public enum AuditActionTypeDto
  {
    Checkin = 1,
    FulFillRequest = 2,
    CoilMove = 3,
    CoilRequest = 4,
    CoilReturn = 5,
    CoilReject = 6,
    EnableDisable = 7,
    CreateEntity = 8,
    ModifyEntity = 9,
    ModifyPattern = 10,
    ModifyPatternCalendar = 11,
    ModifyRunOrderList = 12,
    CreateRunOrderListByOperator = 13,
    CoilMoveRequest = 14,
    DeleteCoilMoveRequest = 15,
    CancelCoilMoveRequest = 16
  }
  public class AuditLogsDto
  {
    public int Id;

    public string UserName;

    public AuditActionTypeDto ActionType { get; set; }


    public DateTime ActionTime;


    public string Log;
  }
}
