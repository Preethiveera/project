﻿using System;

namespace CoilTracking.DTO
{
  public class CalendarItem
  {
    public int id;
    public DateTime start;
    public DateTime end;
    public string title;
    public bool allDay;
    public int shiftId;
    public int lineId;
    public string shiftName;
  }
}