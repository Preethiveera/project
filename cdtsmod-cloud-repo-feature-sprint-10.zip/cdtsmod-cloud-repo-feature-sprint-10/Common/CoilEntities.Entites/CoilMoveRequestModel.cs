using CoilTracking.Data.Models;

namespace CoilTracking.DTO
{
  public class CoilMoveRequestModel
  {
    public Coil CoilsToMove { get; set; }

    public AuditActionType ActionType { get; set; }
  }
}
