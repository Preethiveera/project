﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CoilTracking.DTO
{
  /// <summary>
  /// The coil checkin model, contains all the fields needed to check in a new coil
  /// </summary>
  public class CoilCheckIn
  {
    /// <summary>
    /// The Order # for the new coil
    /// </summary>
    //[Required(AllowEmptyStrings = false)]
    public int? OrderNo;

    /// <summary>
    /// The YNA # of the new coil
    /// </summary>
    [Required(AllowEmptyStrings = false)]
    public string YNANo;

    /// <summary>
    /// The weight of the new coil
    /// </summary>
    [Required(AllowEmptyStrings = false)]
    public int Weight;

    /// <summary>
    /// The thickness of the new coil
    /// </summary>
    [Required(AllowEmptyStrings = false)]
    public decimal Thickness;

    /// <summary>
    /// The width of the new coil
    /// </summary>
    [Required(AllowEmptyStrings = false)]
    public int Width;

    /// <summary>
    /// The location the coil will be placed
    /// </summary>
    [Required(AllowEmptyStrings = false)]
    public string Location;

    /// <summary>
    /// The FTZ of the coil (Toyota Tsusho #)
    /// </summary>
    [Required(AllowEmptyStrings = false)]
    public string FTZ;

    /// <summary>
    /// The Mill the coil is from
    /// </summary>
    [Required(AllowEmptyStrings = false)]
    public string Mill;

    /// <summary>
    /// The serial number of the coil (or original coil this one was cut down from)
    /// </summary>
    [Required(AllowEmptyStrings = false)]
    public string SerialNum;

    /// <summary>
    /// Determines if this coil is a Priority Coil or not. (Moved in front of non priority in FIFO)
    /// </summary>
    public bool IsPriorityCoil;

    /// <summary>
    /// Applicable for Aluminium coil for prioritization
    /// </summary>
    public DateTime? BornOnDate { get; set; }
  }
}