﻿using System;

namespace CoilTracking.DTO
{
  public class ScrapResultsDto
  {
    public int RunResultId;
    public DateTime Date;
    public int LineId;
    public string Line;
    public int ShiftId;
    public string Shift;
    public int DataNumber;
    public string PartNumber;
    public int CoilTypeId;
    public string CoilType;
    public string YNANumber;
    public string FTZ;
    public int BlanksRequested;
    public int PressCount;
    public int BlanksProduced;
    public decimal BlankWeight;
    public decimal TotalBlankWeight;
    public decimal WeightBefore;
    public decimal WeightAfter;
    public decimal WeightUsed;
    public int ScrapCount;
    public decimal BlankScrap;
    public decimal HeadAndTailScrap;
    public decimal TotalScrap;
    public decimal Yield;
  }
}