using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CoilTracking.DTO
{
  public class PatternDto
  {
    public int Id { get; set; }
    public DateTime CreateDate { get; set; }

    [Required]
    public LineDto Line { get; set; }

    [Required]
    [StringLength(2)]
    public string Name { get; set; }

    public List<PatternItemDto> PatternItems { get; set; }

    public PlantDto Plant { get; set; }
    public int Plant_Id { get; set; }
  }
}
