﻿namespace CoilTracking.DTO
{
  /// <summary>
  /// The data transfer object for the information needed on the BLanking Lines Andon
  /// </summary>
  public class AndonBlankingLinesDto
  {
    /// <summary>
    /// The Line Name
    /// </summary>
    public string Name;

    /// <summary>
    /// The Part Number currently being produced
    /// </summary>
    public string PartNumber;

    /// <summary>
    /// The Part Name currently being produced
    /// </summary>
    public string PartName;

    /// <summary>
    /// The Model for the part being produced
    /// </summary>
    public string Model;

    /// <summary>
    /// The Coil type currently being used
    /// </summary>
    public string Coil;

    /// <summary>
    /// The # of parts requested to be produced
    /// </summary>
    public int PartsRequested;

    /// <summary>
    /// The current # of parts produced
    /// </summary>
    public int PartsProduced;
  }
}