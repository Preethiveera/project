using System;

namespace CoilTracking.DTO
{
  public class RunResultDto
  {
    public int Id { get; set; }
    public int RunOrderListId;
    public string Line;
    public string Shift;
    public DateTime RunStarted;
    public DateTime RunFinished;
    public int DataNumber;
    public string PartNumber;
    public int BlanksRequested;
    public int CoilId;
    public string YNANumber;
    public string FTZ;
    public string CoilType;
    public decimal MeasuredThickness;
    public int MeasuredWidth;
    public int MeasuredPitch;
    public int AdcDt;
    public int MaintDt;
    public int ToolDieDt;
    public int ProdDt;
    public int KanbanDt;
    public int TryoutDt;
    public int SchdDt;
    public int DownTime;
    public string Comments;
    public decimal BlankWeight;
    public decimal BlankPitch;
    public decimal BlankWidth;
    public decimal BlankStackSize;
    public decimal BlankDieNo;
    public int PressCount;
    public int BlanksProduced;
    public decimal WeightBefore;
    public decimal WeightAfter;
    public decimal WeightUsed;
    public decimal CoilCurrentWeight;
    public string ModifiedBy;
    public string BlankCoilTypeName;
    public CoilDto coil;
    public RunOrderListDto runOrderList;
    public PlantDto Plant { get; set; }
    public int Plant_Id { get; set; }
  }
}
