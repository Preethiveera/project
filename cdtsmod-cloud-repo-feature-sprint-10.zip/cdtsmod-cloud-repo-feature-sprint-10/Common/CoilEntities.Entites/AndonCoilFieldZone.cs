﻿using System.Collections.Generic;

namespace CoilTracking.DTO
{
  /// <summary>
  /// The main object holding the list of Zones and the total columns
  /// </summary>
  public class AndonCoilFieldZoneDisplayObject
  {
    public List<AndonCoilFieldZone> Zones;
    public int TotalZoneColumns;
  }

  /// <summary>
  /// The zone object with zone fields and the list of locations for that zone
  /// </summary>
  public class AndonCoilFieldZone
  {
    public string Name;
    public int Rows;
    public int Columns;
    public string BackgroundColor;
    public string TextColor;
    public List<AndonCoilFieldZoneLocation> Locations;
  }

  /// <summary>
  /// The location object with the fields for that location, rather it is empty, and the coil type that is in the location (if any)
  /// </summary>
  public class AndonCoilFieldZoneLocation
  {
    public string Name;
    public int Row;
    public int Column;
    public bool IsEmpty;
    public string BackgroundColor;
    public string TextColor;

    /// <summary>
    /// The Coil Type name of the coil in the location, if any
    /// </summary>
    public string CoilType;
  }
}