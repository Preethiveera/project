﻿namespace CoilTracking.DTO
{
  public class CoilToBeWeighed
  {
    public int RunResultId;
    public int RunOrderListId;
    public int CoilId;
    public string FTZ;
    public string CoilType;
    public string YNA;
    public int OriginalWeight;
    public string Zone;
    public string CoilLocation;
    public int CurrentWeight;
    public int NewWeight;
    public bool AttachedToRunResult;
    public string CoilTypeName;
    public string CoilStatusName;
    public string CoilFieldLocationName;
  }
}