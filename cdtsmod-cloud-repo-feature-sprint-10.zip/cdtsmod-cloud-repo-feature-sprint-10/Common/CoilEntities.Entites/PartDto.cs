namespace CoilTracking.DTO
{
  public class PartDto
  {
    public int Id { get; set; }
    public string PartNumber { get; set; }
    public string PartName { get; set; }
    public bool Disabled { get; set; }
    public string ModelList { get; set; }
    public int StrokeCount { get; set; } //hari added code on 08282018

    public PlantDto Plant { get; set; }
    public int Plant_Id { get; set; }
  }
}
