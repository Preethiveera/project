using System.Net.Mail;

namespace CoilTracking.DTO
{
  public class EmailModel
  {
    public string From { get; set; }

    public string Subject { get; set; }

    public bool IsBodyHtml { get; set; }

    public string Body { get; set; }

    public int Port { get; set; }

    public string Host { get; set; }

    public bool EnableSSL { get; set; }

    public SmtpDeliveryMethod DeliveryMethod { get; set; }
  }
}
