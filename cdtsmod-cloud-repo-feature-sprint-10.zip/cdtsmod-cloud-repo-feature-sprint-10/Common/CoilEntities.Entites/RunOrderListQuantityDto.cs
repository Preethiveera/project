namespace CoilTracking.DTO
{
  public class RunOrderListQuantityDto
  {

    public int Id { get; set; }

    public int SortOrder { get; set; }

    public PartDto Part { get; set; }

    public BlankInfoDto BlankInfo { get; set; }

    public int Quantity { get; set; }

    public int OverrideQty { get; set; }

    public PlantDto Plant { get; set; }
    public int Plant_Id { get; set; }
  }
}
