using System.ComponentModel.DataAnnotations;

namespace CoilTracking.DTO
{
  public class PlantDto
  {

    public int Id { get; set; }

    [Required]
    [MaxLength(200)]
    public string PlantName { get; set; }

    public PlantTimeZoneDto TimeZone { get; set; }

    public string NAMCCode { get; set; }
  }
}
