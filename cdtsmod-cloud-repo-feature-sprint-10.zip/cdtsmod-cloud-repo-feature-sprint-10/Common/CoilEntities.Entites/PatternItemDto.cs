using System.ComponentModel.DataAnnotations;

namespace CoilTracking.DTO
{
  public class PatternItemDto
  {
    public int Id { get; set; }
    [Required]
    public int SortOrder { get; set; }
    [Required]
    [StringLength(50)]
    public string PartNumber { get; set; }
    [Required]
    [StringLength(200)]
    public string ModelNumber { get; set; }
    [StringLength(250)]
    public string PartName { get; set; }
    public string DataNumber { get; set; }
    public PlantDto Plant { get; set; }
    public int Plant_Id { get; set; }
  }
}
