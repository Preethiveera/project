namespace CoilTracking.DTO
{
  public class WebsocketConnectionInfoDto
  {
    public string ConnectionId { get; set; }
    public string[] Groups { get; set; }
  }
}
