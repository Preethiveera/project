namespace CoilTracking.DTO
{
  public class LineDto
  {
    public int Id { get; set; }
    public string LineName { get; set; }
    public int PlantId { get; set; }
    public OPCConfigDTO OPCServer { get; set; }
    public string LinePath { get; set; }
    public string DataNumberTag { get; set; }
    public string DieStrokeTag { get; set; }
    public string Stacker1FrontTag { get; set; }
    public string Stacker1RearTag { get; set; }
    public string Stacker2FrontTag { get; set; }
    public string Stacker2RearTag { get; set; }
    public string CoilODTag { get; set; }
    public string AdcDt { get; set; }
    public string MaintDt { get; set; }
    public string ToolDt { get; set; }
    public string ProdDt { get; set; }
    public string KanbanDt { get; set; }
    public string TryoutDt { get; set; }
    public string SchdDt { get; set; }
    public bool Disabled { get; set; }
    public PlantDto Plant { get; set; }
    public string Tags { get; set; }
    public bool Subscribed { get; set; }
  }
}
