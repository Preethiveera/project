using System;

namespace CoilTracking.DTO
{
  /// <summary>
  /// Coil Inventory data transfer object used for the CoilInventory screen
  /// </summary>
  public class CoilInventoryDto
  {
    /// <summary>
    /// The Coil Id
    /// </summary>
    public int CoilId;

    /// <summary>
    /// The CoilType.Name
    /// </summary>
    public string Type;

    /// <summary>
    /// The YNA of the coil
    /// </summary>
    public string YNA;

    /// <summary>
    /// The CoilStatus.Name
    /// </summary>
    public string Status;

    /// <summary>
    /// The Zone-Location such as 1-A2
    /// </summary>
    public string Location;

    /// <summary>
    /// The foreign trade zone #
    /// </summary>
    public string FTZ;

    /// <summary>
    /// The mill
    /// </summary>
    public string Mill;

    /// <summary>
    /// The serial # of the coil
    /// </summary>
    public string Serial;

    /// <summary>
    /// Original weight of the coil at checkin
    /// </summary>
    public int OriginalWeight;

    /// <summary>
    /// Current weight after subtracing run history
    /// </summary>
    public int CurrentWeight;

    /// <summary>
    /// Part number(s) that this coil produces
    /// </summary>
    public string PartNumbers;
    /// <summary>
    /// ModelList
    /// </summary>
    public string ModelList;

    /// <summary>
    /// Datetime of when the coil was checked in/received
    /// </summary>
    public DateTime Received;
  }
}
