namespace CoilTracking.DTO
{
  public class CoilRunHistoryDto
  {
    public int Id { get; set; }

    public CoilDto Coil { get; set; }

    public RunOrderListDto RunOrderList { get; set; }

    public int WeightUsed { get; set; }
    public PlantDto Plant { get; set; }
    public int Plant_Id { get; set; }
  }
}
