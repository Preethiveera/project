namespace CoilTracking.DTO
{
  public class PatternLetterDto
  {
    public int Id;

    public string Name;

    public string Desc;

    public bool Disabled;
    public int Plant_Id { get; set; }
  }
}
