using System;

namespace CoilTracking.DTO
{
  public class CalendarItemDto
  {
    public int Id { get; set; }
    public DateTime Start { get; set; }
    public DateTime End { get; set; }
    public string Title { get; set; }
    public bool AllDay { get; set; }
    public int ShiftId { get; set; }
    public int LineId { get; set; }
    public string ShiftName { get; set; }
  }
}
