using System.ComponentModel.DataAnnotations;

namespace CoilTracking.DTO
{
  public class PrinterConfigDto
  {
    public int Id { get; set; }

    [Required]
    public string IPAddress { get; set; }

    [Required]
    public int PortNumber { get; set; }

    [Required]
    public string PrinterName { get; set; }

    public string ErrorMessage { get; set; }

    public string NAMCCode { get; set; }

    public int LineId { get; set; }
  }
}
