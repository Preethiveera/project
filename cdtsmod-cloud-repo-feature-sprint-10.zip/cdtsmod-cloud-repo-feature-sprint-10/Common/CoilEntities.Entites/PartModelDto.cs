namespace CoilTracking.DTO
{
  public class PartModelDto
  {
    public int Id { get; set; }

    public PartDto Part { get; set; }

    public ModelDto Model { get; set; }
    public int Plant_Id { get; set; }
  }
}
