using System.Collections.Generic;

namespace CoilTracking.DTO
{
  public class PatternCalendarExportDto
  {
    public List<ExportDto> Data { get; set; }
    public List<string> DateList { get; set; }

  }
}

