using System.Diagnostics.CodeAnalysis;

namespace CoilTracking.Common.Constant
{
  [ExcludeFromCodeCoverage]
  public static class CoilStatusName
  {

    public const string New = "New";
    public const string Partial = "Partial";
    public const string PartialNeedsWeighed = "Partial Needs Weighed";
    public const string CompletelyUsed = "Completely Used";
    public const string RejectedOnHand = "Rejected On Hand";
    public const string RejectedReturned = "Rejected Returned";
    public const string Returned = "Returned";
    public const string LoadedAtLine = "Loaded at Line";
  }
}
