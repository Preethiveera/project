using System.Diagnostics.CodeAnalysis;

namespace CoilTracking.Common.Constants
{
  [ExcludeFromCodeCoverage]
  public static class Constant
  {
    public const string classname = "CLASS_NAME :";
    public const string methodname = "METHOD_NAME :";
    public const string parameters = "PARAM :";
    public const string message = "MESSAGE :";
    public const string countoflines = "COUNT_OF_LINES :";
    public const string Green = "Green";
    public const string White = "White";
    public const string New = "New";
    public const string EX = "X";
    public const string exclamation = " !";
    public const string WHY = "Y";
    public const string RejectedOnHand = "Rejected On Hand";
    public const string Red = "Red";
    public const string Black = "Black";
    public const string TryoutCoils = "Tryout Coils";
    public const string Violet = "Violet";
    public const string Partial = "Partial";
    public const string MinusPR = "-PR";
    public const string Yellow = "Yellow";
    public const string TMMI = "TMMI";
    public const string TMMK = "TMMK";
    public const string FSlash = "/";
    public const string Disabled = "Disabled";
    public const string Zone = "Zone";
    public const string defaultPatternLetter = "X";
    public const string given_name = "given_name";
    public const string Unknown_User = "Unknown User";
    public const string family_name = "family_name";
    public const string sub = "sub";
    public const string tmmiNAMC = "02";
    public const string coilLoaded = "loaded";
    public const string moveRequest = "moveRequest";
    public const string edited = "editing";
    public const string loadedatLine = "Loaded at Line ";
    public const string coilzone = "coilzone";
    public const int CoilStatus = 8;
    public const string coilType = "CoilType";
    public const string OK = "OK";
    public const string NA = "NA";
    public const string zero = "0";
    public const string errornotfound = "404";
    public const string badrequest = "400";
    public const string jpg = ".JPG";
    public const string png = ".PNG";
    public const string Editing = "coilzone";
    public const string locationFormat = "' is not in the correct format. It should be the zone number - location, such as 4-A6";
    public const string location = "Location '";
    public const string locationNotfound = "Could not find a coil location for: ";
    public const string rejected = "Reject";
    public const string validationerrors = " The validation errors are: ";
    public const string supplier = "Supplier";
    public const string other = "Other";
    public const string badRequest = "BadRequest";
    public const string internalServerError = "InternalServerError";
    public const string notfound = "NotFound";
    public const string cloud = "CLOUD";
    public const string Edited = "editing";
    public const string RunOrder = "runorder";
    public const string Pattern = "pattern";
   

    public const string APIerrorMessage = "You Do Not Have Access to CoilTracking API.Please Contact Admin";

    public const string conflict = "Conflict";
    public const string forbidden = "Forbidden";
    public const string PartNo = "PartNo";


    public const string PlantId = "Plant_Id";
    public const string namc = "namc";
    public const string name = "name";

    public const string tmmkcode = "1c7ccbcb2a8ec57e0203beb2bd09c5496fe9d8d9897397c78b082d1647eb652d";
    public const string tmmicode = "7dbfd628bfa93d1a13dd51c02c01495d9e781b0160660a1fea0cadec545fff65";

    public const string partinvalid = "The request is invalid.";



  }
}
