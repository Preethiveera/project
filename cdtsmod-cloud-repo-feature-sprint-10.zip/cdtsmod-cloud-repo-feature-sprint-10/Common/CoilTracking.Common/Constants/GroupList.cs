using System.Collections.Generic;

namespace CoilTracking.Common.Constants
{
  public class RoleGroup
  {
    public int Id { get; set; }
    public string Name { get; set; }
  }

  public class Namc
  {
    public int Id { get; set; }
    public string NAMC { get; set; }
  }

  public static class GroupsList
  {
    public static readonly List<RoleGroup> Groups = new List<RoleGroup>
    {
      //TMMI
        new RoleGroup { Id = 1, Name = "TMMI_CDTS.User" },
        new RoleGroup { Id = 1, Name = "TMMI_CDTS.Admin" },
        new RoleGroup { Id = 1, Name = "TMMI_CDTS.Coilsetter" },
        new RoleGroup { Id = 1, Name = "TMMI_CDTS.Teamleader" },
        new RoleGroup { Id = 1, Name = "TMMI_CDTS.TeamMember" },
        new RoleGroup { Id = 1, Name = "TMMI_CDTS.RunOrderEditor" },

        //TMMK
        new RoleGroup { Id = 2, Name = "TMMK_CDTS.User" },
        new RoleGroup { Id = 2, Name = "TMMK_CDTS.Admin" },
        new RoleGroup { Id = 2, Name = "TMMK_CDTS.Coilsetter" },
        new RoleGroup { Id = 2, Name = "TMMK_CDTS.Teamleader" },
        new RoleGroup { Id = 2, Name = "TMMK_CDTS.TeamMember" },
        new RoleGroup { Id = 2, Name = "TMMK_CDTS.RunOrderEditor" },


  };

    public static readonly List<Namc> Namc = new List<Namc>
    {
        new Namc { Id =1,NAMC ="TMMI" },
        new Namc { Id =2,NAMC ="TMMK" },
    };
  }
}
