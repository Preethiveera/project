using System.Diagnostics.CodeAnalysis;

namespace CoilTracking.Common.Constants
{
  [ExcludeFromCodeCoverage]
  public static class Email
  {
    public const string From = "AdminCCDTS@toyota.com";
    public const string Subject = "Auto-Generated : CDTS Scheduled Report";
    public const string Body = "### Please, do not respond to this email ###. Your opted reports are attached with this mail. Please visit the CDTS site for more information.";
    public const int Port = 25;
    public const string Host = "10.82.48.30";
    public const string FolderName = "CDTSReports";
    public const string RunReport = "Run Results.xlsx";
    public const string ScrapReport = "Scrap Results.xlsx";
    public const string CoilInventoryReport = "Coil Inventory.xlsx";
    public const int Days = 21;
  }
}
