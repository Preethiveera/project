using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace CoilTracking.Common.Constants
{
  [ExcludeFromCodeCoverage]
  public static class PrintTag
  {
    public const string CoilNotLoaded = "Coil not loaded for the current run. Please print after loading coil";

    public const string CoilNotLoadedError = "Error: Coil not loaded";

    public const string PrintUnsuccessful = "Print Unsuccessful. Please contact T/L.";

    public const string BlankPalletTemplateNullError = "Error : Blank Pallet Template is null.";

    public const string PrintSuccessfull = "Print Successful";

    public const string Success = "Success";

    public const string NetworkPrinterError = "Error : Network or Printer issue";

    public const string NAMCPalletError = "Error : NAMC Code / Pallet Id can not be empty. Please contact IS.";
  }
}
