using System.Diagnostics.CodeAnalysis;

namespace CoilTracking.Common.Constants
{
  [ExcludeFromCodeCoverage]
  public static class PrintType
  {
    public const string LostTag = "LostTag";

    public const string Manual = "Manual";

    public const string Automatic = "Automatic";
  }
}
