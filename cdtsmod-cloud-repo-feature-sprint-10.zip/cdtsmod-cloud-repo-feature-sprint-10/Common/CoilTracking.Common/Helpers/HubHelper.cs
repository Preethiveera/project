using CoilTracking.Common.Constants;
using System.Linq;

namespace CoilTracking.Common.Helpers
{
  public static class HubHelper
  {
    public static string[] GetGroups(string namc)
    {
      var namcCode = GroupsList.Namc.FirstOrDefault(x => x.NAMC == namc).Id;
      var groupsByNamc = GroupsList.Groups.Where(x => x.Id == namcCode).Select(x => x.Name).ToArray();
      return groupsByNamc;
    }
  }
}
