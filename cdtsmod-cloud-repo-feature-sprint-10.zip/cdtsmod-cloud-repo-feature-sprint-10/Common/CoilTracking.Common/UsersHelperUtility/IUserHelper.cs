namespace CoilTracking.Common.UsersHelperUtility
{
  public interface IUserHelper
  {
    string GetSubject();
    string GetNAMCCode();

    string GetNamcSecretcode(string namc);
    int GetUsernamcCode();
  }
}
