using CoilTracking.Common.UsersHelperUtility;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CoilTracking.Common.UsersHelperUtility
{
 public class UserHelper : IUserHelper
  {
    private readonly IHttpContextAccessor httpContextAccessor;
    public UserHelper(IHttpContextAccessor httpContextAccessor)
    {
      this.httpContextAccessor = httpContextAccessor;
    }
    /// <summary>
    /// Get UserName
    /// </summary>
    /// <returns></returns>
    public string GetSubject()
    {
      var User = httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(c => c.Type == Constants.Constant.name)?.Value;
      return User;
    }
    /// <summary>
    /// GetNAMCCode
    /// </summary>
    /// <returns></returns>
    public string GetNAMCCode()
    {
      var NAMCs = httpContextAccessor.HttpContext.Request.Headers[Constants.Constant.namc].ToString();
      var namc = GetNamcSecretcode(NAMCs);
      return namc;
    }

    /// <summary>
    /// NAMC code
    /// </summary>
    /// <returns></returns>
    public int GetUsernamcCode()
    {
      var namcCode = httpContextAccessor.HttpContext.Request.Headers[Constants.Constant.namc].ToString();
      var namc = GetNamcSecretcode(namcCode);
      switch (namc)
      {
        case nameof(Namccode.TMMI) :
          int code = Convert.ToInt32(Namccode.TMMI);
          return code;
        case nameof(Namccode.TMMK):
          return Convert.ToInt32(Namccode.TMMI);
        default:
          return 1;
      }
    }

    public enum Namccode
    {
       TMMI =1,
        TMMK=2
    }

    /// <summary>
    /// Get Namc Secret code
    /// </summary>
    /// <param name="namc"></param>
    /// <returns></returns>
    public string GetNamcSecretcode(string namc)
    {
      switch (namc)
      {
        case Constants.Constant.tmmicode:
          return Namccode.TMMI.ToString();
        case nameof(Namccode.TMMK):
          return Namccode.TMMI.ToString();
        default:
          return null;
      }
    }

   
  }
}

