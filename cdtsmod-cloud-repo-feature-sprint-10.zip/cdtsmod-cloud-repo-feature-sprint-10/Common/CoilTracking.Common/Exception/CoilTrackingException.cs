using System;
namespace CoilTracking.Common.Exception
{
  /// <summary>
  /// For logging Custom Application Exceptions
  /// </summary>
  public class CoilTrackingException : ApplicationException
  {
    /// <summary>
    /// 
    /// </summary>
    /// <param name="message"></param>
    public CoilTrackingException() : base()
    {
    }

    public CoilTrackingException(string message) : base(message)
    {
      ErrorMessage = message;
    }

    public string ApplicationName { get { return "CDTS"; } }
    public string ErrorMessage { get; set; }
    public string ErrorNumber { get; set; }
    public string HttpStatusCode { get; set; }
  }
}
