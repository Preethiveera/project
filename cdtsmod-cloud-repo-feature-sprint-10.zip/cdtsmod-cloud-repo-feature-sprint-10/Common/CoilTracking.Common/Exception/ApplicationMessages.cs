using System.Diagnostics.CodeAnalysis;

namespace CoilTracking.Common.Exception
{
  [ExcludeFromCodeCoverage]
  public static class ApplicationMessages
  {
    public const string defaultPatternExists = "Default pattern X already exists. Please enter a different pattern name.";
    public const string editingMessageForPatternLetter = "Pattern letter already exists. Please use edit function to update.";
    public const string editRunResults = "editRunResults data is null";
    public const string RunResultsSearch = "Results data is null";
    public const string RunOrderRunResult = "Results data is null";
    public const string disableBlankInfo = "Cannot disable a data # that is scheduled on a Run Order";
    public const string returnWeightRunResults = "Results data is null";
    public const string updateCurrentWeight = "Missing data/id/partial";
    public const string scheduleReportExists = "Email already exists.";
    public const string invalidEmailAddress = "Email address is invalid.";
    public const string InvalidrunOrderListQuantityID = "RunOrderListQuantity IDs are not Matched";
    public const string RunOrderListQuantityNotFound = "RunOrderListQuantity is Null";
    public const string disableCoilFieldMsg = "Cannot disable this CoilField because a coil is currently located there.";
    public const string coilTypeAssociation = "coilTypeAssociation count greater than Zero";
    public const string originalCoilType = "originalCoilType is null";
    public const string uploadLimitException = "Maximum 200 images can be uploaded at once";
    public const string coilTypeName = "A Coil Type with name ";
    public const string alreadyexists = " already exists in the system.";
    public const string invalidMsus = " is not a valid Data#MSUS#";
    public const string nullPatternLetter = "Pattern Letter cannot be null";
    public const string uploadError = "Error in upload process. ";
    public const string newBlockingDiagram = "New Blocking diagram added";
     public const string partUnavailable = "Could not find a Part in the database matching part number in the pattern: ";
    public const string deleteMessageForRunOrderList = "Cannot delete a Run Order List that has Coil Run Histories attached to it.";
    public const string deleteMsgRunOrderListForRunResult = "Cannot delete a Run Order List that has Run Results attached to it.";
    public const string coilExistAtCoilLocation = "Cannot disable this location because a coil is currently located there.";
    public const string blockingDiagramExist = "Blocking diagram already exists for this Data Number.";
    public const string blockingUpdateErr = "Cannot update Data Number.";

    public const string completed = "Completed";
    public const string runOrderListExist = "Run Order List and Items must be present";
    public const string CoilTypeY = "Coil Type Y # ";
    public const string existingCoilType = "already exists in the system. Please remove it from this Coil Type, or disable it on the existing Coil Type.";
    public const string runOrderListHasDataNum = "Please make sure all Run Order Items have Data #s associated with them.";


    public const string coilFiledZonesNotFound = "Coil Field Zones not found.";
    public const string coilFiledZoneNotFound = "Coil field zone not found.";

    public const string disableCoilFieldZoneMsg = "Cannot disable this Zone because a coil is currently located there.";

    public const string errorMessageForPatternCalendar = "Could not find a Pattern Calendar entry to use for selected date/line/shift. Please set one up on the ";

    public const string errorMessageForPatterns = "Could not find a pattern to use for selected date/line/shift/pattern. Please create the ";
    public const string partNotFoundForBlanks = "Could not find a BlankInfo for part #: ";

    public const string disableCoilFieldZoneLocatedMsg = "Cannot disable this Zone because a coil is currently located there.";

    public const string moveRequestNotFound = "Unable to find a move request with id: ";
    public const string coilTypeNotFound = "Unable to find a coil type with ID: ";
    public const string CoilIdNotFound = "For a Coil Return or Coil Reject you must pass the coilId you are returning/rejecting.";
    public const string validLocationNotFound = "You must specify a valid new location for the coil, such as 1-A1";
    public const string specifyValidZoneName = "You must specify a valid zone name";
    public const string specifyValidLocation = "You must specify a valid location";
    public const string locationNotEmpty = "The specified location is not empty!";
    public const string unableToUseCoil = "Unable to find a coil to use of type: ";
    public const string invalidWeight = "Please enter a valid number for the new coil weight.";
    public const string coilPrefix = "coil is NULL";

    public const string patternCalendarNotFound = "Pattern Calendar not found.";

    public const string coilNotFound = "Coil not found.";

    public const string AndonCoilsFeildsByZoneId = "AndonCoils is Null";
    public const string defaultMsgForBlockingDiagram = "Blocking diagram already exists for this Data Number. Please use edit function to update.";

    public const string patternNotFound = "Pattern not found.";

    public const string modelNotFound = "Model not found.";
    public const string noPartInfo = "Part is Null ";
    public const string modelExistModelNumber = "Another model with same Model Number exists. Please use Edit function to update.";

    public const string coilEmptyFTZ = "Empty FTZ for Coil not allowed";

    public const string coiltypenotfound = "Could not find a coil type for Y#: ";
    public const string existsbutisdisabled = " Y# Exists but is disabled.";

    public const string coilstatusnotfound = "Could not find a coil status for 'New'";

    public const string coillocationnotcorrectformat = "' is not in the correct format. It should be the zone number - location, such as 4-A6";

    public const string newlocation = "New location '";

    public const string couldnotfindacoillocation = "Could not find a coil location for: ";

    public const string location = "Location: ";
    public const string isnotempty = " is not empty!";
    public const string millisdisabled = "Mill is disabled, Checking in coils from this Mill is not allowed: ";
    public const string coildidnotfoundmatch = "Could not find a coil matching Id: ";
    public const string coilstatusmatchnotfound = "Could not find a coil status matching Id: ";

    public const string newstatus = "New status ";
    public const string returntosupplier = " Is not allowed for return to supplier.";
    public const string lineisnull = "You must select a line to change status to Loaded at Line.";
    public const string lineNotFound = "Could not find a line with Id: ";
    public const string partsalreadyexsit = "Another part with same Part Number exists. Please use Edit function to update.";
    public const string duplicateErrForMillsupdate = "Cannot insert duplicate key row in object 'dbo.Mills' with unique index 'IX_Name'. ";
    public const string Partnumbervalid = "Part is Null , Part number not found";

    public const string deleteInternalserverError = "Internal Server Error An error occurred while saving entities that do not expose foreign key properties for their relationships. The EntityEntries property will return null because a single entity cannot be identified as the source of the exception. Handling of exceptions while saving can be made easier by exposing foreign key properties in your entity types. See the InnerException for details. An error has occurred.";
    public const string validationMsgForDataNum = "Validation failed for one or more entities. The validation errors are: The field Data#/MSUS# must be an integer with a maximum length of '9'.";
    public const string valueTooLong= "Value was either too large or too small for an Int32.";
  }
}
