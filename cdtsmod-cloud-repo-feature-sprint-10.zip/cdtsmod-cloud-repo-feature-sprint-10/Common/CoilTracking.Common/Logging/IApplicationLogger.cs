﻿namespace CoilTracking.Common.Logging
{
  /// <summary>
  /// 
  /// </summary>
  /// <typeparam name="T"></typeparam>
  public interface IApplicationLogger<T>
  {
    /// <summary>
    /// 
    /// </summary>
    /// <param name="Message"></param>
    /// <param name="properties"></param>
    void LogInformation(string Message, params object[] properties);
    /// <summary>
    /// 
    /// </summary>
    /// <param name="Message"></param>
    /// <param name="properties"></param>
    void LogError(string Message, params object[] properties);
    /// <summary>
    /// 
    /// </summary>
    /// <param name="Message"></param>
    /// <param name="properties"></param>
    void LogCritical(string Message, params object[] properties);
    /// <summary>
    /// 
    /// </summary>
    /// <param name="Message"></param>
    /// <param name="properties"></param>
    void LogWarning(string Message, params object[] properties);
    /// <summary>
    /// 
    /// </summary>
    /// <param name="Message"></param>
    /// <param name="properties"></param>
    void LogTrace(string Message, params object[] properties);
    /// <summary>
    /// 
    /// </summary>
    /// <param name="Message"></param>
    /// <param name="properties"></param>
    void LogDebug(string Message, params object[] properties);

  }
}
