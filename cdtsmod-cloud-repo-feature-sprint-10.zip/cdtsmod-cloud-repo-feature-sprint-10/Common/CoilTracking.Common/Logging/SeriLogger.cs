using Microsoft.Extensions.Logging;
using System.Diagnostics.CodeAnalysis;

namespace CoilTracking.Common.Logging
{
  [ExcludeFromCodeCoverage]
  /// <summary>
  /// Logging using Serilog
  /// </summary>
  /// <typeparam name="T"></typeparam>
  public class SeriLogger<T> : IApplicationLogger<T>
  {
    private ILogger Logger { get; set; }

    public SeriLogger(ILogger<T> logger)
    {
      Logger = logger;

    }

    /// <summary>
    /// Logging informational level throught application
    /// </summary>
    /// <param name="Message"></param>
    /// <param name="properties"></param>
    public void LogInformation(string Message, params object[] properties)
    {
      Logger.LogInformation(Message, properties);
    }

    /// <summary>
    /// Logging errors throughout application
    /// </summary>
    /// <param name="Message"></param>
    /// <param name="properties"></param>
    public void LogError(string Message, params object[] properties)
    {
      Logger.LogError(Message, properties);

    }
    /// <summary>
    /// Logging Critical errors throughout application
    /// </summary>
    /// <param name="Message"></param>
    /// <param name="properties"></param>
    public void LogCritical(string Message, params object[] properties)
    {
      Logger.LogCritical(Message, properties);

    }
    /// <summary>
    /// Logging Warning  throughout application
    /// </summary>
    /// <param name="Message"></param>
    /// <param name="properties"></param>
    public void LogWarning(string Message, params object[] properties)
    {
      Logger.LogWarning(Message, properties);

    }
    /// <summary>
    /// Logging trace  throughout application
    /// </summary>
    /// <param name="Message"></param>
    /// <param name="properties"></param>
    public void LogTrace(string Message, params object[] properties)
    {
      Logger.LogTrace(Message, properties);

    }
    /// <summary>
    /// Logging error  throughout application
    /// </summary>
    /// <param name="Message"></param>
    /// <param name="properties"></param>
    public void LogDebug(string Message, params object[] properties)
    {
      Logger.LogDebug(Message, properties);

    }

  }
}
