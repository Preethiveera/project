using Amazon.Extensions.NETCore.Setup;
using AutoMapper;
using CoilTracking.Business.Implementation;
using CoilTracking.Common.Constants;
using CoilTracking.Data;
using CoilTracking.Data.Models;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Extensions;
using CoilTracking.WebAPI.Filters;
using CoilTracking.WebAPI.Middlewares;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Logging;
using StackExchange.Redis;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using System.Text.Json;

namespace CoilTracking.WebAPI
{
  [ExcludeFromCodeCoverage]
  public class Startup
  {
    public Startup(IConfiguration configuration)
    {
      Configuration = configuration;

    }
    public IConfiguration Configuration { get; }
    // This method gets called by the runtime. Use this method to add services to the container.
    public void ConfigureServices(IServiceCollection services)
    {
      var redis = ConnectionMultiplexer.Connect("master.websocket-redis-4.p5mqis.usw2.cache.amazonaws.com:6379,ssl=true");
      services.AddSingleton<IConnectionMultiplexer>(redis);

      IdentityModelEventSource.ShowPII = true;

      ConfigureServiceCollection(services);
      services.AddAntiforgery(options =>
      { // Set Cookie properties using CookieBuilder properties†.
        options.FormFieldName = "AntiforgeryFieldname";
        options.HeaderName = "X-CSRF-TOKEN-HEADERNAME";
        options.SuppressXFrameOptionsHeader = false;
      });
      services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
       .AddJwtBearer(options =>
       {
         options.Audience = Configuration["azuread-audience"];
         options.Authority = $"{Configuration["azuread-instance"]}{Configuration["azuread-tennat-id"]}";
         options.Events = new JwtBearerEvents
         {
           OnMessageReceived = async context =>
           {
             var path = context.HttpContext.Request.Path;

             if (path.StartsWithSegments("/api/Notification/connect"))
             {
               string body = "";
               try
               {
                 context.Request.EnableBuffering();
                 var buffer = new byte[Convert.ToInt32(context.Request.ContentLength)];
                 await context.Request.Body.ReadAsync(buffer, 0, buffer.Length);
                 body = Encoding.UTF8.GetString(buffer);
                 var options = new JsonSerializerOptions
                 {
                   PropertyNameCaseInsensitive = true
                 };
                 var connectiondto = JsonSerializer.Deserialize<ConnectionModelDto>(body, options);

                 var queryParams = connectiondto.QueryParameters.Split(',');

                 var accessToken = queryParams[0].Contains("accessToken") ? queryParams[0].Split('=')[1] : null;
                 var token = accessToken;
                 context.Token = token;
               }
               finally
               {
                 context.Request.Body.Position = 0;
               }
             }
           }
         };
       }
       );
      services.AddAuthorization(options =>
      {
        options.FallbackPolicy = new AuthorizationPolicyBuilder()
            .RequireAuthenticatedUser()
            .Build();

        // Register other policies here
      });
      services.AddScoped<CustomActionFilter>();
      services.AddControllersWithViews();
      services.AddMvc()

  .ConfigureApiBehaviorOptions(options =>
  {
    options.SuppressModelStateInvalidFilter = true;
  });
    }
    public void ConfigureServiceCollection(IServiceCollection services)
    {
      ///Get ConnectionString from AWS KeyManager
      string CDTSConnectionString = "";
      var conn = new ConnectionDetails();
      var secret = new SecretsManager();
      var source = Configuration["ConnectionSource:source"];
      if (source == Constant.cloud)
      {
        var secretName = Configuration["connectionsource-key"];
        AWSOptions awsoptions = Configuration.GetAWSOptions();
        var secrets = secret.GetSecret(secretName, awsoptions);
        //Build ConnectionString
        CDTSConnectionString = conn.GetConnectionstring(secrets);
        services.AddDbContext<CoilTrackingContext>(opts => opts.UseSqlServer(CDTSConnectionString));
      }
      else
      {
        //Local ConnectionString
        services.AddDbContext<CoilTrackingContext>(opts => opts.UseSqlServer(Configuration.GetConnectionString("CDTSConnectionString")));
      }
      services.AddDependencyInjection();

      var appSettingsSection = Configuration.GetSection("ServiceConfiguration");
      services.Configure<BlockingDiagramConfiguration>(appSettingsSection);
      var appSettingsSectionForPLC = Configuration.GetSection("PLCIntegrationURLS");
      services.Configure<PLCIntegrationURLS>(appSettingsSectionForPLC);

      /// var appSettingsForPLCAzureAD = Configuration.GetSection("PLCAzureAd");
      /// services.Configure<PLCAzureAd>(appSettingsForPLCAzureAD);

      services.AddHttpContextAccessor();
      Action<Secret> SecretOptions = (opt =>
      {
        opt.CDTS_ConnectionString = CDTSConnectionString;
      });
      services.Configure(SecretOptions);
      services.AddSingleton(resolver => resolver.GetRequiredService<IOptions<Secret>>().Value);
      var mapperConfig = new MapperConfiguration(mc =>
      {
        mc.AddProfile(new MappingProfile());
      });
      IMapper mapper = mapperConfig.CreateMapper();
      services.AddSingleton(mapper);

      services.AddControllers().AddNewtonsoftJson(x => { x.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore; x.UseMemberCasing(); });
      services.AddControllers().AddJsonOptions(options =>
      {
        // Use the default property (Pascal) casing.
        options.JsonSerializerOptions.PropertyNamingPolicy = null;
      });
    }

    // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
    public void Configure(IApplicationBuilder app, IWebHostEnvironment env, IAntiforgery antiforgery)
    {
      if (env.IsDevelopment())
      {
        app.UseDeveloperExceptionPage();
      }
      app.UseCors(builder =>
      {
        builder.WithOrigins(Configuration.GetSection("AppSettings").GetSection("AllowOrigin").Value.Split(",")).SetIsOriginAllowedToAllowWildcardSubdomains().AllowAnyHeader().AllowAnyMethod();
      });
      app.UseAuthentication();
      app.Use(next => context =>
      {
        return next(context);
      });
      app.UseMiddleware(typeof(ExceptionMiddleware));
      app.UseMiddleware(typeof(CustomResponseHeaderMiddleware));
      app.UseAntiXssMiddleware();
      app.UseRouting();
      app.UseCors();
      app.UseAuthorization();

      app.UseEndpoints(endpoints =>
      {
        endpoints.MapControllers();
      });
    }
  }
}
