using Amazon.Extensions.NETCore.Setup;
using Amazon.SecretsManager;
using Amazon.SecretsManager.Model;
using System;
using System.Diagnostics.CodeAnalysis;
using System.IO;

namespace CoilTracking.WebAPI.Extensions
{
  [ExcludeFromCodeCoverage]
  public class SecretsManager : ISecretsManager
  {
    /// <summary>
    /// Get Secret
    /// </summary>
    /// <param name="Name"></param>
    /// <returns></returns>
    public string GetSecret(string Name, AWSOptions awsoptions)
    {
      string secretName = Name;

      string secret = "";
      MemoryStream memoryStream = null;

      IAmazonSecretsManager client = new AmazonSecretsManagerClient(awsoptions.Region);
      GetSecretValueRequest request = new GetSecretValueRequest();
      request.SecretId = secretName;
      request.VersionStage = "AWSCURRENT"; // VersionStage defaults to AWSCURRENT if unspecified.
      GetSecretValueResponse response = null;

      // In this sample we only handle the specific exceptions for the 'GetSecretValue' API.
      // See https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
      // We rethrow the exception by default.


      try
      {
        response = client.GetSecretValueAsync(request).Result;
        Console.WriteLine("Got Access Key");
      }
      catch (DecryptionFailureException ex)
      {
        Console.WriteLine(ex.Message);
        // Secrets Manager can't decrypt the protected secret text using the provided KMS key.
        // Deal with the exception here, and/or rethrow at your discretion.
        throw;
      }
      catch (InternalServiceErrorException e)
      {
        Console.WriteLine(e.Message);
        // An error occurred on the server side.
        // Deal with the exception here, and/or rethrow at your discretion.
        throw;
      }
      catch (InvalidParameterException e)
      {
        Console.WriteLine(e.Message);
        // You provided an invalid value for a parameter.
        // Deal with the exception here, and/or rethrow at your discretion
        throw;
      }
      catch (InvalidRequestException e)
      {
        Console.WriteLine(e.Message);
        // You provided a parameter value that is not valid for the current state of the resource.
        // Deal with the exception here, and/or rethrow at your discretion.
        throw;
      }
      catch (ResourceNotFoundException e)
      {
        Console.WriteLine(e.Message);
        // We can't find the resource that you asked for.
        // Deal with the exception here, and/or rethrow at your discretion.
        throw;
      }
      catch (AggregateException ae)
      {
        Console.WriteLine(ae.Message);
        // More than one of the above exceptions were triggered.
        // Deal with the exception here, and/or rethrow at your discretion.
        throw;

      }

      // Decrypts secret using the associated KMS CMK.
      // Depending on whether the secret is a string or binary, one of these fields will be populated.
      if (response.SecretString != null)
      {
        secret = response.SecretString;
      }
      else
      {
        memoryStream = response.SecretBinary;
        StreamReader reader = new StreamReader(memoryStream);
        string decodedBinarySecret = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(reader.ReadToEnd()));
      }
      return secret;
    }







  }

}
