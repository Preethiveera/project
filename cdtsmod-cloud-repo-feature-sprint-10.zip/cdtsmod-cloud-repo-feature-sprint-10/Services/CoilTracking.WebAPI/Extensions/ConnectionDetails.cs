using Newtonsoft.Json;
using System.Diagnostics.CodeAnalysis;

namespace CoilTracking.WebAPI.Extensions
{
  [ExcludeFromCodeCoverage]
  public class ConnectionDetails
  {
    public string username { get; set; }
    public string password { get; set; }
    public int port { get; set; }
    public string engine { get; set; }
    public string host { get; set; }
    public string dbname { get; set; }
    public string dbInstanceIdentifier { get; set; }

    public string GetConnectionstring(string secret)
    {
      ConnectionDetails connection = JsonConvert.DeserializeObject<ConnectionDetails>(secret);
      return $"Data Source={connection.host},{connection.port};Database={connection.dbname};MultipleActiveResultSets=true;User Id={connection.username};Password={connection.password}";

    }
  }


}
