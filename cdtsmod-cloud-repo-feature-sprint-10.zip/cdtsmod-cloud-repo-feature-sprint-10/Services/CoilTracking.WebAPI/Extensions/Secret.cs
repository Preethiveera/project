using System.Diagnostics.CodeAnalysis;

namespace CoilTracking.WebAPI.Extensions
{
  [ExcludeFromCodeCoverage]
  public class Secret
  {
    public string CDTS_ConnectionString { get; set; }
  }
}
