using Amazon.S3;
using CoilTracking.Business.Implementation;

using CoilTracking.Business.Implementation.CoilMoveRequest;
using CoilTracking.Business.Implementation.EmailService;
using CoilTracking.Business.Implementation.Lines;
using CoilTracking.Business.Interfaces;
using CoilTracking.Business.Interfaces.BlockingDiagrams;
using CoilTracking.Business.Interfaces.EmailService;
using CoilTracking.Business.Interfaces.Lines;
using CoilTracking.Business.Kentucky;
using CoilTracking.Business.TMMI;
using CoilTracking.Common.Logging;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.DataAccess;
using CoilTracking.DataAccess.Implementation;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting.Internal;
using System.Diagnostics.CodeAnalysis;

namespace CoilTracking.WebAPI.Extensions
{
  [ExcludeFromCodeCoverage]
  public static class DependencyInitializer
  {
    public static IServiceCollection AddDependencyInjection(this IServiceCollection services)
    {
      services.AddTransient(typeof(IApplicationLogger<>), typeof(SeriLogger<>));
      services.AddTransient(typeof(ILineService), typeof(LineService));
      services.AddTransient(typeof(IAndonService), typeof(AndonService));
      services.AddTransient(typeof(IAuditLogsService), typeof(AuditLogsService));
      services.AddTransient(typeof(IRunResultService), typeof(RunResultService));
      services.AddTransient(typeof(ICoilFieldRepository), typeof(CoilFieldRepository));
      services.AddTransient(typeof(ILineRepository), typeof(LineRepository));
      services.AddTransient(typeof(IPlantsRepository), typeof(PlantsRepository));
      services.AddTransient(typeof(IBlankInfoesRepository), typeof(BlankInfoesRepository));
      services.AddTransient(typeof(ICoilFieldLocationRepository), typeof(CoilFieldLocationRepository));
      services.AddTransient(typeof(ICoilFieldZoneRepository), typeof(CoilFieldZoneRepository));
      services.AddTransient(typeof(ICoilRepository), typeof(CoilRepository));
      services.AddTransient(typeof(ICoilTypeRepository), typeof(CoilTypeRepository));
      services.AddTransient(typeof(IRunResultsRepository), typeof(RunResultsRepository));
      services.AddTransient(typeof(IAuditLogsRepository), typeof(AuditLogsRepository));
      services.AddTransient(typeof(IPatternLetterService), typeof(PatternLetterService));
      services.AddTransient(typeof(IPatternLetterRepository), typeof(PatternLetterRepository));
      services.AddTransient(typeof(IPatternCalendarRepository), typeof(PatternCalendarRepository));
      services.AddTransient(typeof(IPatternsRepository), typeof(PatternsRepository));
      services.AddTransient(typeof(IRunOrderRepository), typeof(RunOrderRepository));
      services.AddTransient(typeof(IRunOrderListService), typeof(RunOrderListService));
      services.AddTransient(typeof(IScheduleReportService), typeof(ScheduleReportService));
      services.AddTransient(typeof(IScheduleReportRepository), typeof(ScheduleReportRepository));
      services.AddTransient(typeof(IAdminInfoService), typeof(AdminInfoService));
      services.AddTransient(typeof(IPartRepository), typeof(PartRepository));
      services.AddTransient(typeof(IOPCConfigRepository), typeof(OPCConfigRepository));
      services.AddTransient(typeof(IMillsRepository), typeof(MillsRepository));
      services.AddTransient(typeof(IModelRepository), typeof(ModelRepository));
      services.AddTransient(typeof(IShiftRepository), typeof(ShiftRepository));
      services.AddTransient(typeof(IImportBlankData), typeof(ImportBlankData));
      services.AddTransient(typeof(IBlankInfoService), typeof(BlankInfoService));
      services.AddTransient(typeof(IPressRepository), typeof(PressRepository));
      services.AddTransient(typeof(IRunOrderListQuantityRepository), typeof(RunOrderListQuantityRepository));
      services.AddTransient(typeof(IRunOrderListQuantityService), typeof(RunOrderListQuantityService));
      services.AddTransient(typeof(IProdPlanRepository), typeof(ProdPlanRepository));
      services.AddScoped<IImportBlank, ImportBlankForTMMI>();
      services.AddScoped<IImportBlank, ImportBlanks>();
      services.AddTransient(typeof(IImportBlankInfoFactory), typeof(ImportBlankInfoFactory));
      services.AddTransient(typeof(IMillService), typeof(MillService));
      services.AddTransient(typeof(ICoilFieldsService), typeof(CoilFieldsService));
      services.AddTransient(typeof(ICoilTypeService), typeof(CoilTypeService));
      services.AddTransient(typeof(ICoilTypeRepository), typeof(CoilTypeRepository));
      services.AddTransient(typeof(IMaterialTypesRepository), typeof(MaterialTypesRepository));
      services.AddTransient(typeof(ICoilTypeYNARepository), typeof(CoilTypeYNARepository));
      services.AddTransient(typeof(ICoilMoveRequestsRepository), typeof(CoilMoveRequestsRepository));
      services.AddTransient(typeof(ICoilRunHistoryRepository), typeof(CoilRunHistoryRepository));
      services.AddTransient(typeof(IImportCoilTypeData), typeof(ImportCoilTypeData));
      services.AddTransient(typeof(ICoilFieldLocationsService), typeof(CoilFieldLocationsService));
      services.AddTransient(typeof(IPatternsRepository), typeof(PatternsRepository));
      services.AddTransient(typeof(ICoilStatusRepository), typeof(CoilStatusRepository));
      services.AddTransient(typeof(ICoilMoveRequestService), typeof(CoilMoveRequestsService));
      services.AddTransient(typeof(ICoilFieldZonesService), typeof(CoilFieldZonesService));
      services.AddTransient(typeof(ICoilsService), typeof(CoilsService));
      services.AddTransient(typeof(IPartModelsRepository), typeof(PartModelsRepository));
      services.AddScoped<ICoilMoveRequestManager, CoilRequestManager>();
      services.AddScoped<ICoilMoveRequestManager, CoilReturnManager>();
      services.AddScoped<ICoilsFTZForTMMI, CoilsFTZForTMMI>();
      services.AddScoped<ICoilsFTZForTMMI, CoilsFTZ>();
      services.AddTransient(typeof(Business.Interfaces.CoilMoveRequest.ICoilMoveRequestFactory), typeof(Business.Implementation.CoilMoveRequest.CoilMoveRequestFactory));
      services.AddTransient(typeof(IHttpContextAccessor), typeof(HttpContextAccessor));
      services.AddTransient(typeof(ICoilFactory), typeof(CoilFactory));
      services.AddTransient(typeof(IOPCClientServiceManager), typeof(OPCClientServiceManager));
      services.AddTransient(typeof(ICoilStatusService), typeof(CoilStatusService));
      services.AddTransient(typeof(IPatternCalendarService), typeof(PatternCalendarService));
      services.AddTransient(typeof(IPatternService), typeof(PatternService));
      services.AddTransient(typeof(IPatternItemRepository), typeof(PatternItemRepository));
      services.AddTransient(typeof(ILineDataManager), typeof(LineDataManager));
      services.AddTransient(typeof(IShiftService), typeof(ShiftService));

      services.AddTransient(typeof(IModelService), typeof(ModelService));
      services.AddTransient(typeof(IModelRepository), typeof(ModelRepository));
      services.AddTransient(typeof(IIncompleteRunOrderItemRepository), typeof(IncompleteRunOrderItemRepository));
      services.AddScoped<ICoilLocationManager, CoilLocationManager>();
      services.AddScoped<ICoilLocationManager, CoilLocationManagerOther>();
      services.AddScoped<ICoilLocationManager, CoilLocationManagerSupplier>();
      services.AddTransient(typeof(ICoilLocationManagerFactory), typeof(CoilLocationManagerFactory));
      services.AddTransient(typeof(ISecretsManager), typeof(SecretsManager));
      services.AddTransient(typeof(ISecretsManager), typeof(SecretsManager));

      services.AddAWSService<IAmazonS3>();
      services.AddTransient(typeof(IBlockingDiagramRepository), typeof(BlockingDiagramRepository));

      services.AddTransient(typeof(IBlockingDiagramService), typeof(BlockingDiagramService));
      services.AddTransient(typeof(IAWSS3BucketHelper), typeof(AWSS3BucketHelper));
      services.AddTransient(typeof(IPartsService), typeof(PartsService));
      services.AddTransient(typeof(IProdPlanService), typeof(ProdPlanService));
      services.AddTransient(typeof(IImportProdPlan), typeof(ImportProdPlan));
      services.AddTransient(typeof(IPLCIntegrationService), typeof(PLCIntegrationService));
      services.AddScoped<IRunResultftzManager, RunResultftzManager>();
      services.AddScoped<IRunResultftzManager, RunResultftzTMMIManager>();
      services.AddTransient(typeof(IRunResultFactory), typeof(RunResultFactory));
      services.AddTransient(typeof(IPartModelService), typeof(PartModelService));
      services.AddTransient(typeof(IOPCConfigService), typeof(OPCConfigService));
      services.AddTransient(typeof(IScheduledReportBatchService), typeof(ScheduledReportBatchService));
      services.AddTransient(typeof(IImportPressPattern), typeof(ImportPressPattern));
      services.AddTransient(typeof(IEmailService), typeof(EmailService));
      services.AddTransient(typeof(IImportPartData), typeof(ImportPartData));
      services.AddTransient(typeof(IPrintTagService), typeof(PrintTagService));
      services.AddTransient(typeof(IIncompleteRunOrderItemsRepository), typeof(IncompleteRunOrderItemsRepository));
      services.AddTransient(typeof(IPrintFunctions), typeof(PrintFunctions));
      services.AddTransient(typeof(IUserEventService), typeof(UserEventService));
      services.AddTransient(typeof(IUserEventRepository), typeof(UserEventRepository));

      services.AddTransient(typeof(IUserHelper), typeof(UserHelper));


      services.AddTransient<IWebsocketService, WebsocketService>();
      services.AddTransient<IWebSocketClientService, WebSocketClientService>();


      return services;
    }
  }
}
