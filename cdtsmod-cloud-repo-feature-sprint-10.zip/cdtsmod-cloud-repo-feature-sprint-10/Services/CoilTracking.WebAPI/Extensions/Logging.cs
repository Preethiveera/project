using Amazon.CloudWatchLogs;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Serilog;
using Serilog.Events;
using Serilog.Formatting.Compact;
using Serilog.Sinks.AwsCloudWatch;
using System.Diagnostics.CodeAnalysis;

namespace CoilTracking.WebAPI.Extensions
{
  [ExcludeFromCodeCoverage]
  public class LoggingSettings
  {
    public string CloudWatchLogGroup { get; set; }
  }
  [ExcludeFromCodeCoverage]
  public static class Logging
  {
    public static void SetupAWSLogging(WebHostBuilderContext hostingContext, LoggerConfiguration loggerConfiguration)
    {
      var config = hostingContext.Configuration;
      //var settings = config.GetSection("LoggingSettings").Get<LoggingSettings>();

      loggerConfiguration
          .MinimumLevel.Information()
          .Enrich.FromLogContext()
          .WriteTo.Console();

      if (!string.IsNullOrEmpty(config["cloudwatch-log-group"]))
      {
        var options = new CloudWatchSinkOptions
        {
          LogGroupName = config["cloudwatch-log-group"],
          CreateLogGroup = true,
          MinimumLogEventLevel = LogEventLevel.Information,
          TextFormatter = new CompactJsonFormatter()
        };
        var awsOptions = config.GetAWSOptions();
        var cloudwatchClient = awsOptions.CreateServiceClient<IAmazonCloudWatchLogs>();
        loggerConfiguration
            .WriteTo.AmazonCloudWatch(options, cloudwatchClient);
      }

    }
  }
}

