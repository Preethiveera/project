using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Data.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using System.Threading.Tasks;

namespace CoilTracking.Business.PLCAuthHelper
{
  [ExcludeFromCodeCoverage]
  public static class OpenIDConnectAuthHelper
  {
   ///public static PLCAzureAd Setting { get; set; } = new PLCAzureAd();

    /// <summary>
    /// Gets the token for the common service
    /// </summary>
    /// <param name="context"></param>
    /// <returns></returns>
    public async static Task<string> GetTokenForPLC(HttpContext context, PLCAzureAd plcAzuread)
    {
      AuthenticationResult result = null;
      IConfidentialClientApplication clientapp = MsalAppBuilder.BuildConfidentialClientApplication(context, plcAzuread);
      // use the default permissions assigned from within the Azure AD app registration portal
      List<string> scopes = new List<string>();
      scopes.Add(plcAzuread.ScopeUrl);
      try
      {
        result = await clientapp.AcquireTokenForClient(scopes).ExecuteAsync();
      }
      catch (Exception e)
      {
        throw new CoilTrackingException { HttpStatusCode = "Unauthorized", ErrorMessage = "Error occured while fetching token for PLC api"+ e.InnerException };
      }
      return result.AccessToken;
    }


  }
}
