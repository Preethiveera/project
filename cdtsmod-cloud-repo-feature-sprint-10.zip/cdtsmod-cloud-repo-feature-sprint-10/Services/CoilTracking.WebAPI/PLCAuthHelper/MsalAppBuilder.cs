using CoilTracking.Common.Exception;
using CoilTracking.Data.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace CoilTracking.Business.PLCAuthHelper
{
  [ExcludeFromCodeCoverage]
  public static class MsalAppBuilder
  {
    ///public static PLCAzureAd Setting { get; set; } = new PLCAzureAd();
    public static IConfidentialClientApplication BuildConfidentialClientApplication(HttpContext context, PLCAzureAd plcAzuread)
    {

      IConfidentialClientApplication clientapp = null;
      try
      {
        string clientSecret = plcAzuread.SecretName;


        clientapp = ConfidentialClientApplicationBuilder.Create(plcAzuread.ClientId)
              .WithClientSecret(clientSecret)
              .WithAuthority(plcAzuread.Instance + plcAzuread.TenantId)
              .Build();

      }
      catch (Exception e)
      {
        throw new CoilTrackingException { HttpStatusCode = "Unauthorized", ErrorMessage = "Error occured while fetching clientApp for PLC api" + e.InnerException };

      }
      return clientapp;
    }

  }
}
