using Ganss.XSS;
using System.Diagnostics.CodeAnalysis;

namespace CoilTracking.WebAPI.Middlewares
{
  [ExcludeFromCodeCoverage]
  public class InputSanitizer
  {
    /// <summary>
    /// HTML Sanitizes input string
    /// </summary>
    /// <param name="input"></param>
    /// <returns></returns>
    public static string SanitizeString(string input)
    {
      var sanitizer = new HtmlSanitizer();
      if (input != null && input != string.Empty)
      {
        sanitizer.AllowedSchemes.Add("mailto");
        return sanitizer.Sanitize(input);
      }
      else
        return input;
    }
  }
}
