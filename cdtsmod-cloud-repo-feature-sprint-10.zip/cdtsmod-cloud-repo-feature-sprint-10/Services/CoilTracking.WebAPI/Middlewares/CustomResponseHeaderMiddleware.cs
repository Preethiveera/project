using Microsoft.AspNetCore.Http;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;

namespace CoilTracking.WebAPI.Middlewares
{
  [ExcludeFromCodeCoverage]
  public class CustomResponseHeaderMiddleware
  {
    private readonly RequestDelegate _next;

    public CustomResponseHeaderMiddleware(RequestDelegate next)
    {
      _next = next;
    }

    public async Task Invoke(HttpContext context)
    {
      //To add Headers AFTER everything you need to do this
      context.Response.OnStarting(state =>
      {
        var httpContext = (HttpContext)state;
        httpContext.Response.Headers.Add("X-download-options", "noopen");
        httpContext.Response.Headers.Add("X-Content-Type-Options", "nosniff");
        httpContext.Response.Headers.Add("X-Xss-Protection", "1; mode=block");
        //httpContext.Response.Headers.Add("X-Frame-Options", "Deny");
        httpContext.Response.Headers.Add("x-ua-compatible", "IE = edge,chrome = 1");
        httpContext.Response.Headers.Remove("X-Powered-By");
        httpContext.Response.Headers.Remove("X-AspNet-Version");
        httpContext.Response.Headers.Remove("X-AspNetMvc-Version");
        httpContext.Response.Headers.Remove("Server");

        return Task.CompletedTask;
      }, context);

      await _next(context);
    }


  }
}
