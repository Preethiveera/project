using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Threading.Tasks;

namespace CoilTracking.WebAPI.Middlewares
{
  [ExcludeFromCodeCoverage]
  /// <summary>
  /// Middleware for handling and logging exceptions at request pipeline level
  /// </summary>
  public class ExceptionMiddleware
  {
    private readonly RequestDelegate _next;
    private readonly IApplicationLogger<object> _logger;
    public ExceptionMiddleware(RequestDelegate next, IApplicationLogger<object> logger)
    {
      _logger = logger;
      _next = next;
    }
    /// <summary>
    /// Catches exception raised at request pipeline level
    /// </summary>
    /// <param name="httpContext"></param>
    /// <returns></returns>
    public async Task InvokeAsync(HttpContext httpContext)
    {
      try
      {
        await _next(httpContext);
      }
      catch (Exception ex)
      {
        _logger.LogError($"CDTS exception: {ex.Message} Inner Exception:{ex.InnerException} StackStrace: {ex.StackTrace}");
        
        await HandleExceptionAsync(httpContext, ex);
      }
    }
    public int GetHttpStatusCode(string  code)
    {
      switch (code)
      {
        case Constant.badRequest:
          {
            return 400;
          }
        case Constant.notfound:
          {
            return 404;
          }
        case Constant.conflict:
          {
            return 409;
          }

        default:
          return 500;
      }
    }
    /// <summary>
    /// passing minimal info to user from exception generated in application
    /// </summary>
    /// <param name="context"></param>
    /// <param name="exception"></param>
    /// <returns></returns>
    private Task HandleExceptionAsync(HttpContext context, Exception exception)
    {
      context.Response.ContentType = "application/json";
      if (exception is CoilTrackingException)
      {
        var t = exception as CoilTrackingException;
        context.Response.StatusCode = GetHttpStatusCode(t.HttpStatusCode);
      }
      else
      {
        context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
      }
      string responseBody;
     
      if (exception is CoilTrackingException)
      {
        var ex = exception as CoilTrackingException;
        responseBody = JsonConvert.SerializeObject(new
        {
          ex.ErrorNumber,
          ex.HttpStatusCode,
          ex.ErrorMessage
        });
      }
      else if(exception.Message.Contains("duplicate key"))
      {
        responseBody = JsonConvert.SerializeObject(new
        {
          ErrorNumber = "A502",
          HttpStatusCode = context.Response.StatusCode.ToString(),
          ErrorMessage = exception.Message
        }) ;
      }
      else
      {
        responseBody = JsonConvert.SerializeObject(new
        {
          ErrorNumber = "A502",
          HttpStatusCode = context.Response.StatusCode.ToString(),
          ErrorMessage = "Application failed while processing your request."
        });
      }
      return context.Response.WriteAsync(responseBody);
    }
  }
}
