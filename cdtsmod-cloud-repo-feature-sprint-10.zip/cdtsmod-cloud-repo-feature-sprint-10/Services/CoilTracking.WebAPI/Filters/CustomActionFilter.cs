using CoilTracking.Common.Logging;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Diagnostics.CodeAnalysis;

namespace CoilTracking.WebAPI.Filters
{
  [ExcludeFromCodeCoverage]
  public class CustomActionFilter : IActionFilter 
  {
    private readonly IApplicationLogger<CustomActionFilter> logger;
    public CustomActionFilter(IApplicationLogger<CustomActionFilter> customLogger)
    {
      logger = customLogger;
    }
    /// <summary>
    /// Logging controller Entry Point  Information 
    /// </summary>
    /// <param name="context"></param>
    public void OnActionExecuting(ActionExecutingContext context)
    {
      var controllerName = context.RouteData.Values["controller"];
      var actionName = context.RouteData.Values["action"];
      var message = String.Format("Entry:{0} actionName:{1} controllerName:  ", actionName, controllerName);
      logger.LogDebug(message);
    }
    /// <summary>
    /// Logging controller Exit Point  Information 
    /// </summary>
    /// <param name="context"></param>
    public void OnActionExecuted(ActionExecutedContext context)
    {
      var controllerName = context.RouteData.Values["controller"];
      var actionName = context.RouteData.Values["action"];
      var message = String.Format("Exit:{0} actionName:{1} controllerName", actionName, controllerName);
      logger.LogDebug(message);
    }
  }
}
