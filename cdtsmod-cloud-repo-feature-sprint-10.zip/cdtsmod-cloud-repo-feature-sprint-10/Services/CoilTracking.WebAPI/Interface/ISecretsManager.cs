using Amazon.Extensions.NETCore.Setup;

namespace CoilTracking.WebAPI.Extensions
{
  public interface ISecretsManager
  {
    string GetSecret(string Name, AWSOptions awsoptions);
  }
}
