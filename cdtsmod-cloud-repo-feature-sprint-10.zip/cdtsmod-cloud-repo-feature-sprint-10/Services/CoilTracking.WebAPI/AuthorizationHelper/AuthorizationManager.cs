using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace CoilTracking.WebAPI.AuthorizationHelper
{
  [ExcludeFromCodeCoverage]
  public class AuthorizationManager : IAuthorizationFilter
  {
    readonly Claim Resource;
  
    public AuthorizationManager(Claim Resource)
    {
     this.Resource = Resource;
    }
    /// <summary>
    /// Authorization
    /// </summary>
    /// <param name="context"></param>
    public void OnAuthorization(AuthorizationFilterContext context)
    {
      if (context.ActionDescriptor.EndpointMetadata.OfType<AllowAnonymousAttribute>().Any()) return;
      bool result = SetAuthorizationRoles(context);
      if(result == false)
      {
        context.Result = new CustomUnauthorizedResult("Forbidden", statusCode: 403);

        
      }
    }
    /// <summary>
    /// Validate Roles
    /// </summary>
    /// <param name="context"></param>
    /// <returns></returns>
    public bool SetAuthorizationRoles(AuthorizationFilterContext context)
    {
      /// <summary>
      /// Check if the the current user has permission to resource with the action requested.
      /// </summary>
      /// <param name="context">Contains the Resource and Action we are checking for authorization</param>
      /// <returns>True/False if access is allowed</returns>

      if (context.HttpContext.User.IsInRole(AuthResources.Roles.Admin))
      {
        //Admin has rights to everything, no need to check resource/action etc..
        return true;
      }
      switch (Resource.Value)
      {
        case AuthResources.Home:
          return AuthorizeHomeDetails(context);
        case AuthResources.AdminPage:
          return AuthorizeAdminPages(context);
        case AuthResources.BlankingRunOrderList:
          return AuthorizeBlankingRunOrderList(context);
        case AuthResources.TeamLeaderPage:
          return AuthorizeTeamLeaderPage(context);
        case AuthResources.CoilSetterPage:
          return AuthorizeCoilSetter(context);
        default:
          return ForbidResult(context);
       
      }
    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="context"></param>
    /// <returns></returns>
    private bool ForbidResult(AuthorizationFilterContext context)
    {
      context.Result = new CustomUnauthorizedResult("Forbidden", statusCode: 403);
      return false;
    }
    /// <summary>
    /// Validate Authorize CoilSetter
    /// </summary>
    /// <param name="context">The context to check the action of</param>
    /// <returns>True/False if access is allowed</returns>
    private bool AuthorizeCoilSetter(AuthorizationFilterContext context)
    {
      switch (Resource.Type)
      {
        //We can let normal user's read, and require admins to write
        case AuthResources.CoilSetterActions.View:
          return context.HttpContext.User.IsInRole(AuthResources.Roles.User);
       
        case AuthResources.CoilSetterActions.Edit:
          return context.HttpContext.User.IsInRole(AuthResources.Roles.Admin) || context.HttpContext.User.IsInRole(AuthResources.Roles.CoilSetter);
         

        case AuthResources.CoilSetterActions.UpdateWeights:
          return  context.HttpContext.User.IsInRole(AuthResources.Roles.Admin) || context.HttpContext.User.IsInRole(AuthResources.Roles.StampingTeamLeader)
            || context.HttpContext.User.IsInRole(AuthResources.Roles.CoilSetter);
       
        default:
          return ForbidResult(context);
      }
    }
    /// <summary>
    /// Validate Authorize TeamLeaderPage
    /// </summary>
    /// <param name="context">The context to check the action of</param>
    /// <returns>True/False if access is allowed</returns>
    private bool AuthorizeTeamLeaderPage(AuthorizationFilterContext context)
    {
      switch (Resource.Type)
      {
        //We can let normal user's read, and require admins to write
        case AuthResources.TeamLeaderActions.View:
          return context.HttpContext.User.IsInRole(AuthResources.Roles.User);
         

        case AuthResources.TeamLeaderActions.Edit:
          return (context.HttpContext.User.IsInRole(AuthResources.Roles.Admin)
                     || context.HttpContext.User.IsInRole(AuthResources.Roles.StampingTeamLeader)
                     || context.HttpContext.User.IsInRole(AuthResources.Roles.StampingTeamMember));
         
        case AuthResources.TeamLeaderActions.EditPattern:
          return (context.HttpContext.User.IsInRole(AuthResources.Roles.Admin)
                     || context.HttpContext.User.IsInRole(AuthResources.Roles.StampingTeamLeader));
       
        case AuthResources.TeamLeaderActions.UpdateWeights:
          return (context.HttpContext.User.IsInRole(AuthResources.Roles.Admin)
                      || context.HttpContext.User.IsInRole(AuthResources.Roles.StampingTeamLeader)
                      || context.HttpContext.User.IsInRole(AuthResources.Roles.StampingTeamMember)
                      || context.HttpContext.User.IsInRole(AuthResources.Roles.CoilSetter));
       
        case AuthResources.TeamLeaderActions.CoilMove:
          return (context.HttpContext.User.IsInRole(AuthResources.Roles.Admin)
                      || context.HttpContext.User.IsInRole(AuthResources.Roles.StampingTeamMember)
                      || context.HttpContext.User.IsInRole(AuthResources.Roles.StampingTeamLeader)
                      || context.HttpContext.User.IsInRole(AuthResources.Roles.CoilSetter));
       
        case AuthResources.TeamLeaderActions.EditRunResult:
          return (context.HttpContext.User.IsInRole(AuthResources.Roles.Admin)
                      || context.HttpContext.User.IsInRole(AuthResources.Roles.StampingTeamLeader));
       
        case AuthResources.TeamLeaderActions.EditDataNumber:
          return (context.HttpContext.User.IsInRole(AuthResources.Roles.Admin)
                      || context.HttpContext.User.IsInRole(AuthResources.Roles.StampingTeamLeader));
       
        case AuthResources.TeamLeaderActions.EditCoilType:
          return (context.HttpContext.User.IsInRole(AuthResources.Roles.Admin)
                      || context.HttpContext.User.IsInRole(AuthResources.Roles.StampingTeamLeader));
       
        case AuthResources.TeamLeaderActions.EditCoil:
          return  (context.HttpContext.User.IsInRole(AuthResources.Roles.Admin)
                      || context.HttpContext.User.IsInRole(AuthResources.Roles.StampingTeamLeader));
    
        case AuthResources.TeamLeaderActions.EditPart:
          return (context.HttpContext.User.IsInRole(AuthResources.Roles.Admin)
                      || context.HttpContext.User.IsInRole(AuthResources.Roles.StampingTeamLeader));
        
        case AuthResources.TeamLeaderActions.EditRunOrder:
          return (context.HttpContext.User.IsInRole(AuthResources.Roles.Admin)
                      || context.HttpContext.User.IsInRole(AuthResources.Roles.StampingTeamLeader)
                      || context.HttpContext.User.IsInRole(AuthResources.Roles.RunOrderEditor));
       
        default:
          return ForbidResult(context);
      }
    }
    /// <summary>
    /// Authorize who can access the blanking operator run order list page (line side page)
    /// </summary>
    /// <param name="context"></param>
    /// <returns></returns>
    private bool AuthorizeBlankingRunOrderList(AuthorizationFilterContext context)
    {
      switch (Resource.Type)
      {
        //We can let normal user's read, and require admins to write
        case AuthResources.HomeActions.View:
          return (context.HttpContext.User.IsInRole(AuthResources.Roles.User));
       
        case AuthResources.HomeActions.Edit:
          return (context.HttpContext.User.IsInRole(AuthResources.Roles.Admin)
                         || context.HttpContext.User.IsInRole(AuthResources.Roles.StampingTeamLeader)
                         || context.HttpContext.User.IsInRole(AuthResources.Roles.StampingTeamMember));
       
        default:
          return ForbidResult(context);


      }
    }
    /// <summary>
    /// Sample method, for "Home" resource let "user" have "view" action, and "admin" have "edit" action
    /// </summary>
    /// <param name="context">The context to check the action of</param>
    /// <returns>True/False if access is allowed</returns>
    private bool AuthorizeAdminPages(AuthorizationFilterContext context)
    {
      switch (Resource.Type)
      {
        //We can let nonstamping members user's view, and require admin role to edit
        case AuthResources.AdminPageActions.View:
          return (context.HttpContext.User.IsInRole(AuthResources.Roles.User));
       
        case AuthResources.AdminPageActions.Edit:
          return (context.HttpContext.User.IsInRole(AuthResources.Roles.Admin));
       
        case AuthResources.AdminPageActions.AddUser:
          //Admin or Stamping Team leader can add users. (Team leader only non admin users)
          return (context.HttpContext.User.IsInRole(AuthResources.Roles.Admin)
                      || context.HttpContext.User.IsInRole(AuthResources.Roles.StampingTeamLeader));
       
        case AuthResources.AdminPageActions.EditUser:
          //Admin or Stamping Team leader can edit users. (Team leader only non admin users).... Actually, any user can edit themselves, what about that case?
          return (context.HttpContext.User.IsInRole(AuthResources.Roles.Admin)
                      || context.HttpContext.User.IsInRole(AuthResources.Roles.StampingTeamLeader));
       
        case AuthResources.AdminPageActions.EditAdminUser:
          //Only admin can add/edit admin users
          return (context.HttpContext.User.IsInRole(AuthResources.Roles.Admin));
       
        case AuthResources.AdminPageActions.EditShift:
          //Admin or Team Leader can add/edit shifts
          return (context.HttpContext.User.IsInRole(AuthResources.Roles.Admin)
                      || context.HttpContext.User.IsInRole(AuthResources.Roles.StampingTeamLeader));
       
        default:
          return ForbidResult(context);


      }
    }
    /// <summary>
    /// Start of the admin pages authorize method, for "AdminPage" resource let "user" have "view" action, and "admin" have "edit" action
    /// </summary>
    /// <param name="context">The context to check the action of</param>
    /// <returns>True/False if access is allowed</returns>
    private bool AuthorizeHomeDetails(AuthorizationFilterContext context)
    {
      switch (Resource.Type)
      {
        //We can let normal user's read, and require admins to write
        case AuthResources.HomeActions.View:
          return (context.HttpContext.User.IsInRole(AuthResources.Roles.User));
       
        case AuthResources.HomeActions.Edit:
          return (context.HttpContext.User.IsInRole(AuthResources.Roles.Admin));
       
        default:
          return ForbidResult(context);


      }
    }
  }
}
