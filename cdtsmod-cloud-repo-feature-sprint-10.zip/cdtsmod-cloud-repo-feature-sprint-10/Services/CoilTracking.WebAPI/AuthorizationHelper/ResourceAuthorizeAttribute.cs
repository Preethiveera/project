using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace CoilTracking.WebAPI.AuthorizationHelper
{
  [ExcludeFromCodeCoverage]
  public class ResourceAuthorizeAttribute : TypeFilterAttribute
  {
    /// <summary>
    /// Set claimType and claimValue
    /// </summary>
    /// <param name="claimType"></param>
    /// <param name="claimValue"></param>
    ///Getting Resource and Action value from the Controller  ClaimType = Resource , ClaimValue=Action
    public ResourceAuthorizeAttribute(string claimType, string claimValue) : base(typeof(AuthorizationManager))
    {
      Arguments = new object[] { new Claim(claimType, claimValue) };
    }
  }
}
