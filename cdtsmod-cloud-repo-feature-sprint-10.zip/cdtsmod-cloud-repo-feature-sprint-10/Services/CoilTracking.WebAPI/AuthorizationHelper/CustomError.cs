using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.WebAPI.AuthorizationHelper
{
  [ExcludeFromCodeCoverage]
  public class CustomError
  {
    public string Message { get; }
    /// <summary>
    /// Error Message
    /// </summary>
    /// <param name="message"></param>
    public CustomError(string message)
    {
      Message = message;
    }
  }
}
