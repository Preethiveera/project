using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.WebAPI.AuthorizationHelper
{
  [ExcludeFromCodeCoverage]
  public class AuthResources
  {
    /// <summary>
    /// List of different roles available
    /// </summary>
    public class Roles
    {
      public const string User = "CDTS.User";
      public const string Admin = "CDTS.Admin";
      public const string CoilSetter = "CDTS.Coilsetter";
      public const string StampingTeamLeader = "CDTS.Teamleader";
      public const string StampingTeamMember = "CDTS.TeamMember";
      public const string RunOrderEditor = "CDTS.RunOrderEditor";
    }


    /// <summary>
    /// We'll start each Actions class off with the base View and Edit actions
    /// </summary>
    public abstract class BaseActions
    {
      public const string View = "View";
      public const string Edit = "Edit";
    }

    /// <summary>
    /// Admin pages
    /// </summary>
    public const string AdminPage = "AdminPage";
    public class AdminPageActions : BaseActions
    {
      /// <summary>
      /// We could have different actions for certain things that require different permission
      /// </summary>
      public const string UploadFileType1 = "UploadFileType1";
      public const string EditUser = "EditUser";
      public const string AddUser = "AddUser";
      public const string EditAdminUser = "EditAdminUser";
      public const string EditShift = "EditShift";
    }

    public const string Home = "Home";
    public class HomeActions : BaseActions
    {
    }
    public const string BlankingRunOrderList = "BlankingRunOrderList";
    public class BlankingRunOrderActions : BaseActions
    {
    }
    public const string CoilSetterPage = "CoilSetterPage";
    public class CoilSetterActions : BaseActions
    {
      public const string UpdateWeights = "UpdateWeights";
    }
    public const string TeamLeaderPage = "TeamLeaderPage";
    public class TeamLeaderActions : BaseActions
    {
      public const string EditPattern = "EditPattern";
      public const string CoilMove = "CoilMove";
      public const string EditRunResult = "EditRunResult";
      public const string EditRunOrder = "EditRunOrder";
      public const string EditCoilType = "EditCoilType";
      public const string EditDataNumber = "EditDataNumber";
      public const string UpdateWeights = "UpdateWeights";
      public const string EditCoil = "EditCoil";
      public const string EditPart = "EditPart";
      public const string EditScheduledReport = "EditScheduledReport";
      public const string EditBlockingDiagram = "EditBlockingDiagram";
    }
  }
}
