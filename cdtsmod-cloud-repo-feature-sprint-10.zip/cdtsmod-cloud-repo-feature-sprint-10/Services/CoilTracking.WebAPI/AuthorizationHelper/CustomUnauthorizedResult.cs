using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.WebAPI.AuthorizationHelper
{
  [ExcludeFromCodeCoverage]
  public class CustomUnauthorizedResult : JsonResult
  {
    /// <summary>
    /// Custom Unauthorized Result 
    /// </summary>
    /// <param name="message"></param>
    /// <param name="statusCode"></param>
    public CustomUnauthorizedResult(string message, int statusCode) : base(new CustomError(message))
    {
      StatusCode = statusCode;
    }
  }
}
