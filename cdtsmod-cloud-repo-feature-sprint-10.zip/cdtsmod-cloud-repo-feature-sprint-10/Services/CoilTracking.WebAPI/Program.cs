using CoilTracking.WebAPI.Extensions;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Serilog;
using System;
using System.Diagnostics.CodeAnalysis;

namespace CoilTracking.WebAPI
{
  [ExcludeFromCodeCoverage]
  public class Program
  {
    public static void Main(string[] args)
    {
      Log.Logger = new LoggerConfiguration()
          .Enrich.FromLogContext()
          .CreateLogger();

      CreateHostBuilder(args).Build().Run();
    }

    public static IHostBuilder CreateHostBuilder(string[] args) =>
       Host.CreateDefaultBuilder(args)
           .ConfigureWebHostDefaults(webBuilder =>
           {
             webBuilder.UseStartup<Startup>()
             .UseSerilog(Logging.SetupAWSLogging)
             .ConfigureKestrel(serverOptions =>
              {
                serverOptions.AddServerHeader = false;
                serverOptions.Limits.MaxResponseBufferSize = long.MaxValue;
               });

           })
    
     .ConfigureAppConfiguration((hostingContext, config) =>
                
     {
       var env = Environment.GetEnvironmentVariable("stmpcdts-environment").ToString().ToLower();
       var region_abbr = Environment.GetEnvironmentVariable("REGION").ToString();
       Console.WriteLine("Environment = " + env);
       Console.WriteLine("Region Abbrivation = " + region_abbr);
       config.AddSystemsManager(path: $"/stmpcdts/{env}/{region_abbr}/");
                 
      });

  }
}
