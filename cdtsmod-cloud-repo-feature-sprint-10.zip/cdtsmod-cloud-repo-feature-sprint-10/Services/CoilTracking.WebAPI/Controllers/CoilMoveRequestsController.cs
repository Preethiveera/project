using CoilTracking.Business.Interfaces;
using CoilTracking.Data.Models;
using CoilTracking.DTO;
using CoilTracking.WebAPI.AuthorizationHelper;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/CoilMoveRequests")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]

  [ResourceAuthorize(AuthResources.HomeActions.View, AuthResources.Home)]
  public class CoilMoveRequestsController : ControllerBase
  {
    private readonly ICoilMoveRequestService coilMoveRequestService;

    public CoilMoveRequestsController(ICoilMoveRequestService coilMoveRequestService)
    {
      this.coilMoveRequestService = coilMoveRequestService;
    }

    /// <summary>
    /// Get list of CoilMove Request.
    /// </summary>
    /// <returns></returns>

    [HttpGet]
    public async Task<IQueryable<CoilMoveRequestDto>> GetCoilMoveRequests()
    {
      var moveRequests = await coilMoveRequestService.GetCoilMoveRequests();
      return moveRequests;
    }

    /// <summary>
    /// Get Pending Request by Line.
    /// </summary>
    /// <param name="lineId"></param>
    /// <param name="startTime"></param>
    /// <param name="endTime"></param>
    /// <returns></returns>

    [HttpGet, Route("GetPendingRequestsByLine/{lineId}", Name = "GetPendingRequestsByLine")]
    //startTime and endTime denotes the time bounds for including cancelled requests - ideally the current shift
    public async Task<IQueryable<CoilMoveRequestDto>> GetPendingRequestsByLine(int lineId, DateTime? startTime = null, DateTime? endTime = null)
    {
      var moveRequests = await coilMoveRequestService.GetPendingRequestsByLine(lineId, startTime, endTime);
      return moveRequests;
    }

    /// <summary>
    /// Get UnFulfilled Request by Line.
    /// </summary>
    /// <param name="lineId"></param>
    /// <param name="startTime"></param>
    /// <param name="endTime"></param>
    /// <returns></returns>

    [HttpGet, Route("GetUnfulfilledCoilMoveRequests")]
    public async Task<List<CoilMoveRequestDto>> GetUnfulfilledCoilMoveRequests()
    {
      var moveRequests = await coilMoveRequestService.GetUnfulfilledCoilMoveRequests();
      return moveRequests;
    }

    /// <summary>
    /// Cancels a CoilMove Request.
    /// GET: api/CoilMoveRequests/CancelCoilMove/{id}
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>

    [HttpGet, Route("CancelCoilMove/{id}", Name = "CancelCoilMove")]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.CoilMove, AuthResources.TeamLeaderPage)]
    public async Task<IActionResult> CancelCoilMove(int id)
    {
      var response = await coilMoveRequestService.CancelCoilMove(id);
      return Ok(response);
    }

    /// <summary>
    /// Requests a coil to be moved (To line, back to the field, or rejected)
    /// </summary>
    /// <param name="lineId">The line making the request</param>
    /// <param name="coilTypeId">The type of coil it is for</param>
    /// <param name="requestType">The type of request (return/request/reject)</param>
    /// <param name="coilId">The specific coil (for returns/rejects)</param>
    ///// <param name="delay">The number of MINUTES to delay the CoilMoveRequest</param>
    /// <returns>Id of newly created CoilMoveRequest or Error message</returns>

    [HttpGet, Route("RequestCoilMove/{lineId}/{coilTypeId}/{requestType}/{coilId?}/{delay?}", Name = "RequestCoilMove")]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.CoilMove, AuthResources.TeamLeaderPage)]
    public async Task<IActionResult> RequestCoilMove(int lineId, int coilTypeId, CoilMoveRequestType requestType, int? coilId = null) //, int? delay = 0
    {
      var coilMoveRequest = await coilMoveRequestService.RequestCoilMove(lineId, coilTypeId, requestType, coilId);
      return CreatedAtRoute("RequestCoilMove", new { id = coilMoveRequest.Id }, coilMoveRequest);
    }

    /// <summary>
    /// GET: api/FulfillCoilMoveRequest
    /// Fulfills the coil move request based on the id. newLocation should be passed if it is a coil Return, newWeight should be passed for a coil request with coil.CoilStatus='Partial Needs Weighed'
    /// </summary>
    /// <param name="id"></param>
    /// <param name="newLocation"></param>
    /// <param name="newWeight"></param>
    /// <returns></returns>

    [HttpGet, Route("FulfillCoilMoveRequest/{id}/{newLocation}/{newWeight}")]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.CoilMove, AuthResources.TeamLeaderPage)]
    public async Task<IActionResult> FulfillCoilMoveRequest(int id, string newLocation, string newWeight)
    {
      var coilMoveRequest = await coilMoveRequestService.FulfillCoilMoveRequest(id, newLocation, newWeight);
      return Ok(coilMoveRequest.Id); //Just return the Id, the whole move request object graph is not necessary
    }

    /// <summary>
    /// Get Coil Move Request by Id.
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>

    [HttpGet]
    [Route("{id}")]
    // [ResponseType(typeof(CoilMoveRequest))]
    public async Task<IActionResult> GetCoilMoveRequest(int id)
    {
      var coilMoveRequest = await coilMoveRequestService.GetCoilMoveRequestAsync(id);
      if (coilMoveRequest == null)
      {
        return NotFound();
      }

      return Ok(coilMoveRequest);
    }

    /// <summary>
    /// Post Coil Move Request.
    /// </summary>
    /// <param name="coilMoveRequest"></param>
    /// <returns></returns>

    [HttpPost]
    // [ResponseType(typeof(CoilMoveRequest))]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.CoilMove, AuthResources.TeamLeaderPage)]
    public async Task<IActionResult> PostCoilMoveRequest(CoilMoveRequestDto coilMoveRequest)
    {
      var response = await coilMoveRequestService.PostCoilMoveRequestAsync(coilMoveRequest);
      return Ok(response);
    }

    /// <summary>
    /// Delete Coil Move Request.
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>

    [HttpDelete]
    [Route("{id}")]
    // [ResponseType(typeof(CoilMoveRequest))]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.CoilMove, AuthResources.TeamLeaderPage)]
    public async Task<IActionResult> DeleteCoilMoveRequest(int id)
    {
      var coilMoveRequest = await coilMoveRequestService.DeleteCoilMoveRequest(id);
      return Ok(coilMoveRequest);
    }

    /// <summary>
    /// Get List of Loaded Coils.
    /// </summary>
    /// <param name="lineId"></param>
    /// <param name="shiftId"></param>
    /// <returns></returns>

    [HttpGet, Route("GetLoadedCoils/{lineId}/{shiftId}", Name = "GetLoadedCoils")]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.CoilMove, AuthResources.TeamLeaderPage)]
    public async Task<List<CoilDto>> GetLoadedCoils(int lineId, int shiftId)
    {
      var loadedCoils = await coilMoveRequestService.GetLoadedCoils(lineId, shiftId);
      return loadedCoils;
    }
  }
}
