using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Threading.Tasks;
using CoilTracking.WebAPI.AuthorizationHelper;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/PatternCalendar")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  [ResourceAuthorize(AuthResources.TeamLeaderActions.View, AuthResources.TeamLeaderPage)]
  public class PatternCalendarController : ControllerBase
  {
    private readonly IPatternCalendarService patternCalendarService;

    public PatternCalendarController(IPatternCalendarService patternCalendarService)
    {
      this.patternCalendarService = patternCalendarService;
    }

    /// <summary>
    /// Get pattern calendars
    /// </summary>
    /// <returns>list of CalendarItemDto</returns>
    [HttpGet]
    public IActionResult GetPatternCalendars()
    {
      return Ok(patternCalendarService.GetPatternCalendars());
    }

    /// <summary>
    /// Get pattern calendars for export
    /// </summary>
    /// <returns>PatternCalendarExportDto</returns>
    [Route("GetPatternCalendarsForExport")]
    [HttpGet]
    public async Task<IActionResult> GetPatternCalendarsForExport()
    {

      return Ok(await patternCalendarService.GetPatternCalendarsForExport());
    }

    /// <summary>
    /// Get pattern calendar by id.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>PatternCalendarDto</returns>
    [Route("{id}")]
    [HttpGet]
    public async Task<IActionResult> GetPatternCalendar(int id)
    {
      return Ok(await patternCalendarService.GetPatternCalendar(id));
    }

    /// <summary>
    /// Get pattern calendar by line id and shift id.
    /// </summary> 
    /// <param name="lineId"></param>
    /// <param name="shiftId"></param>
    /// <returns>CalendarItemDto</returns>
    [Route("GetPatternCalendar/{lineId}/{shiftId}")]
    [HttpGet]
    public async Task<IActionResult> GetPatternCalendar(int lineId, int shiftId)
    {
      var queryStrings = Request?.Query.ToDictionary(kv => kv.Key, kv => kv.Value, StringComparer.OrdinalIgnoreCase);

      if (queryStrings == null)
        return NoContent();

      var match = queryStrings.FirstOrDefault(kv => string.Compare(kv.Key, "monthStart", true) == 0);
      if (string.IsNullOrEmpty(match.Value))
        return NoContent();


      DateTime localDate;
      if (!DateTime.TryParse(match.Value.ToString(), out localDate))
        return NoContent();


      if ((((localDate.Year - DateTime.Now.Year) * 12) + localDate.Month) > (DateTime.Now.Month + 1))
        return NoContent(); 

      return Ok(await patternCalendarService.GetPatternCalendar(localDate, lineId, shiftId));
    }

    /// <summary>
    /// Change pattern
    /// </summary>
    /// <param name="id"></param>
    /// <param name="patternLetter"></param>
    /// <returns></returns>
    [Route("ChangePattern/{id}/{patternLetter}")]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditPattern, AuthResources.TeamLeaderPage)]
    [HttpPut]
    public async Task<IActionResult> ChangePattern(int id, string patternLetter)
    {
      var changed = await patternCalendarService.ChangePattern(id, patternLetter);

      if (changed)
      {
        return Ok();
      }

      return BadRequest();
    }


    /// <summary>
    /// Put pattern calendar
    /// </summary>
    /// <param name="id"></param>
    /// <param name="patternCalendarDto"></param>
    /// <returns>NoContent</returns>
    [Route("{id}")]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditPattern, AuthResources.TeamLeaderPage)]
    [HttpPut]
    public async Task<IActionResult> PutPatternCalendar(int id, PatternCalendarDto patternCalendarDto)
    {
      if (id != patternCalendarDto.Id)
      {
        return BadRequest();
      }
      await patternCalendarService.PutPatternCalendar(patternCalendarDto);
      return NoContent();
    }

    /// <summary>
    /// Post pattern calendar
    /// </summary>
    /// <param name="patternCalendarDto"></param>
    /// <returns>PatternCalendarDto</returns>
    [HttpPost]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditPattern, AuthResources.TeamLeaderPage)]
    public async Task<IActionResult> PostPatternCalendar(PatternCalendarDto patternCalendarDto)
    {
      var patternCalendar = await patternCalendarService.PostPatternCalendar(patternCalendarDto);
      return Ok(patternCalendar);
    }

    /// <summary>
    /// Delete pattern calendar
    /// </summary>
    /// <param name="patternCalendarDto"></param>
    /// <returns>PatternCalendarDto</returns>
    [Route("{id}")]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditPattern, AuthResources.TeamLeaderPage)]
    [HttpDelete]
    public async Task<IActionResult> DeletePatternCalendar(int id)
    {
      var patternCalendar = await patternCalendarService.DeletePatternCalendar(id);
      return Ok(patternCalendar);
    }

  }
}
