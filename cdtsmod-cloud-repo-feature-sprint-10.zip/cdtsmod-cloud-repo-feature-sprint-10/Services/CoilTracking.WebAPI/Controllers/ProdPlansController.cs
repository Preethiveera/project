using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using CoilTracking.DTO;
using CoilTracking.Business.Interfaces;
using System.Threading.Tasks;
using System.Net;
using System;
using CoilTracking.Common.Exception;
using System.Collections.Generic;
using CoilTracking.Common;
using CoilTracking.WebAPI.AuthorizationHelper;
using CoilTracking.Common.UsersHelperUtility;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/ProdPlan")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  [ResourceAuthorize(AuthResources.HomeActions.View, AuthResources.Home)]
  public class ProdPlansController : ControllerBase
  {
    private readonly IProdPlanService prodPlanService;
    private readonly IImportProdPlan importProdPlan;
    private readonly IUserHelper usersHelper;
    public ProdPlansController(IProdPlanService prodPlanService,
      IImportProdPlan importProdPlan,IUserHelper usersHelper)
    {
      this.prodPlanService = prodPlanService;
      this.importProdPlan = importProdPlan;
      this.usersHelper = usersHelper;
    }

    /// <summary>
    /// Get list of ProdPlans.
    /// </summary>
    /// <returns></returns>
    [HttpGet]
    [Route("GetProdPlan")]
    public async Task<IQueryable<ProdPlanDto>> GetProdPlan()
    {
      return await prodPlanService.GetProdPlans();
    }

    /// <summary>
    /// Get ProdPlan By id.
    /// </summary>
    /// <returns></returns>
    [HttpGet]
    // [ResponseType(typeof(ProdPlan))]
    public async Task<IActionResult> GetProdPlan(int id)
    {
      var prodPlan = await prodPlanService.GetProdPlanById(id);
      return Ok(prodPlan);
    }

    /// <summary>
    /// Update ProdPlan
    /// </summary>
    /// <returns></returns>
    [Route("PutProdPlan/{id}")]
    [HttpPut]
    // [ResponseType(typeof(void))]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.Edit, AuthResources.TeamLeaderPage)]
    public async Task<IActionResult> PutProdPlan(int id, ProdPlanDto prodPlan)
    {
      if (id != prodPlan.Id)
      {
        return BadRequest();
      }

      await prodPlanService.PutProdPlan(id, prodPlan);
      return NoContent();
    }

    /// <summary>
    /// Add ProdPlan
    /// </summary>
    /// <returns></returns>
    [Route("PostProdPlan")]
    [HttpPost]
    // [ResponseType(typeof(ProdPlan))]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.Edit, AuthResources.TeamLeaderPage)]
    public async Task<IActionResult> PostProdPlan(ProdPlanDto prodPlan)
    {
      var response = await prodPlanService.PostProdPlan(prodPlan);
      return Ok(response);
    }

    /// <summary>
    /// Upload ProdPlan
    /// </summary>
    /// <returns></returns>
    [Route("UploadProdPlan")]
    [HttpPost]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> UploadProdPlan()
    {
      // Check if the request contains multipart/form-data.
      if (!IsMultipartContentType(Request.ContentType))
      {
        throw new CoilTrackingException {HttpStatusCode = HttpStatusCode.UnsupportedMediaType.ToString() };
      }

      try
      {
        // Read the form data, copy it to a memorystream, and pass it to the importer
        var file = HttpContext.Request.Form.Files["UploadedFile"];
        var ms = new System.IO.MemoryStream();
        await file.CopyToAsync(ms);
        List<DataImportMessage> errors
            = await importProdPlan.Import(ms, usersHelper.GetSubject());

        return Ok(new ImportResult(errors, HttpStatusCode.OK));
      }
      catch (Exception ex)
      {
        return BadRequest("Error in upload process. " + ex.ToString());
      }
    }

    /// <summary>
    /// Delete ProdPlan
    /// </summary>
    /// <returns></returns>
    [HttpDelete]
    // [ResponseType(typeof(ProdPlan))]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.Edit, AuthResources.TeamLeaderPage)]
    public async Task<IActionResult> DeleteProdPlan(int id)
    {
      var prodPlan = await prodPlanService.DeleteProdPlan(id);
      return Ok(prodPlan);
    }

    private bool IsMultipartContentType(string contentType)
    {
      return !string.IsNullOrEmpty(contentType)
             && contentType.IndexOf("multipart/", StringComparison.OrdinalIgnoreCase) >= 0;
    }
  }
}
