using CoilTracking.Business.Interfaces;
using CoilTracking.WebAPI.AuthorizationHelper;
using Microsoft.AspNetCore.Mvc;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/AdminInfo")]
  [ApiController]
  [ResourceAuthorize(AuthResources.HomeActions.View, AuthResources.AdminPage)]
  public class AdminInfoController : ControllerBase
  {
    private readonly IAdminInfoService adminInfoService;

    public AdminInfoController(IAdminInfoService adminInfoService)
    {
      this.adminInfoService = adminInfoService;
    }

    /// <summary>
    /// Get counts of objects for the dashboard
    /// </summary>
    /// <returns></returns>
    [HttpGet, Route("GetDashboardCounts")]
    public object GetDashboardCounts()
    {
      var adminInfo = adminInfoService.GetDashboardCounts();

      return adminInfo;

    }

    /// <summary>
    /// Get information about all the SignalR Clients
    /// </summary>
    /// <returns></returns>
    //[HttpGet, Route("GetSignalRInfo")]
    //public List<HubClientInfo> GetSignalRInfo()
    //{
    //    return NotificationHub.ClientInformation;
    //}


  }

}

