using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using CoilTracking.WebAPI.AuthorizationHelper;
using CoilTracking.Business.Interfaces;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Authorization;
using CoilTracking.WebAPI.Attributes;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/BlockingDiagrams")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  [ResourceAuthorize(AuthResources.HomeActions.View, AuthResources.Home)]
  
  public class BlockingDiagramsController : ControllerBase
  {
    private readonly IApplicationLogger<BlockingDiagramsController> logger;
    private readonly BlockingDiagramConfiguration settings;
    private readonly IBlockingDiagramService aWSS3FileService;

    public BlockingDiagramsController(IBlockingDiagramService aWSS3FileService, IOptions<BlockingDiagramConfiguration> settings, IApplicationLogger<BlockingDiagramsController> customLogger)
    {
      this.aWSS3FileService = aWSS3FileService;
      this.settings = settings.Value;
      this.logger = customLogger;

    }

    /// <summary>
    /// To get all blocking diagram details from db
    /// </summary>
    /// <returns>blockingDiagramDto</returns>
    // GET: api/BlockingDiagrams
    [HttpGet]
    public async Task<List<BlockingDiagramDto>> GetBlockingDiagrams()
    {
      var blockingDiagram = await aWSS3FileService.GetBlockingDiagrams();
      return blockingDiagram;
    }

    /// <summary>
    /// To get blocking diagram by Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>BlockingDiagrams</returns>
    // GET: api/BlockingDiagrams/5
    [HttpGet]
    [Route("{id}")]
    public async Task<IActionResult> GetBlockingDiagram(int id)
    {
      var blockingDiagram = await aWSS3FileService.GetBlockingDiagramById(id);
      if (blockingDiagram == null)
      {
        return NotFound();
      }

      return Ok(blockingDiagram);
    }

    /// <summary>
    /// To upload New blocking diagram to s3 bucket
    /// </summary>
    /// <returns></returns>
    [Route("SaveBlockingDiagramDto")]
    [DisableFormValueModelBinding]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> SaveBlockingDiagramDto()
    {
      try
      {
        var formFile = HttpContext.Request.Form.Files["ImageFile"];

        var xsn = Constant.jpg;
        var xsnpng = Constant.png;
        string extension = Path.GetExtension(formFile.FileName);
        if (!String.Equals(extension, xsn, StringComparison.OrdinalIgnoreCase) && !String.Equals(extension, xsnpng, StringComparison.OrdinalIgnoreCase))
        {
          throw new CoilTrackingException { ErrorMessage = "Incorrect File Format", HttpStatusCode = Constant.conflict };
        }
        var dataNum = Int32.Parse(HttpContext.Request.Form["DataNumber"]);
        var length = Math.Floor(Math.Log10(dataNum) + 1);
        if (length > 10 || length == 10)
        {
          throw new CoilTrackingException { ErrorMessage = ApplicationMessages.validationMsgForDataNum, HttpStatusCode = Constant.badRequest };
        }
        await aWSS3FileService.UploadFile(formFile, dataNum);
        logger.LogInformation(Constant.classname + "BlockingDiagram" + Constant.methodname + "SaveBlockingDiagram");
        return Ok();
      }
      catch (Exception ex)
      {
        if( ex.Message.Equals(ApplicationMessages.valueTooLong))
        {
          throw new CoilTrackingException { ErrorMessage = ApplicationMessages.validationMsgForDataNum, HttpStatusCode = Constant.badRequest };
        }
        
        throw;
        
      }
    }
  

          /// <summary>
          /// Get image by Id
          /// </summary>
          /// <param name="id"></param>
          /// <returns>fileStream</returns>
          // GET: api/BlockingDiagrams/GetBlockingDiagramFile/5
          [Route("GetBlockingDiagramFile/{dataNum}")]
    [HttpGet]
    public async Task<IActionResult> GetBlockingDiagramById(int dataNum)
    {
      try
      {
        logger.LogInformation(Constant.classname + "BlockingDiagram" + Constant.methodname + "GetBlockingDiagram");

        var result = await aWSS3FileService.GetFile(dataNum);
        return File(result, "image/png");
      }
      catch(Exception e)
      {
        logger.LogInformation(Constant.classname + "BlockingDiagram" + Constant.methodname + "GetBlockingDiagram" + Constant.message+ e.Message);

        return Ok("NoFile");
      }

    }

    // DELETE: api/BlockingDiagrams/5
    [Route("{id}")]
    [HttpDelete]
    public async Task<IActionResult> DeleteBlockingDiagram(int id)
    {
      var result = await aWSS3FileService.DeleteBlockingDiagram(id);
     
      return Ok(result);
    }
    
    [Route("UpdateBlockingDiagramDto")]
    [HttpPost]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> UpdateBlockingDiagramDto()
    {
        var formFile = HttpContext.Request.Form.Files["ImageFile"];
        var xsn = Constant.jpg;
        var xsnpng = Constant.png;
        string extension = Path.GetExtension(formFile.FileName);
        if (!String.Equals(extension, xsn, StringComparison.OrdinalIgnoreCase) && !String.Equals(extension, xsnpng, StringComparison.OrdinalIgnoreCase))
        {
          throw new CoilTrackingException { ErrorMessage = "Incorrect File Format", HttpStatusCode = Constant.conflict };
        }
        bool result = false;
          var dataNum = Int32.Parse(HttpContext.Request.Form["DataNumber"]);
          var id = Int32.Parse(HttpContext.Request.Form["id"]);
          result = await aWSS3FileService.UpdateBlockingDiagram(formFile, dataNum, id);
       
        if (!result)
        {
          return BadRequest();
        }
        return Ok();
      
    }

    /// <summary>
    /// To import blocking diagrams
    /// </summary>
    /// <returns>DataImportmessages</returns>
    // POST: api/BlockingDiagrams
    [Route("ImportBlockingDiagramDto")]
    [HttpPost]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task< IActionResult> ImportBlockingDiagramDto()
    {
      
      try
      {
        settings.AWSS3.MaxUploadFile = 200;
          var selectedFiles = HttpContext.Request.Form.Files;
        if (selectedFiles.Count > 200)
        {
          return BadRequest(  ApplicationMessages.uploadLimitException);
        }
        var errors = await aWSS3FileService.ImportBlockingDiagram(selectedFiles);
        return Ok(new ImportResult(errors, HttpStatusCode.OK));
      
      }
      catch (System.Exception ex)
      {
        return BadRequest(ApplicationMessages.uploadError + ex.ToString());
      }
    }

   
  }
}
