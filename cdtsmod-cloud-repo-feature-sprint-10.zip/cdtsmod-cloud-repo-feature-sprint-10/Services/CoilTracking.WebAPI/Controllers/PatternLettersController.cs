using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using CoilTracking.WebAPI.AuthorizationHelper;

namespace CoilTracking.WebAPI.Controllers
{

  [Route("api/[controller]")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  public class PatternLettersController : ControllerBase
  {

    private readonly IPatternLetterService patternLetterService;
    /// <summary>
    /// 
    /// </summary>
    /// <param name="customLogger"></param>
    /// <param name="PatternLetterService"></param>
    public PatternLettersController(IPatternLetterService patternLetterService)
    {
      this.patternLetterService = patternLetterService;
    }


    //// GET: api/PatternLetters
    [Route("GetPatternLetters")]
    public List<PatternLetterDto> GetPatternLetters()
    {
      var patternLetters = patternLetterService.GetPatternLetter();
      var data = patternLetters.Where(x => !x.Disabled);

      return data.ToList();
    }
    /// <summary>
    /// To get the PatternLetters
    /// </summary>
    /// <returns></returns>

    // GET: api/PatternLetters
    [Route("GetPatternLettersforAdmin")]
    public IQueryable<PatternLetterDto> GetPatternLetter()
    {
      var patternLetters = patternLetterService.GetPatternLetter();

      return patternLetters;
    }


    /// <summary>
    /// Get Pattern Letter by Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [Route("GetPatternLetterForEdit/{id}")]
    public IActionResult GetPatternLetterById(int id)
    {

      var patternLetters = patternLetterService.GetPatternLetterById(id);
      if (patternLetters == null)
      {
        return NotFound();
      }

      return Ok(patternLetters);

    }

    /// <summary>
    /// To add new PatternLetters
    /// </summary>
    /// <param name="patternLetter"></param>
    /// <returns></returns>
    //[HttpPost, Route("PostPatternLetter", Name = "PostPatternLetter")]
    [HttpPost]
    [Route("PostPatternLetter")]
    public IActionResult PostPatternLetter(PatternLetterDto patternLetter)
    {
      var patternLetters = patternLetterService.PostPatternLetter(patternLetter);
      return Ok(patternLetters);
      //CreatedAtRoute("PostPatternLetter", new { id = patternLetter.Id }, patternLetter);
    }



    /// <summary>
    /// To Edit Pattern Letters
    /// </summary>
    /// <param name="id"></param>
    /// <param name="patternLetter"></param>
    /// <returns></returns>
    [Route("UpdatePatternLetterDto/{id}")]

    public IActionResult PutPatternLetter(int id, PatternLetterDto patternLetter)
    {


      if (id != patternLetter.Id)
      {
        return BadRequest();
      }
      var checkIfPatternLettersEdited = patternLetterService.PutPatternLetter(id, patternLetter);
      if (checkIfPatternLettersEdited == false)
      {
        return NotFound();
      }
      return NoContent();
    }

    /// <summary>
    /// To delete Pattern Letters
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [Route("DeletePatternLetter")]
    public IActionResult DeletePatternLetter(int id)
    {
      var deletedPatternLetters = patternLetterService.DeletePatternLetter(id);

      return Ok(deletedPatternLetters);
    }

    /// <summary>
    /// To disable a Pattern Letter
    /// </summary>
    /// <param name="id"></param>
    /// <param name="disable"></param>
    /// <returns></returns>
    [Route("DisablePatternLetter/{id}/{disable}")]
    [HttpGet]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    //public async Task<IActionResult> DisablePatternLetter(int id, bool disable)
    public IActionResult DisablePatternLetter(int id, bool disable)
    {
      var checkIfPatternLetterDisabled = patternLetterService.DisablePatternLetter(id, disable);

      if (checkIfPatternLetterDisabled == false)
      {
        return NotFound();
      }

      return NoContent();
    }

    /// <summary>
    /// To find associations of PatternLetter with PatternCallendar
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [HttpGet, Route("CheckDependency")]
    public IActionResult CheckDependency(int id)
    {
      List<string> patternLettersDependencyType = new List<string>();
      patternLettersDependencyType = patternLetterService.CheckDependency(id);

      return Ok(patternLettersDependencyType);

    }

    /// <summary>
    /// To check if the model is modified while performing delete operation
    /// </summary>
    /// <param name="id"></param>
    /// <param name="patternLetterDto"></param>
    /// <returns></returns>
    [HttpPost, Route("CheckEdit")]
    [ValidateAntiForgeryToken]
    public IActionResult CheckEdit(int id, PatternLetterDto patternLetterDto)
    {
      var checkIfPatternLettersEdited = patternLetterService.CheckEdit(id, patternLetterDto);

      if (checkIfPatternLettersEdited == false)
      {
        return BadRequest();
      }
      return NotFound();

    }

  }
}
