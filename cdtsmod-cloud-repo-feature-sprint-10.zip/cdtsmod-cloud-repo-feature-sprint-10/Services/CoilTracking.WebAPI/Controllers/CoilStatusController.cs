using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using CoilTracking.WebAPI.AuthorizationHelper;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/[controller]")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  [ResourceAuthorize(AuthResources.HomeActions.View, AuthResources.Home)]
  public class CoilStatusController : ControllerBase
  {
    private readonly ICoilStatusService coilStatusService;

    public CoilStatusController(ICoilStatusService coilStatusService)
    {
      this.coilStatusService = coilStatusService;
    }

    /// <summary>
    /// Get list of  coil status dto 
    /// </summary>
    /// <returns>CoilStatusDto</returns>
    /// // GET: api/CoilStatus
    [HttpGet]
    public async Task<List<CoilStatusDto>> GetCoilStatuses()
    {
      var coilStatus = await coilStatusService.GetCoilStatuses();
      return coilStatus;
    }

    /// <summary>
    /// Get coil status by Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>CoilStatusDto</returns>
    // GET: api/CoilStatus/5
    //[ResponseType(typeof(CoilStatus))]
    [Route("{id}")]
    public async Task<IActionResult> GetCoilStatus(int id)
    {
      CoilStatusDto coilStatus = await coilStatusService.GetCoilStatusById(id);
      if (coilStatus == null)
      {
        return NotFound();
      }

      return Ok(coilStatus);
    }

    /// <summary>
    /// Create new CoilStatus
    /// </summary>
    /// <param name="coilStatus"></param>
    /// <returns>CoilStatusDto</returns>
    // POST: api/CoilStatus
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public IActionResult PostCoilStatus(CoilStatusDto coilStatusDto)
    {
      coilStatusService.InsertCoilStatus(coilStatusDto);
      return Ok(coilStatusDto);
    }

    /// <summary>
    /// Update a coil status 
    /// </summary>
    /// <param name="id"></param>
    /// <param name="coilStatus"></param>
    /// <returns>void</returns>
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    // PUT: api/CoilStatus/5
    [HttpPut, Route("{id}")]
    public IActionResult PutCoilStatus(int id, CoilStatusDto coilStatus)
    {

      if (id != coilStatus.Id)
      {
        return BadRequest();
      }
      coilStatusService.UpdateCoilStatus(id, coilStatus);

      return NoContent();
    }

    /// <summary>
    /// Delete coil status by Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>CoilStatus</returns>
    // DELETE: api/CoilStatus/5
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    [HttpDelete]
    [Route("{id}")]
    public IActionResult DeleteCoilStatus(int id)
    {
      var coilStatus = coilStatusService.DeleteCoilStatus(id);
      if (coilStatus == null)
      {
        return NotFound();
      }

      return Ok(coilStatus);
    }

  }
}
