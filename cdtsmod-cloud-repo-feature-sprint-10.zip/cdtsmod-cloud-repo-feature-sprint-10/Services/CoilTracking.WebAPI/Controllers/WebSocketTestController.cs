using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/websockettest")]
  [ApiController]
  [AllowAnonymous]
  [ExcludeFromCodeCoverage]
  public class WebSocketTestController : ControllerBase
  {
    private readonly IWebSocketClientService webSocketClientService;

    public WebSocketTestController(IWebSocketClientService webSocketClientService)
    {
      this.webSocketClientService = webSocketClientService;
    }

    [HttpGet]
    public async Task TestNotification()
    {
      await webSocketClientService.UpdateNotificationCount(3);
      await webSocketClientService.UpdateStackerCount(3, 5, 5);
      await webSocketClientService.UpdateDt(new UpdateDtDto
      {
        LineId = 1,
        Schd = 3,
        Tryout = 6,
        Kanban = 5,
        Prod = 4,
        Tooldie = 9,
        Adc = 7,
        DataNum = 2,
        Maint = 6
      });
    }
  }
}
