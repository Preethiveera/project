using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Exception;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Threading.Tasks;
using CoilTracking.WebAPI.AuthorizationHelper;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/Patterns")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  [ResourceAuthorize(AuthResources.TeamLeaderActions.View, AuthResources.TeamLeaderPage)]
  public class PatternsController : ControllerBase
  {

    private readonly IPatternService patternService;

    public PatternsController(IPatternService patternService)
    {
      this.patternService = patternService;
    }

    /// <summary>
    /// Get patterns
    /// </summary>
    /// <returns></returns>
    [Route("GetPatterns")]
    [HttpGet]
    public async Task<IActionResult> GetPatterns()
    {
      return Ok(await patternService.GetPatterns());
    }

    /// <summary>
    /// Get pattern
    /// </summary>
    /// <param name="id"></param>
    /// <returns>PatternDto</returns>
    [Route("{id}")]
    [HttpGet]
    public async Task<IActionResult> GetPattern(int id)
    {
      return Ok(await patternService.GetPattern(id));
    }

    /// <summary>
    /// Get pattern by lineId ,patternLetter, year and month
    /// </summary>
    /// <param name="lineId"></param>
    /// <param name="patternLetter"></param>
    /// <param name="year"></param>
    /// <param name="month"></param>
    /// <returns>PatternDto</returns>
    [Route("GetPattern/{lineId}/{patternLetter}/{year}/{month}")]
    [HttpGet]
    public async Task<IActionResult> GetPattern(int lineId, string patternLetter, int year, int month)
    {
      try
      {
        return Ok(await patternService.GetPattern(lineId, patternLetter, year, month));
      }
      catch(CoilTrackingException ex)
      {
        if(ex.HttpStatusCode == "NotFound")
        {
          return NotFound(ex.ErrorMessage);
        }

        return BadRequest();
      }
    }

    /// <summary>
    /// Get patterns for export
    /// </summary>
    /// <returns>PatternExportDto</returns>
    [Route("GetPatternsForExport")]
    [HttpGet]
    public async Task<IActionResult> GetPatternsForExport()
    {
      return Ok(await patternService.GetPatternsForExport());
    }

    /// <summary>
    /// Put pattern
    /// </summary>
    /// <param name="id"></param>
    /// <param name="pattern"></param>
    /// <returns>bool</returns>
    [Route("PutPattern/{id}")]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditPattern, AuthResources.TeamLeaderPage)]
    [HttpPut]
    public async Task<IActionResult> PutPattern(int id, PatternDto pattern)
    {
      if (!ModelState.IsValid)
      {
        return BadRequest(ModelState);
      }

      if (id != pattern.Id)
      {
        return BadRequest();
      }

      await patternService.PutPattern(id, pattern);

      return StatusCode((int)HttpStatusCode.NoContent);
    }

    /// <summary>
    /// Post pattern
    /// </summary>
    /// <param name="patternDto"></param>
    /// <returns></returns>
    [Route("PostPattern")]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditPattern, AuthResources.TeamLeaderPage)]
    [HttpPost]
    public async Task<IActionResult> PostPattern(PatternDto patternDto)
    {
      if (!ModelState.IsValid)
      {
        return BadRequest(ModelState);
      }

      var pattern = await patternService.PostPattern(patternDto);

      return Ok(pattern);

    }

    /// <summary>
    /// Delete pattern
    /// </summary>
    /// <param name="id"></param>
    /// <returns>PatternDto</returns>
    [Route("{id}")]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditPattern, AuthResources.TeamLeaderPage)]
    [HttpDelete]
    public async Task<IActionResult> DeletePattern(int id)
    {
      var pattern = await patternService.DeletePattern(id);

      return Ok(pattern);
    }
  }
}
