using CoilTracking.Common.Logging;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using System;
using CoilTracking.WebAPI.AuthorizationHelper;
using System.Diagnostics.CodeAnalysis;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/TestCloudWatchLog")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  [ExcludeFromCodeCoverage]
  public class TestCloudWatchLogController : Controller
  {

    private readonly IApplicationLogger<TestCloudWatchLogController> _logger;

    public TestCloudWatchLogController(IApplicationLogger<TestCloudWatchLogController> logger)
    {
      _logger = logger;
    }
    public IActionResult Index()
    {
      string teststring = $"Testing cloudwatchlog  { DateTime.Now}";
      _logger.LogInformation(teststring);
      return Content(teststring);
    }
  }
}
