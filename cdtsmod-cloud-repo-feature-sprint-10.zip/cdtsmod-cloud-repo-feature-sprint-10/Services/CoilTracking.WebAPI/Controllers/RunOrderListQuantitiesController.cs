using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Data.Models;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using CoilTracking.WebAPI.AuthorizationHelper;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/RunOrderItems")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  [ResourceAuthorize(AuthResources.HomeActions.View, AuthResources.Home)]
  public class RunOrderListQuantitiesController : ControllerBase
  {
    private readonly IRunOrderListQuantityService runOrderListQuantityService;
    /// <summary>
    /// RunOrderListQuantities
    /// </summary>
    /// <param name="runOrderListQuantityService"></param>
    public RunOrderListQuantitiesController(IRunOrderListQuantityService runOrderListQuantityService)
    {
      this.runOrderListQuantityService = runOrderListQuantityService;
    }

    /// <summary>
    /// Get RunOrderListQuantities
    /// </summary>
    /// <returns></returns>
    // GET: api/RunOrderListQuantities
    [HttpGet]
    public async Task<IActionResult> GetRunOrderListQuantities()
    {
      var rr = await runOrderListQuantityService.GetRunOrderListQuantities();
      return Ok(rr);
    }
    /// <summary>
    /// Get  RunOrderListQuantities Based on ID 
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    // GET: /api/RunOrderItems/RunOrderListQuantities?id=3
    [HttpGet]
    [Route("RunOrderListQuantities/{id}")]
    public IActionResult GetRunOrderListQuantity(int id)
    {
      RunOrderListQuantity runOrderListQuantity = runOrderListQuantityService.GetRunOrderListQuantity(id);
      if (runOrderListQuantity == null)
      {
        return NotFound();
      }
      return Ok(runOrderListQuantity);
    }

    /// <summary>
    /// Get RunOrderItem Based on parameters lineId,partNumber,sortOrder
    /// </summary>
    /// <param name="lineId"></param>
    /// <param name="partNumber"></param>
    /// <param name="sortOrder"></param>
    /// <returns></returns>
    ///GET: api/RunOrderItems/GetRunOrderItem/3/61631-02170/1
    [Route("GetRunOrderItem/{lineId}/{partNumber}/{sortOrder}")]
    [HttpGet]
    public IActionResult GetRunOrderItem(int lineId, string partNumber, int sortOrder)
    {
      try
      {
        RunOrderItemForCreate runOrderItemForCreate = runOrderListQuantityService.GetRunOrderItem(lineId, partNumber, sortOrder);
        if (runOrderItemForCreate == null)
        {
          return NotFound();
        }
        return Ok(runOrderItemForCreate);
      }
      catch (CoilTrackingException ex)
      {
        return ex.ErrorNumber == Constant.notfound ? NotFound(ex.ErrorMessage) : (IActionResult)NotFound(ex.ErrorMessage);
      }
    }
    /// <summary>
    /// Modify  RunOrderListQuantities Based on Id
    /// </summary>
    /// <param name="id"></param>
    /// <param name="runOrderListQuantity"></param>
    /// <returns></returns>
    // PUT: api/RunOrderListQuantities/3
    //{ "id":"3","sortOrder": 0, "part": {"PartName":"yueuir","PartNumber":"8234682"},"blankInfo": {"Line":{"Tags":"A","Plant":{"TimeZone":{"Name":"A1"},"PlantName":"A"},"LineName":"As","LinePath":"A","OPCServer":{"ServerName":"A","InstanceName":"A"}}, "Part":{"PartName":"A1","PartNumber":"8234682"},"CoilType":{"Name":"Ae","Spec":"1"}},"quantity": 0, "overrideQty": 0,"runOrderList": {"Line":{"Tags":"A","Plant":{"TimeZone":{"Name":"A1"},"PlantName":"A"},"LineName":"As","LinePath":"A","OPCServer":{"ServerName":"A","InstanceName":"A"}}, "Shift":{"Name":"rr"}},"incomplete": false}
    [HttpPut]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.Edit, AuthResources.TeamLeaderPage)]
    [Route("RunOrderListQuantities/{id}")]
    public IActionResult PutRunOrderListQuantity(int id, RunOrderListQuantity runOrderListQuantity)
    {
      if (!ModelState.IsValid)
      {
        return BadRequest(ModelState);
      }
      if (id != runOrderListQuantity.Id)
      {
        return NotFound();
      }
      try
      {
        runOrderListQuantityService.UpdateRunOrderListQuantity(id, runOrderListQuantity);
      }
      catch (Exception)
      {
        return NotFound();
      }
      return Ok();
    }

    /// <summary>
    /// Insert new Record to RunOrderListQuantities 
    /// </summary>
    /// <param name="runOrderListQuantity"></param>
    /// <returns></returns>
    // POST: api/RunOrderListQuantities
    //{ "sortOrder": 0, "part": {"PartName":"yueuir","PartNumber":"8234682"},"blankInfo": {"Line":{"Tags":"A","Plant":{"TimeZone":{"Name":"A1"},"PlantName":"A"},"LineName":"As","LinePath":"A","OPCServer":{"ServerName":"A","InstanceName":"A"}}, "Part":{"PartName":"A1","PartNumber":"8234682"},"CoilType":{"Name":"Ae","Spec":"1"}},"quantity": 0, "overrideQty": 0,"runOrderList": {"Line":{"Tags":"A","Plant":{"TimeZone":{"Name":"A1"},"PlantName":"A"},"LineName":"As","LinePath":"A","OPCServer":{"ServerName":"A","InstanceName":"A"}}, "Shift":{"Name":"rr"}},"incomplete": false}
    [HttpPost]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.Edit, AuthResources.TeamLeaderPage)]
    [Route("RunOrderListQuantities")]
    public IActionResult PostRunOrderListQuantity(RunOrderListQuantity runOrderListQuantity)
    {
      if (!ModelState.IsValid)
      {
        return BadRequest(ModelState);
      }
      try
      {
        runOrderListQuantityService.InsertRunOrderListQuantity(runOrderListQuantity);
        return Ok(runOrderListQuantity);
      }
      catch (Exception ex)
      {
        return NotFound(ex);
      }  
    }
    /// <summary>
    /// Deletion of RunOrderListQuantities Based on Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    // DELETE: api/RunOrderListQuantities/5
    [HttpDelete]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.Edit, AuthResources.TeamLeaderPage)]
    [Route("RunOrderListQuantities/{id}")]
    public IActionResult DeleteRunOrderListQuantity(int id)
    {
      try
      {
        runOrderListQuantityService.DeleteRunOrderListQuantity(id);
      }
      catch (Exception ex)
      {
        return NotFound(ex);
      }
      return Ok();
    }
  }
}
