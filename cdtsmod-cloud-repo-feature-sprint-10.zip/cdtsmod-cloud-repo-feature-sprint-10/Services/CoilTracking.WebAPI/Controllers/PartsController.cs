using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data.Models;
using CoilTracking.DTO;
using CoilTracking.WebAPI.AuthorizationHelper;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/Parts")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  [ResourceAuthorize(AuthResources.HomeActions.View, AuthResources.Home)]
  public class PartsController : ControllerBase
  {
    public readonly IPartsService partsService;
    public readonly IBlankInfoService blankinfoService;
    private readonly IImportPartData importPartDataService;
    private readonly IUserHelper usersHelper;

    public PartsController(IPartsService partsService, IBlankInfoService blankinfoService, IImportPartData importPartDataService,IUserHelper usersHelper)
    {
      this.partsService = partsService;
      this.blankinfoService = blankinfoService;
      this.importPartDataService = importPartDataService;
      this.usersHelper = usersHelper;
    }

    // GET: api/Parts
    /// <summary>
    /// Get All Parts
    /// </summary>
    /// <returns></returns>
    ///
    [HttpGet]
    public async Task<IActionResult> GetParts()
    {
      var parts = await partsService.GetParts();
      return Ok(parts);
    }

    /// <summary>
    /// Get Part Dtos
    /// </summary>
    /// <returns></returns>
    // GET: api/Parts
    [HttpGet, Route("GetPartDtos")]
    public async Task<IActionResult> GetPartDtos()
    {
      var parts = await partsService.GetParts();
      return Ok(parts);

    }
    /// <summary>
    /// Get Part By Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    // GET: api/Parts/5
    [HttpGet]
    [Route("{id}")]
    public async Task<IActionResult> GetPart(int id)
    {
      var part = await partsService.GetPartById(id);
      if (part == null)
      {
        return NotFound();
      }

      return Ok(part);
    }
    /// <summary>
    /// Get PartModels Based On ID
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    // GET: api/Parts/GetPartModels/5
    [HttpGet, Route("GetPartModels/{id}")]
    public async Task<IActionResult> GetPartModels(int id)
    {
      try
      {
        var partModels = await partsService.GetPartModelsById(id);
        if (partModels == null)
        {
          return NotFound();
        }
        return Ok(partModels);
      }
      catch (CoilTrackingException ex)
      {
        return ex.ErrorNumber == Constant.errornotfound ? NotFound(ex.ErrorMessage) : (IActionResult)NotFound(ex.ErrorMessage);
      }


    }

    /// <summary>
    /// GetAutoCompleteData
    /// </summary>
    /// <param name="partNumber"></param>
    /// <param name="lineId"></param>
    /// <returns></returns>
    [HttpGet, Route("GetAutoCompleteData")]
    public async Task<IActionResult> GetAutoCompleteData(string partNumber, int lineId)
    {
      var partsInfo = await partsService.GetAutoCompleteInfo(partNumber, lineId);
      return Ok(partsInfo);
    }

    /// <summary>
    /// Update Part Based on Id and Part
    /// </summary>
    /// <param name="id"></param>
    /// <param name="part"></param>
    /// <returns></returns>
    [HttpPut]
    [Route("PutPart/{id}")]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditPart, AuthResources.TeamLeaderPage)]
    
    public async Task<IActionResult> PutPart(int id, Part part)
    {
      if (id != part.Id)
      {
        return BadRequest();
      }
      try
      {
        await partsService.UpdatePart(id, part);
        return NoContent();
      }
      catch (CoilTrackingException ex)
      {
        return ex.ErrorNumber == Constant.errornotfound ? NotFound(ex.ErrorMessage) : (IActionResult)NotFound(ex.ErrorMessage);
      }
    }
    /// <summary>
    /// DisablePart Based On ID
    /// </summary>
    /// <param name="id"></param>
    /// <param name="disable"></param>
    /// <returns></returns>
    [Route("DisablePart/{id}/{disable}")]
    [HttpGet]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditPart, AuthResources.TeamLeaderPage)]
    public async Task<IActionResult> DisablePart(int id, bool disable)
    {
      try
      {
        await partsService.DisablePart(id, disable);
        return NoContent();
      }
      catch (CoilTrackingException ex)
      {
        return ex.ErrorNumber == Constant.errornotfound ? NotFound(ex.ErrorMessage) : (IActionResult)NotFound(ex.ErrorMessage);
      }
    }

    /// <summary>
    /// Change Models 
    /// </summary>
    /// <param name="data"></param>
    /// <returns></returns>
    [Route("ChangeModels")]
    [HttpPut]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditPart, AuthResources.TeamLeaderPage)]
    public async Task<IActionResult> ChangeModels(JObject data)
    {
      int Id = data["Id"].ToObject<int>();
      List<Model> models = data["Models"].ToObject<List<Model>>();
      await partsService.ChangeModels(models, Id);
      return Ok();
    }

    /// <summary>
    /// Insert Part Based On Part Info
    /// </summary>
    /// <param name="part"></param>
    /// <returns></returns>
    // POST: api/Parts
    [Route("PostPart")]
    [HttpPost]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditPart, AuthResources.TeamLeaderPage)]
    public async Task<IActionResult> PostPart(Part part)
    {
      
      try
      {
        var parts = await partsService.InsertPart(part);
        return Ok(parts);
      }
      catch (CoilTrackingException ex)
      {
        return ex.ErrorNumber == Constant.errornotfound ? NotFound(ex.ErrorMessage) : (IActionResult)NotFound(ex.ErrorMessage);
      }
    }
    /// <summary>
    /// Delete Part Based On Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    // DELETE: api/Parts/5
    [HttpDelete]
    [Route("{id}")]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditPart, AuthResources.TeamLeaderPage)]
    public async Task<IActionResult> DeletePart(int id)
    {
      try
      {
        Part part = await partsService.DeletePart(id);
        return Ok(part);
      }
      catch (CoilTrackingException ex)
      {
        return ex.ErrorNumber == Constant.errornotfound ? NotFound(ex.ErrorMessage) : (IActionResult)NotFound(ex.ErrorMessage);
      }
    }

    /// <summary>
    /// Check the Part
    /// </summary>
    /// <param name="id"></param>
    /// <param name="part"></param>
    /// <returns></returns>
    [HttpPost, Route("CheckEdit")]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> CheckEdit(int id, Part part)
    {
      if (!ModelState.IsValid)
      {
        return BadRequest(ModelState);
      }
      try
      {
        await partsService.PartCheckEdit(id, part);
        return Ok();
      }
      catch (CoilTrackingException ex)
      {
        return ex.ErrorNumber == Constant.errornotfound ? NotFound(ex.ErrorMessage) : (IActionResult)NotFound(ex.ErrorMessage);
      }
    }

    /// <summary>
    /// Get BlankInfo Based On Part Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    /// /api/parts/PartsGetDependency?id=3
    [HttpGet, Route("PartsGetDependency")]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditPart, AuthResources.TeamLeaderPage)]
    public async Task<IActionResult> PartsGetDependency(int id)
    {
      var blankinfo = await blankinfoService.GetBlankInfoByPartId(id);
      return Ok(blankinfo);
    }


    /// <summary>
    /// Get Parts In RunOrder
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [HttpGet, Route("GetPartsInRunOrder")]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditPart, AuthResources.TeamLeaderPage)]
    public async Task<IActionResult> GetPartsInRunOrder(int id)
    {
      var blanksData = await blankinfoService.GetBlankInfoPartsInRunOrder(id);
      return Ok(blanksData);
    }

    /// <summary>
    /// Get Part ProdPlan Association
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [HttpGet, Route("PartProdPlanAssociation")]
    public async Task<IActionResult> PartProdPlanAssociation(int id)
    {
      var partAssociation = await partsService.GetPartProdPlanAssociation(id);
      return Ok(partAssociation);
    }

    [Route("UploadPart")]
    [HttpPost]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> UploadPart()
    {
      // Check if the request contains multipart/form-data.
      if (!(Request.HasFormContentType && Request.Form.Files.Any()))
      {
        throw new CoilTrackingException { HttpStatusCode = "UnsupportedMediaType" };
      }
      try
      {
        // Read the form data, copy it to a memorystream, and pass it to the importer
        var file = HttpContext.Request.Form.Files["UploadedFile"];
        var ms = new System.IO.MemoryStream();
        await file.CopyToAsync(ms);
        List<DataImportMessage> messages = await importPartDataService.Import(ms, usersHelper.GetSubject());
        return Ok(new ImportResult(messages, HttpStatusCode.OK));
      }
      catch (System.Exception ex)
      {
        return BadRequest("Error in upload process. " + ex.ToString());
      }
    }
  }
}
