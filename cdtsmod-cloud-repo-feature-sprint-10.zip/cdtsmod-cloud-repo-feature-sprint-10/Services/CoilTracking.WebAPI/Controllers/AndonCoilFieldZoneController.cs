using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using CoilTracking.WebAPI.AuthorizationHelper;
using Microsoft.AspNetCore.Authorization;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/[controller]")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  public class AndonCoilFieldZoneController : ControllerBase
  {

    private readonly IAndonService andonService;
    /// <summary>
    /// AndonCoilFieldZone
    /// </summary>
    /// <param name="customLogger"></param>
    /// <param name="andonService"></param>
    public AndonCoilFieldZoneController(IAndonService andonService)
    {

      this.andonService = andonService;
    }
    /// <summary>
    /// Get Andon CoilFieldZone Info
    /// </summary>
    /// <param name="zoneId"></param>
    /// <returns></returns>
    /// GET: api/AndonCoilFieldZone
    [AllowAnonymous] //Andon's don't authorize, allow anonymous
    [HttpGet]
    public AndonCoilFieldZoneDisplayObject Get(int? zoneId = null)
    {
      //Call service layer to get the list of all coilsthat are placed in a location to avoid querying the DB many times 
      var zones = andonService.GetCoilsFeildsByZoneId(zoneId);
      return zones;

    }

  }
}
