using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoilTracking.WebAPI.AuthorizationHelper;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/OpcConfigs")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  [ResourceAuthorize(AuthResources.HomeActions.View, AuthResources.Home)]
  public class OPCConfigsController : ControllerBase
  {
    private readonly IOPCConfigService configService;

    public OPCConfigsController(IOPCConfigService configService)
    {
      this.configService = configService;
    }

    /// <summary>
    /// To get opc configs from table
    /// </summary>
    /// <returns>List of opcConfigs</returns>
    public async Task<List<OPCConfigDTO>> GetOPCConfigs()
    {
      var opcConfigs = await configService.GetOPCConfigs();
      return opcConfigs.ToList();
    }

    // GET: api/OPCConfigs/5
    //[ResponseType(typeof(OPCConfig))]
    [Route("{id}")]
    public async  Task<IActionResult> GetOPCConfig(int id)
    {
      OPCConfigDTO oPCConfig = await configService.GetOPCConfigById(id);
      
      if (oPCConfig == null)
      {
        return NotFound();
      }

      return Ok(oPCConfig);
    }

    /// <summary>
    /// Get dependency for opcconfigs
    /// </summary>
    /// <param name="id"></param>
    /// <returns>list of lines</returns>
    [HttpGet, Route("KepGetDependency")]
    //[ResponseType(typeof(List<Line>))]
    public async Task<IActionResult> KepGetDependency(int id)
    {
      var lines = await configService.GetDependencyForKep(id);
      return Ok(lines);
    }

    /// <summary>
    /// To update an existing opcconfig
    /// </summary>
    /// <param name="id"></param>
    /// <param name="oPCConfig"></param>
    /// <returns></returns>
    // PUT: api/OPCConfigs/5
    [HttpPut, Route("{id}")]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public IActionResult PutOPCConfig(int id, OPCConfigDTO oPCConfig)
    {
      if (id != oPCConfig.Id)
      {
        return BadRequest();
      }
      configService.UpdateOPCConfig(id, oPCConfig);
     
      return NoContent();
    }

    /// <summary>
    /// To disable an opcconfig by id
    /// </summary>
    /// <param name="id"></param>
    /// <param name="disable"></param>
    /// <returns></returns>
    [Route("DisableOPCConfig/{id}/{disable}")]
    [HttpGet]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> DisableOPCConfig(int id, bool disable)
    {
      await configService.DisableOPCConfig(id, disable);
      return NoContent();
    }

    /// <summary>
    /// To add new opcconfig
    /// </summary>
    /// <param name="oPCConfig"></param>
    /// <returns></returns>
    // POST: api/OPCConfigs
    //[ResponseType(typeof(OPCConfig))]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    [HttpPost]
    public async Task<IActionResult> PostOPCConfig(OPCConfigDTO oPCConfig)
    {
      var opcconfig = await configService.InsertOPCConfig(oPCConfig);
      return Ok(opcconfig);
    }

    /// <summary>
    /// To delete opcconfig by id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    // DELETE: api/OPCConfigs/5
    [HttpDelete, Route("{id}")]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> DeleteOPCConfig(int id)
    {
      var oPCConfig = await configService.DeleteOPCConfig(id);
      return Ok(oPCConfig);
    }

    /// <summary>
    /// Get lines in runorder by opcconfig id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [HttpGet, Route("GetLinesInRunOrderById")]
    //[ResponseType(typeof(List<Line>))]
    public async Task<IActionResult> GetLinesInRunOrderById(int id)
    {
      var linesInRunOrderList = await configService.GetLinesInRunOrderById(id);
      
      return Ok(linesInRunOrderList);
    }

    /// <summary>
    /// to get dependency type from incomplete runorderlist
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [HttpPost, Route("CheckDependency")]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> CheckDependency(int id)
    {
      List<string> kepAssociation = new List<string>();
      var associatedItem =await configService.GetLinesInRunOrderById(id);
      if (associatedItem.Any())
      {
        kepAssociation.Add(Constant.RunOrder);
      }
      
      return Ok(kepAssociation);

    }

    /// <summary>
    /// Check if opcconfig is edited
    /// </summary>
    /// <param name="id"></param>
    /// <param name="oPCConfig"></param>
    /// <returns></returns>
    [HttpPost, Route("CheckEdit")]
    public async Task< IActionResult> CheckEdit(int id, OPCConfigDTO oPCConfig)
    {
      
      var checkIfEdited = await configService.CheckIfEdited(id, oPCConfig);
      if (!checkIfEdited)
      {
        return BadRequest();
      }
     
      return NotFound();

    }
  }
}
