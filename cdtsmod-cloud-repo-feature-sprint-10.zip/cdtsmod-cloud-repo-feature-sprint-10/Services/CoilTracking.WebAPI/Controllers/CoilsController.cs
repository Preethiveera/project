using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constant;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Data.Models;
using CoilTracking.DTO;
using CoilTracking.WebAPI.AuthorizationHelper;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using System;
using System.Threading.Tasks;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/Coils")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  [ResourceAuthorize(AuthResources.HomeActions.View, AuthResources.Home)]
  public class CoilsController : ControllerBase
  {
    private readonly ICoilsService coilsService;
    public CoilsController(ICoilsService coilsService)
    {
      this.coilsService = coilsService;   
    }
    /// <summary>
    /// Get Coils
    /// </summary>
    /// <returns></returns>
    // GET: api/Coils or api/Coils/GetCoils
    [Route("GetCoils")]
    [Route("")]
    public async Task<IActionResult> GetCoils()
    {

      var coils = await coilsService.GetCoils();
      return Ok(coils);
    }

    [AllowAnonymous]
    [HttpGet, Route("GetNAMCCode")]
    public async Task<IActionResult> GetNAMCinfo()
    {
      var code = await coilsService.GetPlantCode();
      return Ok(code);

    }
    // GET: api/Coils/Search
    [HttpGet, Route("Search")]
    public async Task<IActionResult> Search(DateTime? startTime = null, DateTime? endTime = null, string coilType = null, int? coilStatusId = null, int? zoneId = null, string FilterByBornOnDate = Constant.zero)
    {
      var search = await coilsService.SearchForCoils(startTime, endTime, coilType, coilStatusId, zoneId, FilterByBornOnDate);
      return Ok(search);
    }

    /// <summary>
    /// Gets list of coils/inventory information
    /// GET: api/Coils/GetCoilInventory
    /// </summary>
    /// <returns></returns>
    [Route("GetCoilInventory")]
    [HttpGet]
    public async Task<IActionResult> GetCoilInventory()
    {
      var coilInventoryDto = await coilsService.GetCoilInventory();
      return Ok(coilInventoryDto);
    }

    // GET: api/Coils/5
    [Route("{id}")]
    public async Task<IActionResult> GetCoilById(int id)
    {
      var coil = await coilsService.GetCoilsById(id);
      if (coil == null)
      {
        return NotFound();
      }
      return Ok(coil);
    }

    /// <summary>
    /// GET: api/Coils/GetCoilByFTZ/FTZ123456789012
    /// Get coil Dto by the FTZ #
    /// </summary>
    /// <param name="ftz">Foreign Trade Zone # for the coil</param>
    /// <returns>Dto with coil information</returns>
    /// /api/Coils/GetCoilByFTZ/TMSS2104023033
    [HttpGet, Route("GetCoilByFTZ/{ftz}")]
    public async Task<IActionResult> GetCoilByFTZ(string ftz)
    {
      var coilDto = await coilsService.GetCoilByFTZ(ftz);

      if (coilDto == null)
      {
        return NotFound();
      }
      return Ok(coilDto);
    }

    /// <summary>
    /// GET: api/Coils/GetCoilByLocationId/4-B11
    /// Get coil Dto by the coil field location full name (such as 4-B11)
    /// </summary>
    /// <param name="coilFieldLocationFullName">Coil field location full name such as 4-B11</param>
    /// <returns>Dto with coil information</returns>
    /// /api/Coils/GetCoilByLocationFullName/1-A6
    [HttpGet, Route("GetCoilByLocationFullName/{coilFieldLocationFullName}")]
    public async Task<IActionResult> GetCoilByLocationFullName(string coilFieldLocationFullName)
    {
      if (string.IsNullOrWhiteSpace(coilFieldLocationFullName) || !coilFieldLocationFullName.Contains('-') || coilFieldLocationFullName.Length < 4)
      {
        return BadRequest(Constant.location + coilFieldLocationFullName + Constant.locationFormat);
      }
      var location = await coilsService.GetCoilsLocationName(coilFieldLocationFullName);

      if (location == null)
      {
        //A valid existing CoilFieldLocation is required
        return NotFound(Constant.locationNotfound + coilFieldLocationFullName);
      }
      return Ok(location.Id);
    }

    /// <summary>
    /// GET: api/Coils/GetCoilByLocationId/25
    /// Get coil Dto by the coil field location Id
    /// </summary>
    /// <param name="coilFieldLocationId">Coil field location Id</param>
    /// <returns>Dto with coil information</returns>
    [HttpGet, Route("GetCoilByLocationId/{coilFieldLocationId}")]
    public async Task<IActionResult> GetCoilByLocationId(int coilFieldLocationId)
    {
      var coilDto = await coilsService.GetCoilsByLocationId(coilFieldLocationId);
      return Ok(coilDto);
    }

    /// <summary>
    /// GET: api/Coils/GetCoilForEdit/5
    /// Get a coil Dto by the coil id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [HttpGet, Route("GetCoilForEdit/{id}")]
    public async Task<IActionResult> GetCoilForEdit(int id)
    {
      var coilDto = await coilsService.GetCoilForModify(id);
      if (coilDto == null)
      {
        return NotFound();
      }
      return Ok(coilDto);
    }
    /// <summary>
    /// Get Coils To Be Weighed
    /// </summary>
    /// <returns></returns>
    [HttpGet, Route("GetCoilsToBeWeighed")]
    public async Task<IActionResult> GetCoilsToBeWeighed()
    {
      var coilDtos = await coilsService.GetCoilsToBeWeighed();
      return Ok(coilDtos);
    }

    /// <summary>
    /// Gets the total coil weight left in inventory for the given CoilType
    /// </summary>
    /// <param name="coilTypeId"></param>
    /// <returns></returns>
    [HttpGet, Route("GetRemainingCoilWeight/{coilTypeId}")]
    public async Task<IActionResult> GetRemainingCoilWeight(int coilTypeId)
    {
      var weightRemainingMinusYield = await coilsService.GetRemainingCoilWeightById(coilTypeId);
      return Ok(weightRemainingMinusYield);
    }

    /// <summary>
    ///Get  MaterialTypeBased on YNA
    /// </summary>
    /// <param name="yna"></param>
    /// <returns></returns>
    [HttpGet, Route("MaterialTypeByYNA/{yna}")]
    public async Task<IActionResult> MaterialTypeByYNA(string yna)
    {
      var materialType = await coilsService.GetMaterialTypeByYNA(yna);

      return Ok(materialType);
    }
    /// <summary>
    /// Check Dependency
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [HttpGet, Route("CheckDependency")]
    public async Task<IActionResult> CheckDependency(int id)
    {
      var coilsAssociation = await coilsService.CheckDependency(id);
      return Ok(coilsAssociation);
    }

    /// <summary>
    /// Insertion of Coil info
    /// </summary>
    /// <param name="coil"></param>
    /// <returns></returns>
    /// Body: {"Mill":{"Name":"A"},"CoilStatus":{"Name":"A"},"OrderNo":6,"CoilType":{"Name":"test","Width":0,"Thickness":0.0,"Spec":"A","CoilFieldZone":{"Name":"white","CoilField":{"Name":"white"}},"NumCoils":6,"Disabled":false,"Yield":0.0,"MinThickness":0.0,"MaxThickness":0.0,"MinWidth":0.0,"MaxWidth":0.0,"CoilTypeYNAs":null},"SerialNum":"test","OriginalWeight":1,"FTZ":"te","CheckInDate":"2021-05-19T18:23:34.7053472+05:30","ReturnedToField":"2021-05-19T18:23:34.7439641+05:30","CoilFieldLocation":{"Name":"white","Zone":{"Name":"white","CoilField":{"Name":"white"}},"IsEmpty":false,"Row":0,"Column":0,"Disabled":false},"CoilRunHistory":null,"YNA":"c","CurrentWeight":-8,"UnAccountedWeight":9,"IsPriority":true,"BornOnDate":null}
    /// POST: api/Coils
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditCoil, AuthResources.TeamLeaderPage)]
    [HttpPost]
    public async Task<IActionResult> PostCoil(Coil coil)
    {
      var coils = await coilsService.InsertCoil(coil);
      return Ok(coils);
    }


    /// PUT: api/Coils/5
    ///  /// Body: {"Mill":{"Name":"A"},"CoilStatus":{"Name":"A"},"OrderNo":6,"CoilType":{"Name":"test","Width":0,"Thickness":0.0,"Spec":"A","CoilFieldZone":{"Name":"white","CoilField":{"Name":"white"}},"NumCoils":6,"Disabled":false,"Yield":0.0,"MinThickness":0.0,"MaxThickness":0.0,"MinWidth":0.0,"MaxWidth":0.0,"CoilTypeYNAs":null},"SerialNum":"test","OriginalWeight":1,"FTZ":"te","CheckInDate":"2021-05-19T18:23:34.7053472+05:30","ReturnedToField":"2021-05-19T18:23:34.7439641+05:30","CoilFieldLocation":{"Name":"white","Zone":{"Name":"white","CoilField":{"Name":"white"}},"IsEmpty":false,"Row":0,"Column":0,"Disabled":false},"CoilRunHistory":null,"YNA":"c","CurrentWeight":-8,"UnAccountedWeight":9,"IsPriority":true,"BornOnDate":null}   
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditCoil, AuthResources.TeamLeaderPage)]
    [HttpPut]
    [Route("{id}")]
    public async Task<IActionResult> PutCoil(int id, Coil coil)
    {
      if (id != coil.Id)
      {
        return BadRequest();
      }
      await coilsService.UpdateCoil(id, coil);
      return Ok();
    }
    // DELETE: api/Coils/5
   [ResourceAuthorize(AuthResources.TeamLeaderActions.EditCoil, AuthResources.TeamLeaderPage)]
    [HttpDelete]
    [Route("{id}")]
    public async Task<IActionResult> DeleteCoil(int id)
    {
      var coils = await coilsService.DeleteCoilById(id);
      if (coils == null)
      {
        return NotFound();
      }
      return Ok(coils);
    }

    /// <summary>
    /// Coil Check Edit
    /// </summary>
    /// <param name="id"></param>
    /// <param name="dto"></param>
    /// <returns></returns>
    [HttpPost, Route("CheckEdit")]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> CheckEdit(int id, CoilDto dto)
    {
      try
      {
        var coilAssociation = await coilsService.CoilCheckEdit(id, dto);
        return NotFound();
      }
      catch (CoilTrackingException ex)
      {
        return ex.ErrorNumber == Constant.badrequest ? NotFound(ex.ErrorMessage) : (IActionResult)NotFound(ex.ErrorMessage);
      }
    }

    /// <summary>
    ///Insertion of  UnAccounted Weight
    /// </summary>
    /// <param name="id"></param>
    /// <param name="unAccountedWeight"></param>
    /// <returns></returns>
    /// api/Coils/AddUnAccountedWeight/80/800
    [Route("AddUnAccountedWeight/{id}/{unAccountedWeight}")]
    [HttpPut]
    public async Task<IActionResult> AddUnAccountedWeight(int id, int unAccountedWeight)
    {
      await coilsService.UpdateUnAccountedWeight(id, unAccountedWeight);
      return Ok();
    }

    /// <summary>
    /// Checks a new coil into the system
    /// </summary>
    /// <param name="coilCheckIn"></param>
    /// <returns></returns>
    /// /api/Coils/CheckIn
    ///{"YNANo": "YNA0231512","Weight": 100,"width": 1370, "thickness": 0.85,"Location": "Test-Test","ftz": "56","Mill": "USS","bornOnDate": null,"isPriority": false,"serialNum": "123"  }
    [Route("CheckIn", Name = "CheckIn")]
    [HttpPost]
    public async Task<IActionResult> CheckIn(CoilCheckIn coilCheckIn)
    {
      if (!ModelState.IsValid)
      {
        return BadRequest(ModelState);
      }
      try
      {
        var newCoil = await coilsService.CoilsCheckIn(coilCheckIn);
        return Ok(newCoil);
      }
      catch (CoilTrackingException ex)
      {
        return ex.ErrorNumber == Constant.errornotfound ? NotFound(ex.ErrorMessage) : (IActionResult)BadRequest(ex.ErrorMessage);
      }
    }
    /// <summary>
    /// Create CoilRunHistory
    /// </summary>
    /// <param name="coilUpdateData"></param>
    /// <returns></returns>
    /// api/CreateCoilRunHistory
    /// {"id": 125,"runOrderListId": 25,"weightUsed": 1370 ,"coilUpdateData":{"id": 125,"runOrderListId": 25,"weightUsed": 1370  }}
    [Route("CreateCoilRunHistory")]
    [HttpPut]
    public async Task<IActionResult> CreateCoilRunHistory(JObject coilUpdateData)
    {
      int coilId = coilUpdateData["id"].ToObject<int>();
      int runOrderListId = coilUpdateData["runOrderListId"].ToObject<int>();
      int weightUsed = coilUpdateData["weightUsed"].ToObject<int>();

      try
      {
        await coilsService.UpdateCoilRunHistory(coilId, runOrderListId, weightUsed);
      }
      catch (CoilTrackingException ex)
      {
        return ex.ErrorNumber == Constant.errornotfound ? NotFound(ex.ErrorMessage) : (IActionResult)NotFound(ex.ErrorMessage);
      }
      return Ok();
    }


    /// <summary>
    /// Move a coil based on the Id, new location string, and new Status ID
    /// </summary>
    /// <param name="coilId">The Id of the coil to move</param>
    /// <param name="newLocation">The new location such as A-B1, or 'Supplier' to move the coil to</param>
    /// <param name="newStatusId">The new coil status Id to set on the coil</param>
    /// <returns>Ok or BadRequest</returns>
    /// /api/Coils/MoveCoil/4/Other/8/true/5
    [HttpPut, Route("MoveCoil/{coilId}/{newLocation}/{newStatusId}/{isPriorityCoil?}/{lineId?}")]
    public async Task<IActionResult> MoveCoil(int coilId, string newLocation, int newStatusId, bool isPriorityCoil = false, int? lineId = null)
    {
      try
      {
        var newStatus = await coilsService.UpdateMoveCoilsByIds(coilId, newLocation, newStatusId, isPriorityCoil, lineId);
      }
      catch (CoilTrackingException ex)
      {
        return ex.ErrorNumber == Constant.errornotfound ? NotFound(ex.ErrorMessage) : (IActionResult)BadRequest(ex.ErrorMessage);
      }
      return Ok();
    }

    /// <summary>
    /// Update Coil
    /// </summary>
    /// <param name="id"></param>
    /// <param name="dto"></param>
    /// <returns></returns>
    [Route("UpdateCoil/{id}")]
    [HttpPut]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditCoil, AuthResources.TeamLeaderPage)]
    public async Task<IActionResult> UpdateCoil(int id, CoilDto dto)
    {
      if (!ModelState.IsValid)
      {
        return BadRequest(ModelState);
      }
      if (id != dto.Id)
      {
        return BadRequest();
      }
      try
      {
        await coilsService.UpdateCoilsByIdDto(id, dto);
        //Hubs.NotificationHubClients.Instance.CoilLocationsUpdated();
      }
      catch (CoilTrackingException ex)
      {
        return ex.ErrorNumber == Constant.errornotfound ? NotFound(ex.ErrorMessage) : (IActionResult)BadRequest(ex.ErrorMessage);
      }
      return NoContent();
    }

  }
}
