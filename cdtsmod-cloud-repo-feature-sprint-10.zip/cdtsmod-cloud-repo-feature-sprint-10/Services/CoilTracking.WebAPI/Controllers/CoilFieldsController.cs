using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using CoilTracking.WebAPI.AuthorizationHelper;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/CoilFields")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  [ResourceAuthorize(AuthResources.HomeActions.View, AuthResources.Home)]
  public class CoilFieldsController : ControllerBase
  {

    private readonly ICoilFieldsService coilFieldService;

    public CoilFieldsController(ICoilFieldsService coilFieldService)
    {
      this.coilFieldService = coilFieldService;
    }

    /// <summary>
    /// To get the List of CoilFields.Includes both zones and locations with the coil fields
    /// </summary>
    /// <returns>coilFieldsDto</returns>
    [HttpGet]
    [Route("GetCoilFields")]
    public IQueryable<CoilFieldDto> GetCoilFields()
    {
      var coilFields = coilFieldService.GetCoilFields();

      return coilFields.AsQueryable();
    }

    /// <summary>
    /// To get the List of CoilFields by Id.Includes both zones and locations with the coil fields
    /// </summary>
    /// <param name="id"></param>
    /// <returns>coilFieldDto</returns>
    [Route("GetCoilField/{id}")]
    [HttpGet]
    // [ResponseType(typeof(CoilField))]
    public IActionResult GetCoilField(int id)
    {
      var coilField = coilFieldService.GetCoilFieldById(id);

      if (coilField == null)
      {
        return NotFound();
      }

      return Ok(coilField);
    }

    /// <summary>
    /// To get the List of CoilFields by Id.Includes both zones and locations with the coil fields
    /// </summary>
    /// <param name="id"></param>
    /// <returns>coilField</returns>
    [Route("GetCoilFieldForEdit/{id}")]
    [HttpGet]
    // [ResponseType(typeof(CoilFieldDto))]
    public IActionResult GetCoilFieldForEdit(int id)
    {
      var coilField = coilFieldService.GetCoilFieldById(id);
      if (coilField == null)
      {
        return NotFound();
      }

      return Ok(coilField);
    }

    /// <summary>
    /// Check if entity is edited 
    /// </summary>
    /// <param name="id"></param>
    /// <param name="dto"></param>
    /// <returns>NotFound/BadRequest</returns>
    [Route("CheckEdit")]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public IActionResult CheckEdit(int id, CoilFieldDto dto)
    {
      var coilFieldEdited = coilFieldService.CheckIfEdited(id, dto);
      if (coilFieldEdited != null)
      {
        return BadRequest();
      }

      return NotFound();

    }

    /// <summary>
    /// To get the  associated coil field zones with the CoilField
    /// </summary>
    /// <param name="id"></param>
    /// <returns>List of coil field zones</returns>
    [HttpGet, Route("GetAssociatedItemsCoilFields")]
    // [ResponseType(typeof(List<CoilFieldZone>))]
    public IActionResult GetAssociatedItemsCoilFieldsZone(int id)
    {
      var coilfieldzones = coilFieldService.GetCoilFieldsZoneByCoilFieldId(id);

      return Ok(coilfieldzones);
    }

    /// <summary>
    /// To get the list of coils by coilField Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>Id</returns>
    [HttpGet, Route("GetCoilsByCoilField")]
    //[ResponseType(typeof(List<Coil>))]
    public IActionResult GetCoilsByCoilField(int id)
    {
      var coils = coilFieldService.GetCoilsByCoilField(id);
      return Ok(coils);

    }

    /// <summary>
    /// Get the coil field association type
    /// </summary>
    /// <param name="id"></param>
    /// <returns>List of String</returns>
    [HttpGet, Route("CheckDependency")]
    //[ResponseType(typeof(List<string>))]
    public IActionResult CheckDependency(int id)
    {
      var fieldAssociationType = coilFieldService.GetCoilsFieldAssociationType(id);
      return Ok(fieldAssociationType);

    }




    /// <summary>
    /// Disable a coil field
    /// </summary>
    /// <param name="id"></param>
    /// <param name="disable"></param>
    /// <returns>NoContent</returns>
    [Route("DisableCoilField/{id}/{disable}")]
    [HttpGet]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public IActionResult DisableCoilField(int id, bool disable)
    {
      var disableCoilField = coilFieldService.DisableCoilField(id, disable);

      if (!disableCoilField)
      {
        return NotFound();
      }

      return NoContent();
    }

    /// <summary>
    /// To update an existing Coil Field
    /// </summary>
    /// <param name="id"></param>
    /// <param name="dto"></param>
    /// <returns>void</returns>
    [Route("UpdateCoilFieldDto/{id}")]
     [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public IActionResult UpdateCoilFieldDto(int id, CoilFieldDto dto)
    {
      if (id != dto.Id)
      {
        return BadRequest();
      }

      var updateCoilField = coilFieldService.UpdateCoilFieldDto(id, dto);
      if (!updateCoilField)
      {
        return NotFound();
      }
      return NoContent();
    }

    /// <summary>
    /// To add new coil field
    /// </summary>
    /// <param name="dto"></param>
    /// <returns>coilField</returns>
    [Route("SaveCoilFieldDto", Name = "SaveCoilFieldDto")]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public IActionResult SaveCoilFieldDto(CoilFieldDto dto)
    {
      var coilField = coilFieldService.SaveCoilFieldDto(dto);

      return Ok(dto);
    }

    /// <summary>
    /// Delete a coil field
    /// </summary>
    /// <param name="id"></param>
    /// <returns>coil field</returns>
    [Route("DeleteCoilField")]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public IActionResult DeleteCoilField(int id)
    {
      var coilField = coilFieldService.DeleteCoilField(id);
      if (coilField == null)
      {
        return NotFound();
      }
      return Ok(coilField);
    }
  }
}
