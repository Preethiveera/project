using CoilTracking.Business.Interfaces;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/[controller]")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  [Authorize]
  public class ScheduledReportBatchController : ControllerBase
  {
    private readonly IScheduledReportBatchService scheduledReportBatchService;

    public ScheduledReportBatchController(IScheduledReportBatchService scheduledReportBatchService)
    {
      this.scheduledReportBatchService = scheduledReportBatchService;
    }

    /// <summary>
    /// Send Batch Report Emails.
    /// </summary>
    /// <returns></returns>
    [HttpGet]
    public void Get()
    {
      this.scheduledReportBatchService.GetReports();
    }
  }
}
