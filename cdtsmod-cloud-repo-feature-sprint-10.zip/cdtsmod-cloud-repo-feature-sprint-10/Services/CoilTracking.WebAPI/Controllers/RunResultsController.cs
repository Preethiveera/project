using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Exception;
using CoilTracking.Data.Models;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CoilTracking.WebAPI.AuthorizationHelper;
using Microsoft.AspNetCore.Authorization;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/RunResults")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  [ResourceAuthorize(AuthResources.HomeActions.View, AuthResources.Home)]
  public class RunResultsController : ControllerBase
  {
    private readonly IRunResultService runResultsService;

    public RunResultsController(IRunResultService runResultsService)
    {
      this.runResultsService = runResultsService;
    }
    /// <summary>
    /// Get Run Results
    /// </summary>
    /// <returns>List RunResults</returns>
    // GET: api/RunResults
    [HttpGet]
    public async Task<IActionResult> GetRunResults()
    {
      var runResults = await runResultsService.GetRunResults();
      return Ok(runResults);
    }
    /// <summary>
    /// Get RunOrder RunResult Based on runorder ID
    /// </summary>
    /// <param name="runOrderId"></param>
    /// <returns></returns>
    /// Get : api/RunResults/GetRunOrderRunResult?runOrderId=18
    [Route("GetRunOrderRunResult/{runOrderId}")]
    [HttpGet]
    public IActionResult GetRunOrderRunResult(int runOrderId)
    {
      var runResult = runResultsService.GetRunOrderRunResult(runOrderId);
      return Ok(runResult);
    }

    /// <summary>
    /// Get RunResults By Search 
    /// </summary>
    /// <param name="startTime"></param>
    /// <param name="endTime"></param>
    /// <param name="partNum"></param>
    /// <param name="dataNum"></param>
    /// <param name="coilType"></param>
    /// <param name="lineId"></param>
    /// <param name="shiftId"></param>
    /// <param name="ftz"></param>
    /// <returns>List of RunResultDto</returns>
    // GET: api/RunResults/Search
    [HttpGet, Route("Search")]
    public List<RunResultDto> Search(DateTime? startTime = null, DateTime? endTime = null, string partNum = null, int? dataNum = null, string coilType = null, int? lineId = null, int? shiftId = null, string ftz = null)
    {
      var results = runResultsService.GetRunResultsSearch(startTime, endTime, partNum, dataNum, coilType, lineId, shiftId, ftz);
      return results;
    }

    /// <summary>
    /// Get Latest RunResult
    /// </summary>
    /// <returns>RunResult Response</returns>
    // GET: api/RunResults/GetLatestRunResult
    [Route("GetLatestRunResult")]
    [HttpGet]
    public async Task<IActionResult> GetLatestRunResult()
    {
      var runResults = await runResultsService.GetLatestRunResult();
      if (runResults == null)
      {
        return NotFound();
      }
      return Ok(runResults);
    }

    /// <summary>
    /// Get CurrentStack For Size Based on DataNumber
    /// </summary>
    /// <param name="dataNum"></param>
    /// <returns>blankInfo </returns>
    // GET: api/RunResults/GetCurrentStackSize?dataNum=103
    [Route("GetCurrentStackSize")]
    [HttpGet]
    public IActionResult GetCurrentStackSize(int dataNum)
    {
      var blankInfo = runResultsService.GetCurrentStackSize(dataNum);
      if (blankInfo == null)
      {
        return NotFound();
      }
      return Ok(blankInfo);
    }

    /// <summary>
    /// Get RunResult Based On ID 
    /// </summary>
    /// <param name="id"></param>
    /// <returns>List of RunResult </returns>
    // GET: api/RunResults/5
    [Route("{id}")]
    [HttpGet]
    public async Task<IActionResult> GetRunResult(int id)
    {
      var runResult = await runResultsService.GetRunResultById(id);
      if (runResult == null)
      {
        return NotFound();
      }
      return Ok(runResult);
    }

    /// <summary>
    /// Get RunResult For Edit Based on Id
    /// </summary>
    /// <param name="Id"></param>
    /// <returns>List of RunResult </returns>
    ///   GET: api/RunResults/GetRunResultForEdit/5
    [Route("GetRunResultForEdit/{id}")]
    [HttpGet]
    public async Task<IActionResult> GetRunResultForEdit(int Id)
    {
      var runResults = await runResultsService.GetRunResultForEditByID(Id);
      if (runResults == null)
      {
        return NotFound();
      }
      return Ok(runResults);
    }

    /// <summary>
    /// Get Coils To Be Weighed
    /// </summary>
    /// <returns>[]</returns>
    /// GET: api/RunResults/GetCoilsToBeWeighed
    [Route("GetCoilsToBeWeighed")]
    [HttpGet]
    public List<CoilToBeWeighed> GetCoilsToBeWeighed()
    {
      var coilsToBeWeighed = runResultsService.GetRunCoilsToBeWeighed();
      return coilsToBeWeighed;
    }
    /// <summary>
    /// Get Scrap  Results
    /// </summary>
    /// <param name="startTime"></param>
    /// <param name="endTime"></param>
    /// <param name="partNum"></param>
    /// <param name="dataNum"></param>
    /// <param name="coilType"></param>
    /// <param name="lineId"></param>
    /// <param name="shiftId"></param>
    /// <param name="ftz"></param>
    /// <returns></returns>
    /// GET: api/RunResults/GetScrapResults
    [Route("GetScrapResults")]
    [HttpGet]
    public List<ScrapResultsDto> GetScrapResults(DateTime? startTime = null, DateTime? endTime = null, string partNum = null, int? dataNum = null, string coilType = null, int? lineId = null, int? shiftId = null, string ftz = null)
    {
      var runResultsWithPartials = runResultsService.GetScrapResults(startTime, endTime, partNum, dataNum, coilType, lineId, shiftId, ftz);
      return runResultsWithPartials;
    }
    /// <summary>
    /// Save Return Weight Coils
    /// </summary>
    /// <param name="partials"></param>
    /// <returns></returns>
    ///Put : /api/RunResults/SaveReturnWeight 
    /// Pass List  of CoilToBeWeighed 
    /// [{ "RunResultId":1,"RunOrderListId":1, "CoilId":1,"FTZ":"a", "CoilType":"a","YNA":"a", "OriginalWeight":1,"Zone":"a","CoilLocation":"a","NewWeight":1, "AttachedToRunResult":true,"CoilTypeName":"a","CoilStatusName":"a","CoilFieldLocationName":"a"}]
    ///
    [ResourceAuthorize(AuthResources.TeamLeaderActions.Edit, AuthResources.TeamLeaderPage)]
    [Route("SaveReturnWeight/{partials}")]
    [HttpPut]
    public IActionResult SaveReturnWeight(List<CoilToBeWeighed> partials)
    {
      try
      {
        runResultsService.SaveReturnWeight(partials);
      }
      catch (Exception ex)
      {
        return NotFound(ex);
      }
      return Ok();
    }
    /// <summary>
    /// Update Current Weight Based on CoilToBeWeighed Information
    /// </summary>
    /// <param name="data"></param>
    /// <returns></returns>
    /// PUT: api/RunResults/UpdateCurrentWeight 
    /// Pass JSON Data
    ///{"id":2,"partial":{ "RunResultId":1,"RunOrderListId":1, "CoilId":1,"FTZ":"a", "CoilType":"a","YNA":"a", "OriginalWeight":1,"Zone":"a","CoilLocation":"a","NewWeight":1, "AttachedToRunResult":true,"CoilTypeName":"a","CoilStatusName":"a","CoilFieldLocationName":"a"}}
   
   [ResourceAuthorize(AuthResources.TeamLeaderActions.UpdateWeights, AuthResources.TeamLeaderPage)]
    [Route("UpdateCurrentWeight")]
    [HttpPut]
    public async Task<IActionResult> UpdateCurrentWeight(JObject data)
    {
      try
      {
        if (data == null || data["id"] == null || data["partial"] == null)
        {
          throw new CoilTrackingException() { ErrorMessage = ApplicationMessages.updateCurrentWeight, HttpStatusCode = "BadRequest" };
        }
        int id = data["id"].ToObject<int>();
        CoilToBeWeighed partial = data["partial"].ToObject<CoilToBeWeighed>();
      await  runResultsService.UpdateCurrentWeight(partial);
      }
      catch (Exception ex)
      {
        return NotFound(ex);
      }
      return Ok();
    }

    /// <summary>
    /// Get Coil By FTZ ToBeWeighed Based On ftz
    /// </summary>
    /// <param name="ftz"></param>
    /// <returns></returns>
    /// GET: api/RunResults/GetCoilByFTZToBeWeighed/ftz
    [Route("GetCoilByFTZToBeWeighed/{ftz}")]
    [HttpGet]
    public async Task<IActionResult> GetCoilByFTZToBeWeighed(string ftz)
    {
      var coilsToBeWeighed = await runResultsService.GetCoilByFTZToBeWeighed(ftz);
      return Ok(coilsToBeWeighed);
    }

    /// <summary>
    /// Insert RunResult Info
    /// </summary>
    /// <param name="runResult"></param>
    /// {"RunStarted":"2021-01-28 15:13:16.99","DataNumber":"1","PartNumber":"a","BlanksRequested":"1","MeasuredThickness":"0.1","MeasuredWidth":"1","MeasuredPitch":"1","PressCount":"1","BlanksProduced":"1","DownTime":"1","Comments":"a","WeightUsed":"0.1","RunFinished":"2021-01-29 15:13:16.99","BlankWeight":"0.1","BlankPitch":"0.1","BlankWidth":"0.1","BlankStackSize":"0.1","BlankDieNo":"0.1","BlankCoilTypeName":"A","WeightBefore":"0.1","AdcDt":"1","MaintDt":"1","ToolDieDt":1,"ProdDt":"1","KanbanDt":"1","TryoutDt":"1","SchdDt":"1","ModifiedBy":"A","RunOrderList":{"Id":28,"Shift":{"Name":"A"},"Date":"2021-05-19T18:23:34.8177798+05:30","Line":{"Id":0,"Plant":{"Id":6,"PlantName":"NAMC","TimeZone":{"Id":0,"Name":"test","TimeZoneOffset":0},"NAMCCode":null},"Plant_Id":8,"LineName":"A","OPCServer":{"ServerName":"A","InstanceName":"S"},"OPCServer_Id":88,"LinePath":"A","Tags":"tags","Subscribed":true,"Disabled":true},"Quantities":null},"Coil":{"Mill":{"Id":6,"Name":"A"},"CoilStatus":{"Id":4,"Name":"A"},"Id":40,"OrderNo":6,"CoilType":{"Id":40,"Name":"test","Width":0,"Thickness":0.0,"Spec":"A","CoilFieldZone":{"Name":"white","CoilField":{"Name":"white"}},"NumCoils":6,"Disabled":false,"Yield":0.0,"MinThickness":0.0,"MaxThickness":0.0,"MinWidth":0.0,"MaxWidth":0.0,"CoilTypeYNAs":null},"SerialNum":"test","OriginalWeight":1,"FTZ":"te","CheckInDate":"2021-05-19T18:23:34.7053472+05:30","ReturnedToField":"2021-05-19T18:23:34.7439641+05:30","CoilFieldLocation":{"Id":2,"Name":"white","Zone":{"Name":"white","CoilField":{"Name":"white"}},"IsEmpty":false,"Row":0,"Column":0,"Disabled":false},"CoilRunHistory":null,"YNA":"c","CurrentWeight":-8,"UnAccountedWeight":9,"IsPriority":true,"BornOnDate":null}}
    /// <returns></returns>
    /// Post: /api/RunResults
    /// Body: {RunResult}
    ///
    [ResourceAuthorize(AuthResources.TeamLeaderActions.Edit, AuthResources.TeamLeaderPage)]
    [HttpPost]
    public async Task<IActionResult> PostRunResult(RunResult runResult)
    {
      if (!ModelState.IsValid)
      {
        return BadRequest(ModelState);
      }
      try
      {
      await  runResultsService.InsertRunResults(runResult);
      }
      catch (Exception ex)
      {
        return NotFound(ex);

      }
      return Ok(runResult);
    }

    /// <summary>
    /// Update RunResult Based on Id and Runresult
    /// </summary>
    /// <param name="id"></param>
    /// <param name="runResult"></param>
    /// <returns></returns>
    /// Put: api/PutRunResult/4
    /// Body: {runResult}
    /// {"Id":"36","RunStarted":"2021-01-28 15:13:16.99","DataNumber":"1","PartNumber":"a","BlanksRequested":"1","MeasuredThickness":"0.1","MeasuredWidth":"1","MeasuredPitch":"1","PressCount":"1","BlanksProduced":"1","DownTime":"1","Comments":"a","WeightUsed":"0.1","RunFinished":"2021-01-29 15:13:16.99","BlankWeight":"0.1","BlankPitch":"0.1","BlankWidth":"0.1","BlankStackSize":"0.1","BlankDieNo":"0.1","BlankCoilTypeName":"A","WeightBefore":"0.1","AdcDt":"1","MaintDt":"1","ToolDieDt":1,"ProdDt":"1","KanbanDt":"1","TryoutDt":"1","SchdDt":"1","ModifiedBy":"A","RunOrderList":{"Id":28,"Shift":{"Name":"A"},"Date":"2021-05-19T18:23:34.8177798+05:30","Line":{"Id":0,"Plant":{"Id":6,"PlantName":"NAMC","TimeZone":{"Id":0,"Name":"test","TimeZoneOffset":0},"NAMCCode":null},"Plant_Id":8,"LineName":"A","OPCServer":{"ServerName":"A","InstanceName":"S"},"OPCServer_Id":88,"LinePath":"A","Tags":"tags","Subscribed":true,"Disabled":true},"Quantities":null},"Coil":{"Mill":{"Id":6,"Name":"A"},"CoilStatus":{"Id":4,"Name":"A"},"Id":40,"OrderNo":6,"CoilType":{"Id":40,"Name":"test","Width":0,"Thickness":0.0,"Spec":"A","CoilFieldZone":{"Name":"white","CoilField":{"Name":"white"}},"NumCoils":6,"Disabled":false,"Yield":0.0,"MinThickness":0.0,"MaxThickness":0.0,"MinWidth":0.0,"MaxWidth":0.0,"CoilTypeYNAs":null},"SerialNum":"test","OriginalWeight":1,"FTZ":"te","CheckInDate":"2021-05-19T18:23:34.7053472+05:30","ReturnedToField":"2021-05-19T18:23:34.7439641+05:30","CoilFieldLocation":{"Id":2,"Name":"white","Zone":{"Name":"white","CoilField":{"Name":"white"}},"IsEmpty":false,"Row":0,"Column":0,"Disabled":false},"CoilRunHistory":null,"YNA":"c","CurrentWeight":-8,"UnAccountedWeight":9,"IsPriority":true,"BornOnDate":null}}
    
    [ResourceAuthorize(AuthResources.TeamLeaderActions.Edit, AuthResources.TeamLeaderPage)]
    [HttpPut]
    [Route("{id}")]
    public IActionResult PutRunResult(int id, RunResult runResult)
    {
      if (!ModelState.IsValid)
      {
        return BadRequest(ModelState);
      }
      if (id != runResult.Id)
      {
        return BadRequest();
      }
      runResultsService.IsRunResultExists(id);
      try
      {
        runResultsService.ModifyRunResult(runResult);
      }
      catch (Exception ex)
      {
        return NotFound(ex);
      }
      return Ok();
    }

    /// <summary>
    /// Delete RunResult Based On Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
   // DELETE: api/RunResults/5
    [Route("{id}")]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditRunResult, AuthResources.TeamLeaderPage)]
    [HttpDelete]
    public async Task<IActionResult> DeleteRunResult(int id)
    {
      var runResult = runResultsService.DeleteRunResult(id);
      if (runResult == null)
      {
        return NotFound();
      }
      return Ok(runResult);
    }

    /// <summary>
    /// Update RunResult Based On Id and  JObject Data
    /// </summary>
    /// <param name="id"></param>
    /// <param name="data"></param>
    /// <returns></returns>
    /// Put: /api/RunResults/UpdateRunResult/3
    /// Body: {"runResult":{"Id": 3,"RunOrderListId":"1","Line": "A","Shift": "a","RunStarted": "2021-01-28 15:13:16.99","RunFinished": "2021-01-29 15:13:16.99","DataNumber": "1","PartNumber": "a","BlanksRequested": 1,"CoilId": "1","YNANumber": "a","FTZ": "56","CoilType": "a","MeasuredThickness": "0.1","MeasuredWidth": "1","MeasuredPitch": "1","AdcDt": "1","MaintDt": "1","ToolDieDt": 1,"ProdDt": "1","KanbanDt": "1","TryoutDt": "1","SchdDt": "1","DownTime": "1","Comments": "a","BlankWeight": "0.1","BlankPitch": "0.1","BlankWidth": "0.1","BlankStackSize": "0.1","BlankDieNo": "0.1","PressCount": "1","BlanksProduced": "1","WeightBefore": "0.1","WeightAfter": "0.1","WeightUsed": "0.1","CoilCurrentWeight": "0.1","ModifiedBy": "A"}}

    [ResourceAuthorize(AuthResources.TeamLeaderActions.Edit, AuthResources.TeamLeaderPage)]
    [Route("UpdateRunResult/{id}")]
    [HttpPut]
    public async Task<IActionResult>  UpdateRunResult(int id, JObject data)
    {

      try
      {
        RunResultDto runResultDto = data["runResult"].ToObject<RunResultDto>();
        if (id != runResultDto.Id)
        {
          return BadRequest();
        }

      await runResultsService.UpdateRunResult(id, runResultDto);
      }
      catch (Exception ex)
      {
        return NotFound(ex);
      }

      return Ok();
    }
    /// <summary>
    /// Save RunResult Based On JObject Data
    /// </summary>
    /// <param name="data"></param>
    /// <returns></returns>
    /// Post: /api/RunResults/SaveRunResult
    /// Body: {"runResult":{"Id": 3,"RunOrderListId":"1","Line": "A","Shift": "a","RunStarted": "2021-01-28 15:13:16.99","RunFinished": "2021-01-29 15:13:16.99","DataNumber": "1","PartNumber": "a","BlanksRequested": 1,"CoilId": "1","YNANumber": "a","FTZ": "56","CoilType": "a","MeasuredThickness": "0.1","MeasuredWidth": "1","MeasuredPitch": "1","AdcDt": "1","MaintDt": "1","ToolDieDt": 1,"ProdDt": "1","KanbanDt": "1","TryoutDt": "1","SchdDt": "1","DownTime": "1","Comments": "a","BlankWeight": "0.1","BlankPitch": "0.1","BlankWidth": "0.1","BlankStackSize": "0.1","BlankDieNo": "0.1","PressCount": "1","BlanksProduced": "1","WeightBefore": "0.1","WeightAfter": "0.1","WeightUsed": "0.1","CoilCurrentWeight": "0.1","ModifiedBy": "A"}}
    [Route("SaveRunResult")]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.Edit, AuthResources.TeamLeaderPage)]
    [HttpPost]
    public async Task<IActionResult>  SaveRunResult(JObject data)
    {
      RunResultDto runResultDtos = data["runResult"].ToObject<RunResultDto>();
      try
      {
      await  runResultsService.InsertRunResult(runResultDtos);
      }
      catch (Exception ex)
      {
        return NotFound(ex);
      }
      return Ok(runResultDtos);
    }

    /// <summary>
    /// GetNAMCinfo
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous]
    [HttpGet, Route("GetNAMCCode")]
    public async Task<IActionResult> GetNAMCinfo()
    {
      var code = await runResultsService.GetPlantCode();
      return Ok(code);

    }
  }
}
