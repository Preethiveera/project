using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoilTracking.WebAPI.AuthorizationHelper;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/RunOrderLists")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  [ResourceAuthorize(AuthResources.HomeActions.View, AuthResources.Home)]
  public class RunOrderListsController : ControllerBase
  {
    private readonly IRunOrderListService runOrderListService;

    public RunOrderListsController(IRunOrderListService runOrderListService)
    {
      this.runOrderListService = runOrderListService;
    }

    /// <summary>
    /// Get list of runOrderLists
    /// </summary>
    /// <returns>RunOrderListForGet</returns>
    // GET: api/RunOrderLists
    [HttpGet]
    public async Task<IActionResult> GetRunOrderLists()
    {
      var runOrderList = await runOrderListService.GetRunOrderLists();
      return Ok(runOrderList);
    }

    /// <summary>
    /// Get RunOrderList by Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>runorderListForGet</returns>
    // GET: api/RunOrderLists/5
    // [ResponseType(typeof(RunOrderList))]
    [HttpGet, Route("{id}")]
    public async Task<IActionResult> GetRunOrderList(int id)
    {
      var runOrderList = await runOrderListService.GetRunOrderListById(id);
      if (runOrderList == null)
      {
        return NotFound();
      }

      return Ok(runOrderList);
    }

    /// <summary>
    /// Mark RunOrderItems as incomplete state
    /// </summary>
    /// <param name="data"></param>
    /// <returns>void</returns>
    [Route("MarkRunOrderItemsIncomplete")]
    [HttpPost]
    public async Task<IActionResult> MarkRunOrderItemsIncomplete(JObject data)
    {
      List<IncompleteRunOrderItemDto> incompleteItems =
          data["RunOrderItems"].ToObject<List<IncompleteRunOrderItemDto>>();

      await runOrderListService.MarkRunOrderItemsIncomplete(incompleteItems);


      return NoContent();
    }

    /// <summary>
    /// Mark RunOrderItems as started state
    /// </summary>
    /// <param name="data"></param>
    /// <returns>void</returns>
    [Route("MarkRunOrderItemStarted/{runOrderItemId}")]
    [HttpGet]
    public async Task<IActionResult> MarkRunOrderItemStarted(int runOrderItemId)
    {
      var status = RunOrderItemStatusDto.RunStarted;
      await runOrderListService.MarkRunOrderItemStatus(runOrderItemId, status);
      return NoContent();
    }

    /// <summary>
    /// Mark RunOrderItems as complete state
    /// </summary>
    /// <param name="data"></param>
    /// <returns>void</returns>
    [Route("MarkRunOrderItemComplete/{runOrderItemId}")]
    [HttpGet]
    public async Task<IActionResult> MarkRunOrderItemComplete(int runOrderItemId)
    {
      var status = RunOrderItemStatusDto.Completed;
      await runOrderListService.MarkRunOrderItemStatus(runOrderItemId, status);

      return NoContent();
    }

    /// <summary>
    /// Get list of RunOrderList by date, shift and LineId
    /// </summary>
    /// <param name="date"></param>
    /// <param name="lineId"></param>
    /// <param name="shiftId"></param>
    /// <returns>RunOrderListForCreate</returns>
    [Route("CreateRunOrderList/{date}/{lineId}/{shiftId}")]
    [HttpGet]
    public async Task<IActionResult> CreateRunOrderList(DateTime date, int lineId, int shiftId)
    {
      RunOrderListForCreate runOrderListDto = new RunOrderListForCreate();
      try
      {
         runOrderListDto = await runOrderListService.CreateRunOrderList(date, lineId, shiftId);
      }
      catch (CoilTrackingException ex)
      {
        return BadRequest(ex.ErrorMessage);
      }
      return Ok(runOrderListDto);
    }
    /// <summary>
    /// Get runorder list by date, shiftId and lineId
    /// </summary>
    /// <param name="date"></param>
    /// <param name="lineId"></param>
    /// <param name="shiftId"></param>
    /// <returns>RunOrderListForGet</returns>
    [Route("GetRunOrderList/{date}/{lineId}/{shiftId}")]
    [HttpGet]
    //[ResponseType(typeof(RunOrderListForGet))]
    public async Task<IActionResult> GetRunOrderList(DateTime date, int lineId, int shiftId)
    {
      RunOrderListForGet runOrderListDto = new RunOrderListForGet();
      try
      {
         runOrderListDto = await runOrderListService.GetRunOrderItemForGet(date, lineId, shiftId);
      }
      catch (CoilTrackingException ex)
      {
        return BadRequest(ex.ErrorMessage);
      }
      return Ok(runOrderListDto);
    }


    // DELETE: api/RunOrderLists/5
    [Route("DeleteRunOrderList/{id}")]
    [HttpDelete]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditRunOrder, AuthResources.TeamLeaderPage)]
    public async Task<IActionResult> DeleteRunOrderList(int id)
    {
      var runOrderList = await runOrderListService.DeleteRunOrderList(id);
      if (!runOrderList)
      {
        return NotFound();
      }
      return Ok();
    }

    [Route("SaveRunOrderList")]
    //[HttpPost]
    //[ResponseType(typeof(RunOrderListForCreate))]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditRunOrder, AuthResources.TeamLeaderPage)]
    public async Task<IActionResult> SaveRunOrderList(RunOrderListForUpdate runOrderList)
    {
      if (runOrderList == null || runOrderList.RunOrderItems == null)
      {
        return BadRequest(ApplicationMessages.runOrderListExist);
      }
      if (runOrderList.RunOrderItems.Any(roi => roi.DataId == 0))
      {
        return BadRequest(ApplicationMessages.runOrderListHasDataNum);
      }
     
      var runOrderListDto = await runOrderListService.SaveRunOrderList(runOrderList);
      return Ok(runOrderListDto);
    }

    [Route("UpdateRunOrderList/{id}")]
    //[HttpPut]
    //[ResponseType(typeof(void))]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditRunOrder, AuthResources.TeamLeaderPage)]
    public async Task<IActionResult> UpdateRunOrderList(int id, RunOrderListForUpdate runOrderList)
    {
      if (id != runOrderList.Id)
      {
        return BadRequest();
      }
      if (runOrderList.RunOrderItems.Any(roi => roi.DataId == 0))
      {
        return BadRequest(ApplicationMessages.runOrderListHasDataNum);
      }
      await runOrderListService.UpdateRunOrderList(id, runOrderList);

      return NoContent();
    }


  }
}
