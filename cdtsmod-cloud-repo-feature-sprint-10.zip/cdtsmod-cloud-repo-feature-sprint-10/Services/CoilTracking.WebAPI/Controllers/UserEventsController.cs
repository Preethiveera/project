using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using CoilTracking.WebAPI.AuthorizationHelper;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using CoilTracking.DTO;
using CoilTracking.Business.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using Microsoft.AspNetCore.Authorization;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/UserEvents")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  public class UserEventsController : ControllerBase
  {
    private readonly IUserEventService userEventService;
    
    public UserEventsController(IUserEventService userEventService)
    {
      this.userEventService = userEventService;
     }
    /// <summary>
    /// To get list of user events
    /// </summary>
    /// <returns></returns>
    public async Task<List<UserEventDto>> GetUserEvents()
    {
      var events = await userEventService.GetUserEvents();
      return events;
    }

    /// <summary>
    /// to get list of user events by time and username
    /// </summary>
    /// <param name="startTime"></param>
    /// <param name="endTime"></param>
    /// <param name="username"></param>
    /// <returns></returns>
    // GET: api/UserEvents/GetUserEventsBetween
    [HttpGet, Route("GetUserEventsBetween")]
    public async Task<List<UserEventDto>> GetUserEventsBetween(DateTime? startTime = null, DateTime? endTime = null, string username = null)
    {
      var userEvents = await userEventService.GetUserEventsBetween(startTime, endTime, username);
      return userEvents;
    }

    // GET: api/UserEvents/GetUserEventTypes
    [HttpGet, Route("GetUserEventTypes")]
    public Dictionary<int, string> GetUserEventTypes()
    {
      var dict = Enum.GetValues(typeof(UserEventTypeDto)).Cast<UserEventTypeDto>().ToDictionary(t => (int)t, t => t.ToString());
      return dict;
    }

    /// <summary>
    /// to get user event by Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    // GET: api/UserEvents/5
    //[ResponseType(typeof(UserEvent))]
    [HttpGet, Route("{id}")]
    public async Task<IActionResult> GetUserEvent(int id)
    {
      var userEvent = await userEventService.GetUserEventById(id);
      if (userEvent == null)
      {
        return NotFound();
      }

      return Ok(userEvent);
    }

    // PUT: api/UserEvents/5
    [HttpPut, Route("{id}")]
    public async Task<IActionResult> PutUserEvent(int id, UserEventDto userEvent)
    {
      if (id != userEvent.Id)
      {
        return BadRequest();
      }
       userEventService.UpdateUserEvent(id, userEvent);

      return NoContent();
    }

    /// <summary>
    /// to add new user events
    /// </summary>
    /// <param name="userEvent"></param>
    /// <returns></returns>
    // POST: api/UserEvents
    [AllowAnonymous]
    [HttpPost]
    //[ResponseType(typeof(UserEvent))]
    public async Task<IActionResult> PostUserEvent(UserEventDto userEvent)
    {
      var events = await userEventService.InsertUserEvent(userEvent);

      return Ok(events);
    }
   
    // DELETE: api/UserEvents/5
    [HttpDelete, Route("{id}")]
    public async Task<IActionResult> DeleteUserEvent(int id)
    {
      
     var userEvent = await userEventService.DeleteUserEvent(id);
      if (userEvent == null)
      {
        return NotFound();
      }
      return Ok(userEvent);
    }

  }
}
