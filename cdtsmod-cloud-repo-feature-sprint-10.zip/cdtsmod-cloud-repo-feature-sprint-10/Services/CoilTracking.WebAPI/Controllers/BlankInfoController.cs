using CoilTracking.Business.Interfaces;
using CoilTracking.Common;
using CoilTracking.Common.Exception;
using CoilTracking.Data.Models;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using CoilTracking.WebAPI.AuthorizationHelper;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Common.Logging;
using CoilTracking.Common.Constants;
using CoilTracking.Business.Interfaces.BlockingDiagrams;
using System.IO;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/BlankInfo")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  [ResourceAuthorize(AuthResources.HomeActions.View, AuthResources.AdminPage)]
  public class BlankInfoController : ControllerBase
  {
    private readonly IAWSS3BucketHelper aWSS3BucketHelper;
    private readonly IApplicationLogger<BlankInfoController> logger;
    private readonly IBlankInfoService blankInfoService;
    private readonly IImportBlankData importBlankInfoService;
    private readonly IUserHelper usersHelper;
    public BlankInfoController(IBlankInfoService blankInfoService, IImportBlankData importBlankInfoService, IUserHelper usersHelper, IApplicationLogger<BlankInfoController> logger, IAWSS3BucketHelper aWSS3BucketHelper)
    {
      this.importBlankInfoService = importBlankInfoService;
      this.blankInfoService = blankInfoService;
      this.usersHelper = usersHelper;
      this.logger = logger;
      this.aWSS3BucketHelper = aWSS3BucketHelper;
    }

    /// <summary>
    /// to get the blankInfoes
    /// </summary>
    /// <returns> blankInfo</returns>
    /// // GET: api/BlankInfo
    [HttpGet]
    public IQueryable<BlankInfo> GetDatas()
    {
      var blankInfo = blankInfoService.GetAllBlankInfo();

      return blankInfo;

    }

    /// <summary>
    /// To get the blankInfo By Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>blankInfo</returns>
    // // GET: api/BlankInfo/5
    [HttpGet]
    [Route("{id}")]
    public IActionResult GetBlankInfo(int id)
    {
      var blankInfo = blankInfoService.GetBlankInfoById(id);

      if (blankInfo == null)
      {
        return NotFound();
      }

      return Ok(blankInfo);
    }

    //ToDo
    /// <summary>
    /// to get the NAMC code form Plants table
    /// </summary>
    /// <returns>Namc Code</returns>
    [HttpGet, Route("GetNAMCCode")]
    public IActionResult GetNAMCinfo()
    {
      //return plant details and session value for user plant
      List<string> namcCodes = new List<string>();
      var NAMCCode = blankInfoService.GetNAMCinfo();
      if (NAMCCode.Equals("TMMI", StringComparison.OrdinalIgnoreCase))
      {
        namcCodes.Add("OK");

      }
      else
      {
        namcCodes.Add("NA");

      }
      return Ok(namcCodes);
    }


    /// <summary>
    /// Get the blank info details for editDto
    /// </summary>
    /// <param name="id"></param>
    /// <returns>blankInfo</returns>
    [Route("GetBlankInfoForEdit/{id}")]
    [HttpGet]
    public IActionResult GetBlankInfoForEdit(int id)
    {
      var blankInfo = blankInfoService.GetBlankInfoById(id);
      if (blankInfo == null)
      {
        return NotFound();
      }

      return Ok(blankInfo);
    }

    /// <summary>
    /// To get the blankInfo by dataNumber and LineId
    /// 
    /// </summary>
    /// <param name="dataNum"></param>
    /// <param name="lineId"></param>
    /// <returns>BlankInfo</returns>
    [Route("GetBlankInfoFromDataNumber/{dataNum}/{lineId}")]
    [HttpGet]
    public IActionResult GetBlankInfoFromDataNumber(int dataNum, int lineId)
    {
      var blankInfo = blankInfoService.GetBlankInfoByDataNumAndLineId(dataNum, lineId);

      if (blankInfo == null)
      {
        return NotFound();
      }

      return Ok(blankInfo);
    }

    /// <summary>
    /// Check if BlankInfo have any dependency
    /// </summary>
    /// <param name="id"></param>
    /// <returns>dependent items of blankInfo</returns>
    [HttpGet, Route("CheckDependency")]
    public IActionResult CheckDependency(int id)
    {
      List<string> partAssociation = new List<string>();
      var blankInfo = blankInfoService.IsBlankInfoDependent(id);

      if (blankInfo)
      {
        partAssociation.Add("RunOrder");
      }

      return Ok(partAssociation);
    }

    /// <summary>
    /// Add new blank info
    /// </summary>
    /// <param name="blankInfo"></param>
    /// <returns>blankInfo</returns>
    /// // POST: api/BlankInfo
    [HttpPost]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditDataNumber, AuthResources.TeamLeaderPage)]
    public IActionResult PostBlankInfo(BlankInfoDto blankInfo)
    {
      blankInfoService.AddNewBlankInfo(blankInfo);
      return Ok(blankInfo);
    }

    /// <summary>
    /// Adds new blank info
    /// </summary>
    /// <param name="dto"></param>
    /// <returns>blank info</returns>
    [Route("SaveBlankInfoDto")]
    [HttpPost]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditDataNumber, AuthResources.TeamLeaderPage)]
    public IActionResult SaveBlankInfoDto(BlankInfoDto dto)
    {
      blankInfoService.AddNewBlankInfo(dto);
      return Ok(dto);
    }

    /// <summary>
    /// Check if model is edited while deleting the record
    /// </summary>
    /// <param name="id"></param>
    /// <param name="dto"></param>
    /// <returns>Status code</returns>
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    [HttpPost, Route("CheckEdit")]
    public async Task<IActionResult> CheckEdit(int id, BlankInfoDto dto)
    {
      var checkIfBlankInfoEdited = await blankInfoService.CheckEdit(id, dto);

      if (!checkIfBlankInfoEdited)
      {
        return BadRequest();
      }
      return NotFound();
    }

    /// <summary>
    /// To update an existing blankInfo
    /// </summary>
    /// <param name="id"></param>
    /// <param name="dto"></param>
    /// <returns>No Content status code</returns>
    [Route("UpdateBlankInfoDto/{id}")]
   [ResourceAuthorize(AuthResources.TeamLeaderActions.EditDataNumber, AuthResources.TeamLeaderPage)]
    public IActionResult UpdateBlankInfoDto(int id, BlankInfoDto dto)
    {


      if (id != dto.Id)
      {
        return BadRequest();
      }
      blankInfoService.UpdateBlankInfo(id, dto);

      return NoContent();
    }

    /// <summary>
    /// To disable a blankInfo
    /// </summary>
    /// <param name="id"></param>
    /// <param name="disable"></param>
    /// <returns>No Content status code</returns>
    [Route("DisableBlank/{id}/{disable}")]
    [HttpGet]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditDataNumber, AuthResources.TeamLeaderPage)]
    public IActionResult DisableBlank(int id, bool disable)
    {
      blankInfoService.DisableBlankInfo(id, disable);
      return NoContent();
    }

    /// <summary>
    /// Delete BlankInfo
    /// </summary>
    /// <param name="id"></param>
    /// <returns>blank info</returns>
    // DELETE: api/BlankInfo/5
    [Route("{id}")]
   [ResourceAuthorize(AuthResources.TeamLeaderActions.EditDataNumber, AuthResources.TeamLeaderPage)]
    public IActionResult DeleteBlankInfo(int id)
    {
      var blankInfo = blankInfoService.DeleteBlankInfo(id);

      return Ok(blankInfo);
    }

    /// <summary>
    /// Import Blank Info data to excel.
    /// </summary>
    /// <returns>Http Status code</returns>
    [Route("UploadBlanks")]
    [HttpPost]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> UploadBlanks()
    {
      // Check if the request contains multipart/form-data.
      if (!(Request.HasFormContentType && Request.Form.Files.Any()))
      {
        throw new CoilTrackingException { HttpStatusCode = "UnsupportedMediaType" };
      }

      try
      {
        // Read the form data, copy it to a memorystream, and pass it to the importer
        var file = HttpContext.Request.Form.Files["UploadedFile"];
        logger.LogInformation(Constant.classname + "BlankInfoController" + Constant.methodname + "UploadBlanks" + Constant.message +
          file.FileName + file.Length);
        var ms = new System.IO.MemoryStream();
        
        await file.CopyToAsync(ms);

        logger.LogInformation(Constant.message + "adding file to aws s3 bucket");
          
        
        logger.LogInformation(Constant.classname + "BlankInfoController" + Constant.methodname + "UploadBlanks" + Constant.message +
         "memory stream" + ms.Length + "More Info" + ms);

        List<DataImportMessage> messages = importBlankInfoService.Import(ms, usersHelper.GetSubject());
        return Ok(new ImportResult(messages, HttpStatusCode.OK));
      }
      catch (System.Exception ex)
      {
        return BadRequest("Error in upload process. " + ex.ToString());
      }
    }
  }
}
