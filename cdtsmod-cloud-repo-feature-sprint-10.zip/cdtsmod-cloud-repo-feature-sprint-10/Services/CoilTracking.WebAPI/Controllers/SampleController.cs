using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using CoilTracking.WebAPI.AuthorizationHelper;
using Microsoft.AspNetCore.Authorization;
using System.Diagnostics.CodeAnalysis;

namespace CoilTracking.WebAPI.Controllers
{

  [Route("api/[controller]")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  [ExcludeFromCodeCoverage]
  [AllowAnonymous]
  public class SampleController : ControllerBase
  {
    public SampleController()
    {

    }
  }
}
