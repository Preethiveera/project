using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using CoilTracking.WebAPI.AuthorizationHelper;
using System.Diagnostics.CodeAnalysis;

namespace CoilTracking.WebAPI.Controllers
{

  [Route("api/[controller]")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  public class SampleAuthenticatedController : ControllerBase
  {
    [ExcludeFromCodeCoverage]
    public SampleAuthenticatedController()
    {

    }
  }
}
