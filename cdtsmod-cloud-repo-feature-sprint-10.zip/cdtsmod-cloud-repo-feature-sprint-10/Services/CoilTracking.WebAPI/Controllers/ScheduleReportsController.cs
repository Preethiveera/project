using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;
using CoilTracking.WebAPI.AuthorizationHelper;

namespace CoilTracking.WebAPI.Controllers
{

  [Route("api/ScheduleReport")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  [ResourceAuthorize(AuthResources.AdminPageActions.View, AuthResources.AdminPage)]
  public class ScheduleReportsController : Controller
  {
    private readonly IScheduleReportService scheduleReportService;
    /// <summary>
    /// 
    /// </summary>
    /// <param name="customLogger"></param>
    /// <param name="scheduleReportService"></param>
    public ScheduleReportsController(IScheduleReportService scheduleReportService)
    {
      this.scheduleReportService = scheduleReportService;
    }
    /// <summary>
    /// To get the ScheduleReports
    /// </summary>
    /// <returns></returns>
    [HttpGet]
    public IQueryable<ScheduleReportDto> Get()
    {

      var scheduleReports = scheduleReportService.GetScheduleReport();
      return scheduleReports;
    }

    /// <summary>
    /// Get Schedule Report by Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [Route("GetScheduleReportForEdit/{id}")]
    [HttpGet]
    public IActionResult GetScheduleReportForEdit(int id)
    {

      var scheduleReport = scheduleReportService.GetScheduleReportById(id);
      if (scheduleReport == null)
      {
        return NotFound();
      }

      return Ok(scheduleReport);

    }

    /// <summary>
    /// To add new ScheduleReport
    /// </summary>
    /// <param name="scheduleReport"></param>
    /// <returns></returns>

        [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
        [HttpPost]
        [Route("AddReportEmail")]
        public async Task<IActionResult> AddReportEmail(ScheduleReportDto scheduleReport)
    {
            try { 
                  var scheduleReportId = await scheduleReportService.PostScheduleReport(scheduleReport);
                  scheduleReport.Id = scheduleReportId;
            }
            catch (CoilTrackingException ex)
            {
              return BadRequest(ex.ErrorMessage);
            }

      return Ok(scheduleReport);
        }

    /// <summary>
    /// To Edit Schedule Reports
    /// </summary>
    /// <param name="id"></param>
    /// <param name="scheduleReport"></param>
    /// <returns></returns>
    [Route("EditReportEmail")]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    [HttpPut]
    public IActionResult EditReportEmail(int id, ScheduleReportDto scheduleReport)
    {

      if (id != scheduleReport.Id)
      {
        return BadRequest();
      }
      var checkIfScheduleReportEdited = scheduleReportService.PutScheduleReport(id, scheduleReport);
      if (checkIfScheduleReportEdited == false)
      {
        return NotFound();
      }
      return NoContent();
    }
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    [Route("DeleteReportEmail")]
    public IActionResult DeleteReportEmail(int id)
    {
      var deletedScheduleReport = scheduleReportService.DeleteScheduleReport(id);

      return Ok(deletedScheduleReport);
    }
  }
}
