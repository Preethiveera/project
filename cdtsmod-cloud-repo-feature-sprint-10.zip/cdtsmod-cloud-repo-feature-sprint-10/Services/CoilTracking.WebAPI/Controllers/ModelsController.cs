using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using CoilTracking.WebAPI.AuthorizationHelper;
using CoilTracking.Common.Constants;
using Microsoft.AspNetCore.Authorization;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/Models")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  [ResourceAuthorize(AuthResources.HomeActions.View, AuthResources.Home)]
  public class ModelsController : ControllerBase
  {
    private readonly IModelService modelService;

    public ModelsController(IModelService modelService)
    {

      this.modelService = modelService;
    }

    /// <summary>
    /// Get all models.
    /// </summary>
    /// <returns>List of ModelDto</returns>
    [HttpGet]
    public async Task<IActionResult> GetModels()
    {
      return Ok(await modelService.GetModels());
    }

    /// <summary>
    /// Get model by id.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>ModelDto</returns>
    [Route("{id}")]
    [HttpGet]
    public async Task<IActionResult> GetModel(int id)
    {
      return Ok(await modelService.GetModel(id));
    }

    /// <summary>
    /// Check edit.
    /// </summary>
    /// <param name="id"></param>
    /// <param name="model"></param>
    /// <returns>NotFound</returns>
    [Route("CheckEdit")]
    [HttpPost]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> CheckEdit(int id, ModelDto model)
    {
      var edited = await modelService.CheckEdit(id, model);

      if (edited)
        return BadRequest();

      return NotFound();
    }

    /// <summary>
    /// Get parts related to models
    /// </summary>
    /// <param name="id"></param>
    /// <returns>list of partDto</returns>
    [Route("GetPartsRelatedToModels")]
    [HttpGet]
    public async Task<IActionResult> GetPartsRelatedToModels(int id)
    {
      return Ok(await modelService.GetPartsRelatedToModels(id));
    }

    /// <summary>
    /// Get parts in run order by modelId.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>list of PartModelDto</returns>
    [Route("GetPartsInRunOrderByModelId")]
    [HttpGet]
    public async Task<IActionResult> GetPartsInRunOrderByModelId(int id)
    {
      return Ok(await modelService.GetPartsInRunOrderByModelId(id));
    }

    /// <summary>
    /// Check dependency.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>List of string</returns>
    [Route("CheckDependency")]
    [HttpGet]
    public async Task<IActionResult> CheckDependency(int id)
    {
      return Ok(await modelService.CheckDependency(id));
    }

    /// <summary>
    /// Put the model.
    /// </summary>
    /// <param name="id"></param>
    /// <param name="modelDto"></param>
    /// <returns>NoContent</returns>
    [Route("{id}")]
    [HttpPut]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> PutModel(int id, ModelDto modelDto)
    {

      if (id != modelDto.Id)
      {
        return BadRequest();
      }

      await modelService.PutModel(modelDto);

      return NoContent();
    }

    /// <summary>
    /// Disable the model.
    /// </summary>
    /// <param name="id"></param>
    /// <param name="disable"></param>
    /// <returns>NoContent</returns>
    [Route("DisableModel/{id}/{disable}")]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    [HttpGet]
    public async Task<IActionResult> DisableModel(int id, bool disable)
    {
      await modelService.DisableModel(id, disable);
      return NoContent();
    }

    /// <summary>
    /// Post model.
    /// </summary>
    /// <param name="modelDto"></param>
    /// <returns>ModelDto</returns>
    [HttpPost]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> PostModel(ModelDto modelDto)
    {
      var model = await modelService.PostModel(modelDto);

      return Ok(model);
    }

    /// <summary>
    /// Delete the model.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>ModelDto</returns>
    [Route("{id}")]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    [HttpDelete]
    public async Task<IActionResult> DeleteModel(int id)
    {
      return Ok(await modelService.DeleteModel(id));
    }
  }
}
