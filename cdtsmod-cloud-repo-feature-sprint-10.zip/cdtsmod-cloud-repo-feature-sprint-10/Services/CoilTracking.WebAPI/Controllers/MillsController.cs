using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using CoilTracking.WebAPI.AuthorizationHelper;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/Mills")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  [ResourceAuthorize(AuthResources.HomeActions.View, AuthResources.Home)]
  public class MillsController : ControllerBase
  {

    private readonly IMillService millService;

    public MillsController(IMillService millService)
    {
      this.millService = millService;
    }

    /// <summary>
    /// Get Mills from DB
    /// </summary>
    /// <returns>mills</returns>
    /// // GET: api/Mills
    [HttpGet]
    public IQueryable<MillDto> GetMills()
    {
      var mills = millService.GetMills();
      return mills;
    }
    /// <summary>
    /// Get mills By Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>Mill</returns>
    /// // GET: api/Mills/5
    [HttpGet, Route("{id}")]
    public IActionResult GetMill(int id)
    {
      var mill = millService.GetMillById(id);
      if (mill == null)
      {
        return NotFound();
      }

      return Ok(mill);
    }

    /// <summary>
    /// Get Associated coils for a   Mill
    /// </summary>
    /// <param name="id"></param>
    /// <returns>coils</returns>
    [HttpGet, Route("GetAssociatedItemsMills")]
    public IActionResult GetAssociatedItemsMills(int id)
    {
      var coils = millService.GetAssociatedItemsMills(id);

      return Ok(coils);
    }

    /// <summary>
    /// Get list of coils loaded at line
    /// </summary>
    /// <param name="id"></param>
    /// <returns>list of coils</returns>
    [HttpGet, Route("GetLoadedCoilsById")]
    public IActionResult GetLoadedCoilsById(int id)
    {
      var loadedAtLinecoils = millService.GetLoadedCoilsById(id);
      return Ok(loadedAtLinecoils);
    }

    /// <summary>
    /// Check if entity is edited while deletion
    /// </summary>
    /// <param name="id"></param>
    /// <param name="mill"></param>
    /// <returns>string</returns>
    [HttpPost, Route("CheckEdit")]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public IActionResult CheckEdit(int id, MillDto mill)
    {

      var checkIfEdited = millService.CheckIfEdited(id, mill);
      if (checkIfEdited == null)
      {
        return NotFound();        
      }
      return BadRequest();

    }

    /// <summary>
    /// Get the Association Type for Mills
    /// </summary>
    /// <param name="id"></param>
    /// <returns>List of string</returns>

    [HttpGet, Route("CheckDependency")]
    public IActionResult CheckDependency(int id)
    {
      var millsAssociationType = millService.CheckDependencyType(id);


      return Ok(millsAssociationType);

    }


    /// <summary>
    /// Disable a mill by id
    /// </summary>
    /// <param name="id"></param>
    /// <param name="disable"></param>
    /// <returns>void</returns>
    [Route("DisableMill/{id}/{disable}")]
    [HttpGet]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public IActionResult DisableMill(int id, bool disable)
    {
      var disablemill = millService.DisableMill(id, disable);
      if (!disablemill)
      {
        return NotFound();
      }
      return Ok();
    }

    /// <summary>
    /// Add new Mill
    /// </summary>
    /// <param name="mill"></param>
    /// <returns>mill</returns>
    /// // POST: api/Mills
    //[Route("PostMill")]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    [HttpPost]
    public IActionResult PostMill(MillDto mill)
    {
      var addNewMill = millService.InsertMill(mill);
      if (!addNewMill)
      {
        return BadRequest();
      }
      return Ok(mill);
    }

    /// <summary>
    /// Delete a Mill
    /// </summary>
    /// <param name="id"></param>
    /// <returns>mill</returns>
    // DELETE: api/Mills/5]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    [HttpDelete, Route("{id}")]
    public IActionResult DeleteMill(int id)
    {
      var deleteMill = millService.DeleteMill(id);
      if (deleteMill == null)
      {
        return NotFound();
      }

      return Ok(deleteMill);
    }

    /// <summary>
    /// Update a Mill
    /// </summary>
    /// <param name="id"></param>
    /// <param name="mill"></param>
    /// <returns></returns>
    /// // PUT: api/Mills/5
    //[HttpPut,
    [Route("{id}")]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public IActionResult PutMill(int id, MillDto mill)
    {
      var milldto = millService.UpdateMill(id, mill);
      if (!milldto)
      {
        return NotFound();
      }

      return NoContent();
    }



  }
}
