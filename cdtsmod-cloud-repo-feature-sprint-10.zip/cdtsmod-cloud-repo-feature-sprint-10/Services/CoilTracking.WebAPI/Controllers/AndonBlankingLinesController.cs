using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using CoilTracking.WebAPI.AuthorizationHelper;
using Microsoft.AspNetCore.Authorization;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/[controller]")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  [AllowAnonymous]
  /// <summary>
  /// Gets the information needed to build the Blanking Lines andon screen
  /// GET: api/AndonBlankingLines
  /// </summary>
  //Andon's don't authorize, allow anonymous
  public class AndonBlankingLinesController : ControllerBase
  {
    private readonly ILineService lineService;
    /// <summary>
    /// AndonBlankingLines
    /// </summary>
    /// <param name="customLogger"></param>
    /// <param name="lineService"></param>
    public AndonBlankingLinesController(ILineService lineService)
    {
      this.lineService = lineService;
    }
    /// <summary>
    /// Get
    /// </summary>
    /// <returns></returns>
    [HttpGet]
    [AllowAnonymous]
    public List<AndonBlankingLinesDto> Get()
    {
      var lines = lineService.GetLinesForAndons();
      return lines;
    }
  }

}
