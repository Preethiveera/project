using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net.WebSockets;
using System.Text;
using System.Threading.Tasks;

namespace CoilTracking.WebAPI.Controllers
{

  [Route("api/Notification")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  [ExcludeFromCodeCoverage]
  public class NotificationController : ControllerBase
  {

    protected readonly IDatabase _database;
    protected readonly IConnectionMultiplexer _redis;
    private readonly IWebsocketService _websocketService;

    public NotificationController(IConnectionMultiplexer redis, IWebsocketService websocketService)
    {
      _redis = redis;
      _database = redis.GetDatabase();
      _websocketService = websocketService;
    }

    /// <summary>
    /// Having a new connection from client.
    /// </summary>
    
    [HttpPost("connect")]
    public async Task Connect(ConnectionModelDto connection)
    {
      await _websocketService.Connect(connection);
    }

    /// <summary>
    /// There is any disconnected connection from the client.
    /// </summary>
    [AllowAnonymous]
    [HttpPost("disconnect")]
    public async Task Disconnect(ConnectionModelDto connection)
    {
      await _websocketService.Disconnect(connection);
    }
  }
}
