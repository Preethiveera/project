using CoilTracking.Business.Interfaces;
using CoilTracking.Common;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using CoilTracking.WebAPI.AuthorizationHelper;
using CoilTracking.Common.UsersHelperUtility;

namespace CoilTracking.WebAPI.Controllers
{
  /// <summary>
  /// CoilTypes
  /// </summary>
  [Route("api/CoilTypes")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  [ResourceAuthorize(AuthResources.HomeActions.View, AuthResources.Home)]
  public class CoilTypesController : ControllerBase
  {
    private readonly IUserHelper usersHelper;
    private readonly ICoilTypeService coilTypeService;
    private readonly IImportCoilTypeData importCoilTypeDataService;
    private readonly IWebSocketClientService webSocketClientService;
    /// <summary>
    /// CoilTypes
    /// </summary>
    /// <param name="coilTypeService"></param>
    public CoilTypesController(ICoilTypeService coilTypeService, IImportCoilTypeData importCoilTypeDataService,
     IWebSocketClientService webSocketClientService,IUserHelper usersHelper)
    {
      this.usersHelper = usersHelper;
      this.coilTypeService = coilTypeService;
      this.importCoilTypeDataService = importCoilTypeDataService;
      this.webSocketClientService = webSocketClientService;
    }
    /// <summary>
    /// Get CoilTypes
    /// </summary>
    /// <returns></returns>
    // GET: api/CoilTypes
    public async Task<IActionResult> GetCoilTypes()
    {
      var coilTypes = await coilTypeService.GetCoilTypes();
      return Ok(coilTypes);
    }
    /// <summary>
    /// Get CoilTypeDtos
    /// </summary>
    /// <returns></returns>
    /// api/CoilTypes/GetCoilTypeDtos
    [HttpGet, Route("GetCoilTypeDtos")]
    public async Task<IActionResult> GetCoilTypeDtos()
    {
      var coilTypeDtos = await coilTypeService.GetCoilsTypes();

      return Ok(coilTypeDtos);
    }

    /// <summary>
    /// Get CoilType Based on Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    // GET: api/CoilTypes/5
    [HttpGet, Route("{id}")]
    public async Task<IActionResult> GetCoilType(int id)
    {
      var coilType = await coilTypeService.GetCoilTypesById(id);
      if (coilType == null)
      {
        return NotFound();
      }

      return Ok(coilType);
    }

    /// <summary>
    /// Get  MaterialTypes
    /// </summary>
    /// <returns></returns>
    /// /api/CoilTypes/GetMaterialTypes
    [HttpGet, Route("GetMaterialTypes")]
    public async Task<IActionResult> GetMaterialTypes()
    {
      var materialType = await coilTypeService.GetMaterialTypes();

      return Ok(materialType);
    }

    /// <summary>
    /// Get Associated Items CoilTypes Based on Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    /// /api/CoilTypes/GetAssociatedItemsCoilTypes?id=4
    [HttpGet, Route("GetAssociatedItemsCoilTypes")]
    public async Task<IActionResult> GetAssociatedItemsCoilTypes(int id)
    {
      var coils = await coilTypeService.GetCoilsByCoilTypeId(id);
      if (coils == null)
      {
        return NotFound();
      }

      return Ok(coils);
    }

    /// <summary>
    /// Insertion CoilType CheckEdit Based on Id and CoilTypeDto
    /// </summary>
    /// <param name="id"></param>
    /// <param name="dto"></param>
    /// <returns></returns>
    /// /api/CoilTypes/CheckEdit?id=5
    /// {"Id":4, "Name":"16445", "Width":1590,"Thickness":0.70,"Spec":"SCGA270D","CoilFieldZoneId":0, "CoilFieldZoneName":"1","NumCoils":2,"Disabled":false,"Yield":0.98,"MinThickness":0.65,"MaxThickness":0.75,"MinWidth":1590.00,"MaxWidth":1598.00,"CoilTypeYNAs":[{"Id":"1","CoilType":{"Id":"2"},"MaterialType":{"Name":"12"},"YNA":"YNA0011171"}],"CoilTypeYNAsCSVString":"YNA0011171","MaterialTypeId":0,"MaterialTypeName":"Steel", "NAMC":"TMMK"}
    [HttpPost, Route("CheckEdit")]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> CheckEdit(int id, CoilTypeDto dto)
    {
      try
      {
        await coilTypeService.CheckEdit(id, dto);
      }
      catch (CoilTrackingException ex)
      {
        return ex.ErrorNumber == Constant.errornotfound ? NotFound(ex.ErrorMessage) : (IActionResult)NotFound(ex.ErrorMessage);
      }
      return NotFound();

    }

    /// <summary>
    /// Get CoilsLoaded For CoilType
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [HttpGet, Route("GetCoilsLoadedForCoilType")]
    public async Task<IActionResult> GetCoilsLoadedForCoilType(int id)
    {
      var coilsLoaded = await coilTypeService.GetCoilsLoadedForCoilType(id);
      return Ok(coilsLoaded);
    }

    /// <summary>
    /// Get CheckDependency
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [HttpGet, Route("CheckDependency")]
    public async Task<IActionResult> CheckDependency(int id)
    {
      var coilTypesAssociation = await coilTypeService.CheckDependency(id);

      return Ok(coilTypesAssociation);

    }

    /// <summary>
    /// Deletion of CoilType Based on Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [HttpDelete, Route("{id}")]
    // DELETE: api/CoilTypes/5
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditCoilType, AuthResources.TeamLeaderPage)]
    public async Task<IActionResult> DeleteCoilType(int id)
    {
      try
      {
        var coilType = await coilTypeService.DeleteCoilTypeById(id);
        if (coilType == null)
        {
          return NotFound();
        }
        return Ok(coilType);
      }
      catch (CoilTrackingException ex)
      {
        return ex.ErrorNumber == Constant.errornotfound ? NotFound(ex.ErrorMessage) : (IActionResult)NotFound(ex.ErrorMessage);
      }

    }

    /// <summary>
    /// Get DisableCoilType Based on Id and Disable
    /// </summary>
    /// <param name="id"></param>
    /// <param name="disable"></param>
    /// <returns></returns>
    [Route("DisableCoilType/{id}/{disable}")]
    [HttpGet]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditCoilType, AuthResources.TeamLeaderPage)]
    public async Task<IActionResult> DisableCoilType(int id, bool disable)
    {
      try
      {
        await coilTypeService.DisableCoilType(id, disable);
      }
      catch (Exception ex)
      {
        return BadRequest(ex);
      }
      return Ok();
    }

    /// <summary>
    /// Updation data to coilType Based on Id and Coiltype
    /// </summary>
    /// <param name="id"></param>
    /// <param name="coilType"></param>
    /// <returns></returns>
    /// PUT: api/CoilTypes/5
    ///{"Id":5, "Name":"164", "Width":1590,"Thickness":0.70,"Spec":"SCGA270D","CoilFieldZoneId":4, "CoilFieldZoneName":"1","NumCoils":2,"Disabled":false,"Yield":0.98,"MinThickness":0.65,"MaxThickness":0.75,"MinWidth":1590.00,"MaxWidth":1598.00,"CoilTypeYNAs":[{"Id":"1","CoilType":{"Id":"2"},"MaterialType":{"Name":"1"},"YNA":"YNA0011171"}],"CoilTypeYNAsCSVString":"YNA0011171","MaterialTypeId":1,"MaterialTypeName":"Steel", "NAMC":"TMMK"}
    [Route("PutCoilType/{id}")]
    [HttpPut]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditCoilType, AuthResources.TeamLeaderPage)]
    public async Task<IActionResult> PutCoilType(int id, CoilTypeDto coilType)
    {
      if (!ModelState.IsValid)
      {
        return BadRequest(ModelState);
      }
      if (id != coilType.Id)
      {
        return BadRequest();
      }
      try
      {
        await coilTypeService.UpdateCoilType(id, coilType);
      }
      catch (CoilTrackingException ex)
      {
        return ex.ErrorNumber == Constant.errornotfound ? NotFound(ex.ErrorMessage) : (IActionResult)NotFound(ex.ErrorMessage);
      }
      return Ok();

    }

    /// <summary>
    /// Insertion of coilType
    /// </summary>
    /// <param name="coilType"></param>
    /// <returns></returns>
    /// // {"Id":4, "Name":"16445", "Width":1590,"Thickness":0.70,"Spec":"SCGA270D","CoilFieldZoneId":0, "CoilFieldZoneName":"1","NumCoils":2,"Disabled":false,"Yield":0.98,"MinThickness":0.65,"MaxThickness":0.75,"MinWidth":1590.00,"MaxWidth":1598.00,"CoilTypeYNAs":[{"Id":"1","CoilType":{"Id":"2"},"MaterialType":{"Name":"12"},"YNA":"YNA0011171"}],"CoilTypeYNAsCSVString":"YNA0011171","MaterialTypeId":0,"MaterialTypeName":"Steel", "NAMC":"TMMK"}
    // POST: api/CoilTypes

    [Route("PostCoilType", Name = "PostCoilType")]
    [HttpPost]
    [ResourceAuthorize(AuthResources.TeamLeaderActions.EditCoilType, AuthResources.TeamLeaderPage)]
    public async Task<IActionResult> PostCoilType(CoilTypeDto coilType)
    {
      if (!ModelState.IsValid)
      {
        return BadRequest(ModelState);
      }
      try
      {
        var newCoilType = await coilTypeService.InsertCoilType(coilType);
        return Ok(newCoilType);
      }
      catch (CoilTrackingException ex)
      {
        return ex.ErrorNumber == Constant.errornotfound ? NotFound(ex.ErrorMessage) : (IActionResult)NotFound(ex.ErrorMessage);
      }

    }
    /// <summary>
    /// Upload CoilTypes
    /// </summary>
    /// <returns></returns>
    [Route("UploadCoilTypes")]
    [HttpPost]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> UploadCoilTypes()
    {

      // Check if the request contains multipart/form-data.
      if (!(Request.HasFormContentType && Request.Form.Files.Any()))
      {
        throw new CoilTrackingException { HttpStatusCode = "UnsupportedMediaType" };
      }

      try
      {
        // Read the form data, copy it to a memorystream, and pass it to the importer
        var file = HttpContext.Request.Form.Files["UploadedFile"];
        var ms = new System.IO.MemoryStream();
        await file.CopyToAsync(ms);
        List<DataImportMessage> messages = await importCoilTypeDataService.Import(ms, usersHelper.GetSubject());
        await webSocketClientService.CoilLocationsUpdated();
        return Ok(new ImportResult(messages, HttpStatusCode.OK));
      }
      catch (Exception ex)
      {
        return BadRequest("Error in upload process. " + ex.ToString());
      }
    }
  }
}

