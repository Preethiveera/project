using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics.CodeAnalysis;

namespace CoilTracking.WebAPI.Controllers
{
  [AllowAnonymous]
  [Route("api/Users")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  [ExcludeFromCodeCoverage]
  public class UsersController : ControllerBase
  {

    public UsersController()
    {
   
    }

  

  }
}
