using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;
using CoilTracking.WebAPI.AuthorizationHelper;
using System.Threading;
using CoilTracking.Business.PLCAuthHelper;
using Microsoft.Extensions.Configuration;
using CoilTracking.Data.Models;
using Microsoft.Extensions.Logging;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/Lines")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]

  public class LinesController : ControllerBase
  {
    private readonly ILogger<LinesController> logger;
    private readonly ILineService lineService;
    private readonly IConfiguration config;
    public LinesController(ILineService lineService, IConfiguration config, ILogger<LinesController> logger)
    {
      this.lineService = lineService;
      this.config = config;
      this.logger = logger;
    }

    /// <summary>
    /// Get list of Lines.
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous]
    [Route("GetLines")]
    [HttpGet]
    public async Task<IQueryable<LineDto>> GetLines()
    {
      logger.LogInformation("Value from Parameter store=" + config["azuread-instance"]);

      var lines = await lineService.GetLines();
      return lines;
    }

    /// <summary>
    /// Get Line by id
    /// </summary>
    /// <returns></returns>
    ///
    [ResourceAuthorize(AuthResources.HomeActions.View, AuthResources.Home)]
    [Route("GetLine/{id}")]
    [HttpGet]
    // [ResponseType(typeof(Line))]
    public async Task<IActionResult> GetLine(int id)
    {
      LineDto line = await lineService.GetLineById(id);
      if (line == null)
      {
        return NotFound();
      }

      return Ok(line);
    }

    /// <summary>
    /// Get list for Edit
    /// </summary>
    /// <returns></returns>
    ///
    [ResourceAuthorize(AuthResources.HomeActions.View, AuthResources.Home)]
    [Route("GetLineForEdit/{id}")]
    [HttpGet]
    // [ResponseType(typeof(LineDto))]
    public async Task<IActionResult> GetLineForEdit(int id)
    {
      var dto = await lineService.GetLineForEdit(id);
      return Ok(dto);
    }

    /// <summary>
    /// Update Line Subscription
    /// </summary>
    /// <returns></returns>
    [Route("UpdateLineSubscription/{id}/{subscribe}")]
    [HttpGet]
    // [ResponseType(typeof(Line))]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> UpdateLineSubscription(int id, bool subscribe)
    {
      PLCAzureAd plcAzuread = new PLCAzureAd();
      plcAzuread.Instance = config["azuread-instance"];
      plcAzuread.ScopeUrl = config["azuread-scopeurl-plc"];
      plcAzuread.SecretName = config["azuread-secretname-plc"];
      plcAzuread.TenantId = config["azuread-tennat-id"];
      plcAzuread.ClientId = config["azuread-client-id-plc"];
      plcAzuread.Audience = config["azuread-audience"];
      var token = await OpenIDConnectAuthHelper.GetTokenForPLC(HttpContext, plcAzuread);
      
      var line = await lineService.UpdateLineSubscription(id, subscribe, token);
      return Ok(line);
    }

    /// <summary>
    /// Get's the list of LineInfo's for lines that are currently set to subscribed. The OPCClientSelfHosted application calls this
    /// whenever the app is restarting/starting up to resubscribe to the lines that were last subscribed.
    /// </summary>
    /// <returns>A list of LineInfo objects with all the information needed to subscribe to the data</returns>
    [HttpGet, Route("GetSubscribedLines/{namcCode}")]
    // [ResponseType(typeof(IEnumerable<OPCClientService.LineInfo>))]
    // [AllowAnonymous] //Allow anonymous for the OPC client to post back data for now.
    [Authorize]
    public async Task<IActionResult> GetSubscribedLines(string namcCode)
    {
      var lineInfos = await lineService.GetSubscribedLines(namcCode);
      return Ok(lineInfos);
    }

    /// <summary>
    /// Disable A line
    /// </summary>
    /// <returns></returns>
    [Route("DisableLine/{id}/{disable}")]
    [HttpGet]
    //[ResponseType(typeof(void))]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> DisableLine(int id, bool disable)
    {
      await lineService.DisableLine(id, disable);
      return NoContent();
    }

    /// <summary>
    /// Update A line
    /// </summary>
    /// <returns></returns>
    [Route("PutLine/{id}")]
    [HttpPut]
    // [ResponseType(typeof(void))]
  [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> PutLine(int id, LineDto line)
    {
      if (id != line.Id)
      {
        return BadRequest();
      }

      await lineService.PutLine(line);
      return NoContent();
    }

    /// <summary>
    /// Update A line
    /// </summary>
    /// <returns></returns>
    [Route("UpdateLineDto/{id}")]
    [HttpPut]
    // [ResponseType(typeof(LineDto))]
   [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> UpdateLineDto(int id, LineDto lineDto)
    {
      if (id != lineDto.Id)
      {
        return BadRequest();
      }

      var line = await lineService.UpdateLine(id, lineDto);

      return Ok(line);
    }

    /// <summary>
    /// Create A line
    /// </summary>
    /// <returns></returns>
    [Route("PostLine")]
    [HttpPost]
    // [ResponseType(typeof(Line))]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> PostLine(LineDto line)
    {
      var id = await lineService.AddLine(line);
      line.Id = id;
      return Ok(line);
    }

    /// <summary>
    /// Save A line
    /// </summary>
    /// <returns></returns>
    [Route("SaveLineDto")]
    [HttpPost]
   //[AllowAnonymous]
   // [ResponseType(typeof(LineDto))]
   [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> SaveLineDto(LineDto lineDto)
    {
      var line = await lineService.SaveLine(lineDto);
      return Ok(line);
    }

    /// <summary>
    /// Create Line Data
    /// </summary>
    /// <returns></returns>
    [Route("PostLineData")]
    [HttpPost]
    // [ResponseType(typeof(LineData))]
    // [AllowAnonymous] //Allow anonymous for the OPC client to post back data for now.
    [Authorize]
    public async Task<IActionResult> PostLineData(LineDataDto lineDataDto,string namcCode)
    {
      var lineData = await lineService.PostLineData(lineDataDto);
      return Ok(lineData);
    }

    /// <summary>
    /// Check Edit for Line
    /// </summary>
    /// <returns></returns>
    [HttpPost, Route("CheckEdit")]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> CheckEdit(int id, LineDto dto)
    {
      var lineAssociation = await lineService.CheckEdit(id, dto);
      if (lineAssociation.Count > 0)
      {
        return BadRequest();
      }
      return NotFound();
    }

    /// <summary>
    /// Check Dependency for Line
    /// </summary>
    /// <returns></returns>
    [ResourceAuthorize(AuthResources.HomeActions.View, AuthResources.Home)]
    [HttpGet, Route("CheckDependency")]
    //[ResponseType(typeof(List<string>))]
    public async Task<IActionResult> CheckDependency(int id)
    {
      var lineAssociation = await lineService.CheckDependency(id);
      return Ok(lineAssociation);

    }

    /// <summary>
    /// Delete A line
    /// </summary>
    /// <returns></returns>
    [HttpDelete, Route("DeleteLine")]
    // [ResponseType(typeof(Line))]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> DeleteLine(int id)
    {
      var line = await lineService.DeleteLine(id);
      return Ok(line);
    }

    /// <summary>
    /// to call the plc api  for testing connectivity
    /// </summary>
    /// <returns>string</returns>
    [HttpGet]
    [AllowAnonymous]
    [Route("TestPLC")]
    public IActionResult TestPLC()
    {
      var val =  lineService.TestPLC();
      return Ok(val);
    }

    [Route("GetLinesData/{lineId}")]
    [HttpGet]
    public  async Task<IActionResult> GetLinesData(int lineId)
    {
      var lineData = await lineService.GetLinesData(lineId);
      if (lineData == null)
      {
        return NotFound();
      }

      return Ok(lineData);
    }
  }
}
