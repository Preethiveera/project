using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;
using CoilTracking.WebAPI.AuthorizationHelper;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/[controller]")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  public class PartModelsController : ControllerBase
  {
    private readonly IPartModelService partModelService;

    public PartModelsController(IPartModelService partModelService)
    {
      this.partModelService = partModelService;
    }

    /// <summary>
    /// Get list of PartModels.
    /// </summary>
    /// <returns></returns>
    [HttpGet]
    public async Task<IQueryable<PartModelDto>> GetPartModels()
    {
      return await partModelService.GetPartModels();
    }

    /// <summary>
    /// Get PartModel by Id.
    /// </summary>
    /// <returns></returns>
    [HttpGet]
    // [ResponseType(typeof(PartModel))]
    public async Task<IActionResult> GetPartModel(int id)
    {
      var partModel = await partModelService.GetPartModelById(id);
      if (partModel == null)
      {
        return NotFound();
      }

      return Ok(partModel);
    }

    /// <summary>
    /// Update PartModel.
    /// </summary>
    /// <returns></returns>
    [HttpPut]
    // [ResponseType(typeof(void))]
    public async Task<IActionResult> PutPartModel(int id, PartModelDto partModel)
    {
      if (id != partModel.Id)
      {
        return BadRequest();
      }

      await partModelService.PutPartModel(id, partModel);
      return NoContent();
    }

    /// <summary>
    /// Add PartModel.
    /// </summary>
    /// <returns></returns>
    [HttpPost]
    // [ResponseType(typeof(PartModel))]
    public async Task<IActionResult> PostPartModel(PartModelDto partModel)
    {
      var response = await partModelService.AddPartModel(partModel);
      return Ok(response);
    }

    /// <summary>
    /// Delete PartModel.
    /// </summary>
    /// <returns></returns>
    [HttpDelete]
    //[ResponseType(typeof(PartModel))]
    public async Task<IActionResult> DeletePartModel(int id)
    {
      var partModel = await partModelService.DeletePartModel(id);
      return Ok(partModel);
    }
  }
}
