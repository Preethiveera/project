using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;
using CoilTracking.WebAPI.AuthorizationHelper;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/Shifts")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  public class ShiftsController : ControllerBase
  {
    private readonly IShiftService shiftService;

    public ShiftsController(IShiftService shiftService)
    {
      this.shiftService = shiftService;
    }

    /// <summary>
    /// Get list of shifts.
    /// </summary>
    /// <returns></returns>
    [HttpGet]
    public async Task<IQueryable<ShiftDto>> GetShifts()
    {
      return await shiftService.GetShifts();
    }

    /// <summary>
    /// Get shift by Id.
    /// </summary>
    /// <returns></returns>
    [Route("{id}")]
    [HttpGet]
    // [ResponseType(typeof(Shift))]
    public async Task<IActionResult> GetShift(int id)
    {
      var shift = await shiftService.GetShiftById(id);
      if (shift == null)
      {
        return NotFound();
      }

      return Ok(shift);
    }

    /// <summary>
    /// Get current shift by LineId.
    /// </summary>
    /// <returns></returns>
    [Route("GetCurrentShift/{lineId}")]
    [HttpGet]
    // [ResponseType(typeof(Shift))]
    public async Task<IActionResult> GetCurrentShift(int lineId)
    {
      var currentShift = await shiftService.GetCurrentShift(lineId);
      return Ok(currentShift);
    }

    /// <summary>
    /// Get next shift by LineId.
    /// </summary>
    /// <returns></returns>
    [Route("GetNextShift/{lineId}")]
    [HttpGet]
    // [ResponseType(typeof(Shift))]
    public async Task<IActionResult> GetNextShift(int lineId)
    {
      var nextShift = await shiftService.GetNextShift(lineId);
      return Ok(nextShift);
    }

    /// <summary>
    /// Update shift.
    /// </summary>
    /// <returns></returns>
    [Route("{id}")]
    [HttpPut]
    //[ResponseType(typeof(void))]
    [ResourceAuthorize(AuthResources.AdminPageActions.EditShift, AuthResources.AdminPage)]
    public async Task<IActionResult> PutShift(int id, ShiftDto shift)
    {
      if (id != shift.Id)
      {
        return BadRequest();
      }

      await shiftService.PutShift(id, shift);
      return NoContent();
    }

    /// <summary>
    /// Disable shift.
    /// </summary>
    /// <returns></returns>
    [Route("DisableShift/{id}/{disable}")]
    [HttpGet]
    // [ResponseType(typeof(void))]
     [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> DisableShift(int id, bool disable)
    {
      await shiftService.DisableShift(id, disable);
      return NoContent();
    }

    /// <summary>
    /// Create shift.
    /// </summary>
    /// <returns></returns>
    [HttpPost]
    // [ResponseType(typeof(Shift))]
    [ResourceAuthorize(AuthResources.AdminPageActions.EditShift, AuthResources.AdminPage)]
    public async Task<IActionResult> PostShift(ShiftDto shift)
    {
      var response = await shiftService.AddShift(shift);
      return Ok(response);
    }

    /// <summary>
    /// Delete shift.
    /// </summary>
    /// <returns></returns>
    [Route("{id}")]
    [HttpDelete]
    // [ResponseType(typeof(Shift))]
    [ResourceAuthorize(AuthResources.AdminPageActions.EditShift, AuthResources.AdminPage)]
    public async Task<IActionResult> DeleteShift(int id)
    {
      var shift = await shiftService.DeleteShift(id);
      return Ok(shift);
    }

    /// <summary>
    /// CheckEdit for shift.
    /// </summary>
    /// <returns></returns>
    [HttpPost, Route("CheckEdit")]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> CheckEdit(int id, ShiftDto shift)
    {
      var shiftAssociation = await shiftService.CheckEdit(id, shift);
      if (shiftAssociation.Count() > 0)
      {
        return BadRequest();
      }
      return NotFound();
    }

    /// <summary>
    /// Check Dependency.
    /// </summary>
    /// <returns></returns>
    [HttpGet, Route("CheckDependency")]
    // [ResponseType(typeof(List<string>))]
    public async Task<IActionResult> CheckDependency(int id)
    {
      var shiftAssociation = await shiftService.CheckDependency(id);
      return Ok(shiftAssociation);
    }
  }
}
