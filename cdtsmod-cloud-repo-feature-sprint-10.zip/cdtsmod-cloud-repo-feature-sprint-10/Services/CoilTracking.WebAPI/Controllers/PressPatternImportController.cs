using CoilTracking.Common;
using CoilTracking.Common.Exception;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;
using System.Threading.Tasks;
using CoilTracking.WebAPI.AuthorizationHelper;
using CoilTracking.Common.UsersHelperUtility;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/PressPatternImport")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
  public class PressPatternImportController : ControllerBase
  {
    private readonly IImportPressPattern importPressPattern;
    private readonly IUserHelper usersHelper;

    public PressPatternImportController(IImportPressPattern importPressPattern, IUserHelper usersHelper)
    {
      this.importPressPattern = importPressPattern;
      this.usersHelper = usersHelper;
    }

    /// <summary>
    /// Upload Press Pattern.
    /// </summary>
    /// <returns></returns>
    [HttpPost]
    [Route("UploadPressPattern")]
    public async Task<IActionResult> UploadPressPattern()
    {
      // Check if the request contains multipart/form-data.
      if (!IsMultipartContentType(Request.ContentType))
      {
        throw new CoilTrackingException { HttpStatusCode = HttpStatusCode.UnsupportedMediaType.ToString() };
      }

      try
      {
        // Read the form data, copy it to a memorystream, and pass it to the importer
        var file = HttpContext.Request.Form.Files["UploadedFile"];
        var ms = new System.IO.MemoryStream();
        await file.CopyToAsync(ms);
        await importPressPattern.Import(ms, usersHelper.GetSubject());

        return Ok();
      }
      catch (System.Exception ex)
      {
        if (ex is System.FormatException)
        {
          return BadRequest($"Format Error in uploaded excel : {ex.Message}");
        }
        else if (ex.GetType() == typeof(Exception))
        {
          return BadRequest(ex.Message);
        }
        else
        {
          return BadRequest(ex.Message.ToString());
        }
      }
    }

    private bool IsMultipartContentType(string contentType)
    {
      return !string.IsNullOrEmpty(contentType)
             && contentType.IndexOf("multipart/", StringComparison.OrdinalIgnoreCase) >= 0;
    }
  }
}
