using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using CoilTracking.WebAPI.AuthorizationHelper;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/[controller]")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  public class AndonCoilTypesByZoneController : ControllerBase
  {

    private readonly IAndonService andonService;
    /// <summary>
    /// AndonCoilTypesByZone
    /// </summary>
    /// <param name="customLogger"></param>
    /// <param name="andonService"></param>
    public AndonCoilTypesByZoneController(IAndonService andonService)
    {
      this.andonService = andonService;
    }
    /// <summary>
    /// Get Andon CoilTypes By Zone 
    /// </summary>
    /// <param name="zoneId"></param>
    /// <returns></returns>
    /// GET: api/AndonCoilTypesByZone
    [AllowAnonymous] //Andon's don't authorize, allow anonymous
    public AndonCoilTypesByZoneDisplayObject Get(int? zoneId = null)
    {
      AndonCoilTypesByZoneDisplayObject andonDisplayObject = new AndonCoilTypesByZoneDisplayObject()
      {
        Zones = new List<AndonZone>()
      };
      //Get list of coils that have a location from service layer
      andonDisplayObject = andonService.GetCoilsTypesByZoneId(zoneId);
      return andonDisplayObject;
    }
  }
}
