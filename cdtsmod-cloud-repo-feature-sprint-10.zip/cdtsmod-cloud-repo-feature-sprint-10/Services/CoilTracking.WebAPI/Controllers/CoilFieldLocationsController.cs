using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoilTracking.WebAPI.AuthorizationHelper;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/CoilFieldLocations")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  [ResourceAuthorize(AuthResources.HomeActions.View, AuthResources.Home)]
  public class CoilFieldLocationsController : ControllerBase
  {
    private readonly ICoilFieldLocationsService coilFieldLocationsService;

    public CoilFieldLocationsController(ICoilFieldLocationsService coilFieldLocationsService)
    {
      this.coilFieldLocationsService = coilFieldLocationsService;
    }

    /// <summary>
    /// to get the coil field locations
    /// </summary>
    /// <returns> list of coil field locations</returns>

    // GET: api/CoilFieldLocations

    [HttpGet]
    public IQueryable<CoilFieldLocationDto> GetCoilFieldLocations()
    {
      var coilFieldLocations = coilFieldLocationsService.GetCoilFieldLocations();
      return coilFieldLocations;
    }

    /// <summary>
    /// To get the Coil Field Location By Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>coil Field Location</returns>

    // GET: api/CoilFieldLocations/5
    //ResponseType(typeof(CoilFieldLocation))]

    [HttpGet]
    [Route("{id}")]
    public IActionResult GetCoilFieldLocation(int id)
    {
      CoilFieldLocationDto coilFieldLocation = coilFieldLocationsService.GetCoilFieldLocationById(id);
      if (coilFieldLocation == null)
      {
        return NotFound();
      }

      return Ok(coilFieldLocation);
    }

    /// <summary>
    /// To get the coil Field Location for Edit
    /// </summary>
    /// <param name="id"></param>
    /// <returns>coil Field Location</returns>

    [Route("GetcoilFieldLocationForEdit/{id}")]
    [HttpGet]

    //[ResponseType(typeof(CoilFieldLocationDto))]
    public async Task<IActionResult> GetCoilFieldLocationForEdit(int id)
    {
      CoilFieldLocationDto coilFieldLocation = await coilFieldLocationsService.GetCoilFieldLocationWithZone(id);
      if (coilFieldLocation == null)
      {
        return NotFound();
      }

      return Ok(coilFieldLocation);
    }


    /// <summary>
    /// To get the coil Field Location by coild Id4
    /// </summary>
    /// <param name="coilId"></param>
    /// <returns>List of Coil Field Location</returns>

    // GET: api/CoilFieldLocations/5
    [Route("GetLocationsByCoilId/{coilId}")]
    [HttpGet]
    //[ResponseType(typeof(List<CoilFieldLocation>))]
    public List<CoilFieldLocationDto> GetLocationsByCoilId(int coilId)
    {
      var coilFieldLocations = coilFieldLocationsService.GetCoilFieldLocationByCoilId(coilId);
      return coilFieldLocations;
    }

    /// <summary>
    /// To get the coil Field Location by zone Id
    /// </summary>
    /// <param name="zoneId"></param>
    /// <returns>List of Coil Field Location</returns>

    // GET: api/CoilFieldLocations/5
    [Route("GetLocationsByZoneId/{zoneId}")]
    [HttpGet]
    //[ResponseType(typeof(List<CoilFieldLocationDto>))]
    public List<CoilFieldLocationDto> GetLocationsByZoneId(int zoneId)
    {
      var coilFieldLocations = coilFieldLocationsService.GetCoilFieldLocationByZoneId(zoneId);
      return coilFieldLocations;
    }

    /// <summary>
    /// To update the coil Field Location
    /// </summary>
    /// <param name="id"></param>
    /// /// <param name="coilFieldLocation"></param>

    // PUT: api/CoilFieldLocations/5
    // [ResponseType(typeof(void))]
     [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    [HttpPut]
    [Route("{id}")]
    public IActionResult PutCoilFieldLocation(int id, CoilFieldLocationDto coilFieldLocation)
    {
      if (id != coilFieldLocation.Id)
      {
        return BadRequest();
      }

      coilFieldLocationsService.UpdateCoilFieldLocation(id, coilFieldLocation);
      return NoContent();
    }

    /// <summary>
    /// To disable the coil Field Location
    /// </summary>
    /// <param name="id"></param>
    /// /// <param name="disable"></param>

    [Route("DisableCoilFieldLocation/{id}/{disable}")]
    [HttpGet]
    // [ResponseType(typeof(void))]
     [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> DisableCoilFieldLocation(int id, bool disable)
    {
      var response = await coilFieldLocationsService.DisableCoilFieldLocation(id, disable);

      return NoContent();
    }

    /// <summary>
    /// To update the coil Field Location
    /// </summary>
    /// <param name="id"></param>
    /// /// <param name="dto"></param>

    [HttpPut, Route("UpdateCoilFieldLocationDto/{id}")]
    // [ResponseType(typeof(void))]
     [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> UpdateCoilFieldLocationDto(int id, CoilFieldLocationDto dto)
    {
      if (id != dto.Id)
      {
        return BadRequest();
      }

      var response = await coilFieldLocationsService.UpdateCoilFieldLocationDto(id, dto);

      return NoContent();
    }

    /// <summary>
    /// To Add the coil Field Location
    /// </summary>
    /// <param name="coilFieldLocation"></param>

    // POST: api/CoilFieldLocations
    // [ResponseType(typeof(CoilFieldLocation))]
     [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    [HttpPost]
    public async Task<IActionResult> PostCoilFieldLocation(CoilFieldLocationDto coilFieldLocation)
    {
   var coilFieldLocations=  await coilFieldLocationsService.AddCoilFieldLocation(coilFieldLocation);

      return Ok(coilFieldLocations);
    }

    /// <summary>
    /// To Save the coil Field Location
    /// </summary>
    /// <param name="dto"></param>

    [HttpPost, Route("SaveCoilFieldLocationDto", Name = "SaveCoilFieldLocationDto")]
    // [ResponseType(typeof(CoilFieldLocation))]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> SaveCoilFieldLocationDto(CoilFieldLocationDto dto)
    {
   var coilFieldLocation =    await coilFieldLocationsService.AddCoilFieldLocation(dto);

      return Ok(coilFieldLocation);
    }

    /// <summary>
    /// To Delete the coil Field Location
    /// </summary>
    /// <param name="id"></param>

    // DELETE: api/CoilFieldLocations/5
    // [ResponseType(typeof(CoilFieldLocation))]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]

    [HttpDelete]
    [Route("{id}")]
    public IActionResult DeleteCoilFieldLocation(int id)
    {
      var coilFieldLocation = coilFieldLocationsService.DeleteCoilFieldLocation(id);

      return Ok(coilFieldLocation);
    }

    [HttpPost, Route("CheckEdit")]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    public async Task<IActionResult> CheckEdit(int id, CoilFieldLocationDto dto)
    {
      var coilTypeAssociation = await coilFieldLocationsService.CheckEditAsync(id, dto);
      if (coilTypeAssociation.Any())
      {
        return BadRequest();
      }
      return NotFound();
    }
  }
}
