using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Exception;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using CoilTracking.WebAPI.AuthorizationHelper;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/CoilFieldZones")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  [ResourceAuthorize(AuthResources.HomeActions.View, AuthResources.Home)]
  public class CoilFieldZonesController : ControllerBase
  {
    private readonly ICoilFieldZonesService coilFieldZonesService;
    public CoilFieldZonesController(ICoilFieldZonesService coilFieldZonesService)
    {
      this.coilFieldZonesService = coilFieldZonesService;
    }

    /// <summary>
    /// Get list of coil filed zones.
    /// </summary>
    /// <returns>List of CoilFieldZoneDto</returns>
    [HttpGet]
    public async Task<IActionResult> GetCoilFieldZones()
    {
      return Ok(await coilFieldZonesService.GetCoilFieldZones());
    }

    /// <summary>
    /// Get coil field zone by id.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>CoilFieldZoneDto</returns>
    [Route("{id}")]
    [HttpGet]
    public async Task<IActionResult> GetCoilFieldZones(int id)
    {
      return Ok(await coilFieldZonesService.GetCoilFieldZone(id));
    }


    /// <summary>
    /// Get coil filed zone for edit by zone id.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>CoilFieldZoneDto</returns>
    [Route("GetCoilFieldZoneForEdit/{id}")]
    [HttpGet]
    public async Task<IActionResult> GetCoilFieldZoneForEdit(int id)
    {
      return Ok(await coilFieldZonesService.GetCoilFieldZoneForEdit(id));
    }

    /// <summary>
    /// Get associated items by coil field zone id.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>CoilTypeDto</returns>
    [Route("GetAssociatedItemsCoilFieldsZone")]
    [HttpGet]
    public async Task<IActionResult> GetAssociatedItemsCoilFieldsZone(int id)
    {
      return Ok(await coilFieldZonesService.GetAssociatedItemsCoilFieldsZone(id));
    }

    /// <summary>
    /// Get coils by zone id.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>CoilDto</returns>    
    [Route("GetCoilsByZoneId")]
    [HttpGet]
    public async Task<IActionResult> GetCoilsByZoneId(int id)
    {
      return Ok(await coilFieldZonesService.GetCoilsByZoneId(id));
    }

    /// <summary>
    /// Check dependency by zone id.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>List of string</returns>
    [Route("CheckDependency")]
    [HttpGet]
    public async Task<IActionResult> CheckDependency(int id)
    {
      return Ok(await coilFieldZonesService.CheckDependencyByZoneId(id));
    }


    /// <summary>
    /// Disable the coil field zone.
    /// </summary>
    /// <param name="id"></param>
    /// <param name="disable"></param>
    /// <returns>NoContent</returns>
    [Route("DisableCoilFieldZone/{id}/{disable}")]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    [HttpGet]
    public async Task<IActionResult> DisableCoilFieldZone(int id, bool disable)
    {
      try
      {
        await coilFieldZonesService.DisableCoilFieldZone(id, disable);

        return NoContent();
      }
      catch (CoilTrackingException ex)
      {
        if (ex.HttpStatusCode == "NotFound")
        {
          return NotFound(ex.ErrorMessage);
        }

        throw;
      }
    }

    /// <summary>
    /// Check if coil field zone is editable or not.
    /// </summary>
    /// <param name="id"></param>
    /// <param name="coilFeildZoneDto"></param>
    /// <returns></returns>
    [Route("CheckEdit")]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    [HttpPost]
    public async Task<IActionResult> CheckEdit(int id, CoilFieldZoneDto coilFeildZoneDto)
    {
      if (id != coilFeildZoneDto.Id)
      {
        return BadRequest();
      }

      var coilFieldZoneEdited = await coilFieldZonesService.CheckIfEdited(coilFeildZoneDto);
      if (coilFieldZoneEdited != null)
      {
        return BadRequest();
      }

      return NotFound();
    }

    /// <summary>
    /// update the coil field zone.
    /// </summary>
    /// <param name="id"></param>
    /// <param name="coilFeildZoneDto"></param>
    /// <returns>void</returns> //Change thhis
    [Route("UpdateCoilFieldZoneDto/{id}")]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    [HttpPut]
    public async Task<IActionResult> UpdateCoilFieldZoneDto(int id, CoilFieldZoneDto coilFeildZoneDto)
    {

      try
      {
        if (id != coilFeildZoneDto.Id)
        {
          return BadRequest();
        }

        await coilFieldZonesService.UpdateCoilFieldZone(coilFeildZoneDto);

        return NoContent();
      }
      catch (CoilTrackingException ex)
      {
        if (ex.HttpStatusCode == "NotFound")
        {
          return NotFound(ex.ErrorMessage);
        }

        throw;
      }

    }

    /// <summary>
    /// Save the new coil field zone.
    /// </summary>
    /// <param name="dto"></param>
    /// <returns>CoilFiledZoneDto</returns>
    [Route("SaveCoilFieldZoneDto")]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    [HttpPost]
    public async Task<IActionResult> SaveCoilFieldZoneDto(CoilFieldZoneDto dto)
    {
      var coilFieldZone = await coilFieldZonesService.SaveCoilFieldZone(dto);

      return Ok(coilFieldZone);
    }


    /// <summary>
    /// Delete the coil field zone.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>CoilFieldZoneDto</returns>
    [Route("{id}")]
    [ResourceAuthorize(AuthResources.AdminPageActions.Edit, AuthResources.AdminPage)]
    [HttpDelete]
    public async Task<IActionResult> DeleteCoilFieldZone(int id)
    {

      try
      {
        var coilFieldZone = await coilFieldZonesService.DeleteCoilFieldZone(id);

        if (coilFieldZone == null)
        {
          return NotFound();
        }

        return Ok(coilFieldZone);
      }
      catch (CoilTrackingException ex)
      {
        if (ex.HttpStatusCode == "NotFound")
        {
          return NotFound(ex.ErrorMessage);
        }

        throw;
      }
    }
  }
}
