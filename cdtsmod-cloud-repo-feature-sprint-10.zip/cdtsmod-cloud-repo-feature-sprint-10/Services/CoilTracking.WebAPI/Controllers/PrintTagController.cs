using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using System;
using System.Threading.Tasks;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/PrintTag")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  public class PrintTagController : ControllerBase
  {
    private readonly IPrintTagService printTagService;
    public PrintTagController(IPrintTagService printTagService)
    {
      this.printTagService = printTagService;
    }

    /// <summary>
    /// Get list of Current Run Lists.
    /// </summary>
    /// <returns></returns>
    [Route("GetCurrentRunList")]
    [HttpGet]
    // [ResponseType(typeof(CurrentRunListForGet))]
    public async Task<IActionResult> GetCurrentRunList(int id = 0)
    {
      var runOrderListDto = await printTagService.GetCurrentRunListAsync(id);
      return Ok(runOrderListDto);
    }

    /// <summary>
    /// Prints Blank Tag.
    /// </summary>
    /// <returns></returns>
    [Route("PrintBlankTag")]
    [HttpPost]
    public async Task<PrintResultDto> PrintBlankTag(string printType, JObject data, DateTime? heatTreatDate = null, string partNumber = null, string stackSize = null, string lineName = null)
    {
      var printResult = await printTagService.PrintBlankTagAsync(printType, data, heatTreatDate, partNumber, stackSize, lineName);
      return printResult;
    }

    /// <summary>
    /// Print Blank test api.
    /// </summary>
    /// <returns></returns>
    [HttpGet, Route("TagTest")]
    public string PrintBlankTagTest()
    {
      var ZPLString = printTagService.PrintBlankTagTest();
      return ZPLString;
    }
  }
}
