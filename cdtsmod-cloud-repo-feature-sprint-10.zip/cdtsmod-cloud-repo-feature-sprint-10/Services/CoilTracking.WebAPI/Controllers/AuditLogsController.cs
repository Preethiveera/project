using CoilTracking.Business.Interfaces;
using CoilTracking.Data.Models;
using CoilTracking.DTO;
using CoilTracking.WebAPI.Filters;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using CoilTracking.WebAPI.AuthorizationHelper;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace CoilTracking.WebAPI.Controllers
{
  [Route("api/AuditLogs")]
  [ApiController]
  [ServiceFilter(typeof(CustomActionFilter))]
  [ResourceAuthorize(AuthResources.HomeActions.View, AuthResources.AdminPage)]
  public class AuditLogsController : ControllerBase
  {
    private readonly IAuditLogsService auditLogsService;
    public const string classString = "{\"ClassName\":\"";

    public AuditLogsController(IAuditLogsService auditLogsService)
    {
      this.auditLogsService = auditLogsService;
    }

    /// <summary>
    /// validation of AuditLog Exists
    /// </summary>
    /// <param name="Id"></param>
    /// <returns></returns>
    public AuditLog IsAuditLogExists(int Id)
    {
      return auditLogsService.IsAuditLogExists(Id);
    }

    /// <summary>
    /// Get the records of events and changes
    /// </summary>
    /// <returns></returns>
    ///  // GET: api/AuditLogs
    [HttpGet]

    public IQueryable<AuditLogsDto> GetAuditLogs()
    {
      return auditLogsService.GetAuditLogs();
    }

    /// <summary>
    /// Search for a record of events and changes
    /// </summary>
    /// <param name="startTime"></param>
    /// <param name="endTime"></param>
    /// <param name="username"></param>
    /// <param name="actionType"></param>
    /// <param name="className"></param>
    /// <returns> audit Logs</returns>
    [HttpGet, Route("Search")]
    public List<AuditLog> Search(DateTime? startTime = null, DateTime? endTime = null, string username = null, int? actionType = null, string className = null)
    {
      if (!string.IsNullOrWhiteSpace(className))
      {
        className = classString + className + "\"";
      }
      else
      {
        className = null;
      }

      var logs= auditLogsService.Search(startTime, endTime, username, actionType, className);
      return logs;

    }

    /// <summary>
    /// Get User AuditLog Names
    /// </summary>
    /// <returns></returns>
    [HttpGet, Route("Auditusers")]
    public IActionResult GetUserAuditLog()
    {
      var username =  auditLogsService.GetUserAuditLogs();
      return Ok(username);
    }


  }
}
