using AutoMapper;
using CoilTracking.Data.Models;
using CoilTracking.DTO;
using System.Collections.Generic;
using System.Linq;

namespace CoilTracking.Business.Implementation
{
  public class MappingProfile : Profile
  {
    public MappingProfile()
    {
      CreateMap<Mill, MillDto>();
      CreateMap<UserEvent, UserEventDto>().ReverseMap();
      CreateMap<MillDto, Mill>();

      CreateMap<Coil, CoilDto>();

      CreateMap<CoilDto, Coil>();

      CreateMap<CoilType, CoilTypeDto>();
      CreateMap<BlockingDiagrams, BlockingDiagramDto>().ReverseMap();
      CreateMap<CoilFieldDto, CoilField>();

      CreateMap<CoilField, CoilFieldDto>();
      CreateMap<MaterialType, MaterialTypeDto>().ReverseMap();
      CreateMap<CoilField, CoilFieldDto>().
        ForMember(dest => dest.Zones, opt => opt.MapFrom(src => src.Zones.Select(c => c))).ForMember(dest => dest.ZoneId, opt => opt.MapFrom(src => src.Zones.Select(x => x.Id)));

      CreateMap<CoilStatus, CoilStatusDto>().ReverseMap();
      CreateMap<CoilRunHistory, CoilRunHistoryDto>().ReverseMap();
      CreateMap<CoilFieldDto, CoilField>().
       ForMember(dest => dest.Zones, opt => opt.MapFrom(src => src.Zones.Select(c => c)));

      CreateMap<CoilFieldZoneDto, CoilFieldZone>();

      CreateMap<List<CoilFieldZoneDto>, List<CoilFieldZone>>();

      CreateMap<CoilFieldZone, CoilFieldZoneDto>();

      CreateMap<CoilFieldZone, CoilFieldZoneDto>().ForMember(dest => dest.Locations, opt => opt.MapFrom(src => src.Locations.Select(c => c)));

      CreateMap<CoilFieldLocationDto, CoilFieldLocation>();

      CreateMap<CoilFieldLocation, CoilFieldLocationDto>();

      CreateMap<CoilFieldZone, CoilFieldZoneDto>()
      .ForMember(dest => dest.LocationId, opt => opt.MapFrom(src => src.Locations.Select(x => x.Id)));

      CreateMap<CoilFieldZoneDto, CoilFieldZone>();

      CreateMap<CoilTypeDto, CoilType>();
      CreateMap<CoilType, CoilTypeDto>();


      CreateMap<CoilType, CoilTypeDto>().
       ForMember(dest => dest.CoilTypeYNAs, opt => opt.MapFrom(src => src.CoilTypeYNAs.Select(x => x))).
       ForMember(dest => dest.CoilFieldZone, opt => opt.MapFrom(src => src.CoilFieldZone));

      CreateMap<CoilTypeYNA, CoilTypeYNADto>().ForMember(dest => dest.MaterialType, opt => opt.MapFrom(src => src.MaterialType));
      CreateMap<RunResult, RunResultDto>().ReverseMap();
      CreateMap<RunResult, RunResultDto>().
      ForMember(dest => dest.CoilType, opt => opt.MapFrom(src => src.Coil.CoilType.Name));

      CreateMap<List<Part>, List<PartDto>>().ReverseMap();
      CreateMap<RunResult, RunResultDto>().ForMember(dest => dest.FTZ, opt => opt.MapFrom(src => src.Coil.FTZ));

      CreateMap<RunResult, RunResultDto>().ForMember(dest => dest.Line, opt => opt.MapFrom(src => src.RunOrderList.Line.LineName));
      CreateMap<RunResult, RunResultDto>().ForMember(dest => dest.runOrderList, opt => opt.MapFrom(src => src.RunOrderList));


      CreateMap<RunOrderList, RunOrderListDto>().ReverseMap();


      CreateMap<RunResult, RunResultDto>().ForMember(dest => dest.YNANumber, opt => opt.MapFrom(src => src.Coil.YNA));

      CreateMap<BlankInfo, BlankInfoDto>();

      //Convert RunOrderList
      CreateMap<RunOrderListForGet, RunOrderList>();
      CreateMap<RunOrderList, RunOrderListForGet>();
      CreateMap<RunOrderList, RunOrderListForGet>().ForMember(dest => dest.LineId, opt => opt.MapFrom(src => src.Line.Id))
        .ForMember(dest => dest.LineName, opt => opt.MapFrom(src => src.Line.LineName))
        .ForMember(dest => dest.ShiftId, opt => opt.MapFrom(src => src.Shift.Id))
         .ForMember(dest => dest.ShiftName, opt => opt.MapFrom(src => src.Shift.Name));

      //IncompleteRunOrder
      CreateMap<IncompleteRunOrderItemDto, IncompleteRunOrderItem>();
      CreateMap<IncompleteRunOrderItem, IncompleteRunOrderItemDto>();

      CreateMap<Data.Models.CoilMoveRequest, CoilMoveRequestDto>();
      CreateMap<CoilMoveRequestDto, Data.Models.CoilMoveRequest>();

      CreateMap<CoilTypeYNA, CoilTypeYNADto>().ReverseMap();

      CreateMap<LineData, LineDataDto>().ReverseMap();

      CreateMap<Line, LineDto>().ReverseMap();

      CreateMap<Part, PartDto>().ReverseMap();

      CreateMap<Plant, PlantDto>().ReverseMap();

      CreateMap<PlantTimeZone, PlantTimeZoneDto>().ReverseMap();

      CreateMap<RunOrderListQuantity, RunOrderListQuantityDto>().ReverseMap();

      CreateMap<Shift, ShiftDto>().ReverseMap();

      CreateMap<UserEvent, UserDto>().ReverseMap();

      CreateMap<AuditLog, AuditLogsDto>().ReverseMap();
      CreateMap<RunOrderItemStatus, RunOrderItemStatusDto>().ReverseMap();
      CreateMap<PatternCalendar, PatternCalendarDto>().ReverseMap();
      CreateMap<OPCConfig, OPCConfigDTO>().ReverseMap();
      CreateMap<PatternDto, Pattern>().ReverseMap();

      CreateMap<PartModelDto, PartModel>().ReverseMap();
      CreateMap<ModelDto, Model>().ReverseMap();

      CreateMap<PatternItemDto, PatternItem>().ReverseMap();

      CreateMap<ProdPlan, ProdPlanDto>().ReverseMap();
    }
  }

}
