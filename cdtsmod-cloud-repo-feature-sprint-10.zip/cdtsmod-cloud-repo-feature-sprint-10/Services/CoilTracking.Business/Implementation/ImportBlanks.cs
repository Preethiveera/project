﻿namespace CoilTracking.Business.Implementation
{
  public class ImportBlanks : ImportBlankBase
  {

  }
}
