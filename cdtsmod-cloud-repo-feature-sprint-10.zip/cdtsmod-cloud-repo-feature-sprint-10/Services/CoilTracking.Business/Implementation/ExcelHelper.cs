using CoilTracking.DTO;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace CoilTracking.Business.Implementation
{
  public static class ExcelHelper
  {
    public static ExcelResponse ImportWorksheet(List<DataImportMessage> messages, MemoryStream ms, string worksheetName, string userName)
    {
      using (var package = DataImportHelper.GetPackageFromMemoryStream(ms, messages))
      {
        if (package != null && package.Workbook != null && package.Workbook.Worksheets.Count > 0)
        {
          //Data expected only in first worksheet or a worksheet named Data
          ExcelWorksheet worksheet = package.Workbook.Worksheets.Where(ws => string.Equals(ws.Name, worksheetName, StringComparison.InvariantCultureIgnoreCase)).DefaultIfEmpty(package.Workbook.Worksheets.First()).FirstOrDefault();
          return new ExcelResponse
          {
            Worksheet = worksheet,
            Messages = null
          };
        }
        else
        {
          messages.Add(new DataImportMessage(-1, "No valid worksheet found, make sure this is a valid XLSX (Excel 2007+) file", DataImportMessage.MsgType.Error));
          return new ExcelResponse
          {
            Worksheet = null,
            Messages = messages
          };
        }
      }
    }
  }

  public class ExcelResponse
  {
    public ExcelWorksheet Worksheet { get; set; }

    public List<DataImportMessage> Messages { get; set; }
  }
}
