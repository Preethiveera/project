using AutoMapper;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Text;
using System.Threading.Tasks;
using TimeZoneConverter;

namespace CoilTracking.Business.Implementation
{
  public class UserEventService : IUserEventService
  {
    private readonly IUserEventRepository repo;
    private readonly IPlantsRepository plantrepo;
    private readonly IApplicationLogger<UserEventService> logger;
    private readonly IMapper mapper;
    private readonly IHttpContextAccessor httpContextAccessor;
    public UserEventService(IUserEventRepository repo,IPlantsRepository plantrepo, IMapper mapper, IApplicationLogger<UserEventService> logger, IHttpContextAccessor httpContextAccessor)
    {
      this.repo = repo;
      this.mapper = mapper;
      this.logger = logger;
      this.plantrepo = plantrepo;
      this.httpContextAccessor = httpContextAccessor;
    }

    /// <summary>
    /// Get user event by Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<UserEventDto> GetUserEventById(int id)
    {
      var events = await repo.GetUserEventById(id);
      logger.LogInformation(Constant.classname + "UserEventService" + Constant.methodname + "GetUserEvents" + Constant.message + "Get user events");
      return mapper.Map<UserEventDto>(events);
    }

    /// <summary>
    /// Get list of user events
    /// </summary>
    /// <returns></returns>
    public async Task<List<UserEventDto>> GetUserEvents()
    {
      var events = await repo.GetUserEvents();
      logger.LogInformation(Constant.classname + "UserEventService" + Constant.methodname + "GetUserEvents" + Constant.message + "Get user events");
      return mapper.Map<List<UserEventDto>>(events);
    }

    /// <summary>
    /// To get list of user events by time and usename
    /// </summary>
    /// <param name="startTime"></param>
    /// <param name="endTime"></param>
    /// <param name="username"></param>
    /// <returns></returns>
    public async Task<List<UserEventDto>> GetUserEventsBetween(DateTime? startTime = null, DateTime? endTime = null, string username = null)
    {
      var events = await repo.GetUserEventsBetween(startTime, endTime, username);
      logger.LogInformation(Constant.classname + "UserEventService" + Constant.methodname + "GetUserEvents" + Constant.message + "Get user events");
      return mapper.Map<List<UserEventDto>>(events);
    }

    /// <summary>
    /// to update user event
    /// </summary>
    /// <param name="id"></param>
    /// <param name="userEvent"></param>
    /// <returns></returns>
    public  void UpdateUserEvent(int id, UserEventDto userEvent)
    {
      UserEvent userEvents = new UserEvent();
      var events=  mapper.Map<UserEvent>(userEvent);
      try
      {
         userEvents = repo.UpdateUserEvent(id, events);
      }
      catch (DbUpdateConcurrencyException)
      {
        if (userEvents==null)
        {
          throw new CoilTrackingException { HttpStatusCode = Constant.notfound };
        }
        else
        {
          throw;
        }
      }
    }
    /// <summary>
    /// to insert new user events
    /// </summary>
    /// <param name="userEvent"></param>
    /// <returns></returns>
    public async Task<UserEventDto> InsertUserEvent(UserEventDto userEvent)
    {
      
      var plantInfo = await plantrepo.GetPlantByPlantName(GetNAMCCode());
      var timeZone = TZConvert.GetTimeZoneInfo(plantInfo.TimeZone.Name).Id;
      DateTime now = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.UtcNow, timeZone);
      userEvent.EventDate = now;
      var events = mapper.Map<UserEvent>(userEvent);
      var eventAdded =await repo.InsertUserEvent(events);
      return mapper.Map<UserEventDto>(eventAdded);
    }

    public string GetNAMCCode()
    {
     ///var NAMCs = httpContextAccessor.HttpContext.Request.Headers[Constant.namc].ToString();
      var NAMCs = "TMMI";
      return NAMCs;
    }

    /// <summary>
    /// to delete user event by id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<UserEventDto> DeleteUserEvent(int id)
    {
      var userEvents = await repo.DeleteUserEvent(id);
      return mapper.Map<UserEventDto>(userEvents);
    }

  }
}
