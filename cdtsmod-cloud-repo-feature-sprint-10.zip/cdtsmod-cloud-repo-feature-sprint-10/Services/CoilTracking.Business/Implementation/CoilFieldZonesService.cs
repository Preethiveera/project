using AutoMapper;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class CoilFieldZonesService : ICoilFieldZonesService
  {
    private readonly ICoilFieldZoneRepository coilFieldZoneRepository;

    private readonly ICoilFieldLocationRepository coilFieldLocationRepository;

    private readonly ICoilFieldRepository coilFieldRepository;

    private readonly ICoilRepository coilRepository;

    private readonly ICoilTypeRepository coilTypeRepository;

    private readonly IApplicationLogger<CoilFieldZonesService> coilFieldZoneServiceLogger;

    private readonly IWebSocketClientService webSocketClientService;

    private readonly IMapper mapper;


    public CoilFieldZonesService(ICoilFieldZoneRepository coilFieldZoneRepository, ICoilFieldLocationRepository coilFieldLocationRepository,
      ICoilFieldRepository coilFieldRepository, ICoilRepository coilRepository, ICoilTypeRepository coilTypeRepository,
      IApplicationLogger<CoilFieldZonesService> coilFieldZoneServiceLogger, IMapper mapper, IWebSocketClientService webSocketClientService)
    {
      this.coilFieldZoneRepository = coilFieldZoneRepository;
      this.coilFieldZoneServiceLogger = coilFieldZoneServiceLogger;
      this.coilFieldLocationRepository = coilFieldLocationRepository;
      this.coilFieldRepository = coilFieldRepository;
      this.coilTypeRepository = coilTypeRepository;
      this.coilRepository = coilRepository;
      this.mapper = mapper;
      this.webSocketClientService = webSocketClientService;
    }


    /// <summary>
    /// Get list of coil filed zones.
    /// </summary>
    /// <returns>List of CoilFieldZoneDto</returns>
    public async Task<List<CoilFieldZoneDto>> GetCoilFieldZones()
    {
      var coilFieldZones = await coilFieldZoneRepository.GetCoilFieldZones();
      var coilFieldZonesList = mapper.Map<List<CoilFieldZone>, List<CoilFieldZoneDto>>(coilFieldZones);
      coilFieldZoneServiceLogger.LogInformation(Constant.classname + "CoilFieldZonesService" + Constant.methodname + "GetCoilFieldZones" + Constant.message + "To get the List of CoilFieldZones.Includes locations with the coil.");

      return coilFieldZonesList;
    }

    /// <summary>
    /// Get coil field zone by Id.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>CoilFieldZoneDto</returns>
    public async Task<CoilFieldZoneDto> GetCoilFieldZone(int id)
    {
      var coilFieldZone = await coilFieldZoneRepository.GetCoilFieldZoneById(id);
      var coilFieldZoneDto = mapper.Map<CoilFieldZone, CoilFieldZoneDto>(coilFieldZone);
      coilFieldZoneServiceLogger.LogInformation(Constant.classname + "CoilFieldZonesService" + Constant.methodname + "GetCoilFieldZonesId" + Constant.message + "To get the  CoilFieldZones.");

      return coilFieldZoneDto;
    }

    /// <summary>
    /// Get coil filed zone for edit by zone id.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>CoilFieldZoneDto</returns>
    public async Task<CoilFieldZoneDto> GetCoilFieldZoneForEdit(int id)
    {
      var coilFieldZone = await coilFieldZoneRepository.GetCoilFieldZoneById(id);

      if (coilFieldZone == null)
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.coilFiledZonesNotFound, HttpStatusCode = "NotFound" };
      }

      var coilFieldZoneDto = mapper.Map<CoilFieldZone, CoilFieldZoneDto>(coilFieldZone);
      coilFieldZoneServiceLogger.LogInformation(Constant.classname + "CoilFieldZonesService" + Constant.methodname + "GetCoilFieldZoneForEdit" + Constant.message + "To get the coil field Zone for edit");

      return coilFieldZoneDto;
    }

    /// <summary>
    /// Get associated items by coil field zone id.
    /// </summary>
    /// <param name="zoneId"></param>
    /// <returns>CoilTypeDto</returns>
    public async Task<List<CoilTypeDto>> GetAssociatedItemsCoilFieldsZone(int zoneId)
    {
      var coilTypeList = await coilTypeRepository.GetAssociatedItemsByCoilFieldZone(zoneId);
      var coilTypeListDto = mapper.Map<List<CoilType>, List<CoilTypeDto>>(coilTypeList);
      coilFieldZoneServiceLogger.LogInformation(Constant.classname + "CoilFieldZonesService" + Constant.methodname + "GetAssociatedItemsCoilFieldsZone" + Constant.message + "To get the list of Coil type by zone id.");

      return coilTypeListDto;
    }


    /// <summary>
    /// Get coils by zone id.
    /// </summary>
    /// <param name="zoneId"></param>
    /// <returns>CoilDto</returns>
    public async Task<List<CoilDto>> GetCoilsByZoneId(int zoneId)
    {
      var coilTypeList = await coilRepository.GetCoilsByZoneId(zoneId);
      var coilTypeListDto = mapper.Map<List<Coil>, List<CoilDto>>(coilTypeList);
      coilFieldZoneServiceLogger.LogInformation(Constant.classname + "CoilFieldZonesService" + Constant.methodname + "GetCoilsByZoneId" + Constant.message + "To get the List of Coils by Zone Id.");

      return coilTypeListDto;
    }

    /// <summary>
    /// Check dependency by zone id.
    /// </summary>
    /// <param name="zoneId"></param>
    /// <returns>List of string</returns>
    public async Task<List<string>> CheckDependencyByZoneId(int zoneId)
    {
      List<string> fieldZoneAssociation = new List<string>();

      var coils = await coilRepository.GetCoilsByZoneId(zoneId);
      var exist = coils.Count > 0;

      if (exist)
      {
        fieldZoneAssociation.Add(Constant.Editing);
      }
      coilFieldZoneServiceLogger.LogInformation(Constant.classname + "CoilFieldZonesService" + Constant.methodname + "CheckDependencyByZoneId" + Constant.message + "To check the dependency by zone id");
      return fieldZoneAssociation;
    }


    /// <summary>
    /// Disable the coil filed zone.
    /// </summary>
    /// <param name="zoneId"></param>
    /// <param name="disable"></param>
    /// <returns>bool</returns>
    public async Task<bool> DisableCoilFieldZone(int zoneId, bool disable)
    {
      var zone = await coilRepository.GetCoilsByZoneId(zoneId);

      if (disable && zone.Count > 0)
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.disableCoilFieldZoneMsg, HttpStatusCode = "BadRequest" };
      }

      if (!await CoilFieldZoneExists(zoneId))
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.coilFiledZoneNotFound, HttpStatusCode = "NotFound" };
      }

      var disabled = await coilFieldZoneRepository.DisableCoilFieldZone(zoneId, disable);

      coilFieldZoneServiceLogger.LogInformation(Constant.classname + "CoilFieldZonesService" + Constant.methodname + "DisableCoilFieldZone" + Constant.message + "Disable the coil field zone");
      await webSocketClientService.CoilLocationsUpdated();
      return disabled;
    }

    /// <summary>
    /// Check if Coil field zone can be edited or not.
    /// </summary>
    /// <param name="coilFeildZoneDto"></param>
    /// <returns>string</returns>
    public async Task<string> CheckIfEdited(CoilFieldZoneDto coilFeildZoneDto)
    {
      string edited = null;

      var coilFieldZone = await coilFieldZoneRepository.GetCoilFieldZoneById(coilFeildZoneDto.Id);
      if (coilFeildZoneDto.Name != coilFieldZone.Name
         || coilFeildZoneDto.TextColor != coilFieldZone.TextColor
         || coilFeildZoneDto.Color != coilFieldZone.Color
         || coilFeildZoneDto.CoilFieldId != coilFieldZone.CoilField.Id
         || coilFeildZoneDto.Disabled != coilFieldZone.Disabled
         )
      {
        edited = Constant.edited;
      }

      coilFieldZoneServiceLogger.LogInformation(Constant.classname + "CoilFieldZonesService" + Constant.methodname + "CheckIfEdited" + Constant.message + "Check if entity is edited ");

      return edited;
    }


    /// <summary>
    /// Update the coil field zone.
    /// </summary>
    /// <param name="coilFiledZoneDto"></param>
    /// <returns>Task</returns>
    public async Task UpdateCoilFieldZone(CoilFieldZoneDto coilFeildZoneDto)
    {
      var coils = await coilRepository.GetCoilsByZoneId(coilFeildZoneDto.Id);

      if (!await CoilFieldZoneExists(coilFeildZoneDto.Id))
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.coilFiledZoneNotFound, HttpStatusCode = "NotFound" };
      }

      if (coilFeildZoneDto.Disabled && coils.Count > 0)
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.disableCoilFieldZoneLocatedMsg, HttpStatusCode = "BadRequest" };
      }

      var coilFieldZone = await coilFieldZoneRepository.GetCoilFieldZoneById(coilFeildZoneDto.Id);
      List<CoilFieldLocation> locations = coilFieldLocationRepository.GetCoilFieldLocationByZoneId(coilFeildZoneDto.Id);

      coilFieldZone.Name = coilFeildZoneDto.Name;

      if (coilFeildZoneDto.CoilFieldId != null)
      {
        coilFieldZone.CoilField = coilFieldRepository.GetCoilFieldById(coilFeildZoneDto.CoilFieldId.Value);
      }
      
      coilFieldZone.Color = coilFeildZoneDto.Color;
      coilFieldZone.TextColor = coilFeildZoneDto.TextColor;
      coilFieldZone.Disabled = coilFeildZoneDto.Disabled;

      await coilFieldZoneRepository.UpdateCoilFieldZone(coilFieldZone);

      foreach (CoilFieldLocation location in locations)
      {
        if (!coilFeildZoneDto.LocationId.Exists(x => x.Equals(location.Id)))
        {
          coilFieldLocationRepository.DeleteCoilFieldLocationEntry(location);
        }
      }

      await coilFieldZoneRepository.SaveChangesAsync(AuditActionType.ModifyEntity);
      await webSocketClientService.CoilLocationsUpdated();
    }

    /// <summary>
    /// Check if coil field zone exist or not.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>bool</returns>
    public async Task<bool> CoilFieldZoneExists(int id)
    {
      var coilFieldZone = await coilFieldZoneRepository.GetCoilFieldZoneById(id);
      coilFieldZoneServiceLogger.LogInformation(Constant.classname + "CoilFieldZonesService" + Constant.methodname + "CoilFieldZoneExists" + Constant.message + "Check if a coil field zone exists");

      if (coilFieldZone != null)
        return true;
      return false;
    }

    /// <summary>
    /// Add the coil field zone.
    /// </summary>
    /// <param name="coilFeildZoneDto"></param>
    /// <returns>CoilFieldZoneDto</returns>
    public async Task<CoilFieldZoneDto> SaveCoilFieldZone(CoilFieldZoneDto coilFeildZoneDto)
    {
      var coilFieldZone = new CoilFieldZone();
      coilFieldZone.Name = coilFeildZoneDto.Name;
      if (coilFeildZoneDto.CoilFieldId != null)
      {
        coilFieldZone.CoilField = coilFieldRepository.GetCoilFieldById(coilFeildZoneDto.CoilFieldId.Value);
      }
      coilFieldZone.Color = coilFeildZoneDto.Color;
      coilFieldZone.TextColor = coilFeildZoneDto.TextColor;
      coilFieldZone.Locations = coilFieldLocationRepository.GetAllCoilFieldLocations().Where(l => coilFeildZoneDto.LocationId.Contains(l.Id)).ToList();

      var result = await coilFieldZoneRepository.AddCoilFieldZone(coilFieldZone);

      var coilFieldZoneDto = mapper.Map<CoilFieldZoneDto>(result);
      await webSocketClientService.CoilLocationsUpdated();
      return coilFieldZoneDto;
    }

    /// <summary>
    /// Delete the coil filed zone.
    /// </summary>
    /// <param name="zoneId"></param>
    /// <returns>CoilFieldZoneDto</returns>
    public async Task<CoilFieldZoneDto> DeleteCoilFieldZone(int zoneId)
    {
      var coilFieldZone = await coilFieldZoneRepository.GetCoilFieldZoneById(zoneId);

      if (coilFieldZone == null)
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.coilFiledZoneNotFound, HttpStatusCode = "NotFound" };
      }

      await coilFieldZoneRepository.DeleteCoilFieldZone(zoneId);

      var coilTypeListDto = mapper.Map<CoilFieldZoneDto>(coilFieldZone);
      await webSocketClientService.CoilLocationsUpdated();
      return coilTypeListDto;
    }

  }
}

