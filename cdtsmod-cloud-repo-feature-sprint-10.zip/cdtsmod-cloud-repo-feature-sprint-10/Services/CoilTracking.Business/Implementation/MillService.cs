using AutoMapper;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using System.Collections.Generic;
using System.Linq;


namespace CoilTracking.Business.Implementation
{
  public class MillService : IMillService
  {

    private readonly IMillsRepository millsRepo;
    private readonly ICoilRepository coilRepo;
    private readonly IApplicationLogger<MillService> millServiceLogger;
    private readonly IMapper mapper;

    public MillService(IMillsRepository millsRepo, ICoilRepository coilRepo, IApplicationLogger<MillService> millServiceLogger, IMapper mapper)
    {
      this.coilRepo = coilRepo;
      this.millsRepo = millsRepo;
      this.millServiceLogger = millServiceLogger;
      this.mapper = mapper;
    }

    /// <summary>
    /// Get Mills from DB
    /// </summary>
    /// <returns>mills</returns>
    public IQueryable<MillDto> GetMills()
    {
      var millsList = millsRepo.GetMills();
      var millDtoList = mapper.Map<List<Mill>, List<MillDto>>(millsList);

      millServiceLogger.LogInformation(Constant.classname + "MillService" + Constant.methodname + "GetMills" + Constant.message + "Get List of all Mills");
      return millDtoList.AsQueryable();
    }



    /// <summary>
    /// Get mills By Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>Mill</returns>
    public MillDto GetMillById(int id)
    {
      var mills = millsRepo.GetMillById(id);
      var millsDto = mapper.Map<MillDto>(mills);
      millServiceLogger.LogInformation(Constant.classname + "MillService" + Constant.methodname + "GetMillById" + Constant.message + "Get Mill By Id" + Constant.parameters + "Id" + id);

      return millsDto;
    }



    /// <summary>
    /// Get Associated coils for a   Mill
    /// </summary>
    /// <param name="id"></param>
    /// <returns>coils</returns>
    public List<CoilDto> GetAssociatedItemsMills(int id)
    {
      var coils = coilRepo.GetCoilsByMillId(id);
      var coilDtoList = mapper.Map<List<Coil>, List<CoilDto>>(coils);

      millServiceLogger.LogInformation(Constant.classname + "MillService" + Constant.methodname + "GetAssociatedItemsMills" + Constant.message + "Get List of coils associated with a Mills");

      return coilDtoList;
    }



    /// <summary>
    /// Get list of coils loaded at line
    /// </summary>
    /// <param name="id"></param>
    /// <returns>list of coils</returns>
    public List<CoilDto> GetLoadedCoilsById(int id)
    {
      var coils = coilRepo.GetLoadedCoilsById(id);
      var coilDtoList = mapper.Map<List<Coil>, List<CoilDto>>(coils);
      millServiceLogger.LogInformation(Constant.classname + "MillService" + Constant.methodname + "GetLoadedCoilsById" + Constant.message + "To get list of loaded at line coils");

      return coilDtoList;
    }

    /// <summary>
    /// Check if entity is edited while deletion
    /// </summary>
    /// <param name="id"></param>
    /// <param name="mill"></param>
    /// <returns>string</returns>
    public string CheckIfEdited(int id, MillDto mill)
    {
      string edited = null;
      var mills = mapper.Map<Mill>(mill);
      var checkIfEdited = millsRepo.CheckIfEdited(id, mills);
      if (checkIfEdited)
        edited = Constant.edited;
      millServiceLogger.LogInformation(Constant.classname + "MillService" + Constant.methodname + "CheckIfEdited" + Constant.message + "To check if an entity is edited");

      return edited;
    }


    /// <summary>
    /// Get the Association Type for Mills
    /// </summary>
    /// <param name="id"></param>
    /// <returns>List of string</returns>
    public List<string> CheckDependencyType(int id)
    {
      List<string> millAssociationType = new List<string>();

      var millIdInCoilMoveRequest = coilRepo.IsmillIdPresentInCoilMoveRequest(id);
      var coils = coilRepo.GetLoadedCoilsById(id);
      if (millIdInCoilMoveRequest)
      {
        millAssociationType.Add(Constant.moveRequest);
      }
      if (coils.Any())
      {
        millAssociationType.Add(Constant.coilLoaded);
      }
      millServiceLogger.LogInformation(Constant.classname + "MillService" + Constant.methodname + "CheckDependencyType" + Constant.message + "To get the type of association with a mill");

      return millAssociationType;
    }

    /// <summary>
    /// Disable a mill by id
    /// </summary>
    /// <param name="id"></param>
    /// <param name="disable"></param>
    /// <returns>void</returns>
    public bool DisableMill(int id, bool disable)
    {
      if (!MillExists(id))
      {
        return false;
      }
      millsRepo.DisableMill(id, disable);
      millServiceLogger.LogInformation(Constant.classname + "MillService" + Constant.methodname + "DisableMill" + Constant.message + "To disable a mill");

      return true;
    }

    /// <summary>
    /// Check if Mill Exists
    /// </summary>
    /// <param name="id"></param>
    /// <returns>bool</returns>
    public bool MillExists(int id)
    {
      var mill = millsRepo.GetMillById(id);
      millServiceLogger.LogInformation(Constant.classname + "MillService" + Constant.methodname + "MillExists" + Constant.message + "To check if  mill exists");

      if (mill != null)
        return true;
      return false;

    }

    /// <summary>
    /// Add new Mill
    /// </summary>
    /// <param name="mill"></param>
    /// <returns>mill</returns>
    public bool InsertMill(MillDto milldto)
    {
      var mill = mapper.Map<Mill>(milldto);
      millsRepo.InsertMill(mill);
      milldto.Id = mill.Id;
      millServiceLogger.LogInformation(Constant.classname + "MillService" + Constant.methodname + "InsertMill" + Constant.message + "To add a new mill");

      return true;
    }

    /// <summary>
    /// Delete a Mill
    /// </summary>
    /// <param name="id"></param>
    /// <returns>mill</returns>
    public MillDto DeleteMill(int id)
    {
      MillDto millDto = null;
      var mill = millsRepo.DeleteMill(id);
      if (mill != null)
      {
        millDto = mapper.Map<MillDto>(mill);
      }
      millServiceLogger.LogInformation(Constant.classname + "MillService" + Constant.methodname + "DeleteMill" + Constant.message + "To delete a mill");

      return millDto;
    }

    /// <summary>
    /// Update a Mill
    /// </summary>
    /// <param name="id"></param>
    /// <param name="milldto"></param>
    /// <returns>bool</returns>
    public bool UpdateMill(int id, MillDto mill)
    {
      var millFromDto = mapper.Map<Mill>(mill);
      if (!MillExists(id))
      {
        return false;
      }
      Mill millExist = millsRepo.GetMillById(mill.Id);
      millFromDto.Plant_Id = millExist == null ? 0 : millExist.Plant_Id;
     ///if (millExist != null && millExist.Name != mill.Name)
      ///{
     ///  throw new CoilTrackingException { ErrorMessage = ApplicationMessages.duplicateErrForMillsupdate+ "The duplicate key value is ("+mill.Name+") .\r\nThe statement has been terminated." };
      ///}
      
      millsRepo.UpdateMill(millFromDto);
      millServiceLogger.LogInformation(Constant.classname + "MillService" + Constant.methodname + "UpdateMill" + Constant.message + "To update a mill");

      return true;
    }

    
  }
}
