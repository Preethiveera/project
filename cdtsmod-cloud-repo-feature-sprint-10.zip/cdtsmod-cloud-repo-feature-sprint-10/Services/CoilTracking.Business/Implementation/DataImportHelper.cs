using CoilTracking.DTO;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;

namespace CoilTracking.Business.Implementation
{
  public static class DataImportHelper
  {
    /// <summary>
    /// Try to get an excel package from a memorystream, return the excel package if able or null if not and adding a DataImportMessage to the errors list
    /// </summary>
    /// <param name="ms">MemoryStream containing an excel file</param>
    /// <param name="errors">List of DataImportMessage containing errors</param>
    /// <returns></returns>
    public static ExcelPackage GetPackageFromMemoryStream(MemoryStream ms, List<DataImportMessage> errors)
    {
      ExcelPackage package = null;

      try
      {
        package = new ExcelPackage(ms);
      }
      catch (Exception ex)
      {
        errors.Add(new DataImportMessage(-1, "Fatal Exception opening excel file. Make sure it is a valid xlsx file", DataImportMessage.MsgType.Error));
        errors.Add(new DataImportMessage(-1, ex.ToString(), DataImportMessage.MsgType.ErrorDetails));
      }

      return package;
    }

    /// <summary>
    /// Try to get a decimal from the worksheet/cell specified, returning a list of any errors/details.
    /// </summary>
    /// <param name="worksheet">The worksheet to try to get the value from</param>
    /// <param name="row">Row number containing the value</param>
    /// <param name="col">Column number containing the value</param>
    /// <param name="colName">The name of the column (used for better error messages)</param>
    /// <param name="value">Output value</param>
    /// <returns>A list of DataImportMessages with any errors/details, or an empty list if none</returns>
    public static List<DataImportMessage> GetDecimal(ExcelWorksheet worksheet, int row, int col, string colName, out decimal value, bool allowNulls = false)
    {
      List<DataImportMessage> messages = new List<DataImportMessage>();
      decimal parsedValue = 0;

      try
      {
        string text = worksheet.Cells[row, col].Text;
        if (text != null)
        {
          text = text.Trim();
        }
        bool isPercent = false;

        if (!string.IsNullOrWhiteSpace(text) && text.EndsWith("%"))
        {
          text = text.TrimEnd('%');
          isPercent = true;
        }
        if ((!string.IsNullOrWhiteSpace(text) || (string.IsNullOrWhiteSpace(text) && !allowNulls)) && (!decimal.TryParse(text, out parsedValue)))
        {
            messages.Add(new DataImportMessage(row, "Invalid decimal format found for " + colName + " in column " + col + ": '" + text + "'", DataImportMessage.MsgType.Error));
        }
        if (isPercent)
        {
          parsedValue /= 100;
        }
      }
      catch (Exception ex)
      {
        messages.Add(new DataImportMessage(row, "Error getting decimal for " + colName + "in column " + col + " \r\n<br>" + ex.ToString(), DataImportMessage.MsgType.ErrorDetails));
      }

      value = parsedValue;
      return messages;
    }

    /// <summary>
    /// Try to get a float from the worksheet/cell specified, returning a list of any errors/details.
    /// </summary>
    /// <param name="worksheet">The worksheet to try to get the value from</param>
    /// <param name="row">Row number containing the value</param>
    /// <param name="col">Column number containing the value</param>
    /// <param name="colName">The name of the column (used for better error messages)</param>
    /// <param name="value">Output value</param>
    /// <returns>A list of DataImportMessages with any errors/details, or an empty list if none</returns>
    public static List<DataImportMessage> GetFloat(ExcelWorksheet worksheet, int row, int col, string colName, out float value)
    {
      List<DataImportMessage> messages = new List<DataImportMessage>();
      decimal decimalParsedVal = 0;
      messages.AddRange(GetDecimal(worksheet, row, col, colName, out decimalParsedVal));

      value = (float)decimalParsedVal;
      return messages;
    }

    /// <summary>
    /// Try to get an integer from the worksheet/cell specified, returning a list of any errors/details.
    /// </summary>
    /// <param name="worksheet">The worksheet to try to get the value from</param>
    /// <param name="row">Row number containing the value</param>
    /// <param name="col">Column number containing the value</param>
    /// <param name="colName">The name of the column (used for better error messages)</param>
    /// <param name="value">Output value</param>
    /// <returns>A list of DataImportMessages with any errors/details, or an empty list if none</returns>
    public static List<DataImportMessage> GetInt(ExcelWorksheet worksheet, int row, int col, string colName, out int value)
    {
      List<DataImportMessage> messages = new List<DataImportMessage>();
      int parsedValue = 0;

      try
      {
        string text = worksheet.Cells[row, col].Text;
        if (text != null)
        {
          text = text.Trim();
        }

        if (!int.TryParse(text, out parsedValue))
        {
          messages.Add(new DataImportMessage(row, "Invalid integer format found for " + colName + " in column " + col + ": '" + text + "'", DataImportMessage.MsgType.Error));
        }
      }
      catch (Exception ex)
      {
        messages.Add(new DataImportMessage(row, "Error getting int for " + colName + "in column " + col + " \r\n<br>" + ex.ToString(), DataImportMessage.MsgType.ErrorDetails));
      }

      value = parsedValue;
      return messages;
    }

    /// <summary>
    /// Try to get a string from the worksheet/cell specified, returning a list of any errors/details.
    /// </summary>
    /// <param name="worksheet">The worksheet to try to get the value from</param>
    /// <param name="row">Row number containing the value</param>
    /// <param name="col">Column number containing the value</param>
    /// <param name="colName">The name of the column (used for better error messages)</param>
    /// <param name="value">Output value</param>
    /// <returns>A list of DataImportMessages with any errors/details, or an empty list if none</returns>
    public static List<DataImportMessage> GetString(ExcelWorksheet worksheet, int row, int col, string colName, out string value)
    {
      List<DataImportMessage> messages = new List<DataImportMessage>();

      string text = null;
      try
      {
        text = worksheet.Cells[row, col].Text;
        if (text != null)
        {
          text = text.Trim();
        }
      }
      catch (Exception ex)
      {
        messages.Add(new DataImportMessage(row, "Error getting text for " + colName + "in column " + col + " \r\n<br>" + ex.ToString(), DataImportMessage.MsgType.ErrorDetails));
      }

      value = text;
      return messages;
    }

    /// <summary>
    /// Try to get a boolean from the worksheet/cell specified, returning a list of any errors/details.
    /// </summary>
    /// <param name="worksheet">The worksheet to try to get the value from</param>
    /// <param name="row">Row number containing the value</param>
    /// <param name="col">Column number containing the value</param>
    /// <param name="colName">The name of the column (used for better error messages)</param>
    /// <param name="value">Output value</param>
    /// <returns>A list of DataImportMessages with any errors/details, or an empty list if none</returns>
    public static List<DataImportMessage> GetBool(ExcelWorksheet worksheet, int row, int col, string colName, out bool value, bool allowNulls = false)
    {
      List<DataImportMessage> messages = new List<DataImportMessage>();

      bool parsedValue = false;
      try
      {
        string text = worksheet.Cells[row, col].Text;
        if (text != null)
        {
          text = text.Trim();
        }
        if (string.Equals("Y", text, StringComparison.InvariantCultureIgnoreCase) || string.Equals("Yes", text, StringComparison.InvariantCultureIgnoreCase) || string.Equals("1", text, StringComparison.InvariantCultureIgnoreCase))
        {
          parsedValue = true;
        }
        else if (string.Equals("N", text, StringComparison.InvariantCultureIgnoreCase) || string.Equals("No", text, StringComparison.InvariantCultureIgnoreCase) || string.Equals("0", text, StringComparison.InvariantCultureIgnoreCase))
        {
          parsedValue = false;
        }
        else
        {
          bool tempValue = false;

          if ((!string.IsNullOrWhiteSpace(text) || (string.IsNullOrWhiteSpace(text) && !allowNulls)) && (!bool.TryParse(text, out tempValue)))
          {
              messages.Add(new DataImportMessage(row, "Invalid boolean format found for " + colName + " in column " + col + ": '" + text + "'", DataImportMessage.MsgType.Error));
          }
          parsedValue = tempValue;
        }
      }
      catch (Exception ex)
      {
        messages.Add(new DataImportMessage(row, "Error getting boolean for " + colName + "in column " + col + " \r\n<br>" + ex.ToString(), DataImportMessage.MsgType.ErrorDetails));
      }

      value = parsedValue;
      return messages;
    }
  }
}
