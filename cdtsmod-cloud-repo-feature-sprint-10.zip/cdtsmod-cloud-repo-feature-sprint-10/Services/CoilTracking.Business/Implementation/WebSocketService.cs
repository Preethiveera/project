using Amazon.ApiGatewayManagementApi;
using Amazon.ApiGatewayManagementApi.Model;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Helpers;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.DTO;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using StackExchange.Redis;
using System;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  [ExcludeFromCodeCoverage]
  public class WebsocketService : IWebsocketService

  {
    private readonly string webSocketEndpoint; 
    protected readonly IDatabase _database;
    protected readonly IConnectionMultiplexer _redis;
    private readonly IUserHelper usersHelper;

    private static readonly JsonSerializerSettings JsonSettings = new JsonSerializerSettings
    {
      ContractResolver = new CamelCasePropertyNamesContractResolver()
    };

    private AmazonApiGatewayManagementApiClient _webSocketApiClient;

    public WebsocketService(IConnectionMultiplexer redis, IUserHelper usersHelper, IConfiguration configuration)
    {
      _redis = redis;
      _database = redis.GetDatabase();
      this.usersHelper = usersHelper;
      webSocketEndpoint = configuration.GetSection("WebsocketURL").Value;
    }

    private AmazonApiGatewayManagementApiClient WebSocketApiClient
    {
      get
      {
        if (_webSocketApiClient != null)
        {
          return _webSocketApiClient;
        }


        var apiConfig = new AmazonApiGatewayManagementApiConfig { ServiceURL = webSocketEndpoint };

        return _webSocketApiClient = new AmazonApiGatewayManagementApiClient(apiConfig);
      }
    }


    /// <summary>
    /// 
    /// </summary>
    /// <param name="connection"></param>
    /// <returns></returns>
    public async Task Connect(ConnectionModelDto connection)
    {

      var queryParams = connection.QueryParameters.Split(',');

      var namcId = queryParams[1].Contains("namc") ? queryParams[1].Split('=')[1] : null;

      if (namcId != null)
      {
        Console.WriteLine("namcId: " + namcId.Remove(namcId.Length - 1));

        var namCode = usersHelper.GetNamcSecretcode(namcId.Remove(namcId.Length - 1));

        Console.WriteLine("namcCode: " + namCode);

        WebsocketConnectionInfoDto websocketConnectionInfoDto = new WebsocketConnectionInfoDto
        {
          ConnectionId = connection.Id,
          Groups = HubHelper.GetGroups(namCode)
        };
        await _database.HashSetAsync("connectionList", connection.Id, JsonConvert.SerializeObject(websocketConnectionInfoDto));
      }
    }

    public async Task Disconnect(ConnectionModelDto connection)
    {
      await _database.HashDeleteAsync("connectionList", connection.Id.ToString());
    }

    public async Task SendMessageToGroup(string[] groups, string action, object payload)
    {
      var connectionIdsDict = await _database.HashGetAllAsync("connectionList");
      var connectionIds = connectionIdsDict.Select(x => JsonConvert.DeserializeObject<WebsocketConnectionInfoDto>(x.Value)).ToList();

      foreach (var connectionId in connectionIds)
      {
        if (connectionId.Groups.SequenceEqual(groups))
        {
          await PostToConnection(connectionId.ConnectionId, action, payload);
        }
      }
    }

    private async Task PostToConnection(string connectionId, string action, object payload)
    {
      try
      {
        var json = JsonConvert.SerializeObject(new WebSocketMessageDto(action, payload), JsonSettings);

        await WebSocketApiClient.PostToConnectionAsync(new PostToConnectionRequest
        {
          ConnectionId = connectionId,
          Data = new MemoryStream(Encoding.UTF8.GetBytes(json))
        });
      }
      catch
      {
        await _database.HashDeleteAsync("connectionList", connectionId);
        Console.WriteLine("ConnectionId: " + connectionId + " Lost");
      }
    }
  }
}
