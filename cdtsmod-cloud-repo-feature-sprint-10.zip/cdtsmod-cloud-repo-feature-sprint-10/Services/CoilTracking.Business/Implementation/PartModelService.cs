using AutoMapper;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class PartModelService : IPartModelService
  {
    private readonly IPartModelsRepository partModelsRepository;
    private readonly IMapper mapper;
    private readonly IApplicationLogger<PartModelService> logger;

    public PartModelService(IPartModelsRepository partModelsRepository,
      IMapper mapper,
      IApplicationLogger<PartModelService> logger)
    {
      this.partModelsRepository = partModelsRepository;
      this.mapper = mapper;
      this.logger = logger;
    }

    /// <summary>
    /// Get list of PartModel.
    /// </summary>
    /// <returns></returns>
    public async Task<IQueryable<PartModelDto>> GetPartModels()
    {
      var partModels = await partModelsRepository.GetPartModelsAsync();
      logger.LogInformation(Constant.classname + "PartModelService" + Constant.methodname + "GetPartModels" + Constant.message + "Get list of all Part Models.");
      return mapper.Map<List<PartModelDto>>(partModels).AsQueryable();
    }

    /// <summary>
    /// Get PartModel By Id.
    /// </summary>
    /// <returns></returns>
    public async Task<PartModelDto> GetPartModelById(int id)
    {
      var partModel = await partModelsRepository.GetPartModelById(id);
      logger.LogInformation(Constant.classname + "PartModelService" + Constant.methodname + "GetPartModelById" + Constant.message + "Get Part Model by Id");
      return mapper.Map<PartModelDto>(partModel);
    }

    /// <summary>
    /// Update PartModel.
    /// </summary>
    /// <returns></returns>
    public async Task PutPartModel(int id, PartModelDto partModel)
    {
      var partmodel = await partModelsRepository.GetPartModelById(id);
        if(partmodel ==null)
        {
          throw new CoilTrackingException { HttpStatusCode = "NotFound" };
        }
      try
      {
        partModel.Plant_Id =  partmodel.Plant_Id;
        await partModelsRepository.UpdatePartModelAsync(mapper.Map<PartModel>(partModel));
      }
      catch (DbUpdateConcurrencyException)
      {
        if (partModelsRepository.GetPartModelById(id) == null)
        {
          throw new CoilTrackingException { HttpStatusCode = "NotFound" };
        }
        else
        {
          throw;
        }
      }

      logger.LogInformation(Constant.classname + "PartModelService" + Constant.methodname + "PutPartModel" + Constant.message + "Update Part Model");
    }

    /// <summary>
    /// Add PartModel.
    /// </summary>
    /// <returns></returns>
    public async Task<PartModelDto> AddPartModel(PartModelDto partModel)
    {
      var response = await partModelsRepository.AddPartModelAsync(mapper.Map<PartModel>(partModel));
      logger.LogInformation(Constant.classname + "PartModelService" + Constant.methodname + "AddPartModel" + Constant.message + "Add Part Model");
      return mapper.Map<PartModelDto>(response);
    }

    /// <summary>
    /// Delete PartModel.
    /// </summary>
    /// <returns></returns>
    public async Task<PartModelDto> DeletePartModel(int id)
    {
      var partModel = await partModelsRepository.GetPartModelById(id);
      if (partModel == null)
      {
        throw new CoilTrackingException { HttpStatusCode = "NotFound" };
      }

      await partModelsRepository.DeletePartModelAsync(partModel);
      logger.LogInformation(Constant.classname + "PartModelService" + Constant.methodname + "DeletePartModel" + Constant.message + "Delete Part Model");
      return mapper.Map<PartModelDto>(partModel);
    }
  }
}
