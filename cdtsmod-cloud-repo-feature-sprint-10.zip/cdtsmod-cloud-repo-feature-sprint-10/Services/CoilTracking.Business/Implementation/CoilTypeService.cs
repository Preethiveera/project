using AutoMapper;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  /// <summary>
  /// CoilTypeService
  /// </summary>
  public class CoilTypeService : ICoilTypeService
  {
    private readonly IMaterialTypesRepository materialTypesRepo;
    private readonly ICoilRepository coilRepo;
    private readonly IApplicationLogger<CoilTypeService> coilTypeServiceLogger;
    private readonly ICoilTypeRepository coilTypeRepo;
    private readonly ICoilMoveRequestsRepository coilMoveRequestsRepo;
    private readonly ICoilFieldZoneRepository coilFieldZoneRepo;
    private readonly ICoilTypeYNARepository coilTypeYNARepo;
    private readonly IMapper mapper;
    private readonly IWebSocketClientService webSocketClientService;

    /// <summary>
    /// Coil Type Service Layer
    /// </summary>
    /// <param name="coilTypeRepo"></param>
    /// <param name="materialTypesRepo"></param>
    /// <param name="coilRepo"></param>
    /// <param name="mapper"></param>
    /// <param name="coilTypeServiceLogger"></param>
    /// <param name="coilMoveRequestsRepo"></param>
    /// <param name="coilFieldZoneRepo"></param>
    /// <param name="coilTypeYNARepo"></param>
    public CoilTypeService(ICoilTypeRepository coilTypeRepo, IMaterialTypesRepository materialTypesRepo,
      ICoilRepository coilRepo, IMapper mapper, IApplicationLogger<CoilTypeService> coilTypeServiceLogger,
      ICoilMoveRequestsRepository coilMoveRequestsRepo, ICoilFieldZoneRepository coilFieldZoneRepo,
      ICoilTypeYNARepository coilTypeYNARepo, IWebSocketClientService webSocketClientService)
    {
      this.coilTypeRepo = coilTypeRepo;
      this.materialTypesRepo = materialTypesRepo;
      this.coilRepo = coilRepo;
      this.mapper = mapper;
      this.coilTypeServiceLogger = coilTypeServiceLogger;
      this.coilMoveRequestsRepo = coilMoveRequestsRepo;
      this.coilFieldZoneRepo = coilFieldZoneRepo;
      this.coilTypeYNARepo = coilTypeYNARepo;
      this.webSocketClientService = webSocketClientService;
    }
    /// <summary>
    /// Get CoilTypes For CoilType
    /// </summary>
    /// <returns>CoilTypeDto</returns>
    public async Task<List<CoilTypeDto>> GetCoilTypes()
    {
      //Get CoilTypes Material Type info
      var materialCoilTypes = await coilTypeRepo.GetMaterialCoilTypes();
      var coilType = materialCoilTypes.OrderBy(ct => ct.Name).ToList();
      //Logging
      coilTypeServiceLogger.LogInformation(Constant.classname + "CoilTypeService" + Constant.methodname + "GetCoilTypes" + Constant.countoflines + coilType.Count);
      //Mapping
      var coilTypes = mapper.Map<List<CoilType>, List<CoilTypeDto>>(coilType);
      return coilTypes;
    }
    /// <summary>
    /// Get CoilTypeDtos for coilTypes
    /// </summary>
    /// <returns></returns>
    public async Task<List<CoilTypeDto>> GetCoilsTypes()
    {
      //Get CoilTypes Material Type info
      var materialCoilTypes = await coilTypeRepo.GetMaterialCoilTypes();
      var coilTypes = materialCoilTypes.OrderBy(ct => ct.Name).ToList();
      //Logging
      coilTypeServiceLogger.LogInformation(Constant.classname + "CoilTypeService" + Constant.methodname + "GetCoilTypeDtos" + Constant.countoflines + coilTypes.Count);
      List<CoilTypeDto> coilTypeDtos = new List<CoilTypeDto>();
      foreach (var item in coilTypes)
      {
        var coilTypeDto = new CoilTypeDto()
        {
          Id = item.Id,
          Name = item.Name,
          Width = item.Width,
          Thickness = item.Thickness,
          Spec = item.Spec,
          CoilFieldZoneName = (item.CoilFieldZone == null ? "Invalid Zone" : item.CoilFieldZone.Name),
          NumCoils = item.NumCoils,
          Yield = item.Yield,
          Disabled = item.Disabled,
          MinThickness = item.MinThickness,
          MaxThickness = item.MaxThickness,
          MinWidth = item.MinWidth,
          MaxWidth = item.MaxWidth,
          NAMC = (item.CoilFieldZone == null ? "" : item.CoilFieldZone.CoilField.Name),

        };
        coilTypeDto.CoilTypeYNAsCSVString = string.Join(", ", item.CoilTypeYNAs.Select(cty => cty.YNA).OrderBy(yna => yna));
        coilTypeDto.MaterialTypeName = item.CoilTypeYNAs.Select(y => y.MaterialType.Description).FirstOrDefault();
        coilTypeDtos.Add(coilTypeDto);
      }
      return coilTypeDtos;
    }

    /// <summary>
    /// Get CoilTypes Based on Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<CoilTypeDto> GetCoilTypesById(int id)
    {
      //Get CoilTypes Material Type info
      //changes
      var materialCoilTypesId = await coilTypeRepo.GetMaterialCoilTypeById(id);
      //Logging
      coilTypeServiceLogger.LogInformation(Constant.classname + "CoilTypeService" + Constant.methodname + "GetCoilTypesById" + Constant.message + "Material CoilTypes");
      //Mapping
      var coilTypes = mapper.Map<CoilTypeDto>(materialCoilTypesId);
      return coilTypes;
    }

    /// <summary>
    /// Get the MaterialTypes
    /// </summary>
    /// <returns></returns>
    public async Task<List<MaterialTypeDto>> GetMaterialTypes()
    {
      //Get Coils material types
      var materialType = await materialTypesRepo.GetCoilsMaterialTypes();
      //Logging
      coilTypeServiceLogger.LogInformation(Constant.classname + "CoilTypeService" + Constant.methodname + "GetMaterialTypes" + Constant.countoflines + materialType.Count);
      //Mapping
      var materialTypes = mapper.Map<List<MaterialTypeDto>>(materialType);
      return materialTypes;
    }

    /// <summary> 
    /// Get AssociatedItems for CoilTypes Based on Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<List<CoilDto>> GetCoilsByCoilTypeId(int id)
    {
      //Get Associated CoilType 
      var coils = await coilRepo.GetCoilsByCoilTypeId(id);
      //Logging
      coilTypeServiceLogger.LogInformation(Constant.classname + "CoilTypeService" + Constant.methodname + "GetAssociatedItemsCoilTypes" + Constant.parameters + id);
      //Mapping
      var coilDtos = mapper.Map<List<Coil>, List<CoilDto>>(coils);
      return coilDtos;
    }

    /// <summary>
    /// Insertion to coiltype Based on Id and CoilTypeDto
    /// </summary>
    /// <param name="id"></param>
    /// <param name="dto"></param>
    public Task<string> CheckEdit(int id, CoilTypeDto dto)
    {
      List<string> coilTypeAssociation = new List<string>();
      //Get CoilTypes Check
      var CoilTypeId = coilTypeRepo.GetCoilTypeById(id);
      var Id = CoilTypeId.Id;
      //Logging
      coilTypeServiceLogger.LogInformation(Constant.classname + "CoilTypeService" + Constant.methodname + "InsertCheckEdit" + Constant.parameters + id);
      if (dto.Id != Id)
      {
        coilTypeAssociation.Add(Constant.edited);
      }
      if (coilTypeAssociation.Count > 0)
      {
        throw new CoilTrackingException {  HttpStatusCode = "BadRequest" };
      }
      return Task.FromResult(ApplicationMessages.completed);
    }
    /// <summary>
    /// Get CoilsLoaded For CoilType
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<List<CoilDto>> GetCoilsLoadedForCoilType(int id)
    {
      //Get Coils Loaded For CoilType
      var coils = await coilRepo.GetCoilsLoadedById(id);
      //Logging
      coilTypeServiceLogger.LogInformation(Constant.classname + "CoilTypeService" + Constant.methodname + "GetCoilsLoadedForCoilType" + Constant.parameters + id + Constant.countoflines + coils.Count);
      //Mapping
      var coilDtos = mapper.Map<List<Coil>, List<CoilDto>>(coils);
      return coilDtos;
    }
    /// <summary>
    /// Check Dependency Based on Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<List<string>> CheckDependency(int id)
    {
      List<string> coilTypesAssociation = new List<string>();
      //Get CoilMoveRequest 
      var CoilMoveRequest = coilMoveRequestsRepo.GetCoilMoveRequestById(id);
      //Logging
      coilTypeServiceLogger.LogInformation(Constant.classname + "CoilTypeService" + Constant.methodname + "CheckDependency" + Constant.parameters + id);
      //Get Coils Loaded ForCoilType 
      var coils = await coilRepo.GetCoilsLoadedById(id);
      if (CoilMoveRequest.Any())
      {
        coilTypesAssociation.Add("moveRequest");
      }
      if (coils.Any())
      {
        coilTypesAssociation.Add("loaded");
      }
      return coilTypesAssociation;
    }

    /// <summary>
    /// Delete CoilType Based on Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public Task<CoilTypeDto> DeleteCoilTypeById(int id)
    {
      //Get CoilType
     
        var coilType = coilTypeRepo.GetCoilTypeById(id);
        //Logging
        coilTypeServiceLogger.LogInformation(Constant.classname + "CoilTypeService" + Constant.methodname + "DeleteCoilTypeById" + Constant.parameters + id);
      try
      {
        coilTypeRepo.DeleteCoilType(coilType);
      }
      catch (Exception)
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.deleteInternalserverError};
      }
        var coilTypes = mapper.Map<CoilTypeDto>(coilType);
        webSocketClientService.CoilLocationsUpdated();
        return Task.FromResult(coilTypes);
     

    }
    /// <summary>
    /// Get  Disable CoilType
    /// </summary>
    /// <param name="id"></param>
    /// <param name="disable"></param>
    /// <returns></returns>
    public Task<CoilTypeDto> DisableCoilType(int id, bool disable)
    {
      //Get CoilType
      var coilType = coilTypeRepo.GetCoilTypeById(id);
      //logging
      coilTypeServiceLogger.LogInformation(Constant.classname + "CoilTypeService" + Constant.methodname + "DisableCoilType" + Constant.parameters + id);
      coilType.Disabled = disable;
      coilTypeRepo.ModifyCoilType(coilType);
      var coilTypes = mapper.Map<CoilTypeDto>(coilType);
      webSocketClientService.CoilLocationsUpdated();
      return Task.FromResult(coilTypes);

    }

    /// <summary>
    /// Update Coiltype Based on Id and CoilTypeDto
    /// </summary>
    /// <param name="id"></param>
    /// <param name="coilType"></param>
    public async Task<string> UpdateCoilType(int id, CoilTypeDto coilType)
    {
      CoilType originalCoilType = coilTypeRepo.GetoriginalCoilTypeById(coilType);
      coilTypeServiceLogger.LogInformation(Constant.classname + "CoilTypeService" + Constant.methodname + "UpdateCoilType" + Constant.parameters + id);
      if (originalCoilType == null)
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.originalCoilType, HttpStatusCode = "NotFound" };
      }
      originalCoilType.Name = coilType.Name;
      originalCoilType.NumCoils = coilType.NumCoils;
      originalCoilType.Spec = coilType.Spec;
      originalCoilType.Thickness = coilType.Thickness;
      originalCoilType.Width = coilType.Width;
      originalCoilType.CoilFieldZone = await coilFieldZoneRepo.GetCoilFieldZoneById(coilType.CoilFieldZoneId);
      originalCoilType.MinThickness = coilType.MinThickness;
      originalCoilType.MaxThickness = coilType.MaxThickness;
      originalCoilType.MinWidth = coilType.MinWidth;
      originalCoilType.MaxWidth = coilType.MaxWidth;
      originalCoilType.Disabled = coilType.Disabled;

      //INC16521521 - update yield %
      originalCoilType.Yield = coilType.Yield;

      MaterialType materialType = materialTypesRepo.GetMaterialTypesById(coilType.MaterialTypeId);
      //Update existing YNAs
      foreach (CoilTypeYNADto coilTypeYNA in coilType.CoilTypeYNAs.Where(cty => cty.Id > 0))
      {
        var ynaToUpdate = originalCoilType.CoilTypeYNAs.FirstOrDefault(cty => cty.Id == coilTypeYNA.Id);
        if (ynaToUpdate != null)
        {
          ynaToUpdate.YNA = coilTypeYNA.YNA;
          ynaToUpdate.Disabled = coilTypeYNA.Disabled;
          ynaToUpdate.MaterialType = materialType;
        }
      }

      //Add any new YNAs
      foreach (CoilTypeYNADto coilTypeYNA in coilType.CoilTypeYNAs.Where(cty => cty.Id <= 0))
      {
        if (!originalCoilType.CoilTypeYNAs.Exists(cty => cty.YNA == coilTypeYNA.YNA))
        {
          originalCoilType.CoilTypeYNAs.Add(new CoilTypeYNA() { YNA = coilTypeYNA.YNA, DateAdded = coilTypeYNA.DateAdded, Disabled = coilTypeYNA.Disabled, MaterialType = materialType });
        }
      }

      //Delete any removed YNAs
      var removedYNAs = originalCoilType.CoilTypeYNAs.Where(cty => !coilType.CoilTypeYNAs.Select(ctyDto => ctyDto.YNA).Contains(cty.YNA)).ToList(); //ToList so we're not modifying the same collection
      foreach (var removedYNA in removedYNAs)
      {
        originalCoilType.CoilTypeYNAs.Remove(removedYNA);
        coilTypeRepo.DeleteCoilTypeYNA(removedYNA);
      }

      //Check if all Y#'s are disabled, if so, then disable the CoilType 
      if (originalCoilType.CoilTypeYNAs.All(cty => cty.Disabled))
      {
        originalCoilType.Disabled = true;
      }
      if (originalCoilType.Disabled && originalCoilType.CoilTypeYNAs.Any(cty => !cty.Disabled))
      //if the coil type is currently disabled
      {
        originalCoilType.Disabled = false;
      }

      coilTypeRepo.ModifyCoilType(originalCoilType);
      await webSocketClientService.CoilLocationsUpdated();
      return ApplicationMessages.completed;

    }

    /// <summary>
    /// Insertion of CoilType Based on CoilTypeDto
    /// </summary>
    /// <param name="coilType"></param>
    /// <returns></returns>
    public async Task<CoilTypeDto> InsertCoilType(CoilTypeDto coilType)
    {
      if (coilTypeRepo.IsCoilTypeByName(coilType.Name))
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.coilTypeName + coilType.Name + ApplicationMessages.alreadyexists, HttpStatusCode = "BadRequest" };
      }
      CoilType newCoilType = new CoilType
      {
        Name = coilType.Name,
        NumCoils = coilType.NumCoils,
        Spec = coilType.Spec,
        Thickness = coilType.Thickness,
        Width = coilType.Width,
        CoilFieldZone = await coilFieldZoneRepo.GetCoilFieldZoneById(coilType.CoilFieldZoneId),
        MinThickness = coilType.MinThickness,
        MaxThickness = coilType.MaxThickness,
        MinWidth = coilType.MinWidth,
        MaxWidth = coilType.MaxWidth,
        Disabled = coilType.Disabled,
        //INC16521521 - update yield %
        Yield = coilType.Yield
      };
      MaterialType materialType = materialTypesRepo.GetMaterialTypesById(coilType.MaterialTypeId);
      //Add new YNAs
      newCoilType.CoilTypeYNAs = new List<CoilTypeYNA>();
      var CoilTypesYNA = coilTypeYNARepo.GetCoilTypeYNAsByYNA(newCoilType.CoilTypeYNAs);
      foreach (CoilTypeYNADto coilTypeYNA in coilType.CoilTypeYNAs)
      {
        if (CoilTypesYNA.Any(cty => cty.YNA == coilTypeYNA.YNA && !cty.Disabled))
        {
          throw new CoilTrackingException { ErrorMessage = ApplicationMessages.CoilTypeY + coilTypeYNA.YNA + ApplicationMessages.existingCoilType, HttpStatusCode = "BadRequest" };
        }
        newCoilType.CoilTypeYNAs.Add(new CoilTypeYNA() { YNA = coilTypeYNA.YNA, DateAdded = coilTypeYNA.DateAdded, Disabled = coilTypeYNA.Disabled, MaterialType = materialType });
      }
      coilTypeRepo.InsertCoilType(newCoilType);
      var coilTypes = mapper.Map<CoilTypeDto>(newCoilType);
      await webSocketClientService.CoilLocationsUpdated();
      return coilTypes;
    }
  }
}
