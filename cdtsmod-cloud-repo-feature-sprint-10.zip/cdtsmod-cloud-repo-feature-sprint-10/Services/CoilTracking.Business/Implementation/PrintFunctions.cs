using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;

namespace CoilTracking.Business.Implementation
{
  public class PrintFunctions : IPrintFunctions
  {
    private readonly IIncompleteRunOrderItemsRepository incompleteRunOrderItemsRepository;
    private readonly IApplicationLogger<PrintFunctions> logger;
    private readonly PLCIntegrationURLS settings;
    private readonly IHttpContextAccessor httpContextAccessor;
    public PrintFunctions(IOptions<PLCIntegrationURLS> settings,IIncompleteRunOrderItemsRepository incompleteRunOrderItemsRepository, IApplicationLogger<PrintFunctions> logger, IHttpContextAccessor httpContextAccessor)
{
      this.incompleteRunOrderItemsRepository = incompleteRunOrderItemsRepository;
      this.httpContextAccessor = httpContextAccessor;
      this.logger = logger;
      this.settings = settings.Value;

    }

    public string GetZPLTemplateString(ZPLParametersDto ZPLParameters)
    {

      string ZPLTemplate = string.Empty;
      string tagPartName = string.Empty;

      ZPLTemplate = GetTemplate("CDTS_Blank_Tag.zpl", ZPLParameters.TemplatesLocation); //T or M tag print

      if (ZPLParameters.PartName.Length > 13)
        tagPartName = ZPLParameters.PartName.Substring(0, 13);
      else
        tagPartName = ZPLParameters.PartName;


      //get final template with data
      ZPLTemplate = string.Format(ZPLTemplate, ZPLParameters.CustomerPartNumber, tagPartName, ZPLParameters.FTZ, "", DateTime.Now.ToString("MM/dd"), DateTime.Now.ToString("HH:mm"), ZPLParameters.palletSequence, ZPLParameters.Line, ZPLParameters.TagSerialNumber, ZPLParameters.Quantity, ZPLParameters.HTDText, ZPLParameters.HeatTreatDate, ZPLParameters.PalletId, ZPLParameters.PalletId);

      return ZPLTemplate;
    }

    public string GetTemplate(string filename, string fileLocation)
    {
      string readTextCode = string.Empty;
      string path = fileLocation + filename;
      try
      {
        if (File.Exists(path))
        {
          // Open the file to read from.
          readTextCode = File.ReadAllText(path);
        }
      }
      catch (Exception ex)
      {
        throw ex;
      }
      return readTextCode;
    }

    public PrinterConfigDto GetPrinterConfigValuesByPrinterName(string strNAMC, string PrinterName)
    {
      PrinterConfigDto printerVM = new PrinterConfigDto();

      try
      {
        IEnumerable<PrinterConfigDto> qryResult = incompleteRunOrderItemsRepository.GetPrinterConfigDto(strNAMC, PrinterName);
        if (qryResult.Count() > 0)
        {
          printerVM = qryResult.FirstOrDefault();
        }
        else
        {
          printerVM.ErrorMessage = "Printer is not recognized.";
        }
      }
      catch (Exception ex1)
      {
        printerVM.ErrorMessage = "Printer is not recognized.";
        throw ex1;
      }
      return printerVM;
    }

    public PrinterConfigDto GetPrinterConfigValues(string strNAMC, string lineName)
    {
      PrinterConfigDto printerVM = new PrinterConfigDto();

      try
      {
        IEnumerable<PrinterConfigDto> qryResult = incompleteRunOrderItemsRepository.GetPrinterConfigDto(strNAMC, lineName);
        if (qryResult.Count() > 0)
        {
          printerVM = qryResult.FirstOrDefault();
        }
        else
        {
          printerVM.ErrorMessage = "Printer is not recognized.";
        }
      }
      catch (Exception ex1)
      {
        printerVM.ErrorMessage = "Printer is not recognized.";
        throw ex1;
      }
      return printerVM;
    }


    public bool PrintFunction(string ZPLprintTemplate, string PrinterIPAddress, int port)
    {
      string responseString = string.Empty;
      var urlDictionary = settings.PlantUrl;
      using (var client = new HttpClient())
      {
        string baseurl = string.Empty;
        //to get the base url based upon the NamcCode
        var NAMCcode = GetNAMCCode();
        logger.LogInformation(Constant.methodname + "Print function" + Constant.message + "Namc code = " + NAMCcode);

        baseurl =urlDictionary[NAMCcode];
          
        logger.LogInformation(Constant.message + "Base Url" + baseurl );
       
        client.BaseAddress = new Uri(baseurl);
        client.DefaultRequestHeaders.Accept.Clear();
        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        // call subscribed line data if subscribe=true 

        try
        {
          var response =  client.GetAsync(string.Format(settings.PrintTag+"{0}/{1}/{2}", ZPLprintTemplate, PrinterIPAddress,port)).Result;

          if (response.IsSuccessStatusCode)
          {
            logger.LogInformation(Constant.message + "Response from PLC" + response);
            responseString =response.Content.ReadAsStringAsync().Result;
          }
          else if (response.StatusCode.Equals(StatusCodes.Status400BadRequest) || response.StatusCode.Equals(StatusCodes.Status500InternalServerError))
          {
            logger.LogInformation(Constant.message + "Response from PLC =" + response);
          }
          else
          {
            logger.LogInformation("Response from PLC =" + response.ReasonPhrase + response.StatusCode + response.RequestMessage);
          }


        }
        catch (Exception e)
        {
          logger.LogError("PLCException=" + e.Message + e.InnerException + e.StackTrace);
          throw new CoilTrackingException
          {
            ErrorMessage = "PLCException" + e.Message + "Inner Exception="
            + e.InnerException + "StackTrace=" + e.StackTrace
          };
        }
        var responseBool = bool.Parse(responseString);
        return responseBool;
      }
    }

    public string GetNAMCCode()
    {
      var NAMCs = httpContextAccessor.HttpContext.Request.Headers[Constant.namc].ToString();
       return NAMCs;
    }
  }
}
