using AutoMapper;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constant;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class CoilsService : ICoilsService
  {
    private readonly ICoilRepository coilRepo;
    private readonly IApplicationLogger<CoilsService> coilsServiceLogger;
    private readonly ICoilTypeRepository coilTypeRepo;
    private readonly ICoilMoveRequestsRepository coilMoveRequestsRepo;
    private readonly ICoilFieldLocationRepository coilFieldLocationRepo;
    private readonly ICoilTypeYNARepository coilTypeYNARepo;
    private readonly IPlantsRepository plantsRepo;
    private readonly IMapper mapper;
    private readonly IPartModelsRepository partModelsRepo;
    private readonly ICoilFactory coilFactory;
    private readonly IMillsRepository millsRepo;
    private readonly ICoilStatusRepository coilStatusRepo;
    private readonly IRunOrderRepository runOrderListRepo;
    private readonly ILineRepository lineRepo;
    private readonly ICoilLocationManagerFactory coilNewLocationFactory;
    private readonly IWebSocketClientService webSocketClientService;

    public CoilsService(ICoilRepository coilRepo, IApplicationLogger<CoilsService> coilsServiceLogger,
      ICoilTypeRepository coilTypeRepo, ICoilMoveRequestsRepository coilMoveRequestsRepo,
      ICoilFieldLocationRepository coilFieldLocationRepo, ICoilTypeYNARepository coilTypeYNARepo,
      IPlantsRepository plantsRepo, IMapper mapper, IPartModelsRepository partModelsRepo,
      ICoilFactory coilFactory, IMillsRepository millsRepo, ICoilStatusRepository coilStatusRepo,
      IRunOrderRepository runOrderListRepo,
      ILineRepository lineRepo,
      ICoilLocationManagerFactory coilNewLocationFactory,
      IWebSocketClientService webSocketClientService)
    {
      this.coilTypeRepo = coilTypeRepo;
      this.coilRepo = coilRepo;
      this.mapper = mapper;
      this.coilsServiceLogger = coilsServiceLogger;
      this.coilMoveRequestsRepo = coilMoveRequestsRepo;
      this.coilFieldLocationRepo = coilFieldLocationRepo;
      this.coilTypeYNARepo = coilTypeYNARepo;
      this.plantsRepo = plantsRepo;
      this.partModelsRepo = partModelsRepo;
      this.coilFactory = coilFactory;
      this.millsRepo = millsRepo;
      this.coilStatusRepo = coilStatusRepo;
      this.runOrderListRepo = runOrderListRepo;
      this.lineRepo = lineRepo;
      this.coilNewLocationFactory = coilNewLocationFactory;
      this.webSocketClientService = webSocketClientService;
    }
    /// <summary>
    /// Get Coils
    /// </summary>
    /// <returns></returns>
    public async Task<List<CoilDto>> GetCoils()
    {
      var coils = await coilRepo.GetCoils();
      var coilDtos = coils.Select(x => TransformCoilToDto(x)).ToList();
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "GetCoils" + Constant.countoflines + coilDtos.Count);

      return coilDtos;
    }

    /// <summary>
    /// Get Plant Code
    /// </summary>
    /// <returns></returns>
    public async Task<string> GetPlantCode()
    {
      var plantCode = await plantsRepo.GetPlantNAMCCode();
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "GetPlantCode" + Constant.countoflines + plantCode.Count());
      if (plantCode.Equals(Constant.tmmiNAMC, StringComparison.OrdinalIgnoreCase))
      {
        return Constant.OK;
      }
      else
      {
        return Constant.NA;
      }
    }


    public async Task<List<CoilDto>> SearchForCoils(DateTime? startTime = null, DateTime? endTime = null, string coilType = null,
      int? coilStatusId = null, int? zoneId = null, string FilterByBornOnDate = Constant.zero)
    {
      List<Coil> results = null;
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "SearchForCoils" + Constant.message + " before coilRepo.GetCoilsForSearch");  
      if (FilterByBornOnDate == Constant.zero) //Filter by checkin date
      {
        var coils = await coilRepo.GetCoilsForSearch(startTime, endTime, coilType, coilStatusId, zoneId, FilterByBornOnDate);
        if (coils == null)
        {
          throw new CoilTrackingException { ErrorMessage = "coils is empty" };
        }
        coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "SearchForCoils" + Constant.message + " after coilRepo.GetCoilsForSearch");

        coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "SearchForCoils" + Constant.countoflines + coils.Count);
        results = coils.Where(c => (!startTime.HasValue || c.CheckInDate >= startTime)
                                                && (!endTime.HasValue || c.CheckInDate <= endTime)
                                                ).OrderBy(c => c.CheckInDate).ToList();
        coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "SearchForCoils" + Constant.message+"Get result by BOD" + results);

      }
      else
      {
        var coils = await coilRepo.GetCoilsForSearch(startTime, endTime, coilType, coilStatusId, zoneId, FilterByBornOnDate);
        if (coils == null)
        {
          throw new CoilTrackingException { ErrorMessage = "coils is empty" };
        }
        coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "SearchForCoils" + Constant.message + " after coilRepo.GetCoilsForSearch");

        coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "SearchForCoils" + Constant.countoflines + coils.Count);
        results = coils.Where(c => (c.BornOnDate != null)
                                               && (!startTime.HasValue || c.BornOnDate >= startTime)
                                               && (!endTime.HasValue || c.BornOnDate <= endTime)).OrderBy(c => c.BornOnDate).ToList();
        coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "SearchForCoils" + Constant.message + "Get result by coils" + results);

      }
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "SearchForCoils" + Constant.message + " before TransformCoilToDto");

      var resultDTOs = results.Select(x => TransformCoilToDto(x)).ToList();
      return resultDTOs;
    }

    /// <summary>
    /// Map the Coil fields to the Dto info
    /// </summary>
    /// <param name="coil">The coil to get a Data Transfer Object for</param>
    /// <returns>Dto with Coil info</returns>
    private CoilDto TransformCoilToDto(Coil coil)
    {
      if (coil == null)
      {
        return null;
      }
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "TransformCoilToDto" + Constant.message + "Before mapping to dto");

      CoilDto dto = new CoilDto
      {
        Id = coil.Id,
        CoilFieldLocationId = coil.CoilFieldLocation != null ? coil.CoilFieldLocation.Id : -1,
        CoilFieldLocationName = coil.CoilFieldLocation != null && coil.CoilFieldLocation.Zone != null ? coil.CoilFieldLocation.Zone.Name + "-" + coil.CoilFieldLocation.Name : null,
        CoilStatusId = coil.CoilStatus != null ? coil.CoilStatus.Id : -1,
        CoilStatusName = coil.CoilStatus?.Name,
        CoilTypeId = coil.CoilType != null ? coil.CoilType.Id : -1,
        CoilTypeName = coil.CoilType?.Name,
        ZoneId = coil.CoilType.CoilFieldZone != null ? coil.CoilType.CoilFieldZone.Id : -1,
        MillId = coil.Mill != null ? coil.Mill.Id : -1,
        MillName = coil.Mill?.Name,
        FTZ = coil.FTZ,
        YNA = coil.YNA,
        OrderNo = coil.OrderNo,
        SerialNum = coil.SerialNum,
        OriginalWeight = coil.OriginalWeight,
        CurrentWeight = coil.CurrentWeight,
        CheckInDate = coil.CheckInDate,
        BornOnDate = coil.BornOnDate,
        IsPriority = coil.IsPriority
      };
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "TransformCoilToDto" + Constant.message + "After mapping to dto");

      return dto;
    }
    /// <summary>
    /// Get CoilInventory
    /// </summary>
    /// <returns></returns>
    public async Task<List<CoilInventoryDto>> GetCoilInventory()
    {
      var partmodels = await partModelsRepo.GetPartModels();
      var coilTypepartmodels = coilTypeRepo.GetCoilTypesWithAllPartNums();
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "GetCoilInventory" + Constant.countoflines + coilTypepartmodels.Count);
      var allCoilTypesWithAllPartNums = coilTypepartmodels.Select(x => new CoilTypePartModel
      {
        CoilTypeId = x.CoilTypeId,
        PartNumber = x.PartNumber,
        Models = ((x.Parts == null || x.PartNumber == null) ? string.Empty : GetModelListFromPart(x.Parts, partmodels))
      }).ToList();
      //Then group by the coilType ID, and join a distinct list of the (First 5 digit) part numbers into a single string
      var coilTypesWithDistinctPartNumsList = (from coilTypePart in allCoilTypesWithAllPartNums
                                               group coilTypePart by coilTypePart.CoilTypeId
                                               into groupedByCoilTypeID
                                               select new
                                               {
                                                 CoilTypeId = groupedByCoilTypeID.Key,
                                                 PartNumbers = string.Join(",", groupedByCoilTypeID.Select(d => d.PartNumber).Distinct()),
                                                 Models = string.Join(",", groupedByCoilTypeID.Select(d => d.Models).Distinct())
                                               }
                                              ).ToList();
      //materialize the results into a list

      //Get a list of coils in inventory
      var coilsInInventory = await coilRepo.GetCoilsByInInventory();
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "GetCoilInventory" + Constant.countoflines + coilsInInventory.Count);
      List<CoilInventoryDto> coilInventoryDtos = (from coil in coilsInInventory
                                                  join coilTypePartNum in coilTypesWithDistinctPartNumsList
                                                  on coil.CoilType.Id equals coilTypePartNum.CoilTypeId
                                                  into groupJoined
                                                  from coilTypePartNum
                                                  in groupJoined.DefaultIfEmpty()
                                                  select new CoilInventoryDto
                                                  {
                                                    CoilId = coil.Id,
                                                    Type = coil.CoilType.Name,
                                                    YNA = coil.YNA,
                                                    Status = coil.CoilStatus.Name,
                                                    Location = coil.CoilFieldLocation == null ? null : coil.CoilFieldLocation.Zone.Name + "-" + coil.CoilFieldLocation.Name,
                                                    FTZ = coil.FTZ,
                                                    Mill = coil.Mill.Name,
                                                    Serial = coil.SerialNum,
                                                    OriginalWeight = coil.OriginalWeight,
                                                    CurrentWeight = coil.CurrentWeight,
                                                    PartNumbers = (coilTypePartNum?.PartNumbers),
                                                    ModelList = (coilTypePartNum?.Models),
                                                    Received = coil.CheckInDate
                                                  }).ToList();
      return coilInventoryDtos;
    }

    /// <summary>
    /// Get ModelsList
    /// </summary>
    /// <param name="part"></param>
    /// <param name="partModels"></param>
    /// <returns></returns>
    public string GetModelListFromPart(Part part, List<PartModel> partModels)
    {
      List<string> partModel = partModels.Where(p => p.Part.PartNumber == part.PartNumber).Select(p => p.Model.ModelNumber).OrderBy(modelNum => modelNum).ToList();
      string modelList = string.Join("/", partModel);
      return modelList;
    }
    /// <summary>
    /// Get Coils By Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<CoilDto> GetCoilsById(int id)
    {
      //Get CoilType History
      //CoilsByIdWithTypeRunHistory
      var coils = await coilRepo.GetCoilsByIdWithTypeRunHistory(id);
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "GetCoilsById" + Constant.parameters + id);
      var coilDtos = mapper.Map<CoilDto>(coils);
      return coilDtos;
    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="ftz"></param>
    /// <returns></returns>
    public async Task<CoilDto> GetCoilByFTZ(string ftz)
    {
      var getObject = coilFactory.Create();
      var coil = await getObject.GetCoilFTZByPrefix(ftz);
      if (coil == null)
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.coilPrefix, HttpStatusCode = Constant.notfound };
      }
      var resultDTOs = mapper.Map<CoilDto>(coil);
      return resultDTOs;
    }
    /// <summary>
    /// Get Coils Based on CoilFieldLocation Name
    /// </summary>
    /// <param name="coilFieldLocationFullName"></param>
    /// <returns></returns>
    public async Task<CoilDto> GetCoilsLocationName(string coilFieldLocationFullName)
    {
      //Split out the coil location 
      string[] locationSplit = coilFieldLocationFullName.Split('-');
      string zone = locationSplit[0];
      string locationName = locationSplit[1];
      var location = await coilFieldLocationRepo.GetCoilFieldLocationByName(zone, locationName);
      var coilDto = await GetCoilsByLocationId(location.Id);
      return coilDto;
    }
    /// <summary>
    /// Get Coils Based on LocationId
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<CoilDto> GetCoilsByLocationId(int id)
    {
      var coil = await coilRepo.GetCoilsByLocationId(id);
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "GetCoilsByLocationId" + Constant.parameters + id);
      CoilDto coilDto = TransformCoilToDto(coil);

      return coilDto;
    }

    /// <summary>
    /// Get Coil For Modify
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<CoilDto> GetCoilForModify(int CoilId)
    {
      var coil = await coilRepo.GetCoilsById(CoilId);
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "GetCoilForModify" + Constant.parameters + CoilId);
      CoilDto coilDto = TransformCoilToDto(coil);
      return coilDto;

    }
    /// <summary>
    /// Get Coils To Be Weighed
    /// </summary>
    /// <returns></returns>
    public async Task<List<CoilDto>> GetCoilsToBeWeighed()
    {
      string Name = CoilStatusName.PartialNeedsWeighed;
      var coil = await coilRepo.GetCoilsByCoilStatusName(Name);
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "GetCoilsToBeWeighed");
      var coilDtos = mapper.Map<List<CoilDto>>(coil);
      return coilDtos;

    }
    /// <summary>
    /// Get Remaining CoilWeight
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<decimal> GetRemainingCoilWeightById(int id)
    {
      var coilType = coilTypeRepo.GetCoilTypeById(id);
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "GetRemainingCoilWeightById" + Constant.parameters + id);
      var coilTypeYield = coilType.Yield;
      var coils = await coilRepo.CoilsInventoryBYTypeId(id);
      var totalWeightRemaining = coils.Sum(c => c.CurrentWeight);
      var weightRemainingMinusYield = totalWeightRemaining * coilTypeYield;
      return weightRemainingMinusYield;


    }
    /// <summary>
    /// Get Material Type Based on  YNA
    /// </summary>
    /// <param name="yna"></param>
    /// <returns></returns>
    public async Task<string> GetMaterialTypeByYNA(string yna)
    {
      string materialType = await coilTypeYNARepo.GetMaterialTypeByYNA(yna);
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "GetMaterialTypeByYNA" + Constant.parameters + yna);
      return materialType;
    }

    /// <summary>
    /// Check Dependency
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<List<string>> CheckDependency(int id)
    {
      List<string> coilsAssociation = new List<string>();

      var coilMoveRequest = coilMoveRequestsRepo.GetCoilMoveRequestById(id);
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "CheckDependency" + Constant.parameters + id);
      var coils = await coilRepo.GetCoilsLoadedById(id);
      if (coilMoveRequest.Any())
      {
        coilsAssociation.Add(Constant.moveRequest);
      }
      if (coils.Any())
      {
        coilsAssociation.Add(Constant.coilLoaded);
      }
      return coilsAssociation;
    }



    /// <summary>
    /// Insertion Coil info 
    /// </summary>
    /// <param name="coil"></param>
    /// <returns></returns>
    public async Task<CoilDto> InsertCoil(Coil coil)
    {
      await coilRepo.InsertCoil(coil);
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "InsertCoil" + Constant.parameters + coil);
      var coilDto = mapper.Map<CoilDto>(coil);
      await webSocketClientService.CoilLocationsUpdated();
      return coilDto;
    }
    /// <summary>
    /// Deletion of coil info based on Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<CoilDto> DeleteCoilById(int id)
    {
      var coil = await coilRepo.GetCoilId(id);
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "DeleteCoilById" + Constant.parameters + coil);
      await coilRepo.DeleteCoil(coil);
      var coilDto = mapper.Map<CoilDto>(coil);
      return coilDto;
    }

    /// <summary>
    /// Coil Check Edit
    /// </summary>
    /// <param name="id"></param>
    /// <param name="dto"></param>
    /// <returns></returns>
    public async Task<List<string>> CoilCheckEdit(int id, CoilDto dto)
    {
      List<string> coilAssociation = new List<string>();

      var coils = await coilRepo.GetCoilId(id);
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "CheckDependency" + Constant.parameters + id);
      if (dto.Id != coils.Id
              || dto.CoilStatusName != coils.CoilStatus.Name
              || dto.CoilTypeName != coils.CoilType.Name
              || dto.CheckInDate != coils.CheckInDate
          )
      {
        coilAssociation.Add(Constant.edited);

      }
      if (coilAssociation.Count > 0)
      {
        throw new CoilTrackingException { HttpStatusCode = Constant.badRequest };
      }

      return coilAssociation;

    }
    /// <summary>
    /// Update Coil info
    /// </summary>
    /// <param name="id"></param>
    /// <param name="coil"></param>
    /// <returns></returns>
    public async Task<int> UpdateCoil(int id, Coil coil)
    {
      var coilExists = await coilRepo.GetCoilId(id);
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "UpdateCoil" + Constant.parameters + id);
      if (coilExists == null)
      {
        throw new CoilTrackingException { HttpStatusCode = Constant.badRequest, ErrorMessage = ApplicationMessages.coilNotFound };
      }
      var coils = await coilRepo.ModifyCoil(coil);
      await webSocketClientService.CoilLocationsUpdated();
      return coils;


    }

    /// <summary>
    /// Updation of AccountedWeight
    /// </summary>
    /// <param name="id"></param>
    /// <param name="unAccountedWeight"></param>
    /// <returns></returns>
    public async Task<string> UpdateUnAccountedWeight(int id, int unAccountedWeight)
    {
      try
      {
        var coilUpdated = await coilRepo.GetCoilStatusByCoilId(id);
        coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "UpdateUnAccountedWeight" + Constant.parameters + id);
        coilUpdated.UnAccountedWeight += unAccountedWeight;
        await coilRepo.UpdateCoilStatus(coilUpdated);
      }
      catch (DbUpdateConcurrencyException)
      {
        throw new CoilTrackingException { HttpStatusCode = Constant.internalServerError };
      }

      return ApplicationMessages.completed;

    }
    /// <summary>
    /// Coils CheckIn
    /// </summary>
    /// <param name="coilCheckIn"></param>
    /// <returns></returns>
    public async Task<CoilDto> CoilsCheckIn(CoilCheckIn coilCheckIn)
    {
      // Don't allow empty FTZ coil check-in
      if (String.IsNullOrEmpty(coilCheckIn.FTZ))
      {
        throw new CoilTrackingException { HttpStatusCode = Constant.badRequest, ErrorMessage = ApplicationMessages.coilEmptyFTZ };
      }
      var coilTypeYNA =  CheckcoilTypeYNAs(coilCheckIn);
      //next lookup the coil status 
      var coilStatuses = await coilStatusRepo.GetCoilStatusByName(CoilStatusName.New);
      var coilStatus = coilStatuses.FirstOrDefault();
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "CoilsCheckIn" + Constant.countoflines + coilStatus);
      ValidateNewCoil(coilStatus);
      //Split out the coil location 
      CoilFieldLocation location = await GetCoilFieldLocationBynewLocation(coilCheckIn.Location);
      ValidateLocation(location, coilCheckIn.Location);
      Mill mill = await SetMill(coilCheckIn.Mill);
      Coil newCoil = new Coil()
      {
        CoilType = coilTypeYNA.CoilType,
        OrderNo = coilCheckIn.OrderNo.GetValueOrDefault(0),
        OriginalWeight = coilCheckIn.Weight,
        CoilFieldLocation = location,
        FTZ = coilCheckIn.FTZ,
        Mill = new Mill { Name = mill.Name, Disabled=mill.Disabled, Plant_Id = mill.Plant_Id },
        SerialNum = coilCheckIn.SerialNum,
        YNA = coilCheckIn.YNANo,
        CoilStatus = coilStatus,
        CheckInDate = DateTime.Now,
        IsPriority = coilCheckIn.IsPriorityCoil,
        BornOnDate = coilCheckIn.BornOnDate
      };
      location.IsEmpty = false;
      await coilRepo.InsertCoil(newCoil);
      var newCoils = mapper.Map<CoilDto>(newCoil);
      await webSocketClientService.CoilLocationsUpdated();
      return newCoils;
    }

    /// <summary>
    /// Check coilTypeYNAn
    /// </summary>
    /// <param name="coilTypeYNA"></param>
    /// <param name="coilCheckIn"></param>
    public  CoilTypeYNA CheckcoilTypeYNAs(CoilCheckIn coilCheckIn)
    {
      //First lookup the coil type based on the YNA # (That is not disabled)
      var coilTypeYNA =  coilTypeYNARepo.GetcoilTypeYNAsByYNANo(coilCheckIn.YNANo);
      if (coilTypeYNA == null || coilTypeYNA.CoilType == null)
      {
        //A valid existing CoilType is required    
          //If Y# actually exists but is disabled, show a little different error message
          throw new CoilTrackingException
          {
            HttpStatusCode = Constant.badRequest,
            ErrorMessage = ApplicationMessages.coiltypenotfound + coilCheckIn.YNANo 
          };
        
        throw new CoilTrackingException { HttpStatusCode = Constant.badRequest, ErrorMessage = ApplicationMessages.coiltypenotfound + coilCheckIn.YNANo };
      }
      return coilTypeYNA;


    }
    /// <summary>
    /// Set Mill
    /// </summary>
    /// <param name="Mill"></param>
    /// <returns></returns>
    public async Task<Mill> SetMill(string Mill)
    {
      Mill mill = await millsRepo.GetMillByName(Mill);
      if (mill == null)
      {
        mill = new Mill()
        { Name = Mill, Disabled = false };
      }
      else if (mill.Disabled)
      {
        throw new CoilTrackingException { HttpStatusCode = Constant.badRequest, ErrorMessage = ApplicationMessages.millisdisabled + Mill };
      }

      return mill;

    }
    /// <summary>
    /// Validation For Coil
    /// </summary>
    /// <param name="coil"></param>
    /// <param name="coilId"></param>
    public void ValidateNewCoil(CoilStatus coilStatus)
    {
      if (coilStatus == null)
      {
        //A valid existing CoilType is required
        throw new CoilTrackingException { HttpStatusCode = Constant.badRequest, ErrorMessage = ApplicationMessages.coilstatusnotfound };
      }
    }
    /// <summary>
    /// Validation For Coil
    /// </summary>
    /// <param name="coil"></param>
    /// <param name="coilId"></param>
    public void ValidateLocation(CoilFieldLocation location, string locations)
    {
      if (!location.IsEmpty)
      {
        //An empty location is required. They moved a coil without telling the system?
        throw new CoilTrackingException { HttpStatusCode = Constant.badRequest, ErrorMessage = ApplicationMessages.location + locations + ApplicationMessages.isnotempty };
      }
    }

    /// <summary>
    /// Get CoilFieldLocationByName
    /// </summary>
    /// <param name="newLocation"></param>
    /// <returns></returns>
    public async Task<CoilFieldLocation> GetCoilFieldLocationBynewLocation(string location)
    {
      if (string.IsNullOrWhiteSpace(location) || !location.Contains('-') || location.Length < 4)
      {
        throw new CoilTrackingException { HttpStatusCode = Constant.badRequest, ErrorMessage = ApplicationMessages.newlocation + location + ApplicationMessages.coillocationnotcorrectformat };
      }
      //Split out the coil location 
      string[] locationSplit = location.Split('-');
      string zone = locationSplit[0];
      string locationName = locationSplit[1];
      CoilFieldLocation locations = await coilFieldLocationRepo.GetCoilFieldLocationByName(zone, locationName);
      if (locations == null)
      { //A valid existing CoilFieldLocation is required
        throw new CoilTrackingException { HttpStatusCode = Constant.badRequest, ErrorMessage = ApplicationMessages.couldnotfindacoillocation + location };
      }
      return locations;
    }


    /// <summary>
    /// Update  CoilRunHistory
    /// </summary>
    /// <param name="coilId"></param>
    /// <param name="runOrderListId"></param>
    /// <param name="weightUsed"></param>
    /// <returns></returns>
    public async Task<string> UpdateCoilRunHistory(int coilId, int runOrderListId, int weightUsed)
    {
      try
      {
        var coilUpdated = coilRepo.GetCoilsWithAllInfo(coilId);
        coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "UpdateCoilRunHistory" + Constant.parameters + coilId);
        CoilRunHistory runHistory = new CoilRunHistory()
        {
          Coil = coilUpdated,
          RunOrderList = await runOrderListRepo.GetRunOrderListByIdAsync(runOrderListId),
          WeightUsed = weightUsed
        };
        if (coilUpdated.CoilRunHistory == null)
          coilUpdated.CoilRunHistory = new List<CoilRunHistory>();
        coilUpdated.CoilRunHistory.Add(runHistory);
        if (coilUpdated.CurrentWeight <= 0)
        {
          List<CoilStatus> CoilStatuses = await coilStatusRepo.GetCoilStatusByName(CoilStatusName.CompletelyUsed);
          coilUpdated.CoilStatus = CoilStatuses.FirstOrDefault();

        }
        await coilRepo.UpdateCoilForRunHistory(coilUpdated);
      }
      catch (DbUpdateConcurrencyException)
      {
        throw new CoilTrackingException { HttpStatusCode = Constant.internalServerError };
      }
      return ApplicationMessages.completed;
    }

    /// <summary>
    /// MoveCoils
    /// </summary>
    /// <param name="coilId"></param>
    /// <param name="newLocation"></param>
    /// <param name="newStatusId"></param>
    /// <param name="isPriorityCoil"></param>
    /// <param name="lineId"></param>
    /// <returns></returns>
    public async Task<string> UpdateMoveCoilsByIds(int coilId, string newLocation, int newStatusId, bool isPriorityCoil = false, int? lineId = null)
    {
      var coil = await coilRepo.GetCoilsById(coilId);
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "UpdateMoveCoilsByIds" + Constant.parameters + coilId);
      ValidateCoil(coil, coilId);
      CoilStatus newStatus = await coilStatusRepo.GetCoilStatusByIdAsync(newStatusId);
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "UpdateMoveCoilsByIds" + Constant.parameters + newStatusId);
      ValidateNewStatus(newStatus, newStatusId);
      var getObject = coilNewLocationFactory.Create(newLocation);
      Coil coilinfo = await getObject.AssignCoilLocation(newStatus, coil, lineId, newLocation);
      if (newLocation == Constant.other && newStatus.Name == CoilStatusName.LoadedAtLine)
      {
        await SetCoilMoveRequestByLineId(coil, lineId);
      }
      //update status and save
      coilinfo.CoilStatus = newStatus;
      coilinfo.IsPriority = isPriorityCoil;
      
      await coilRepo.CoilSaveChanges(coilinfo);

      await webSocketClientService.CoilLocationsUpdated();

      //Update andons and handheld since coil location/status/etc changed

      if (newLocation == Constant.other && newStatus.Name == CoilStatusName.LoadedAtLine && lineId.HasValue)
      {
        //If this was a coil load, update the signalR clients with the line Id the coil Id is now loaded at

        //Hubs.NotificationHubClients.Instance.CoilLoaded(lineId.Value, coilId);
      }
      return newStatus.Name;
    }
    /// <summary>
    /// Validation For NewStatus
    /// </summary>
    /// <param name="newStatus"></param>
    /// <param name="newStatusId"></param>
    public void ValidateNewStatus(CoilStatus newStatus, int newStatusId)
    {
      if (newStatus == null)
      { throw new CoilTrackingException { HttpStatusCode = Constant.badRequest, ErrorMessage = ApplicationMessages.coilstatusmatchnotfound + newStatusId }; }
    }

    /// <summary>
    /// Validation For Coil
    /// </summary>
    /// <param name="coil"></param>
    /// <param name="coilId"></param>
    public void ValidateCoil(Coil coil, int coilId)
    {
      if (coil == null)
      {
        throw new CoilTrackingException { HttpStatusCode = Constant.badRequest, ErrorMessage = ApplicationMessages.coildidnotfoundmatch + coilId };
      }
    }

    /// <summary>
    /// Set CoilMoveRequest By LineId
    /// </summary>
    /// <param name="coil"></param>
    /// <param name="newStatus"></param>
    /// <param name="lineId"></param>
    public async Task SetCoilMoveRequestByLineId(Coil coil, int? lineId)
    {
      Line line = null;
      if (lineId.HasValue)
      {
        line = lineRepo.GetLineByLineID((int)lineId);
      }
      if (line == null)
      {
        throw new CoilTrackingException
        {
          HttpStatusCode = Constant.badRequest,
          ErrorMessage = ApplicationMessages.lineisnull
        };
      }
      //Create a 'fake'? CoilMoveRequest so the line side app will pick it up, mark it as already fulfilled so coil setter doesn't get an extra notification
      Data.Models.CoilMoveRequest fakeMoveRequest = new Data.Models.CoilMoveRequest()
      {
        Line = line,
        Requested = DateTime.Now,
        Fulfilled = DateTime.Now,
        Coil = coil,
        RequestType = CoilMoveRequestType.CoilRequest,
        IsCancelled = false
      };
      await coilMoveRequestsRepo.AddCoilMoveRequest(fakeMoveRequest);
    }

    /// <summary>
    /// Get Coils in inventory
    /// </summary>
    /// <returns></returns>
    public async Task<List<Coil>> GetCoilsInInventoryAsync()
    {
      return await coilRepo.GetCoilsByInInventory();
    }

    /// <summary>
    /// UpdateCoils Based on Id Dto
    /// </summary>
    /// <param name="id"></param>
    /// <param name="dto"></param>
    /// <returns></returns>
    public async Task<string> UpdateCoilsByIdDto(int id, CoilDto dto)
    {
    Coil coil =  await coilRepo.GetCoilsIds(id);
      if(coil == null)
      {
        throw new CoilTrackingException { HttpStatusCode = Constant.badRequest, ErrorMessage = ApplicationMessages.coilNotFound };
      }
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "UpdateCoilsByIdDto" + Constant.countoflines + coil);
      CoilFieldLocation oldLocation = coil.CoilFieldLocation;
      CoilFieldLocation newLocation = null;
      if (dto.CoilFieldLocationId != -1)
      {
        newLocation =  coilFieldLocationRepo.GetCoilFieldLocationWithZone(dto.CoilFieldLocationId);
        coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "UpdateCoilsByIdDto" + Constant.parameters + newLocation);
      }
      coil.CoilFieldLocation = newLocation;
      coil.CoilStatus = coilStatusRepo.GetCoilStatusById(dto.CoilStatusId);
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "UpdateCoilsByIdDto" + Constant.parameters + dto.CoilStatusId);
      coil.CoilType = coilTypeRepo.GetCoilTypeById(dto.CoilTypeId);
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "UpdateCoilsByIdDto" + Constant.parameters + dto.CoilTypeId);
      coil.Mill = millsRepo.GetMillById(dto.MillId);
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "UpdateCoilsByIdDto" + Constant.parameters + dto.MillId);
      coil.OrderNo = dto.OrderNo;
      coil.OriginalWeight = dto.OriginalWeight;
      coil.CheckInDate = dto.CheckInDate;
      coil.BornOnDate = dto.BornOnDate;
      coil.CoilStatus.Id = dto.CoilStatusId;
      coil.Mill.Name = dto.MillName;
      coil.Mill.Id = dto.MillId;
      if (dto.CurrentWeight != coil.CurrentWeight)
      {
        // Always add difference in current weight to existing unaccounted weight of coil.
        //coil.UnAccountedWeight = coil.CurrentWeight - dto.CurrentWeight;
        coil.UnAccountedWeight += coil.CurrentWeight - dto.CurrentWeight;
      }
      coil.SerialNum = dto.SerialNum;
      coil.IsPriority = dto.IsPriority;
      

      if (oldLocation != null)
      {
        oldLocation.IsEmpty = true;
      }

      if (newLocation != null)
      {
        newLocation.IsEmpty = false;
      } 
     await coilRepo.UpdateCoils(coil);
     await  coilFieldLocationRepo.SaveChangesAync(AuditActionType.ModifyEntity);
      return ApplicationMessages.completed;
    }
  }
}

