using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class ImportPressPattern : IImportPressPattern
  {
    public static readonly string[] AllowedPatternsForCalendars = new string[] { "A", "B", "C", "D", "X" };
    public static readonly string[] AllowedPatterns = new string[] { "A", "B", "C", "D" };

    private readonly ILineRepository lineRepository;
    private readonly IShiftRepository shiftRepository;
    private readonly IPatternCalendarRepository patternCalendarRepository;
    private readonly IPartRepository partRepository;
    private readonly IApplicationLogger<ImportPressPattern> logger; 

    public ImportPressPattern(ILineRepository lineRepository,
      IShiftRepository shiftRepository,
      IPatternCalendarRepository patternCalendarRepository,
      IPartRepository partRepository,
      IApplicationLogger<ImportPressPattern> logger)
    {
      this.lineRepository = lineRepository;
      this.shiftRepository = shiftRepository;
      this.patternCalendarRepository = patternCalendarRepository;
      this.partRepository = partRepository;
      this.logger = logger;
    }

    /// <summary>
    /// Import File.
    /// </summary>
    /// <returns></returns>
    public async void Import(string filename, string userName)
    {
      logger.LogInformation(Constant.classname + "ImportPressPattern" + Constant.methodname + "Import" + Constant.message + "Import method start");
      await Import(new MemoryStream(File.ReadAllBytes(filename)), userName);
    }

    /// <summary>
    /// import.
    /// </summary>
    /// <returns></returns>
    public async Task<int> Import(MemoryStream ms, string userName)
    {
      var shiftLineDatePatternLookup = new Dictionary<string, Dictionary<DateTime, char>>();
      var lineNamePatternLetterPartModelLookup = new Dictionary<string, Dictionary<string, List<string>>>();

      logger.LogInformation(Constant.classname + "ImportPressPattern" + Constant.methodname + "Import" + Constant.message + "Calling Generate Excel Method");
      var excelResponse = GenerateExcel(shiftLineDatePatternLookup, ms, lineNamePatternLetterPartModelLookup);
      logger.LogInformation(Constant.classname + "ImportPressPattern" + Constant.methodname + "Import" + Constant.message + "Generate Excel method completed");
      shiftLineDatePatternLookup = excelResponse.ShiftLineDatePatternLookup;
      lineNamePatternLetterPartModelLookup = excelResponse.LineNamePatternLetterPartModelLookup;

        List<Pattern> newPatterns = new List<Pattern>();
        List<PatternCalendar> newCalendars = new List<PatternCalendar>();

        List<Line> lines = await lineRepository.GetLinesAsync();

        if (shiftLineDatePatternLookup != null && shiftLineDatePatternLookup.Count > 0)
        {
          ProcessShiftLineDatePatternLookup(shiftLineDatePatternLookup, lines);
        }

        if (lineNamePatternLetterPartModelLookup != null && lineNamePatternLetterPartModelLookup.Count > 0)
        {
          var patterns = ProcessLineNamePatternLetterPartModelLookup(lineNamePatternLetterPartModelLookup, lines, newPatterns);
          newPatterns = patterns;
        }
        if (shiftLineDatePatternLookup.Count > 0 || lineNamePatternLetterPartModelLookup.Count > 0)
        {
        //We have the patterns+calendars, now save it to the database
        //IMPORTANT 12142018 : Disable saving to DB from import option. Uncomment below lines to enable import to DB. Records are added to the repository but save changes are not called. TO fix it call the save changes on db context.
        
        return 0;
        }
        else
        {
          throw new CoilTrackingException("No Pattern or Calendar Data found to import");
        }

      logger.LogInformation(Constant.classname + "ImportPressPattern" + Constant.methodname + "Import" + Constant.message + "Complete");
    }

    /// <summary>
    /// excel generation.
    /// </summary>
    /// <returns></returns>
    private ExcelResult GenerateExcel(Dictionary<string, Dictionary<DateTime, char>> shiftLineDatePatternLookup, MemoryStream ms, Dictionary<string, Dictionary<string, List<string>>> lineNamePatternLetterPartModelLookup)
    {
      using (var package = new ExcelPackage(ms))
      {
        ExcelWorkbook workbook = package.Workbook;
        if (workbook.Worksheets.Count > 0)
        {
          foreach (ExcelWorksheet worksheet in workbook.Worksheets)
          {
            string worksheetName = worksheet.Name.ToUpper();
            switch (worksheetName)
            {
              case "CALENDAR": //Correct spelling (in case they fix the typo)
              case "CALENDER": //Typo spelling (as found in the actual spreadsheet)
                shiftLineDatePatternLookup = ImportCalendar(worksheet);
                break;
              case "PATTERNLETTERS": //Don't parse pattern letters sheet as it's to validate user pattern letter selection
                continue;
              default:
                //If it's not a calendar sheet, it must be a pattern sheet
                if (!worksheetName.Contains("PATTERN"))
                  continue;
                string lineName = worksheet.Name.Replace("PATTERN", "").Trim(); //Remove "PATTERN" from the sheet name "BL3 PATTERN" to get just BL3, the line name
                Dictionary<string, List<string>> patternPartModelLookup = ImportPattern(worksheet);
                lineNamePatternLetterPartModelLookup.Add(lineName, patternPartModelLookup);
                break;
            }
          }
        }
      }

      return new ExcelResult
      {
        LineNamePatternLetterPartModelLookup = lineNamePatternLetterPartModelLookup,
        ShiftLineDatePatternLookup = shiftLineDatePatternLookup
      };
    }

    private void ProcessShiftLineDatePatternLookup(Dictionary<string, Dictionary<DateTime, char>> shiftLineDatePatternLookup, List<Line> lines)
    {
      List<Shift> shifts = shiftRepository.GetShifts().Result;
      //We have a calendar (shift/date/pattern lookup) and a patternLetter/part/model lookup lists
      //Now, do something with it.... Convert to our db model objects, and then save it in the database etc
      foreach (string shiftLineName in shiftLineDatePatternLookup.Keys)
      {
        //split line and shift by space. e.g. 'BL1 Blue'
        string[] shiftLineSplit = shiftLineName.Split(' ');
        string lineText = shiftLineSplit[0].ToUpper();
        string shiftText = shiftLineSplit[1].ToUpper();

        Shift shift = shifts.FirstOrDefault(item => item.Name == shiftText);
        if (shift is null)
          throw new CoilTrackingException($"Shift not found in DB : {shiftText}");
        Line line = lines.FirstOrDefault(item => item.LineName == lineText);
        if (line is null)
          throw new CoilTrackingException($"Line not found in DB : {lineText}");

        var minDate = shiftLineDatePatternLookup[shiftLineName].Keys.Min();
        var maxDate = shiftLineDatePatternLookup[shiftLineName].Keys.Max();
        var patternCalendars = patternCalendarRepository.GetPatternCalendarsByLineIdAndShiftIdAsync(line.Id, shift.Id, minDate, maxDate).Result;

        int DaysInMonth = DateTime.DaysInMonth(DateTime.Today.Year, DateTime.Today.Month);

        DateTime date;
        //By default, import calender data only for current month-year
        for (int i = 1; i < DaysInMonth; i++)
        {
          //Add default 'X' for all dates of current month-year and assign excel data if available.
          date = new DateTime(DateTime.Today.Year, DateTime.Today.Month, i);
          string patternLetter = "X";
          if (shiftLineDatePatternLookup[shiftLineName].ContainsKey(date))
            patternLetter = shiftLineDatePatternLookup[shiftLineName][date].ToString();

          //Update if existing or add record to calendar table.
          var patternCalendar = patternCalendars.FirstOrDefault(p => p.Date == date);
          if (patternCalendar == null)
          {
            PatternCalendar newPatternCalendar = new PatternCalendar() { PatternLetter = patternLetter, Line = line, Date = date, Shift = shift };
            patternCalendarRepository.AddPatternCalenderAsync(newPatternCalendar);
          }
          else
          {
            patternCalendar.PatternLetter = patternLetter;
          }
        }
      }
    }

    private List<Pattern> ProcessLineNamePatternLetterPartModelLookup(Dictionary<string, Dictionary<string, List<string>>> lineNamePatternLetterPartModelLookup, List<Line> lines, List<Pattern> newPatterns)
    {
      var partInfos = partRepository.GetPartsAsync().Result;
      foreach (string lineName in lineNamePatternLetterPartModelLookup.Keys)
      {
        foreach (string patternLetter in lineNamePatternLetterPartModelLookup[lineName].Keys)
        {
          Line line = lines.FirstOrDefault(item => item.LineName == lineName);
          if (line is null)
            throw new CoilTrackingException($"Line not found in DB : {lineName}");

          Pattern newPattern = new Pattern()
          {
            CreateDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1),
            Name = patternLetter,
            Line = line
          };
          newPattern.PatternItems = new List<PatternItem>();

          int sortOrder = 1;
          foreach (string partModelStrings in lineNamePatternLetterPartModelLookup[lineName][patternLetter])
          {
            var updatedPattern = ProcessPartModelString(partModelStrings, partInfos, newPattern, sortOrder);
            newPattern = updatedPattern;
            sortOrder++;
          }
          if (newPattern.PatternItems.Count > 0)
            newPatterns.Add(newPattern);
        }
      }
      return newPatterns;
    }

    private Pattern ProcessPartModelString(string partModelStrings, List<Part> partInfos, Pattern newPattern, int sortOrder)
    {
      string partModelStringsUpper = partModelStrings.ToUpper().Trim();
      if (partModelStrings.ToUpper() == "FREE")
      {
        partModelStringsUpper = "FREE-FREE"; //We'll put FREE for both part and model
      }
      //First row = pattern letter, 2nd+ rows = part#:data#:model# (:partName) (or FREE) (partName is optional)
      string[] partModelSplit = partModelStringsUpper.Split(':');
      string partNum = partModelSplit[0].Trim();
      string dataNum = partModelSplit[1].Trim();
      string modelNum = partModelSplit[2].Trim();
      
      if (dataNum == "-") dataNum = null;
      string partName = partInfos.FirstOrDefault(p => p.PartNumber == partNum).PartName;

      newPattern.PatternItems.Add(new PatternItem()
      {
        SortOrder = sortOrder,
        ModelNumber = modelNum,
        PartNumber = partNum,
        PartName = partName,
        DataNumber = dataNum
      });

      return newPattern;
    }
    /// <summary>
    /// Imports the calendar tab that shows which pattern to use for a shift on each date
    /// </summary>
    /// <param name="worksheet">The excel worksheet named calendar/calender.</param>
    /// <returns>A dictionary lookup of pattern letter by shift/date.</returns>
    private Dictionary<string, Dictionary<DateTime, char>> ImportCalendar(ExcelWorksheet worksheet)
    {
      if (worksheet.Dimension is null)
        throw new CoilTrackingException("Empty Pattern Calendar sheet");
      Dictionary<string, Dictionary<DateTime, char>> shiftLineDatePatternLookup = new Dictionary<string, Dictionary<DateTime, char>>();
      Dictionary<int, string> shiftLineColumnLookup = new Dictionary<int, string>();

      int maxColumns = worksheet.Dimension.End.Column;
      int maxRows = worksheet.Dimension.End.Row;

      if (maxRows < 2 || maxColumns < 2)
        throw new CoilTrackingException("Header in 1st row and minimum 1 row with data needed to Import Pattern Calendar");

      //Get the list of shifts to map to column numbers (1st row). 1st row - 1st column has 'Date' header. so check from 2nd column
      for (int col = 2; col <= maxColumns; col++)
      {
        string shiftLineName = worksheet.Cells[1, col].Text;
        shiftLineColumnLookup.Add(col, shiftLineName);
      }

      //Add all the shifts to the shift/date/pattern lookup dictionary with an empty date/pattern lookup dictionary
      foreach (string shiftLineName in shiftLineColumnLookup.Values.Distinct())
      {
        shiftLineDatePatternLookup.Add(shiftLineName, new Dictionary<DateTime, char>());
      }
      // 2nd row onwards contains pattern letters for 'Line Shift' combo like 'BL1 Blue' with 1st column as MM/dd/yyyy pattern.
      for (int row = 2; row <= maxRows; row++)
      {
        string dateString = worksheet.Cells[row, 1].Text;
        //Sometimes empty string comes for date. Skip the iteration. Otherwise if non-convertible text into DateTime, throw Format exception.
        if (string.IsNullOrEmpty(dateString))
          continue;
        string[] monthDayYear = dateString.Split('/');
        if (monthDayYear.Length != 3)
          throw new CoilTrackingException($"Date Format Error at Row-{row}. Enter date in 'MM/dd/yyyy' format");
        int month = int.Parse(monthDayYear[0]);
        int day = int.Parse(monthDayYear[1]);
        int year = int.Parse(monthDayYear[2]);

        DateTime date = new DateTime(year, month, day);

        //First read the dates
        for (int col = 2; col <= maxColumns; col++)
        {
          string pattern = worksheet.Cells[row, col].Text;
          string shift = shiftLineColumnLookup[col];

          if (!AllowedPatternsForCalendars.Contains(pattern))
            throw new CoilTrackingException($"Invalid Pattern Letters present at Row-{row}, Column-{col}. Only A,B,C,D,X are allowed in Pattern Calendar sheet.");

          shiftLineDatePatternLookup[shift].Add(date, pattern.FirstOrDefault());
        }
      }
      return shiftLineDatePatternLookup;
    }

    private Dictionary<string, List<string>> ImportPattern(ExcelWorksheet worksheet)
    {
      if (worksheet.Dimension is null)
        throw new CoilTrackingException("Empty Pattern Items sheet");
      int maxColumns = worksheet.Dimension.End.Column;
      int maxRows = worksheet.Dimension.End.Row;
      if (maxRows < 2 || maxColumns < 1)
        throw new CoilTrackingException("Header in 1st row and minimum 1 row with data needed to Import Pattern items");

      Dictionary<string, List<string>> patternPartModelLookup = new Dictionary<string, List<string>>();
      //First row = pattern letter, 2nd+ rows = part#:data#:model# (:partName) (or FREE) (partName is optional)
      //string fullName = worksheet.Cells[1, 1].Text; //First row/cell (merged cell) is the full name.

      Dictionary<int, string> patternColumnLookup = new Dictionary<int, string>();
      //Get the list of patterns to map to column numbers (third row)
      for (int col = 1; col <= maxColumns; col++)
      {
        string patternLetterText = worksheet.Cells[1, col].Text;
        if (!string.IsNullOrWhiteSpace(patternLetterText))
        {
          if (!AllowedPatterns.Contains(patternLetterText))
            throw new CoilTrackingException($"Invalid Pattern Letters present at Column-{col}. Only A,B,C,D are allowed in Pattern sheet.");
          patternColumnLookup.Add(col, patternLetterText);
        }
      }

      //Add all the patterns to the lookup dictionary with an empty list
      patternPartModelLookup = AddPatternsToDictionary(patternPartModelLookup, patternColumnLookup);

      for (int row = 2; row <= maxRows; row++)
      {
        for (int col = 1; col <= maxColumns; col++)
        {
          string partModelString = worksheet.Cells[row, col].Text;
          if (!string.IsNullOrWhiteSpace(partModelString))
          {
            string patternLetter = patternColumnLookup[col];
            patternPartModelLookup[patternLetter].Add(partModelString);
          }
        }
      }
      return patternPartModelLookup;
    }

    private Dictionary<string, List<string>> AddPatternsToDictionary(Dictionary<string, List<string>> patternPartModelLookup, Dictionary<int, string> patternColumnLookup)
    {
      foreach (string patternLetter in patternColumnLookup.Values)
      {
        patternPartModelLookup.Add(patternLetter, new List<string>());
      }

      return patternPartModelLookup;
    }
  }
  public class ExcelResult
  {
    public Dictionary<string, Dictionary<DateTime, char>> ShiftLineDatePatternLookup { get; set; }

    public Dictionary<string, Dictionary<string, List<string>>> LineNamePatternLetterPartModelLookup { get; set; }
  }
}
