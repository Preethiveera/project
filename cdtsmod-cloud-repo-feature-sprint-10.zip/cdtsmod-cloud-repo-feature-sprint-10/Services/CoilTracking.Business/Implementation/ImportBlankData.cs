using CoilTracking.Business.Interfaces;
using CoilTracking.Business.Kentucky;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace CoilTracking.Business.Implementation
{
  public class ImportBlankData : IImportBlankData
  {
    private readonly IImportBlankInfoFactory importBlankFactory;
    private readonly IBlankInfoesRepository blankInfoRepo;
    private readonly IPressRepository pressRepo;
    private readonly ILineRepository lineRepo;
    private readonly IPartRepository partRepo;
    private readonly ICoilTypeRepository coilTypeRepo;

    private readonly IApplicationLogger<ImportBlankData> ServiceLogger;

    public ImportBlankData(IBlankInfoesRepository blankInfoRepo, ILineRepository lineRepo, IPressRepository pressRepo, ICoilTypeRepository coilTypeRepo, IPartRepository partRepo, IApplicationLogger<ImportBlankData> ServiceLogger, IImportBlankInfoFactory importBlankFactory)
    {
      this.blankInfoRepo = blankInfoRepo;
      this.pressRepo = pressRepo;
      this.lineRepo = lineRepo;
      this.partRepo = partRepo;
      this.coilTypeRepo = coilTypeRepo;
      this.ServiceLogger = ServiceLogger;
      this.importBlankFactory = importBlankFactory;

    }

    /// <summary>
    /// Enum for Excel sheet columns
    /// </summary>
    public enum Columns
    {
      DataNo = 1,
      PartNo = 2,
      CoilType = 3,
      Press = 4,
      Width = 5,
      Pitch = 6,
      StackSize = 7,
      BlankWeight = 8,
      DieNo = 9,
      Line = 10,
      MinPitch = 11,
      MaxPitch = 12,
      MinWidth = 13,
      MaxWidth = 14,
      RewindWeight = 15,
    }

    /// <summary>
    /// Blank data structure
    /// </summary>
    public struct BlankDataRecord
    {
      public string PartName;
      public string LineName;
      public string CoilTypeName;
      public string PressName;
      public int DataNumber;
      public decimal Pitch;
      public int StackSize;
      public int Width;
      public decimal Weight;
      public decimal RewindWeight;
      public decimal MinPitch;
      public decimal MaxPitch;
      public decimal MinWidth;
      public decimal MaxWidth;
      public int DieNo;
    }

    /// <summary>
    /// To import the blankInfo to excel
    /// </summary>
    /// <param name="ms"></param>
    /// <param name="userName"></param>
    /// <returns></returns>
    public List<DataImportMessage> Import(MemoryStream ms, string userName)
    {

      List<DataImportMessage> messages = new List<DataImportMessage>();

      using (var package = GetPackageFromMemoryStreamForBlanks(ms, messages))
      {
        if (package != null && package.Workbook != null && package.Workbook.Worksheets.Count > 0)
        {
          ServiceLogger.LogInformation(Constant.classname + "ImportBlank" + Constant.methodname + "Import" + Constant.message + "To import the memory stream ");

          //Data expected only in first worksheet or a worksheet named Data
          ExcelWorksheet worksheet = package.Workbook.Worksheets.Where(ws => string.Equals(ws.Name, "Data", StringComparison.InvariantCultureIgnoreCase)).DefaultIfEmpty(package.Workbook.Worksheets.First()).FirstOrDefault();
          List<DataImportMessage> newMessages = ImportData(worksheet, userName);
          messages.AddRange(newMessages);
        }
        else
        {
          ServiceLogger.LogInformation(Constant.classname + "ImportBlank" + Constant.methodname + "Import" + Constant.message + "No valid worksheet is found ");

          messages.Add(new DataImportMessage(-1, "No valid worksheet found, make sure this is a valid XLSX (Excel 2007+) file", DataImportMessage.MsgType.Error));
        }
      }

      return messages;
    }

    public  ExcelPackage GetPackageFromMemoryStreamForBlanks(MemoryStream ms, List<DataImportMessage> errors)
    {
      ExcelPackage package = null;

      try
      {
        package = new ExcelPackage(ms);
      }
      catch (Exception ex)
      {
        errors.Add(new DataImportMessage(-1, "Fatal Exception opening excel file. Make sure it is a valid xlsx file", DataImportMessage.MsgType.Error));
        errors.Add(new DataImportMessage(-1, ex.ToString(), DataImportMessage.MsgType.ErrorDetails));
      }

      return package;
    }

    /// <summary>
    /// Imports data
    /// </summary>
    /// <param name="worksheet"></param>
    /// <param name="userName"></param>
    /// <returns></returns>
    public List<DataImportMessage> ImportData(ExcelWorksheet worksheet, string userName)
    {
      var getObj = importBlankFactory.Create();
      List<DataImportMessage> errors = new List<DataImportMessage>();
      int maxRows = worksheet.Dimension.End.Row;
      var line = lineRepo.GetAllLines();
      var lines = line.ToList();
      //Load lines into memory since there are not very many and to avoid querying the database on every row
      ServiceLogger.LogInformation(Constant.classname + "ImportBlank" + Constant.methodname + "ImportData" + Constant.message + "max rows=" + maxRows);

      for (int row = 2; row <= maxRows; row++)
      {
        int originalErrorCount = errors.Count;
        BlankDataRecord record = getObj.GetRecordFromRow(worksheet, errors, row);

        if (errors.Count > originalErrorCount)
        {
          //Errors on required fields, skip to next row
          continue;
        }
        BlankInfo blank = new BlankInfo
        {
          DataNumber = record.DataNumber,
          Pitch = record.Pitch,
          Width = record.Width,
          StackSize = record.StackSize,
          Weight = record.Weight,
          RewindWeight = record.RewindWeight,
          DieNo = record.DieNo,
          MinPitch = record.MinPitch,
          MaxPitch = record.MaxPitch,
          MinWidth = record.MinWidth,
          MaxWidth = record.MaxWidth,

          Part = partRepo.GetPartByName(record.PartName)
        };

        if (blank.Part == null)
        {
          errors.Add(new DataImportMessage(row, "Part Number " + record.PartName + " is missing in system", DataImportMessage.MsgType.Error));
          continue;
        }

        blank.Line = lines.FirstOrDefault(l => l.LineName == record.LineName || l.LineName == "BL" + record.LineName);
        if (blank.Line == null)
        {
          errors.Add(new DataImportMessage(row, "Line Name " + record.LineName + " is missing in system", DataImportMessage.MsgType.Error));
          continue;
        }

        blank.CoilType = coilTypeRepo.GetCoilTypeByName(record.CoilTypeName);
        if (blank.CoilType == null)
        {
          errors.Add(new DataImportMessage(row, "Coil Type " + record.CoilTypeName + " is missing in system", DataImportMessage.MsgType.Error));
          continue;
        }

        GetPresssNameForImport(record, blank, errors, row);

        try
        {
          blankInfoRepo.AddNewBlankInfo(blank);
        }
        catch (Exception)
        {
          var blankInfoByDataNum = blankInfoRepo.GetBlankInfoByDataNumber(blank.DataNumber);
          //Do not report error if its because of duplicate data number entry
          CheckErrorForBlankInfo(errors, row, blank, blankInfoByDataNum);

          blankInfoRepo.RemoveBlankInfo(blank);
        }

      }

      return errors;
    }

    public void CheckErrorForBlankInfo(List<DataImportMessage> errors, int row, BlankInfo blank, List<BlankInfo> blankInfoByDataNum)
    {
      if (blankInfoByDataNum.Count == 0)
      {
        errors.Add(new DataImportMessage(row, "Unidentified database error occured while saving the data", DataImportMessage.MsgType.Error));
      }
      else
      {
        errors.Add(new DataImportMessage(row, "Duplicate data number exists for '" + blank.DataNumber + "' please manually edit it.", DataImportMessage.MsgType.Notification));
      }

    }
    /// <summary>
    /// Get Press details for blankInfo import
    /// </summary>
    /// <param name="record"></param>
    /// <param name="blank"></param>
    /// <param name="errors"></param>
    /// <param name="row"></param>
    public void GetPresssNameForImport(BlankDataRecord record, BlankInfo blank, List<DataImportMessage> errors, int row)
    {
      if (!string.IsNullOrWhiteSpace(record.PressName))
      {
        blank.Press = pressRepo.GetPressByName(record.PressName);
        if (blank.Press == null)
        {
          var press = new Press() { Name = record.PressName };
          pressRepo.AddNewPress(press);
          blank.Press = press;
          errors.Add(new DataImportMessage(row, "New Press " + record.PressName + " added to system", DataImportMessage.MsgType.Notification));
        }
      }
    }


  }
}
