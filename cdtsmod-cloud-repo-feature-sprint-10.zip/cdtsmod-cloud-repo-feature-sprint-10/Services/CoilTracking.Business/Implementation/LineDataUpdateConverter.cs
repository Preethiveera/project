using CoilTracking.DTO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;

namespace CoilTracking.Business.Implementation
{
  public class LineDataUpdateConverter : JsonConverter
  {
    private readonly string[] _tags;

    public LineDataUpdateConverter(string[] tags)
    {
      this._tags = tags;
    }

    public override bool CanConvert(Type objectType)
    {
      return (objectType == typeof(DataUpdateDto));
    }

    public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
    {
      JObject jo = JObject.Load(reader);
      DataUpdateDto dto = new DataUpdateDto();
      dto.Die = (int)jo[_tags[0]];
      dto.CoilODWarning = (bool)jo[_tags[6]];
      dto.IsNew = false;
      dto.StackerVals = new Dictionary<string, StackerContainer>();
      dto.DownTimeVals = new Dictionary<string, DownTimeContainer>();
      for (int i = 1; i <= 5; i++)
      {
        StackerContainer container = new StackerContainer()
        {
          Tag = _tags[i],
          CurVal = (int)jo[_tags[i]]
        };
        dto.StackerVals.Add(_tags[i], container);
      }

      for (int j = 7; j <= 13; j++)
      {
        DownTimeContainer container = new DownTimeContainer()
        {
          Tag = _tags[j],
          Flag = (bool)jo[_tags[j]]
        };
        dto.DownTimeVals.Add(_tags[j], container);
      }

      return dto;
    }

    public override bool CanWrite
    {
      get { return false; }
    }

    public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
    {
      throw new NotImplementedException();
    }
  }
}
