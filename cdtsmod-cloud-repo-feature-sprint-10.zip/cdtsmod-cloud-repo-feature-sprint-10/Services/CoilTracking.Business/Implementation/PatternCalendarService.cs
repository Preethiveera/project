using AutoMapper;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class PatternCalendarService : IPatternCalendarService
  {
    private readonly IPatternCalendarRepository patternCalendarRepository;
    private readonly ILineRepository lineRepository;
    private readonly IShiftRepository shiftRepository;

    private readonly IApplicationLogger<PatternCalendarService> patternCalendarServiceLogger;

    private readonly IMapper mapper;

    public PatternCalendarService(IPatternCalendarRepository patternCalendarRepository, ILineRepository lineRepository,
      IShiftRepository shiftRepository, IApplicationLogger<PatternCalendarService> patternCalendarServiceLogger, IMapper mapper)
    {
      this.patternCalendarRepository = patternCalendarRepository;
      this.lineRepository = lineRepository;
      this.shiftRepository = shiftRepository;
      this.patternCalendarServiceLogger = patternCalendarServiceLogger;
      this.mapper = mapper;
    }


    /// <summary>
    /// Get pattern calendars
    /// </summary>
    /// <returns>List of CalendarItemDto</returns>
    public List<CalendarItemDto> GetPatternCalendars()
    {
      var calendarItems = new List<CalendarItemDto>();
      DateTime localDate = DateTime.Now;
      int daysInMonth = DateTime.DaysInMonth(localDate.Year, localDate.Month);


      for (int i = 1; i <= daysInMonth; i++)
      {
        var calendarItem = new CalendarItemDto();

        calendarItems.Add(calendarItem);
      }
      patternCalendarServiceLogger.LogInformation(Constant.classname + "PatternCalendarService" + Constant.methodname + "GetPatternCalendars"
        + Constant.message + "To get the List of Calendar items.");
      return calendarItems;
    }


    /// <summary>
    /// Get pattern calendar for for export
    /// </summary>
    /// <returns>PatternCalendarExport</returns>
    public async Task<PatternCalendarExportDto> GetPatternCalendarsForExport()
    {

      int month = DateTime.Today.Month;
      int year = DateTime.Today.Year;
      int monthPre = month > 1 ? month - 1 : 12;
      int yearPre = month > 1 ? year : year - 1;

      var patternCalendars = await patternCalendarRepository.GetPatternCalendarByMonthAndYear(monthPre, yearPre);

      var exportList = patternCalendars.GroupBy(p => new { p.Line, p.Shift }).Select(e => new ExportDto()
      {
        LineShift = e.Key.Line.LineName,
        Shift = e.Key.Shift.Name,
        Calendars = e.OrderBy(p => p.Date).Select(p => p.PatternLetter)
      }).OrderBy(g => g.LineShift).ThenBy(g => g.Shift).ToList();

      exportList.ForEach(e => e.LineShift = $"{e.LineShift} {e.Shift}");

      var dateList = new List<string>();
      for (int i = 1; i <= DateTime.DaysInMonth(yearPre, monthPre); i++)
      {
        dateList.Add(new DateTime(yearPre, monthPre, i).ToShortDateString());
      }

      var exportListFinal = new PatternCalendarExportDto { Data = exportList, DateList = dateList };

      patternCalendarServiceLogger.LogInformation(Constant.classname + "PatternCalendarService" + Constant.methodname + "GetPatternCalendarsForExport"
        + Constant.message + "To get the List of pattern calendar export.");
      return exportListFinal;
    }

    /// <summary>
    /// Get pattern calendar by id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>PatternCalendarDto</returns>
    public async Task<PatternCalendarDto> GetPatternCalendar(int id)
    {
      var patterCalendar = await patternCalendarRepository.GetPatternCalendarById(id);

      var patterCalendarDto = mapper.Map<PatternCalendarDto>(patterCalendar);

      patternCalendarServiceLogger.LogInformation(Constant.classname + "PatternCalendarService" + Constant.methodname + "GetPatternCalendar"
        + Constant.message + "To get the pattern calendar.");

      return patterCalendarDto;
    }


    /// <summary>
    /// Get pattern calendar by line id, shift id and date. 
    /// </summary>
    /// <param name="localDate"></param>
    /// <param name="lineId"></param>
    /// <param name="shiftId"></param>
    /// <returns>List of CalendarItemDto</returns>
    public async Task<List<CalendarItemDto>> GetPatternCalendar(DateTime localDate, int lineId, int shiftId)
    {

      var patternCalendars = await patternCalendarRepository
        .GetPatternCalendarByMonthYearShiftIdLineId(localDate.Month, localDate.Year, shiftId, lineId);

      if (patternCalendars == null || patternCalendars.Count == 0)
      {
        patternCalendars = await GeneratePatternCalendarItem(localDate, lineId, shiftId);
      }

      var calendarItems = new List<CalendarItemDto>();

      if (patternCalendars != null)
      {
        foreach (PatternCalendar patternCalendar in patternCalendars)
        {

          var calendarItem = new CalendarItemDto
          {
            Id = patternCalendar.Id,
            Title = patternCalendar.PatternLetter,
            Start = patternCalendar.Date.Add(patternCalendar.Shift.Start),
            End = patternCalendar.Date.Add(patternCalendar.Shift.Finish),
            AllDay = true,
            LineId = patternCalendar.Line.Id,
            ShiftId = patternCalendar.Shift.Id,
            ShiftName = patternCalendar.Shift.Name
          };
          calendarItems.Add(calendarItem);
        }
      }
      patternCalendarServiceLogger.LogInformation(Constant.classname + "PatternCalendarService" + Constant.methodname + "GetPatternCalendar"
        + Constant.message + "To get the pattern calendar items.");

      return calendarItems;
    }

    private async Task<List<PatternCalendar>> GeneratePatternCalendarItem(DateTime localDate, int lineId,int shiftId)
    {
      int daysInMonth = DateTime.DaysInMonth(localDate.Year, localDate.Month);
      var patternCalendars = new List<PatternCalendar>();
      var Line = mapper.Map<Line>(await lineRepository.GetLineByLineIDAsync(lineId));
      var Shift = mapper.Map<Shift>(await shiftRepository.GetShiftByIdAsync(shiftId));
      for (int i = 1; i <= daysInMonth; i++)
      {
        DateTime calendarDate = new DateTime(localDate.Year, localDate.Month, i);

        var patternCalendarItem = new PatternCalendar
        {
          Date = calendarDate,
          PatternLetter = "X",
          Line = Line,
          Shift = Shift
        };
        patternCalendars.Add(patternCalendarItem);
      }

      patternCalendarServiceLogger.LogInformation(Constant.classname + "PatternCalendarService" + Constant.methodname + "GeneratePatternCalendarItem"
        + Constant.message + "To generate the pattern calendar items.");
      var patterns = patternCalendars.Distinct().ToList();
      await patternCalendarRepository.AddPatternCalendar(patterns);

      return patternCalendars;
    }

    /// <summary>
    /// Change pattern
    /// </summary>
    /// <param name="id"></param>
    /// <param name="patternLetter"></param>
    /// <returns>bool</returns>
    public async Task<bool> ChangePattern(int id, string patternLetter)
    {
      var patternCalendar = await patternCalendarRepository.GetPatternCalendarById(id);

      if (patternCalendar == null)
      {
        throw new CoilTrackingException
        {
          ErrorMessage = ApplicationMessages.patternCalendarNotFound,
          HttpStatusCode = "NotFound"
        };
      }

      patternCalendar.PatternLetter = patternLetter;

      var updated = await patternCalendarRepository.UpdatePatternCalendar(patternCalendar);

      patternCalendarServiceLogger.LogInformation(Constant.classname + "PatternCalendarService" + Constant.methodname + "ChangePattern"
       + Constant.message + "To change the pattern.");

      return updated;
    }

    /// <summary>
    /// Put pattern calendar
    /// </summary>
    /// <param name="patternCalendarDto"></param>
    /// <returns>bool</returns>
    public async Task<bool> PutPatternCalendar(PatternCalendarDto patternCalendarDto)
    {
      if (!PatternCalendarExists(patternCalendarDto.Id))
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.patternCalendarNotFound, HttpStatusCode = "NotFound" };
      }

      var patternCalendar = mapper.Map<PatternCalendar>(patternCalendarDto);

      var updated = await patternCalendarRepository.UpdatePatternCalendar(patternCalendar);

      patternCalendarServiceLogger.LogInformation(Constant.classname + "PatternCalendarService" + Constant.methodname + "PutPatternCalendar"
       + Constant.message + "To put the pattern calender.");

      return updated;
    }


    /// <summary>
    /// Post pattern calendar
    /// </summary>
    /// <param name="patternCalendarDto"></param>
    /// <returns>PatternCalendarDto</returns>
    public async Task<PatternCalendarDto> PostPatternCalendar(PatternCalendarDto patternCalendarDto)
    {
      var patternCalendar = mapper.Map<PatternCalendar>(patternCalendarDto);

      var result = mapper.Map<PatternCalendarDto>(await patternCalendarRepository.AddPatternCalendar(patternCalendar));

      patternCalendarServiceLogger.LogInformation(Constant.classname + "PatternCalendarService" + Constant.methodname + "PostPatternCalendar"
       + Constant.message + "To post the pattern calender.");

      return result;
    }

    /// <summary>
    /// Delete pattern calendar.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>PatternCalendarDto</returns>
    public async Task<PatternCalendarDto> DeletePatternCalendar(int id)
    {
      PatternCalendar patternCalendar = await patternCalendarRepository.GetPatternCalendarById(id);

      if (patternCalendar == null)
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.patternCalendarNotFound, HttpStatusCode = "NotFound" };
      }

      await patternCalendarRepository.RemovePatternCalendar(patternCalendar);

      var patternCalendarDto = mapper.Map<PatternCalendarDto>(patternCalendar);

      patternCalendarServiceLogger.LogInformation(Constant.classname + "PatternCalendarService" + Constant.methodname + "DeletePatternCalendar"
      + Constant.message + "To delete the pattern calender.");

      return patternCalendarDto;
    }


    /// <summary>
    /// Check if pattern calendar exist or not.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>bool</returns>
    public bool PatternCalendarExists(int id)
    {
      var coilFieldZone = patternCalendarRepository.GetPatternCalendarById(id);
      patternCalendarServiceLogger.LogInformation(Constant.classname + "PatternCalendarService" + Constant.methodname
        + "PatternCalendarExists" + Constant.message + "Check if a Pattern Calendar exists");

      if (coilFieldZone != null)
        return true;
      return false;
    }
  }
}
