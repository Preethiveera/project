using AutoMapper;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Exception;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class BlankInfoService : IBlankInfoService
  {
    private readonly IBlankInfoesRepository blankInfoRepo;
    private readonly IPlantsRepository plantRepo;
    private readonly ILineRepository lineRepo;
    private readonly IPartRepository partRepo;
    private readonly ICoilTypeRepository coilTypeRepo;
    private readonly IRunOrderRepository runOrderRepo;
    private readonly IMapper mapper;
    private readonly IIncompleteRunOrderItemRepository incompleteRunOrderItemRepo;
    private readonly IRunOrderListQuantityRepository runOrderListQuantityRepo;
    public BlankInfoService(IBlankInfoesRepository blankInfoRepo, IRunOrderRepository runOrderRepo, ICoilTypeRepository coilTypeRepo, IPartRepository partRepo, ILineRepository lineRepo, IPlantsRepository plantRepo, IMapper mapper, IIncompleteRunOrderItemRepository incompleteRunOrderItemRepo, IRunOrderListQuantityRepository runOrderListQuantityRepo)
    {
      this.blankInfoRepo = blankInfoRepo;
      this.plantRepo = plantRepo;
      this.lineRepo = lineRepo;
      this.partRepo = partRepo;
      this.coilTypeRepo = coilTypeRepo;
      this.runOrderRepo = runOrderRepo;
      this.mapper = mapper;
      this.incompleteRunOrderItemRepo = incompleteRunOrderItemRepo;
      this.runOrderListQuantityRepo = runOrderListQuantityRepo;
    }



    /// <summary>
    /// Get blank info by dataNum and lineId
    /// </summary>
    /// <param name="dataNum"></param>
    /// <param name="lineId"></param>
    /// <returns>blankInfoDto</returns>
    public BlankInfo GetBlankInfoByDataNumAndLineId(int dataNum, int lineId)
    {
      var blankInfoes = blankInfoRepo.GetBlankInforByDataNumAndLineId(dataNum, lineId);
      
        return blankInfoes;
    }
    /// <summary>
    /// Get list of blank info by Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>blankInfoDto</returns>

    public BlankInfoDto GetBlankInfoById(int id)
    {
      var blankInfoes = blankInfoRepo.GetBlankInfoById(id);

      BlankInfoDto blankInfoDto = null;
      if (blankInfoes != null)
      {
        blankInfoDto = new BlankInfoDto
        {
          Id = blankInfoes.Id,
          LineId = blankInfoes.Line.Id,
          MaxPitch = blankInfoes.MaxPitch,
          MaxWidth = blankInfoes.MaxWidth,
          MinPitch = blankInfoes.MinPitch
        };
        blankInfoDto.MaxWidth = blankInfoes.MaxWidth;
        blankInfoDto.PartId = blankInfoes.Part.Id;
        blankInfoDto.Pitch = blankInfoes.Pitch;
        blankInfoDto.StackSize = blankInfoes.StackSize;
        blankInfoDto.Weight = blankInfoes.Weight;
        blankInfoDto.Width = blankInfoes.Width;
        blankInfoDto.Disabled = blankInfoes.Disabled;
        blankInfoDto.DieNo = blankInfoes.DieNo;
        blankInfoDto.DataNumber = blankInfoes.DataNumber;
        blankInfoDto.CoilTypeId = blankInfoes.CoilType.Id;
        blankInfoDto.RewindWeight = blankInfoes.RewindWeight;
        blankInfoDto.MinWidth = blankInfoes.MinWidth;
        return blankInfoDto;
      }

      return blankInfoDto;
    }


    /// <summary>
    /// Get the list of BlankInfoes
    /// </summary>
    /// <returns>blankInfoDto</returns>
    public IQueryable<BlankInfo> GetAllBlankInfo()
    {
      var blankInfoes = blankInfoRepo.GetAllBlankInfo();
      
      return blankInfoes.AsQueryable();
    }

    /// <summary>
    /// Get the NAMC code
    /// </summary>
    /// <returnsNamc code></returns>
    public string GetNAMCinfo()
    {
      var namcCode = plantRepo.GetPlantName();
      return namcCode;
    }

    /// <summary>
    /// Check if blank info has any dependency
    /// </summary>
    /// <param name="id"></param>
    /// <returns> bool </returns>
    public bool IsBlankInfoDependent(int id)
    {
      var dependencyCheck = blankInfoRepo.GetDependencyForBlankInfo(id);
      if (dependencyCheck.Count > 0)
      {
        return true;
      }
      return false;
    }
    /// <summary>
    /// Add new BlankInfo
    /// </summary>
    /// <param name="blankInfo"></param>
    /// <returnsbool></returns>
    public Task<bool> AddNewBlankInfo(BlankInfoDto blankInfoDto)
    {
      BlankInfo blankInfo = new BlankInfo
      {
        Line = lineRepo.GetLineByLineID(blankInfoDto.LineId),
        MaxPitch = blankInfoDto.MaxPitch,
        MaxWidth = blankInfoDto.MaxWidth,
        MinPitch = blankInfoDto.MinPitch,
        MinWidth= blankInfoDto.MinWidth
      };
      blankInfo.MaxWidth = blankInfoDto.MaxWidth;
      blankInfo.Part = partRepo.GetPartById(blankInfoDto.PartId);
      blankInfo.Pitch = blankInfoDto.Pitch;
      blankInfo.StackSize = blankInfoDto.StackSize;
      blankInfo.Weight = blankInfoDto.Weight;
      blankInfo.Width = blankInfoDto.Width;
      blankInfo.Disabled = blankInfoDto.Disabled;
      blankInfo.DieNo = blankInfoDto.DieNo;
      blankInfo.DataNumber = blankInfoDto.DataNumber;
      blankInfo.CoilType = coilTypeRepo.GetCoilTypeById(blankInfoDto.CoilTypeId);
      blankInfo.RewindWeight = blankInfoDto.RewindWeight;


      blankInfoRepo.AddNewBlankInfo(blankInfo);
      blankInfoDto.Id = blankInfo.Id;
      return Task.FromResult(true);
    }

    /// <summary>
    /// Check if model is edited while deleting the record
    /// </summary>
    /// <param name="id"></param>
    /// <param name="dto"></param>
    /// <returns>bool</returns>
    public Task<bool> CheckEdit(int id, BlankInfoDto blankInfoDto)
    {
      BlankInfo blankInfo = new BlankInfo
      {
        Line = lineRepo.GetLineByLineID(blankInfoDto.LineId),
        MaxPitch = blankInfoDto.MaxPitch,
        MaxWidth = blankInfoDto.MaxWidth,
        MinPitch = blankInfoDto.MinPitch,
        MinWidth=blankInfoDto.MinWidth
      };
      blankInfo.MaxWidth = blankInfoDto.MaxWidth;
      blankInfo.Part = partRepo.GetPartById(blankInfoDto.PartId);
      blankInfo.Pitch = blankInfoDto.Pitch;
      blankInfo.StackSize = blankInfoDto.StackSize;
      blankInfo.Weight = blankInfoDto.Weight;
      blankInfo.Width = blankInfoDto.Width;
      blankInfo.Disabled = blankInfoDto.Disabled;
      blankInfo.DieNo = blankInfoDto.DieNo;
      blankInfo.DataNumber = blankInfoDto.DataNumber;
      blankInfo.RewindWeight = blankInfoDto.RewindWeight;
      blankInfo.CoilType = coilTypeRepo.GetCoilTypeById(blankInfoDto.CoilTypeId);
      var blankInfoFromDB = blankInfoRepo.GetBlankInfoById(id);
      bool flag = false;
      if (blankInfoFromDB != null)
      {
        if (blankInfoFromDB.Line.Id != blankInfo.Line.Id ||
            blankInfoFromDB.MaxPitch != blankInfo.MaxPitch ||
            blankInfoFromDB.MaxWidth != blankInfo.MaxWidth ||
            blankInfoFromDB.MinPitch != blankInfo.MinPitch ||
            blankInfoFromDB.MinWidth != blankInfo.MinWidth ||
            blankInfoFromDB.Part.Id != blankInfo.Part.Id ||
            blankInfoFromDB.Pitch != blankInfo.Pitch ||
            blankInfoFromDB.StackSize != blankInfo.StackSize ||
            blankInfoFromDB.Weight != blankInfo.Weight ||
            blankInfoFromDB.Width != blankInfo.Width ||
            blankInfoFromDB.DataNumber != blankInfo.DataNumber ||
            blankInfoFromDB.RewindWeight != blankInfo.RewindWeight ||
        blankInfoFromDB.DieNo != blankInfo.DieNo || blankInfoFromDB.Disabled != blankInfo.Disabled || blankInfoFromDB.CoilType.Id != blankInfo.CoilType.Id)
        {
          
          return Task.FromResult(flag);

        }
       
      }

      return Task.FromResult(true);
    }

    /// <summary>
    /// To check if blankInfo is present in  scheduled RunOrder
    /// </summary>
    /// <param name="blankInfoId"></param>
    /// <returns>bool</returns>
    public bool IsScheduledOnRunOrder(int blankInfoId)
    {
      //If we are disabling the blank, does any RunOrderLists exist with a RunOrderListQuantity listing this blankinfo.id for today/the future? If so we can't allow disabling it
      return runOrderRepo.IsScheduledOnRunOrder(blankInfoId);

    }

    /// <summary>
    /// To update an existing Blankinfo
    /// </summary>
    /// <param name="id"></param>
    /// <param name="blankInfoDto"></param>
    public void UpdateBlankInfo(int id, BlankInfoDto blankInfoDto)
    {
      if (blankInfoDto.Disabled && IsScheduledOnRunOrder(id))
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.disableBlankInfo, HttpStatusCode = "BadRequest" };

      }

      BlankInfo blankInfo = blankInfoRepo.GetBlankInfoById(id);

      blankInfo.RewindWeight = blankInfoDto.RewindWeight;
      blankInfo.Line = lineRepo.GetLineByLineID(blankInfoDto.LineId);
      blankInfo.MaxPitch = blankInfoDto.MaxPitch;
      blankInfo.MinWidth = blankInfoDto.MinWidth;
      blankInfo.MaxWidth = blankInfoDto.MaxWidth;
      blankInfo.MinPitch = blankInfoDto.MinPitch;
      blankInfo.MaxWidth = blankInfoDto.MaxWidth;
      blankInfo.Part = partRepo.GetPartById(blankInfoDto.PartId);
      blankInfo.Pitch = blankInfoDto.Pitch;
      blankInfo.StackSize = blankInfoDto.StackSize;
      blankInfo.Weight = blankInfoDto.Weight;
      blankInfo.Width = blankInfoDto.Width;
      blankInfo.Disabled = blankInfoDto.Disabled;
      blankInfo.DieNo = blankInfoDto.DieNo;
      blankInfo.DataNumber = blankInfoDto.DataNumber;
      blankInfo.CoilType = coilTypeRepo.GetCoilTypeById(blankInfoDto.CoilTypeId);


      try
      {
        blankInfoRepo.UpdateBlankInfo(blankInfo);
      }

      catch (DbUpdateConcurrencyException)
      {
        if (!BlankInfoExists(id))
        {
          throw new CoilTrackingException { HttpStatusCode = "NotFound" };

        }
        else
        {
          throw;
        }
      }
    }

    /// <summary>
    /// To check if the blankInfo id is present in DB
    /// </summary>
    /// <param name="id"></param>
    /// <returns>bool</returns>
    public bool BlankInfoExists(int id)
    {
      var blankInfoCount = blankInfoRepo.GetBlankInfoById(id);
      if (blankInfoCount == null)
        return false;
      return true;
    }

    /// <summary>
    /// Disable blankInfo
    /// </summary>
    /// <param name="id"></param>
    /// <param name="disable"></param>
    public void DisableBlankInfo(int id, bool disable)
    {
      if (disable && IsScheduledOnRunOrder(id))
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.disableBlankInfo, HttpStatusCode = "BadRequest" };

      }

      if (!BlankInfoExists(id))
      {
        throw new CoilTrackingException { HttpStatusCode = "NotFound" };

      }

      blankInfoRepo.DisableBlankInfo(id, disable);

    }

    /// <summary>
    /// Delete BlankInfo
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public BlankInfoDto DeleteBlankInfo(int id)
    {

      if (IsScheduledOnRunOrder(id))
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.disableBlankInfo, HttpStatusCode = "BadRequest" };
      }
      var blankInfoes = blankInfoRepo.GetBlankInfoById(id);


      if (blankInfoes == null)
      {
        throw new CoilTrackingException { HttpStatusCode = "NotFound" };
      }

      blankInfoRepo.DeleteBlankInfo(id);
      BlankInfoDto blankInfoDto = new BlankInfoDto();
      if (blankInfoes != null)
      {
        blankInfoDto.Id = blankInfoes.Id;
        blankInfoDto.LineId = blankInfoes.Line.Id;
        blankInfoDto.MaxPitch = blankInfoes.MaxPitch;
        blankInfoDto.MaxWidth = blankInfoes.MaxWidth;
        blankInfoDto.MinPitch = blankInfoes.MinPitch;
        blankInfoDto.MaxWidth = blankInfoes.MaxWidth;
        blankInfoDto.PartId = blankInfoes.Part.Id;
        blankInfoDto.Pitch = blankInfoes.Pitch;
        blankInfoDto.StackSize = blankInfoes.StackSize;
        blankInfoDto.Weight = blankInfoes.Weight;
        blankInfoDto.Width = blankInfoes.Width;
        blankInfoDto.Disabled = blankInfoes.Disabled;
        blankInfoDto.DieNo = blankInfoes.DieNo;
        blankInfoDto.DataNumber = blankInfoes.DataNumber;
        blankInfoDto.CoilTypeId = blankInfoes.CoilType.Id;
        blankInfoDto.RewindWeight = blankInfoes.RewindWeight;
      }
      return blankInfoDto;
    }
    /// <summary>
    /// Get BlankInfo
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<List<BlankInfoDto>> GetBlankInfoByPartId(int id)
    {
      var blankinfo = await blankInfoRepo.GetBlankInfoByPartId(id);
      var blankinfoDto = mapper.Map<List<BlankInfoDto>>(blankinfo);
      return blankinfoDto;

    }
    /// <summary>
    /// Get BlankInfo Parts InRunOrder
    /// </summary>
    /// <returns></returns>
    public async Task<List<BlankInfoDto>> GetBlankInfoPartsInRunOrder(int id)
    {
      List<BlankInfo> blanksData = new List<BlankInfo>();
      var blankinfoPart = await blankInfoRepo.GetBlankInfoByPartId(id);
      if (blankinfoPart != null && blankinfoPart.Count > 0)
      {
        List<BlankInfo> blanks = blankinfoPart;
        List<int> blankids = new List<int>();

        var items = await GetBlankInfoRunOrder(blanks);
        var blanksInfo = items.Select(x => x.RunOrderItem.BlankInfo.Id).Distinct().ToList();
        blankids.AddRange(blanksInfo);
        var distinctsIds = blankids.Select(x => x).Distinct().ToList();
        var blankinfos = blankInfoRepo.GetBlanksByDataIdList(distinctsIds);
        blanksData.AddRange(blankinfos);

      }
      var blanksInfoDtos = mapper.Map<List<BlankInfoDto>>(blanksData);
      return blanksInfoDtos;
    }
    /// <summary>
    /// Get BlankInfoRunOrder
    /// </summary>
    /// <param name="blanks"></param>
    /// <returns></returns>
    public async Task<List<IncompleteRunOrderItem>> GetBlankInfoRunOrder(List<BlankInfo> blanks)
    {
      List<IncompleteRunOrderItem> blanksInfo = new List<IncompleteRunOrderItem>();
      var incompleteRunOrderItems = await incompleteRunOrderItemRepo.GetIncompleteRunOrderItems();
      if (incompleteRunOrderItems != null && incompleteRunOrderItems.Count > 0)
      {
        var runorders = runOrderListQuantityRepo.GetRunOrderListQuantityByListBlankInfo(blanks);
        foreach (BlankInfo blank in blanks)
        {
          var runorder = runorders.Where(x => x.BlankInfo.Id == blank.Id).ToList();
          foreach (var run in runorder)
          {
             blanksInfo = incompleteRunOrderItems.Where(i => i.RunOrderItem.Id == run.Id && (i.Status == RunOrderItemStatus.Incomplete
           || i.Status == RunOrderItemStatus.RunStarted || i.Status == RunOrderItemStatus.New
           || i.Status == RunOrderItemStatus.CarriedOver)).Distinct().ToList();
          }
        }        
      }
      return blanksInfo;
    }


  }
}
