using AutoMapper;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class RunOrderListService : IRunOrderListService
  {
    private readonly IRunOrderRepository runOrderListRepo;
    private readonly ICoilRepository coilRepo;
    private readonly IShiftRepository shiftRepo;
    private readonly ILineRepository lineRepo;
    private readonly IPartRepository partRepo;
    private readonly IBlankInfoesRepository blanksRepo;
    private readonly IPatternsRepository patternsRepo;
    private readonly IProdPlanRepository prodPlanRepo;
    private readonly IRunResultsRepository runResultRepo;
    private readonly ICoilRunHistoryRepository coilRunHistoryRepo;
    private readonly IPatternCalendarRepository patternCalendarRepo;
    private readonly IRunOrderListQuantityRepository runOrderListQuantityRepo;
    private readonly IApplicationLogger<RunOrderListService> runOrderListServiceLogger;
    private readonly IMapper mapper;
    private readonly string[] errorList = { "ROL001", "ROL002", "ROL003" };
    private readonly IWebSocketClientService webSocketClientService;

    public RunOrderListService(IRunOrderRepository runOrderListRepo, IRunOrderListQuantityRepository runOrderListQuantityRepo,
      IRunResultsRepository runResultRepo, ICoilRunHistoryRepository coilRunHistoryRepo, ILineRepository lineRepo,
      IShiftRepository shiftRepo, IPatternsRepository patternsRepo, IProdPlanRepository prodPlanRepo,
      IPatternCalendarRepository patternCalendarRepo, IBlankInfoesRepository blanksRepo, IPartRepository partRepo,
      ICoilRepository coilRepo, IApplicationLogger<RunOrderListService> runOrderListServiceLogger, IMapper mapper,
      IWebSocketClientService webSocketClientService)
    {
      this.mapper = mapper;
      this.coilRepo = coilRepo;
      this.runOrderListRepo = runOrderListRepo;
      this.partRepo = partRepo;
      this.blanksRepo = blanksRepo;
      this.patternCalendarRepo = patternCalendarRepo;
      this.prodPlanRepo = prodPlanRepo;
      this.patternsRepo = patternsRepo;
      this.shiftRepo = shiftRepo;
      this.lineRepo = lineRepo;
      this.coilRunHistoryRepo = coilRunHistoryRepo;
      this.runResultRepo = runResultRepo;
      this.runOrderListQuantityRepo = runOrderListQuantityRepo;
      this.runOrderListServiceLogger = runOrderListServiceLogger;
      this.webSocketClientService = webSocketClientService;

    }

    /// <summary>
    /// Get list of runOrderLists
    /// </summary>
    /// <returns>RunOrderListForGet</returns>
    public async Task<List<RunOrderListForGet>> GetRunOrderLists()
    {
      var runOrderList = await runOrderListRepo.GetRunOrderListsAsync();
      var runOrderListDto = mapper.Map<List<RunOrderList>, List<RunOrderListForGet>>(runOrderList);
      runOrderListServiceLogger.LogInformation(Constant.classname + "RunOrderListService" + Constant.methodname + "GetRunOrderList" + Constant.message + "Get List of all runorderlist");
      return runOrderListDto;
    }

    /// <summary>
    /// Get RunOrderList by Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>runorderListForGet</returns>
    public async Task<RunOrderListForGet> GetRunOrderListById(int id)
    {
      var runOrderList = await runOrderListRepo.GetRunOrderListByIdAsync(id);
      runOrderListServiceLogger.LogInformation(Constant.classname + "RunOrderListService" + Constant.methodname + "GetRunOrderListById" + Constant.message + "Get List of all runorderlist by Id");

      var runOrderListDto = mapper.Map<RunOrderListForGet>(runOrderList);
      await webSocketClientService.RunOrderListUpdated(runOrderList.Line.Id, runOrderList.Id);
      return runOrderListDto;
    }

    /// <summary>
    /// Get the totalWeightRemaining of coils  by coilTypeId
    /// </summary>
    /// <param name="coilTypeId"></param>
    /// <returns>totalWeightRemaining</returns>
    public async Task<int> GetCoilTypeUsableWeight(int coilTypeId)
    {
      var coils = await coilRepo.CoilsInventoryBYTypeId(coilTypeId);

      var totalWeightRemaining = coils.Sum(c => c.CurrentWeight);
      runOrderListServiceLogger.LogInformation(Constant.classname + "RunOrderListService" + Constant.methodname + "GetCoilTypeUsableWeight" + Constant.message + "Get List of all coils weight");

      return totalWeightRemaining;
    }

    /// <summary>
    /// To check if RunOrderList exists
    /// </summary>
    /// <param name="id"></param>
    /// <returns>bool</returns>
    public bool RunOrderListExists(int id)
    {
      var runOrderListExists = runOrderListRepo.RunOrderListExists(id);
      runOrderListServiceLogger.LogInformation(Constant.classname + "RunOrderListService" + Constant.methodname + "RunOrderListExists" + Constant.message + "Check if run order list exists");

      return runOrderListExists;
    }

    /// <summary>
    /// Convert RunOrderList For CreateDto 
    /// </summary>
    /// <param name="runOrderList"></param>
    /// <param name="runOrderListDto"></param>
    public void GetRunOrderListForCreateDto(RunOrderList runOrderList, ref RunOrderListForCreate runOrderListDto)
    {
      runOrderListDto.Id = runOrderList.Id;
      runOrderListDto.PatternLetter = runOrderList.PatternLetter;

      //Get blank by partNum  list and LineId
      var partnumList = runOrderList.Quantities.Select(x => x.Part.PartNumber).Distinct().ToList();
      var blankInfoList = blanksRepo.GetListByPartnumberLineIds(partnumList, runOrderList.Line.Id);

      var prodPlanList = prodPlanRepo.GetProdPlanByPartnumberList(partnumList);

      // to get coils by coil types list
      var coilTypesList = blankInfoList.Select(c => c.CoilType.Id).Distinct().ToList();
      var coils = coilRepo.GetCoilsList(coilTypesList);

      foreach (RunOrderListQuantity runOrderItem in runOrderList.Quantities)
      {
        RunOrderItemForCreate runOrderEntry = new RunOrderItemForCreate
        {
          Id = runOrderItem.Id,
          PartNumber = runOrderItem.Part.PartNumber,
          PartName = runOrderItem.Part.PartName,
          ModelList = partRepo.GetModelList(runOrderItem.Part.PartNumber),
          Blanks = new List<DataNumberDto>()
        };

        List<BlankInfo> blanks = blankInfoList.Where(x => x.Part.PartNumber == runOrderItem.Part.PartNumber && x.Line.Id == runOrderList.Line.Id).ToList();
        runOrderListServiceLogger.LogInformation(Constant.classname + "RunOrderListService" + Constant.methodname + "GetRunOrderListForCreateDto" + Constant.message + "Get blanks by part no and line Id");

        foreach (BlankInfo blank in blanks)
        {
          DataNumberDto dataNumberDto = new DataNumberDto
          {
            Id = blank.Id,
            DataNumber = blank.DataNumber,
            CoilType = blank.CoilType.Name,
            CoilTypeId = blank.CoilType.Id
          };
          // To get the remaining weight for the coil type
          runOrderListServiceLogger.LogInformation(Constant.classname + "RunOrderListService" + Constant.methodname + "GetRunOrderListForCreateDto" + Constant.message + "Get coil type usable weight");

          var coilsbyCoilType = coils.Where(c => c.CoilType.Id == blank.CoilType.Id).ToList();
          var totalWeightRemaining = coilsbyCoilType.Sum(c => c.CurrentWeight);

          dataNumberDto.CoilRemaining = totalWeightRemaining * blank.CoilType.Yield;
          dataNumberDto.BlankWeight = blank.Weight;
          dataNumberDto.StackSize = blank.StackSize;
          runOrderEntry.Blanks.Add(dataNumberDto);
        }

        runOrderEntry.RequestQuantity = prodPlanList.Where(l => l.Part.PartNumber == runOrderItem.Part.PartNumber).Select(l => l.LotSize).FirstOrDefault();

        runOrderEntry.SortOrder = runOrderItem.SortOrder;
        runOrderEntry.OverrideQuantity = runOrderItem.OverrideQty;
        runOrderListDto.RunOrderItems.Add(runOrderEntry);
      }
    }

    /// <summary>
    /// Get ModelsList
    /// </summary>
    /// <param name="part"></param>
    /// <param name="partModels"></param>
    /// <returns></returns>
    public string GetModelListFromPart(Part part, List<PartModel> partModels)
    {
      List<string> partModel = partModels.Where(p => p.Part.PartNumber == part.PartNumber).Select(p => p.Model.ModelNumber).OrderBy(modelNum => modelNum).ToList();
      string modelList = string.Join("/", partModel);
      return modelList;
    }

    /// <summary>
    /// Get Incomplete RunOrderItems by line Id
    /// </summary>
    /// <param name="lineId"></param>
    /// <param name="runOrderItems"></param>
    public void GetIncompleteRunOrderItems(int lineId, ref List<RunOrderItemForCreate> runOrderItems)
    {
      List<IncompleteRunOrderItem> incompleteRunOrderItems = runOrderListRepo.GetIncompleteRunOrderItemsByLineId(lineId);
      runOrderListServiceLogger.LogInformation(Constant.classname + "RunOrderListService" + Constant.methodname + "GetIncompleteRunOrderItems" + Constant.message + "Get incomplete runOrder items");

      var dataNumList = incompleteRunOrderItems.Select(x => x.DataNumber).Distinct().ToList();

      List<BlankInfo> blankInfoList = blanksRepo.GetBlankInfoByListOfDataNumAndLineId(dataNumList, lineId);

      // Get coils details by coil type to get coil remaining weight
      var coilTypesList = blankInfoList.Select(x => x.CoilType.Id).Distinct().ToList();
      var coils = coilRepo.GetCoilsList(coilTypesList);

      var partNumberList = incompleteRunOrderItems.Select(c => c.Part.PartNumber).ToList();
      var partmodels = partRepo.GetPartModelsByPartNumberList(partNumberList);
      int sortOrder = 0;
      foreach (IncompleteRunOrderItem incompleteRunOrderItem in incompleteRunOrderItems)
      {
        RunOrderItemForCreate runOrderEntry = new RunOrderItemForCreate
        {
          PartNumber = incompleteRunOrderItem.Part.PartNumber,
          // get list of models by part number
          ModelList = ((incompleteRunOrderItem.Part == null || incompleteRunOrderItem.Part.PartNumber == null) ? string.Empty : GetModelListFromPart(incompleteRunOrderItem.Part, partmodels))
        };

        List<BlankInfo> blanks = blankInfoList.Where(c => c.DataNumber == incompleteRunOrderItem.DataNumber && c.Line.Id == incompleteRunOrderItem.Line.Id).ToList();
        runOrderEntry.Blanks = new List<DataNumberDto>();

        foreach (BlankInfo blank in blanks)
        {
          DataNumberDto dataNumberDto = new DataNumberDto
          {
            Id = blank.Id,
            DataNumber = blank.DataNumber,
            CoilType = blank.CoilType.Name,
            CoilTypeId = blank.CoilType.Id
          };

          var coilsbyCoilType = coils.Where(c => c.CoilType.Id == blank.CoilType.Id).ToList();
          var totalWeightRemaining = coilsbyCoilType.Sum(c => c.CurrentWeight);

          dataNumberDto.CoilRemaining = totalWeightRemaining * blank.CoilType.Yield;
          dataNumberDto.BlankWeight = blank.Weight;
          dataNumberDto.StackSize = blank.StackSize;
          runOrderEntry.Blanks.Add(dataNumberDto);
        }
        runOrderEntry.RequestQuantity = incompleteRunOrderItem.Quantity;
        runOrderEntry.SortOrder = sortOrder;
        runOrderEntry.OverrideQuantity = runOrderEntry.RequestQuantity;
        runOrderEntry.Incomplete = true;

        runOrderItems.Add(runOrderEntry);
        sortOrder++;
      }
    }

    /// <summary>
    /// Get IncompleteRunOrderItems  by line Id which get the list of runOrderListQuantity
    /// </summary>
    /// <param name="lineId"></param>
    /// <param name="runOrderItems"></param>
    public void GetIncompleteRunItemsOfTypeQuantity(int lineId, ref List<RunOrderListQuantity> runOrderItems)
    {
      List<IncompleteRunOrderItem> incompleteRunOrderItems = runOrderListRepo.GetIncompleteItemsWithShiftLinePart(lineId);
      int sortOrder = 0;

      var dataNumList = incompleteRunOrderItems.Select(c => c.DataNumber).Distinct().ToList();
      var blanks = blanksRepo.GetListWithPlantsAndTimeZones(dataNumList, lineId);


      foreach (IncompleteRunOrderItem incompleteRunOrderItem in incompleteRunOrderItems)
      {
        RunOrderListQuantity qty = new RunOrderListQuantity()
        {
          Part = incompleteRunOrderItem.Part,
          BlankInfo = blanks.FirstOrDefault(c => c.DataNumber == incompleteRunOrderItem.DataNumber),

          SortOrder = sortOrder,
          Quantity = incompleteRunOrderItem.Quantity,
          OverrideQty = incompleteRunOrderItem.Quantity,
          Incomplete = true
        };

        runOrderItems.Add(qty);
        sortOrder++;
      }

    }

    /// <summary>
    /// Mark RunOrderItems as incomplete state
    /// </summary>
    /// <param name="incompleteItems"></param>
    /// <returns>void</returns>
    public async Task MarkRunOrderItemsIncomplete(List<IncompleteRunOrderItemDto> incompleteItems)
    {
      var incompleteItemModel = mapper.Map<List<IncompleteRunOrderItemDto>, List<IncompleteRunOrderItem>>(incompleteItems);
      runOrderListServiceLogger.LogInformation(Constant.classname + "RunOrderListService" + Constant.methodname + "MarkRunOrderItemsIncomplete" + Constant.message + "mark runOrder Items incomplete");
      await runOrderListRepo.MarkRunOrderItemsIncomplete(incompleteItemModel);

    }

    /// <summary>
    /// Create entries for IncompleteRunOrderItems
    /// </summary>
    /// <param name="runOrderList"></param>
    public void CreateIncompleteRunOrderItemEntries(RunOrderList runOrderList)
    {
      runOrderListServiceLogger.LogInformation(Constant.classname + "RunOrderListService" + Constant.methodname + "CreateIncompleteRunOrderItemEntries" + Constant.message + "create records for incomplete run order list");

      runOrderListRepo.CreateIncompleteRunOrderItemEntries(runOrderList);

    }

    /// <summary>
    /// Assign data to DataNumberDto for CreateRunOrderList 
    /// </summary>
    /// <param name="blank"></param>
    /// <param name="coils"></param>
    /// <returns>DataNumDto</returns>
    public DataNumberDto AssignDataNumDtovalue(BlankInfo blank, List<Coil> coils)
    {
      DataNumberDto dataNumberDto = new DataNumberDto
      {
        Id = blank.Id,
        DataNumber = blank.DataNumber,
        CoilType = blank.CoilType.Name,
        CoilTypeId = blank.CoilType.Id
      };

      var coilsbyCoilType = coils.Where(c => c.CoilType.Id == blank.CoilType.Id).ToList();
      var totalWeightRemaining = coilsbyCoilType.Sum(c => c.CurrentWeight);

      dataNumberDto.CoilRemaining = totalWeightRemaining * blank.CoilType.Yield;
      dataNumberDto.BlankWeight = blank.Weight;
      dataNumberDto.StackSize = blank.StackSize;

      return dataNumberDto;
    }

    /// <summary>
    /// Check if Pattern or Callendar entry is not present for a runorder list
    /// and trow error accordingly
    /// </summary>
    /// <param name="calendarEntry"></param>
    /// <param name="pattern"></param>
    public void CheckCallendarEntryOrPatternPresent(PatternCalendar calendarEntry, Pattern pattern)
    {
      //Check if calendar Entry is null and throw exception accordingly
      if (calendarEntry == null || calendarEntry.PatternLetter == Constant.defaultPatternLetter)
      {
        throw new CoilTrackingException { ErrorMessage = errorList[0] + "=" + ApplicationMessages.errorMessageForPatternCalendar, HttpStatusCode = HttpStatusCode.BadRequest.ToString(),ErrorNumber= errorList[0] };

      }
      if (pattern == null)
      {
        throw new CoilTrackingException { ErrorMessage = errorList[1] + "=" + ApplicationMessages.errorMessageForPatterns + calendarEntry.PatternLetter + " pattern on the ", HttpStatusCode = HttpStatusCode.BadRequest.ToString(), ErrorNumber = errorList[1] };

      }
    }
    /// <summary>
    /// Get list of RunOrderList by date, shift and LineId
    /// </summary>
    /// <param name="date"></param>
    /// <param name="lineId"></param>
    /// <param name="shiftId"></param>
    /// <returns>RunOrderListForCreate</returns>
    public async Task<RunOrderListForCreate> CreateRunOrderList(DateTime date, int lineId, int shiftId)
    {
      RunOrderList runOrderList = await runOrderListRepo.GetListByDateLineIdAndShift(date, lineId, shiftId);
      RunOrderListForCreate runOrderListDto = new RunOrderListForCreate
      {
        Date = date,
        LineId = lineId,
        ShiftId = shiftId,
        RunOrderItems = new List<RunOrderItemForCreate>()
      };

      if (runOrderList == null)
      {
        PatternCalendar calendarEntry = await patternCalendarRepo.GetPatternCalendarByDateLineIdAndShiftId(date, lineId, shiftId);
        Pattern pattern = await patternsRepo.GetPatternsByLineIdPatternLetterAndDate(lineId, calendarEntry.PatternLetter, date);

        //Check if calendar Entry or Pattern is null and throw exception accordingly
        CheckCallendarEntryOrPatternPresent(calendarEntry, pattern);

        // get the runOrderItems by lineId
        GetIncompleteRunOrderItems(lineId, ref runOrderListDto.RunOrderItems);
        int startingSortOrder = runOrderListDto.RunOrderItems.Count;

        // to get list of parts by part Number
        var partNumberList = pattern.PatternItems.Select(c => c.PartNumber).Distinct().ToList();
        var partList = partRepo.GetPartsListByPartNumberList(partNumberList);
        var partmodels = partRepo.GetPartModelsByPartNumberList(partNumberList);

        // to get list of blank infoes by part number and line Id
        List<BlankInfo> blankInfoList = blanksRepo.GetListByPartnumberLineIds(partNumberList, lineId);
        // get list of prodplans by list of partNumber list
        var prodPlans = prodPlanRepo.GetProdPlanByPartnumberList(partNumberList);

        // Get coils details by coil type to get coil remaining weight
        var coilTypesList = blankInfoList.Select(c => c.CoilType.Id).Distinct().ToList();
        var coils = coilRepo.GetCoilsList(coilTypesList);

        foreach (PatternItem patternItem in pattern.PatternItems)
        {
          runOrderListDto.PatternLetter = pattern.Name;
          RunOrderItemForCreate runOrderEntry = new RunOrderItemForCreate
          {
            Id = 0
          };
          Part part = partList.FirstOrDefault(x => x.PartNumber == patternItem.PartNumber);
          if (part == null)
          {
            throw new CoilTrackingException { ErrorMessage = errorList[2] + "="+ ApplicationMessages.partUnavailable + patternItem.PartNumber, HttpStatusCode = HttpStatusCode.BadRequest.ToString(),ErrorNumber = errorList[2] };
          }
          runOrderEntry.PartNumber = part.PartNumber;
          runOrderEntry.PartName = part.PartName;
          // Get list of models by partNumber
          runOrderEntry.ModelList = GetModelListFromPart(part, partmodels);
          runOrderEntry.Blanks = new List<DataNumberDto>();
          List<BlankInfo> blanks = blankInfoList.Where(x => x.Part.PartNumber == patternItem.PartNumber).ToList();

          //If pattern item has data number selected, add to start of list
          int currentDataNum = 0;
          Int32.TryParse(patternItem.DataNumber, out currentDataNum);

          foreach (BlankInfo blank in blanks)
          {
            // Assign values to DataNumberDto
            var dataNumberDto = AssignDataNumDtovalue(blank, coils);

            //If pattern item has data number selected, add to start of list
            if (blank.DataNumber == currentDataNum)
              runOrderEntry.Blanks.Insert(0, dataNumberDto);
            else
              runOrderEntry.Blanks.Add(dataNumberDto);
          }
          runOrderEntry.RequestQuantity = prodPlans.Where(c => c.Part.PartNumber == patternItem.PartNumber).Select(c => c.LotSize).FirstOrDefault();
          runOrderEntry.SortOrder = patternItem.SortOrder + startingSortOrder;
          runOrderEntry.OverrideQuantity = runOrderEntry.RequestQuantity;
          runOrderEntry.Incomplete = false;
          runOrderListDto.RunOrderItems.Add(runOrderEntry);
        }
      }
      else
      {
        //Get RunOrderListDto from runOrderList
        GetRunOrderListForCreateDto(runOrderList, ref runOrderListDto);
      }

      runOrderListDto.RunOrderItems.Sort(new RunOrderItemDtoComparer());
      return runOrderListDto;
    }

    public Pattern GetpatternForGetRunOrderList(DateTime date, int lineId, PatternCalendar calendarEntry)
    {
      if (calendarEntry == null)
      {
        throw new CoilTrackingException { ErrorMessage = errorList[0] + "=" + ApplicationMessages.errorMessageForPatternCalendar, HttpStatusCode = HttpStatusCode.BadRequest.ToString(), ErrorNumber = errorList[0] };

      }
      var pattern = patternsRepo.GetPatternsWithPlantOPCServer(lineId, calendarEntry.PatternLetter, date);
      if (pattern == null)
      {
        throw new CoilTrackingException { ErrorMessage = errorList[0] + "=" + ApplicationMessages.errorMessageForPatternCalendar, HttpStatusCode = HttpStatusCode.BadRequest.ToString(), ErrorNumber = errorList[0] };

      }

      return pattern;
    }

    /// <summary>
    /// Get RunOrderListForGet by date, lineId and shiftId to add in RunOrderList table
    /// </summary>
    /// <param name="date"></param>
    /// <param name="lineId"></param>
    /// <param name="shiftId"></param>
    /// <returns>RunOrderListForGet</returns>
    public async Task<RunOrderListForGet> GetRunOrderItemForGet(DateTime date, int lineId, int shiftId)
    {
      RunOrderList runOrderList = await runOrderListRepo.GetListWithQuantitiesAndShifts(date, lineId, shiftId);
      if (runOrderList == null)
      {
        runOrderList = new RunOrderList
        {
          Date = date,
          Line = new Line() { Id=lineId }, //lineRepo.GetLineByLineID(lineId),
          Shift = new Shift() { Id=shiftId },//await shiftRepo.GetShiftByIdAsync(shiftId),
          Quantities = new List<RunOrderListQuantity>()
        };
        List<RunOrderListQuantity> incompleteRunOrderItems = new List<RunOrderListQuantity>();
        GetIncompleteRunItemsOfTypeQuantity(lineId, ref incompleteRunOrderItems);
        int startingSortOrder = incompleteRunOrderItems.Count;
        runOrderList.Quantities.AddRange(incompleteRunOrderItems);


        PatternCalendar calendarEntry = await patternCalendarRepo.GetPatternCalendarByDateLineIdAndShiftId(date, lineId, shiftId);
        ////to get the patterns by calandar entry and throw error accordingly

        var pattern = GetpatternForGetRunOrderList(date, lineId, calendarEntry);

        runOrderList.PatternLetter = calendarEntry.PatternLetter;
        ////get prod plans by part Number list
        var partNumList = pattern.PatternItems.Select(c => c.PartNumber).Distinct().ToList();
        var prodPlans = prodPlanRepo.GetProdPlanByPartnumberList(partNumList);

        // to get list of parts by part Number
        var partList = partRepo.GetPartsListByPartNumberList(partNumList);
        // to get list of blank infoes by part number and line Id
        var blankInfoList = await blanksRepo.GetListWithPlantTimeZonePart(partNumList, lineId);

        foreach (PatternItem patternItem in pattern.PatternItems)
        {
          RunOrderListQuantity runOrderEntry = new RunOrderListQuantity
          {
            Part = partList.FirstOrDefault(c => c.PartNumber == patternItem.PartNumber)
          };
          IQueryable<BlankInfo> tempList = blankInfoList.Where(c => c.Part.PartNumber == patternItem.PartNumber);

          if (!string.IsNullOrEmpty(patternItem.DataNumber))
            tempList = tempList.Where(b => b.DataNumber.ToString() == patternItem.DataNumber);
          runOrderEntry.BlankInfo = tempList.FirstOrDefault();

          if (runOrderEntry.BlankInfo == null)
          {
            throw new CoilTrackingException { ErrorMessage = errorList[2] + "=" + ApplicationMessages.partNotFoundForBlanks + patternItem.PartNumber, HttpStatusCode = HttpStatusCode.BadRequest.ToString(), ErrorNumber = errorList[2] };

          }
          runOrderEntry.Quantity = prodPlans.Select(l => l.LotSize).FirstOrDefault();
          runOrderEntry.SortOrder = patternItem.SortOrder + startingSortOrder;
          runOrderEntry.OverrideQty = runOrderEntry.Quantity;
          runOrderEntry.Incomplete = false;
          runOrderList.Quantities.Add(runOrderEntry);
        }

        runOrderListRepo.AddNewRunOrderList(runOrderList);
       /// await webSocketClientService.RunOrderListUpdated(runOrderList.Line.Id, runOrderList.Id);

        //create records for  Incomplete runOrder items 
        CreateIncompleteRunOrderItemEntries(runOrderList);
      }
      runOrderList.Quantities.Sort(new RunOrderItemComparer());
      RunOrderListForGet runOrderListDto = new RunOrderListForGet
      {
        Id = runOrderList.Id,
        LineId = runOrderList.Line.Id,
        LineName = runOrderList.Line.LineName,
        ShiftId = runOrderList.Shift.Id,
        ShiftName = runOrderList.Shift.Name,
        PatternLetter = runOrderList.PatternLetter,
        
        //CCDTS-41 : to maintain selected runorder item even if blanking lines are changed.
        Date = runOrderList.Date,
        RunOrderItems = new List<RunOrderItemForGet>()
      };

      foreach (RunOrderListQuantity qty in runOrderList.Quantities)
      {
        var runOrderItem = await AssignDataToRunOrderItem(qty);
        runOrderListDto.RunOrderItems.Add(runOrderItem);
        runOrderItem.StrokeCount = qty.Part.StrokeCount;
        runOrderItem.BlanksCutCount = runOrderItem.Quantity * runOrderItem.StrokeCount;
        runOrderItem.DieNo = qty.BlankInfo.DieNo;
        runOrderItem.StackSize= qty.BlankInfo.StackSize;
      }
      return runOrderListDto;
    }

    /// <summary>
    /// Assign data to run orderItem
    /// </summary>
    /// <param name="qty"></param>
    /// <returns></returns>
    public async Task<RunOrderItemForGet> AssignDataToRunOrderItem(RunOrderListQuantity qty)
    {
      RunOrderItemForGet runOrderItem = new RunOrderItemForGet
      {
        Id = qty.Id,
        CoilType = qty.BlankInfo.CoilType.Name,
        CoilTypeId = qty.BlankInfo.CoilType.Id
      };
      var yna = qty.BlankInfo.CoilType.CoilTypeYNAs.Where(y => !y.Disabled).OrderByDescending(y => y.DateAdded).FirstOrDefault();
      if (yna != null)
      {
        runOrderItem.YNA = yna.YNA;
      }
      runOrderItem.BlankWeight = qty.BlankInfo.Weight;
      runOrderItem.RewindWeight = qty.BlankInfo.RewindWeight;
      runOrderItem.DataNumber = qty.BlankInfo.DataNumber;
      runOrderItem.ModelList = partRepo.GetModelList(qty.Part.PartNumber);
      runOrderItem.PartNumber = qty.Part.PartNumber;
      runOrderItem.Quantity = qty.OverrideQty;
      runOrderItem.SortOrder = qty.SortOrder;
      runOrderItem.Incomplete = qty.Incomplete;
      runOrderItem.RequestQueueLength = 0;
      var totalWeightRemaining = await GetCoilTypeUsableWeight(qty.BlankInfo.CoilType.Id);
      runOrderItem.CoilRemaining = totalWeightRemaining * qty.BlankInfo.CoilType.Yield;

      return runOrderItem;
    }
    /// <summary>
    /// To changes the Run order status 
    /// </summary>
    /// <param name="runOrderItemId"></param>
    /// <param name="status"></param>
    /// <returns></returns>
    public async Task MarkRunOrderItemStatus(int runOrderItemId, RunOrderItemStatusDto status)
    {
      runOrderListServiceLogger.LogInformation(Constant.classname + "RunOrderListService" + Constant.methodname + "MarkRunOrderItemsComplete" + Constant.message + "mark runOrder Items complete");
      var statusFromDto = mapper.Map<RunOrderItemStatus>(status);
      await runOrderListRepo.MarkRunOrderItemStatus(runOrderItemId, statusFromDto);
    }

    /// <summary>
    /// Delete a runOrderList
    /// </summary>
    /// <param name="id"></param>
    /// <returns>bool</returns>
    public async Task<bool> DeleteRunOrderList(int id)
    {
      var runOrderList = await runOrderListRepo.GetListByIdWithLineQuantity(id);

      if (runOrderList == null)
      {
        return false;
      }
      var coilRunHistory = await coilRunHistoryRepo.GetCoilRunHistoryByRunOrderListId(id);

      if (coilRunHistory != null)
      {
        throw new CoilTrackingException { HttpStatusCode = "BadRequest", ErrorMessage = ApplicationMessages.deleteMessageForRunOrderList };
      }
      var runResult = await runResultRepo.GetRunResultByRunOrderListId(id);
      if (runResult != null)
      {
        throw new CoilTrackingException { HttpStatusCode = "BadRequest", ErrorMessage = ApplicationMessages.deleteMsgRunOrderListForRunResult };
      }

      runOrderListRepo.DeleteRunOrderList(id, runOrderList);
      await webSocketClientService.RunOrderListUpdated(runOrderList.Line.Id, id);
      return true;

    }

    /// <summary>
    /// Save new run order list
    /// </summary>
    /// <param name="runOrderList"></param>
    /// <returns>RunOrderListForCreate</returns>
    public async Task<RunOrderListForCreate> SaveRunOrderList(RunOrderListForUpdate runOrderList)
    {
      RunOrderList runOrderListToSave = new RunOrderList
      {
        Line = await lineRepo.GetLineWithTimeZoneOpcServer(runOrderList.LineId),

        Quantities = new List<RunOrderListQuantity>()
      };
      // get list of blanks by dataId list
      var dataIdList = runOrderList.RunOrderItems.Select(c => c.DataId).ToList();
      var blanksInfoes = blanksRepo.GetBlanksByDataIdList(dataIdList);

      //get list of parts by PartNumbers list
      var partNumList = runOrderList.RunOrderItems.Select(c => c.PartNumber).Distinct().ToList();
      var parts = partRepo.GetPartsListByPartNumberList(partNumList);
      try
      {
        foreach (RunOrderItemForUpdate qty in runOrderList.RunOrderItems)
        {
          RunOrderListQuantity newQty = new RunOrderListQuantity
          {
            BlankInfo = blanksInfoes.FirstOrDefault(c => c.Id == qty.DataId),
            Part = parts.FirstOrDefault(x => x.PartNumber == qty.PartNumber),
            OverrideQty = qty.OverrideQuantity,
            SortOrder = qty.SortOrder
          };
          if (newQty.BlankInfo != null && newQty.Part != null)
          {
            runOrderListToSave.Quantities.Add(newQty);
          }
        }
        runOrderListToSave.Shift = await shiftRepo.GetShiftByIdAsync(runOrderList.ShiftId);
        runOrderListToSave.Date = runOrderList.Date;
        if (runOrderList.PatternLetter != null)
        {
          runOrderListToSave.PatternLetter = runOrderList.PatternLetter;
        }
        if (runOrderList.PatternLetter == null && runOrderListToSave.Line != null && runOrderListToSave.Shift != null)
        {
          runOrderListToSave.PatternLetter = runOrderListRepo.GetPatternLetterByLineId(runOrderListToSave.Date, runOrderListToSave.Line.Id, runOrderListToSave.Shift.Id);
        }
       
        runOrderListServiceLogger.LogInformation(Constant.classname + "RunOrderListService" +
          Constant.message + "before SaveNewRunOrderList");

        runOrderListRepo.SaveNewRunOrderList(runOrderListToSave);

        runOrderListServiceLogger.LogInformation(Constant.classname + "RunOrderListService" +
          Constant.message + "after SaveNewRunOrderList");

        var result = from r in runOrderList.RunOrderItems
                     where r.Incomplete
                     select r;
        List<RunOrderItemForUpdate> incompleteItems = result.ToList();

        // get incomplete run items by part numbers
        var partList = incompleteItems.Select(c => c.PartNumber).ToList();
        var incompleteRunItems = runOrderListRepo.GetIncompleteItemByStatusAndPart(partList, runOrderList.LineId);
        List<IncompleteRunOrderItem> runItemsToModify = new List<IncompleteRunOrderItem>();
        foreach (RunOrderItemForUpdate incompleteItem in incompleteItems)
        {
          IncompleteRunOrderItem item = incompleteRunItems.FirstOrDefault(c => c.Part.PartNumber == incompleteItem.PartNumber);

          if (item != null)
          {

            item.Status = RunOrderItemStatus.CarriedOver;
            item.CarriedOverToRunOrder = runOrderListToSave;
            runItemsToModify.Add(item);


          }
        }
        if (runItemsToModify.Count > 0)
        {
          runOrderListServiceLogger.LogInformation(Constant.classname + "RunOrderListService" +
          Constant.message + "before ModifyIncompleteRunOrderRecordState");
          runOrderListRepo.ModifyIncompleteRunOrderRecordState(runItemsToModify);

          runOrderListServiceLogger.LogInformation(Constant.classname + "RunOrderListService" +
          Constant.message + "after ModifyIncompleteRunOrderRecordState");
        }
        List<IncompleteRunOrderItem> itemsToRemove = runOrderListRepo.GetIncompleteRunItemByLineId(runOrderList.LineId);

        List<IncompleteRunOrderItem> incompleteItemsModified = new List<IncompleteRunOrderItem>();
        foreach (var item in itemsToRemove)
        {
          item.Status = RunOrderItemStatus.Removed;
          incompleteItemsModified.Add(item);

        }
        if (incompleteItems.Count > 0)
        {
          runOrderListServiceLogger.LogInformation(Constant.classname + "RunOrderListService" +
          Constant.message + "before ModifyIncompleteRunOrderRecordState");

          runOrderListRepo.ModifyIncompleteRunOrderRecordState(incompleteItemsModified);

          runOrderListServiceLogger.LogInformation(Constant.classname + "RunOrderListService" +
         Constant.message + "after ModifyIncompleteRunOrderRecordState");
        }

        runOrderListServiceLogger.LogInformation(Constant.classname + "RunOrderListService" +
         Constant.message + "before webSocketClientService");
        await webSocketClientService.RunOrderListUpdated(runOrderListToSave.Line.Id, runOrderListToSave.Id);
        runOrderListServiceLogger.LogInformation(Constant.classname + "RunOrderListService" +
         Constant.message + "after webSocketClientService");

        runOrderListServiceLogger.LogInformation(Constant.classname + "RunOrderListService" +
         Constant.message + "before CreateIncompleteRunOrderItemEntries");
        CreateIncompleteRunOrderItemEntries(runOrderListToSave);
        runOrderListServiceLogger.LogInformation(Constant.classname + "RunOrderListService" +
         Constant.message + "after CreateIncompleteRunOrderItemEntries");

        RunOrderListForCreate runOrderListDto = new RunOrderListForCreate
        {
          Date = runOrderList.Date,
          LineId = runOrderList.LineId,
          ShiftId = runOrderList.ShiftId,
          PatternLetter = runOrderList.PatternLetter,
          RunOrderItems = new List<RunOrderItemForCreate>()
        };
        runOrderListServiceLogger.LogInformation(Constant.classname + "RunOrderListService" +
         Constant.message + "before GetRunOrderListForCreateDto");
        GetRunOrderListForCreateDto(runOrderListToSave, ref runOrderListDto);
        runOrderListServiceLogger.LogInformation(Constant.classname + "RunOrderListService" +
        Constant.message + "after GetRunOrderListForCreateDto");
        return runOrderListDto;
      }
      catch (Exception e)
      {
        runOrderListServiceLogger.LogInformation(Constant.classname + "RunOrderListService" +
        Constant.message + e.Message + e);
        throw new CoilTrackingException { ErrorMessage = e.Message + e.InnerException.ToString() };
      }
      
    }
    /// <summary>
    /// Assign values to RunOrderListQuantity
    /// </summary>
    /// <param name="runQty"></param>
    /// <param name="qty"></param>
    /// <param name="dataIds"></param>
    /// <param name="partNums"></param>
    /// <returns>RunOrderListquantity</returns>
    public RunOrderListQuantity AssignValueToRunOrderQty(RunOrderListQuantity runQty, RunOrderItemForUpdate qty, List<int> dataIds, List<string> partNums)
    {
        var blanksByDataIds = blanksRepo.GetBlanksByDataIdList(dataIds);
        var partsByPartNums = partRepo.GetPartsListByPartNumberList(partNums);
        runQty.BlankInfo = blanksByDataIds.FirstOrDefault(x => x.Id == qty.DataId);
        runQty.Part = partsByPartNums.FirstOrDefault(c => c.PartNumber == qty.PartNumber);
        runQty.Quantity = qty.RequestQuantity;
        runQty.OverrideQty = qty.OverrideQuantity;
        runQty.SortOrder = qty.SortOrder;
      return runQty;
    }
    /// <summary>
    /// Update an existing RunOrderList
    /// </summary>
    /// <param name="id"></param>
    /// <param name="runOrderList"></param>
    /// <returns>void</returns>
    public async Task UpdateRunOrderList(int id, RunOrderListForUpdate runOrderList)
    {
      try
      {
        var listIncludeQuantities = await runOrderListRepo.GetListByIdWithLineQuantity(id);
        List<RunOrderListQuantity> quantities = listIncludeQuantities.Quantities.ToList();

        var quantityIds = quantities.Select(x => x.Id).ToList();
        var incompleteRunOrder = await runOrderListRepo.GetIncompleteItemListByRunOrderId(quantityIds);
        List<RunOrderListQuantity> quantitiesForRemoval = new List<RunOrderListQuantity>();
        foreach (RunOrderListQuantity qty in quantities)
        {
          if (!runOrderList.RunOrderItems.Any(i => i.Id == qty.Id))
          {
            IncompleteRunOrderItem relatedItem = incompleteRunOrder.FirstOrDefault(c => c.RunOrderItem.Id == qty.Id);
            if (relatedItem != null)
            {
              runOrderListRepo.ModifyIncompleteRunStateToDeleted(relatedItem);
            }

            quantitiesForRemoval.Add(qty);
          }
        }
        //Remove RunOrderQty list
        RemoveRunOrderQtyListForUpdate(quantitiesForRemoval);
        RunOrderList runOrderListOriginal = await runOrderListRepo.GetRunOrderListByIdAsync(id);

        runOrderListOriginal.Line = await lineRepo.GetLineWithTimeZoneOpcServer(runOrderList.LineId);

        List<IncompleteRunOrderItem> incompleteItemsList = new List<IncompleteRunOrderItem>();

        List<int> newItemsSortOrder = new List<int>();
        // to get the parts by list of partNumbers
        var partNums = runOrderList.RunOrderItems.Select(x => x.PartNumber).ToList();
        //// to get list of blanks by dataId list
        var dataIds = runOrderList.RunOrderItems.Select(x => x.DataId).ToList();

        ////get runOrderListQuantity by qty Id
        var qtyIdList = runOrderList.RunOrderItems.Select(c => c.Id).ToList();
        var runOrderQuantity = runOrderListQuantityRepo.GetRunOrderListQuantityByQtyIdList(qtyIdList);

        foreach (RunOrderItemForUpdate qty in runOrderList.RunOrderItems)
        {
          if (qty.Id == 0)
          {
            RunOrderListQuantity newQty = new RunOrderListQuantity();
            AssignValueToRunOrderQty(newQty, qty, dataIds, partNums);
            runOrderListOriginal.Quantities.Add(newQty);
            newItemsSortOrder.Add(qty.SortOrder);
          }
          else
          {
            RunOrderListQuantity oldQty = runOrderQuantity.FirstOrDefault(x => x.Id == qty.Id);
            AssignValueToRunOrderQty(oldQty, qty, dataIds, partNums);
            runOrderListQuantityRepo.ModifyRunOrderListQuantity(oldQty);
          }
        }
        runOrderListOriginal.Shift = await shiftRepo.GetShiftByIdAsync(runOrderList.ShiftId);

        runOrderListRepo.ChangeEntityState(runOrderListOriginal, runOrderList.Date);

        await webSocketClientService.RunOrderListUpdated(runOrderListOriginal.Line.Id, runOrderListOriginal.Id);

        foreach (RunOrderListQuantity qty in runOrderListOriginal.Quantities)
        {
          if (newItemsSortOrder.IndexOf(qty.SortOrder) != -1)
          {
            IncompleteRunOrderItem item = new IncompleteRunOrderItem()
            {
              Line = runOrderListOriginal.Line,
              RunOrderList = runOrderListOriginal,
              RunOrderItem = qty,
              Part = qty.Part,
              DataNumber = qty.BlankInfo.DataNumber,
              SortOrder = qty.SortOrder,
              Quantity = qty.OverrideQty,
              Status = RunOrderItemStatus.New,
              Date = DateTime.Now
            };

            incompleteItemsList.Add(item);
          }
        }
        AddIncompleteRunRecordForUpdate(incompleteItemsList);
      }
      catch (DbUpdateConcurrencyException ex)
      {
        throw new CoilTrackingException { ErrorMessage = ex.Message, HttpStatusCode = Constant.internalServerError };
        
      }
      }
    public void AddIncompleteRunRecordForUpdate(List<IncompleteRunOrderItem> incompleteItemsList)
    {
      if (incompleteItemsList.Count > 0)
      {
        runOrderListRepo.AddIncompleteRunOrderRecordList(incompleteItemsList);
      }
    }

    public void RemoveRunOrderQtyListForUpdate(List<RunOrderListQuantity>  quantitiesForRemoval)
    {
      if (quantitiesForRemoval.Any())
      {
        runOrderListQuantityRepo.RemoveRunOrderQtyList(quantitiesForRemoval);
      }
    }


  }
}
