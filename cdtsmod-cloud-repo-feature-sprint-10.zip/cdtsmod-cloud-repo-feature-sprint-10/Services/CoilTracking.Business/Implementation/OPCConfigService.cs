using AutoMapper;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class OPCConfigService : IOPCConfigService
  {
    private readonly IOPCConfigRepository configRepository;
    private readonly ILineRepository lineRepo;
    private readonly IMapper mapper;
    private readonly IApplicationLogger<OPCConfigService> logger;

    public OPCConfigService(IOPCConfigRepository configRepository,
      IMapper mapper,
      IApplicationLogger<OPCConfigService> logger, ILineRepository lineRepo
      )
    {
      this.configRepository = configRepository;
      this.mapper = mapper;
      this.logger = logger;
      this.lineRepo = lineRepo;
    }

    /// <summary>
    /// Get list of lines for dependency of opcconfigs
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<List<LineDto>> GetDependencyForKep(int id)
    {
      var lines =await lineRepo.GetLinesByOPcConfigId(id);
      return mapper.Map<List<LineDto>>(lines);
    }

    /// <summary>
    /// Get OPCConfigs by Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>OPCConfigDTO</returns>
    public async Task<OPCConfigDTO> GetOPCConfigById(int id)
    {
      var configs = await configRepository.GetOPCConfigById(id);
      return mapper.Map<OPCConfigDTO>(configs);
    }
    /// <summary>
    /// Get list of configs
    /// </summary>
    /// <returns>IQueryable<OPCConfigDTO></returns>
    public async Task<IQueryable<OPCConfigDTO>> GetOPCConfigs()
    {
      var configs = await configRepository.GetOPCConfigsAsync();
      logger.LogInformation(Constant.classname + "OPCConfigService" + Constant.methodname + "GetOPCConfigs" + Constant.message + "Get list of all OPC Configs");
      return mapper.Map<List<OPCConfigDTO>>(configs).AsQueryable();
    }

    /// <summary>
    /// To update opcconfig by id
    /// </summary>
    /// <param name="id"></param>
    /// <param name="oPCConfig"></param>
    /// <returns>void</returns>
    public void  UpdateOPCConfig(int id, OPCConfigDTO oPCConfig)
    {
        if (!OPCConfigExists(id))
        {
          throw new CoilTrackingException { HttpStatusCode = Constant.notfound };
        }
      logger.LogInformation(Constant.classname + "OPCConfigService" + Constant.methodname + "UpdateOPCConfig");
      configRepository.UpdateOPCConfig(mapper.Map<OPCConfig>(oPCConfig));
    
    }
    /// <summary>
    /// To check if opcconfig exist
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public  bool OPCConfigExists(int id)
    {
      var configs =  configRepository.OPCConfigExistsbyId(id);
      if (configs == null)
      {
        return false;
      }
      return true;
    }
    /// <summary>
    /// To disable an opcconfig
    /// </summary>
    /// <param name="id"></param>
    /// <param name="disable"></param>
    /// <returns></returns>
    public async  Task DisableOPCConfig(int id, bool disable)
    {

      if (!OPCConfigExists(id))
      {
        throw new CoilTrackingException { HttpStatusCode = Constant.notfound };
      }
      logger.LogInformation(Constant.classname + "OPCConfigService" + Constant.methodname + "UpdateOPCConfig");
      await configRepository.DisableOPCConfig(id, disable);

    }

    /// <summary>
    /// To add new opcconfig
    /// </summary>
    /// <param name="opcconfig"></param>
    /// <returns></returns>
    public async Task<OPCConfigDTO> InsertOPCConfig(OPCConfigDTO opcconfig)
    {
      var configs = await configRepository.InsertOPCConfig(mapper.Map<OPCConfig>(opcconfig));
      return mapper.Map<OPCConfigDTO>(configs);
    }
    /// <summary>
    /// To delete opcconfig by id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<OPCConfigDTO> DeleteOPCConfig(int id)
    {
      if (!OPCConfigExists(id))
      {
        throw new CoilTrackingException { HttpStatusCode = Constant.notfound };
      }
      var configs = await configRepository.DeleteOPCConfig(id);

      return mapper.Map<OPCConfigDTO>(configs);
    }
    /// <summary>
    /// Get lines list from runOrderList by lineId
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async  Task<List<LineDto>> GetLinesInRunOrderById(int id)
    {
      var lines =await lineRepo.GetLinesByOPcConfigId(id);
      var linesFromIncompleteRunList =  lineRepo.GetIncompleteRunLinesByLineList(lines);
      return mapper.Map < List<LineDto>>(linesFromIncompleteRunList);

    }

    /// <summary>
    /// check if entity is edited .
    /// </summary>
    /// <param name="id"></param>
    /// <param name="oPCConfig"></param>
    /// <returns></returns>
    public async Task<bool> CheckIfEdited(int id, OPCConfigDTO oPCConfig)
    {
      var configs = await configRepository.GetOPCConfigById(id);
      if(configs.InstanceName!=oPCConfig.InstanceName || configs.ServerName!= oPCConfig.ServerName || configs.Disabled!= oPCConfig.Disabled)
      {
        return false;
      }
      return true;
    }
  }
}
