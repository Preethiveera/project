
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;

namespace CoilTracking.Business.Implementation
{
  [ExcludeFromCodeCoverage]
  public class PLCIntegrationService : IPLCIntegrationService
  {
    private readonly IHttpContextAccessor httpContextAccessor;
    private readonly PLCIntegrationURLS settings;
    private readonly IApplicationLogger<PLCIntegrationService> logger;
    public PLCIntegrationService( IOptions<PLCIntegrationURLS> settings, IHttpContextAccessor httpContextAccessor, IApplicationLogger<PLCIntegrationService> logger)
    {
      this.settings = settings.Value;
      this.httpContextAccessor = httpContextAccessor;
      this.logger = logger;
    }

    /// <summary>
    /// To subscribe lineData
    /// </summary>
    /// <param name="lineInfo"></param>
    /// <returns>string</returns>
    public int SubscribeLineData(LineInfo lineInfo, string token=null)
    {
      
      var urlDictionary = settings.PlantUrl;
      string responseString = string.Empty;
      
        using (var client = new HttpClient())
        {
          string baseurl = string.Empty;
          //to get the base url based upon the NamcCode
          var NAMCcode = GetNAMCCode();
          logger.LogInformation(Constant.methodname + "Subscribe line data" + Constant.message + "Namc code = " + NAMCcode);

        baseurl = urlDictionary[NAMCcode];

          logger.LogInformation(Constant.message + "Base Url" + baseurl + "token=" + token + "LineInfo=" + lineInfo.lineId);
          logger.LogInformation(Constant.message + "SubscribeLine Data= " + settings.SubscribeLineData);

          SetHeader(client, baseurl, token);
          StringContent content = new StringContent(JsonConvert.SerializeObject(lineInfo), Encoding.UTF8, "application/json");
        // call subscribed line data if subscribe=true settings.SubscribeLineData
        try
        {
          var response = client.PostAsync(settings.SubscribeLineData, content).Result;

          if (response.IsSuccessStatusCode)
          {
            logger.LogInformation(Constant.message + "Response from PLC" + response);
            responseString = response.Content.ReadAsStringAsync().Result;
          }
          else if (response.StatusCode.Equals(StatusCodes.Status400BadRequest) || response.StatusCode.Equals(StatusCodes.Status500InternalServerError))
          {
            logger.LogInformation(Constant.message + "Response from PLC =" + response);
          }
          else
          {
            logger.LogInformation("Response from PLC =" + response.ReasonPhrase + response.StatusCode + response.RequestMessage);
          }


        }
        catch (Exception e)
        {
          logger.LogError("PLCException=" + e.Message + e.InnerException + e.StackTrace);
          throw new CoilTrackingException
          {
            ErrorMessage ="PLCException"+ e.Message + "Inner Exception="
            + e.InnerException + "StackTrace=" + e.StackTrace
          };
        }
        int responseResult = Int32.Parse(responseString);
        
      
        return responseResult;
      }
    }
    /// <summary>
    /// To unsubscribe lineData
    /// </summary>
    /// <param name="lineInfo"></param>
    /// <returns>string</returns>
    public int UnSubscribeLineData(LineInfo lineInfo, string token=null)
    {
      string responseString = string.Empty;
      using (var client = new HttpClient())
      {
        var urlDictionary = settings.PlantUrl;
        string baseurl = string.Empty;
        //to get the base url based upon the NamcCode
        baseurl = urlDictionary[GetNAMCCode()];
        logger.LogInformation(Constant.methodname + "UnSubscribe line data" + Constant.message + "base url = " + baseurl);
        logger.LogInformation(Constant.message + "token=" + token + "LineInfo=" + lineInfo.lineId);
        logger.LogInformation(Constant.message + "UnSubscribeLine Data= " + settings.UnSubscribeLineData);


        SetHeader(client, baseurl, token);
        StringContent content = new StringContent(JsonConvert.SerializeObject(lineInfo), Encoding.UTF8, "application/json");
        // call subscribed line data if subscribe=true
        try
        {
          ///var testUrl = "api/LineDataPull/Testing";
          var response = client.PostAsync(settings.UnSubscribeLineData, content).Result;
          logger.LogInformation(Constant.message + "Response from PLC" + response);

          if (response.IsSuccessStatusCode)
          {
            responseString = response.Content.ReadAsStringAsync().Result;
          }
          else if (response.StatusCode.Equals(StatusCodes.Status400BadRequest) || response.StatusCode.Equals(StatusCodes.Status500InternalServerError))
          {
            logger.LogInformation(Constant.message + "Response from PLC =" + response);
          }
          else
          {
            logger.LogInformation("Response from PLC =" + response.ReasonPhrase + response.StatusCode + response.RequestMessage);
          }

          logger.LogInformation(Constant.message + "Response code from PLC" + response.StatusCode);
        }
        catch(Exception e)
        {
          logger.LogError("PLCException=" + e.Message + e.InnerException + e.StackTrace);
          throw new CoilTrackingException
          {
            ErrorMessage = "PLCException" + e.Message + "Inner Exception="
            + e.InnerException + "StackTrace=" + e.StackTrace
          };
        }
        int responseResult = Int32.Parse(responseString);
        return responseResult;
      }
    }

    public void SetHeader(HttpClient client , string baseurl,string token)
    {
      client.BaseAddress = new Uri(baseurl);
      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

    }
    public string GetNAMCCode()
    {
      ///var NAMCs = httpContextAccessor.HttpContext.Request.Headers[Constant.namc].ToString();
      var NAMCs = "TMMI";
      return NAMCs;
    }
    /// <summary>
    /// to call the plc api  for testing connectivity
    /// </summary>
    /// <returns></returns>
    public string TestPLC()
    {
      string responseString = string.Empty;
      using (var client = new HttpClient())
      {
        var urlDictionary = settings.PlantUrl;
        string baseurl = string.Empty;
        //to get the base url based upon the NamcCode
        baseurl = urlDictionary[GetNAMCCode()];
        logger.LogInformation(Constant.methodname + "Test plc api " + Constant.message + "base url = " + baseurl);
        logger.LogInformation(Constant.message + "test plc api = " + "api/LineDataPush/Test");
        client.BaseAddress = new Uri(baseurl);
        client.DefaultRequestHeaders.Accept.Clear();
        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
       try
        {
          var testUrl = "api/LineDataPush/Test";
          var response = client.GetAsync(testUrl).Result;
          logger.LogInformation(Constant.message + "Response from PLC" + response);

          if (response.IsSuccessStatusCode)
          {
            responseString = response.Content.ReadAsStringAsync().Result;
          }
          else if (response.StatusCode.Equals(StatusCodes.Status400BadRequest) || response.StatusCode.Equals(StatusCodes.Status500InternalServerError))
          {
            logger.LogInformation(Constant.message + "Response from PLC =" + response);
          }
          else
          {
            logger.LogInformation("Response from PLC =" + response.ReasonPhrase + response.StatusCode + response.RequestMessage);
          }

          logger.LogInformation(Constant.message + "Response code from PLC" + response.StatusCode);
        }
        catch (Exception e)
        {
          logger.LogError("PLCException=" + e.Message + e.InnerException + e.StackTrace);
          throw new CoilTrackingException
          {
            ErrorMessage = "PLCException" + e.Message + "Inner Exception="
            + e.InnerException + "StackTrace=" + e.StackTrace
          };
        }
        
        return responseString;
      }
    }
  }
}
