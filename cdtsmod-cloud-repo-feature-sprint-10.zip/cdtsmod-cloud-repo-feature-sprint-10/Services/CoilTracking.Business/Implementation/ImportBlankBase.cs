using CoilTracking.Business.Interfaces;
using CoilTracking.DTO;
using OfficeOpenXml;
using System.Collections.Generic;
using static CoilTracking.Business.Implementation.ImportBlankData;

namespace CoilTracking.Business.Implementation
{

  public abstract class ImportBlankBase : IImportBlank
  {
    /// <summary>
    /// Get the BlankDataRecord from the row index specified
    /// </summary>
    /// <param name="worksheet"></param>
    /// <param name="errors"></param>
    /// <param name="row"></param>
    /// <returns>records</returns>
    public virtual ImportBlankData.BlankDataRecord GetRecordFromRow(ExcelWorksheet worksheet, List<DataImportMessage> errors, int row)
    {
      BlankDataRecord record = new BlankDataRecord();
      errors.AddRange(DataImportHelper.GetInt(worksheet, row, (int)Columns.DataNo, Columns.DataNo.ToString(), out record.DataNumber));
      errors.AddRange(DataImportHelper.GetDecimal(worksheet, row, (int)Columns.Pitch, Columns.Pitch.ToString(), out record.Pitch));
      errors.AddRange(DataImportHelper.GetInt(worksheet, row, (int)Columns.Width, Columns.Width.ToString(), out record.Width));
      errors.AddRange(DataImportHelper.GetInt(worksheet, row, (int)Columns.StackSize, Columns.StackSize.ToString(), out record.StackSize));
      errors.AddRange(DataImportHelper.GetDecimal(worksheet, row, (int)Columns.BlankWeight, Columns.BlankWeight.ToString(), out record.Weight));
      errors.AddRange(DataImportHelper.GetInt(worksheet, row, (int)Columns.DieNo, Columns.DieNo.ToString(), out record.DieNo));
      errors.AddRange(DataImportHelper.GetString(worksheet, row, (int)Columns.PartNo, Columns.PartNo.ToString(), out record.PartName));
      errors.AddRange(DataImportHelper.GetString(worksheet, row, (int)Columns.Line, Columns.Line.ToString(), out record.LineName));
      errors.AddRange(DataImportHelper.GetString(worksheet, row, (int)Columns.CoilType, Columns.CoilType.ToString(), out record.CoilTypeName));
      errors.AddRange(DataImportHelper.GetDecimal(worksheet, row, (int)Columns.MinPitch, Columns.MinPitch.ToString(), out record.MinPitch, true));
      errors.AddRange(DataImportHelper.GetDecimal(worksheet, row, (int)Columns.MaxPitch, Columns.MaxPitch.ToString(), out record.MaxPitch, true));
      errors.AddRange(DataImportHelper.GetDecimal(worksheet, row, (int)Columns.MinWidth, Columns.MinWidth.ToString(), out record.MinWidth, true));
      errors.AddRange(DataImportHelper.GetDecimal(worksheet, row, (int)Columns.MaxWidth, Columns.MaxWidth.ToString(), out record.MaxWidth, true));
      errors.AddRange(DataImportHelper.GetString(worksheet, row, (int)Columns.Press, Columns.Press.ToString(), out record.PressName));

      return record;
    }
  }




}
