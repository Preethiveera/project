using AutoMapper;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;
using TimeZoneConverter;

namespace CoilTracking.Business.Implementation
{
  public class ShiftService : IShiftService
  {
    private readonly IApplicationLogger<ShiftService> logger;
    private readonly IShiftRepository shiftRepository;
    private readonly IMapper mapper;
    private readonly ILineRepository lineRepository;
    private readonly IRunOrderRepository runOrderRepository;
    private readonly IIncompleteRunOrderItemsRepository incompleteRunOrderItemsRepository;

    public ShiftService(IApplicationLogger<ShiftService> logger,
      IShiftRepository shiftRepository,
      IMapper mapper,
      ILineRepository lineRepository,
      IRunOrderRepository runOrderRepository,
      IIncompleteRunOrderItemsRepository incompleteRunOrderItemsRepository)
    {
      this.logger = logger;
      this.shiftRepository = shiftRepository;
      this.mapper = mapper;
      this.lineRepository = lineRepository;
      this.runOrderRepository = runOrderRepository;
      this.incompleteRunOrderItemsRepository = incompleteRunOrderItemsRepository;
    }

    /// <summary>
    /// Get list of shift.
    /// </summary>
    /// <returns></returns>
    public async Task<IQueryable<ShiftDto>> GetShifts()
    {
      var shifts = await shiftRepository.GetShifts();
      logger.LogInformation(Constant.classname + "ShiftService" + Constant.methodname + "GetShifts" + Constant.message + "Get list of all shifts.");
      var shiftData = mapper.Map<List<ShiftDto>>(shifts);
      return shiftData.AsQueryable();
    }

    /// <summary>
    /// Get shift by Id.
    /// </summary>
    /// <returns></returns>
    public async Task<ShiftDto> GetShiftById(int id)
    {
      var shift = await shiftRepository.GetShiftByIdAsync(id);
      logger.LogInformation(Constant.classname + "ShiftService" + Constant.methodname + "GetShiftById" + Constant.message + "Get shift by Id.");
      return mapper.Map<ShiftDto>(shift);
    }

    /// <summary>
    /// Get current shift.
    /// </summary>
    /// <returns></returns>
    public async Task<ShiftDto> GetCurrentShift(int lineId)
    {
      var line = await lineRepository.GetLineWithPlantDetails(lineId);
      if (line == null)
      {
        throw new CoilTrackingException { HttpStatusCode = "BadRequest", ErrorMessage = ApplicationMessages.lineNotFound + lineId };
      }

      var timeZone = TZConvert.GetTimeZoneInfo(line.Plant.TimeZone.Name).Id;
      DateTime now = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.UtcNow, timeZone);
      TimeSpan currentTime = now.TimeOfDay;
      var currentShift = await shiftRepository.GetCurrentShift(currentTime);

      if (currentShift == null)
      {
        var lateNightShift = await shiftRepository.GetLateNightShift();
        DateTime midNight = DateTime.Today.AddDays(1);

        if (currentTime > lateNightShift?.Start && now < midNight)   //to handle shifts running during midnight
                                                                    //assumes no overlapping midnight shift
        {
          return mapper.Map<ShiftDto>(lateNightShift);
        }
        else if (currentTime < lateNightShift?.Finish && now > DateTime.Today)
        {
          return mapper.Map<ShiftDto>(lateNightShift);
        }
        else
        {
          currentShift = await shiftRepository.GetOrderedCurrentShift(currentTime);
          return mapper.Map<ShiftDto>(currentShift);
        }
      }

      logger.LogInformation(Constant.classname + "ShiftService" + Constant.methodname + "Get Current Shift" + Constant.message + "Get current shift by LineId.");
      return mapper.Map<ShiftDto>(currentShift);
    }

    /// <summary>
    /// Get next shift.
    /// </summary>
    /// <returns></returns>
    public async Task<ShiftDto> GetNextShift(int lineId)
    {
      var line = await lineRepository.GetLineWithPlantDetails(lineId);
      if (line == null)
      {
        throw new CoilTrackingException { HttpStatusCode = "BadRequest", ErrorMessage = ApplicationMessages.lineNotFound + lineId };
      }

      DateTime now = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.UtcNow, line.Plant.TimeZone.Name);
      TimeSpan currentTime = now.TimeOfDay;
      var nextShift = await shiftRepository.GetNextShiftByCurrentTime(currentTime);
      if (nextShift == null)
      {
        nextShift = await shiftRepository.GetNextShift();
        return mapper.Map<ShiftDto>(nextShift);
      }

      logger.LogInformation(Constant.classname + "ShiftService" + Constant.methodname + "GetNextShift" + Constant.message + "Get next shift by lineId.");
      return mapper.Map<ShiftDto>(nextShift);
    }

    /// <summary>
    /// Update shift.
    /// </summary>
    /// <returns></returns>
    public async Task PutShift(int id, ShiftDto shift)
    {
      var shiftData = mapper.Map<Shift>(shift);
      var shiftinfo = await shiftRepository.GetShiftByIdAsync(id);
      if (shiftinfo ==null)
      {
        throw new CoilTrackingException { HttpStatusCode = "BadRequest"};
      }
      try
      {
        shiftData.Plant_Id =  shiftinfo.Plant_Id;
         await shiftRepository.UpdateShift(shiftData, AuditActionType.ModifyEntity);
      }
      catch (DbUpdateConcurrencyException)
      {
        if (shiftinfo == null)
        {
          throw new CoilTrackingException { HttpStatusCode = "NotFound" };
        }
        else
        {
          throw;
        }
      }

      logger.LogInformation(Constant.classname + "ShiftService" + Constant.methodname + "PutShift" + Constant.message + "Update Shift");
    }

    /// <summary>
    /// Disable shift.
    /// </summary>
    /// <returns></returns>
    public async Task DisableShift(int id, bool disable)
    {
      var shift = await shiftRepository.GetShiftByIdAsync(id);
      shift.Disabled = disable;
      try
      {
        await shiftRepository.UpdateShift(shift, AuditActionType.EnableDisable);
      }
      catch (DbUpdateConcurrencyException)
      {
        if (shift == null)
        {
          throw new CoilTrackingException { HttpStatusCode = "NotFound" };
        }
        else
        {
          throw;
        }
      }

      logger.LogInformation(Constant.classname + "ShiftService" + Constant.methodname + "DisableShift" + Constant.message + "Disable Shift");
    }

    /// <summary>
    /// Add shift.
    /// </summary>
    /// <returns></returns>
    public async Task<ShiftDto> AddShift(ShiftDto shift)
    {
      var data = mapper.Map<Shift>(shift);
      var shiftData = await shiftRepository.AddShift(data);

      logger.LogInformation(Constant.classname + "ShiftService" + Constant.methodname + "AddShift" + Constant.message + "Add a new Shift");
      return mapper.Map<ShiftDto>(shiftData);
    }

    /// <summary>
    /// Delete shift.
    /// </summary>
    /// <returns></returns>
    public async Task<ShiftDto> DeleteShift(int id)
    {
      var shift = await shiftRepository.GetShiftByIdAsync(id);
      if (shift == null)
      {
        throw new CoilTrackingException { HttpStatusCode = "NotFound" };
      }

      await shiftRepository.DeleteShift(shift);

      logger.LogInformation(Constant.classname + "ShiftService" + Constant.methodname + "DeleteShift" + Constant.message + "Delete an existing Shift");
      return mapper.Map<ShiftDto>(shift);
    }

    /// <summary>
    /// Check Edit for shift.
    /// </summary>
    /// <returns></returns>
    public async Task<List<string>> CheckEdit(int id, ShiftDto shift)
    {
      List<string> shiftAssociation = new List<string>();
      var shiftData = mapper.Map<Shift>(shift);
      if (await shiftRepository.CheckEdit(id, shiftData))
      {
        shiftAssociation.Add("editing");
      }

      return shiftAssociation;
    }

    /// <summary>
    /// Check Dependency.
    /// </summary>
    /// <returns></returns>
    public async Task<List<string>> CheckDependency(int id)
    {
      List<string> shiftAssociation = new List<string>();
      var item = await runOrderRepository.GetRunOrderListsByShiftId(id);
      foreach (var k in item)
      {
        if (await incompleteRunOrderItemsRepository.IncompleteRunOrderItemsExists(k.Id))
        {
          shiftAssociation.Add("runorder");
        }
      }
      return shiftAssociation;
    }
  }
}
