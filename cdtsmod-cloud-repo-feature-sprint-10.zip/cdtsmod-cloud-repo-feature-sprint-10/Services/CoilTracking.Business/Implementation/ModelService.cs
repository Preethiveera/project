using AutoMapper;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class ModelService : IModelService
  {
    private readonly IModelRepository modelRepository;
    private readonly IPartModelsRepository partModelsRepository;
    private readonly IIncompleteRunOrderItemRepository incompleteRunOrderItemRepository;

    private readonly IApplicationLogger<ModelService> modelServiceApplicationLogger;

    private readonly IMapper mapper;

    public ModelService(IModelRepository modelRepository, IPartModelsRepository partModelsRepository,
      IIncompleteRunOrderItemRepository incompleteRunOrderItemRepository,
      IApplicationLogger<ModelService> modelServiceApplicationLogger, IMapper mapper)
    {
      this.incompleteRunOrderItemRepository = incompleteRunOrderItemRepository;
      this.modelRepository = modelRepository;
      this.partModelsRepository = partModelsRepository;
      this.mapper = mapper;
      this.modelServiceApplicationLogger = modelServiceApplicationLogger;
    }

    /// <summary>
    /// Get the models.
    /// </summary>
    /// <returns></returns>
    public async Task<List<ModelDto>> GetModels()
    {
      var models = await modelRepository.GetModels();

      var modelsDto = mapper.Map<List<Model>, List<ModelDto>>(models);

      modelServiceApplicationLogger.LogInformation(Constant.classname + "ModelService"
        + Constant.methodname + "GetModels" + Constant.message + "To get the List of Models.");

      return modelsDto;
    }

    /// <summary>
    /// Get model by id.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>ModelDto</returns>
    public async Task<ModelDto> GetModel(int id)
    {
      var model = await modelRepository.GetModelById(id);
      var modelDto = mapper.Map<Model, ModelDto>(model);

      modelServiceApplicationLogger.LogInformation(Constant.classname + "ModelService"
        + Constant.methodname + "GetModel" + Constant.message + "To get the model by id.");

      return modelDto;
    }

    /// <summary>
    /// Check edit.
    /// </summary>
    /// <param name="id"></param>
    /// <param name="modelDto"></param>
    /// <returns></returns>
    public async Task<bool> CheckEdit(int id, ModelDto modelDto)
    {
      var model = await modelRepository.GetModelById(id);

      if (model.ModelNumber != modelDto.ModelNumber
          || model.Name != modelDto.Name
          || model.Disabled != modelDto.Disabled)

      {
        return true;
      }

      modelServiceApplicationLogger.LogInformation(Constant.classname + "ModelService"
        + Constant.methodname + "CheckEdit" + Constant.message + "To check edit.");

      return false;
    }

    /// <summary>
    /// Get parts related to models.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>List of PartDto</returns>
    public async Task<List<PartDto>> GetPartsRelatedToModels(int id)
    {
      var parts = await partModelsRepository.GetPartsRelatedToModels(id);

      var partsDto = mapper.Map<List<Part>, List<PartDto>>(parts);

      modelServiceApplicationLogger.LogInformation(Constant.classname + "ModelService"
        + Constant.methodname + "GetPartsRelatedToModels" + Constant.message + "To get parts related to model.");

      return partsDto;
    }

    /// <summary>
    /// Get parts in run order by modelId.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>List of PartModelDto</returns>
    public async Task<List<PartModelDto>> GetPartsInRunOrderByModelId(int id)
    {
      var dependentModels = await GetDependentPartModels(id);

      modelServiceApplicationLogger.LogInformation(Constant.classname + "ModelService"
        + Constant.methodname + "GetPartsInRunOrderByModelId" + Constant.message + "To get parts in run order by model id.");

      return dependentModels;
    }

    /// <summary>
    /// Check dependency
    /// </summary>
    /// <param name="id"></param>
    /// <returns>list of string</returns>
    public async Task<List<string>> CheckDependency(int id)
    {
      var modelAssociation = new List<string>();

      var dependentModels = await GetDependentPartModels(id);

      if (dependentModels != null && dependentModels.Any())
      {
        modelAssociation.Add("Runorder");
      }

      modelServiceApplicationLogger.LogInformation(Constant.classname + "ModelService"
        + Constant.methodname + "CheckDependency" + Constant.message + "To check the dependency by model id.");

      return modelAssociation;
    }

    /// <summary>
    /// Put the model.
    /// </summary>
    /// <param name="modelDto"></param>
    /// <returns>bool</returns>
    public async Task<bool> PutModel(ModelDto modelDto)
    {
      var modelExist = await ModelExists(modelDto.Id);

      if (!modelExist)
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.modelNotFound, HttpStatusCode = "NotFound" };
      }
      
      var partModel = await partModelsRepository.GetPartModel(modelDto.Id);
      var models = await modelRepository.GetModelById(modelDto.Id);
      var model = mapper.Map<ModelDto, Model>(modelDto);

      if (partModel != null && partModel.Id > 0)
      {
        partModel.Model = model;

        partModelsRepository.UpdatePartModel(partModel);
      }

      modelServiceApplicationLogger.LogInformation(Constant.classname + "ModelService"
        + Constant.methodname + "PutModel" + Constant.message + "To update the model.");
      model.Plant_Id = models.Plant_Id;
      return await modelRepository.UpdateModel(model);
    }

    /// <summary>
    /// Disable the model.
    /// </summary>
    /// <param name="id"></param>
    /// <param name="disable"></param>
    /// <returns>bool</returns>
    public async Task<bool> DisableModel(int id, bool disable)
    {
      var model = await modelRepository.GetModelById(id);

      if (model == null || model.Id == 0)
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.modelNotFound, HttpStatusCode = "NotFound" };
      }

      model.Disabled = disable;

      modelServiceApplicationLogger.LogInformation(Constant.classname + "ModelService"
        + Constant.methodname + "DisableModel" + Constant.message + "To disable the model.");

      return await modelRepository.UpdateModel(model, AuditActionType.EnableDisable);
    }

    /// <summary>
    /// Post model.
    /// </summary>
    /// <param name="modelDto"></param>
    /// <returns>ModelDto</returns>
    public async Task<ModelDto> PostModel(ModelDto modelDto)
    {
      var models = await modelRepository.GetModelByModelNo(modelDto.ModelNumber);

      // if model with same model number exist then throw exception
      if (models.Any())
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.modelExistModelNumber, HttpStatusCode = "BadRequest" };
      }

      var model = mapper.Map<ModelDto, Model>(modelDto);

      await modelRepository.AddModel(model);

      var result = mapper.Map<Model, ModelDto>(model);

      modelServiceApplicationLogger.LogInformation(Constant.classname + "ModelService"
        + Constant.methodname + "PostModel" + Constant.message + "To post the model.");

      return result;
    }

    /// <summary>
    /// Delete the model.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>ModelDto</returns>
    public async Task<ModelDto> DeleteModel(int id)
    {
      var model = await modelRepository.GetModelById(id);

      if (model == null)
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.modelNotFound, HttpStatusCode = "NotFound" };
      }

      await modelRepository.DeleteModel(model);

      modelServiceApplicationLogger.LogInformation(Constant.classname + "ModelService"
         + Constant.methodname + "DeleteModel" + Constant.message + "To delete the model.");

      return mapper.Map<Model, ModelDto>(model);
    }

    /// <summary>
    /// Get dependent part models
    /// </summary>
    /// <param name="id"></param>
    /// <returns>list of PartModelDto</returns>
    public async Task<List<PartModelDto>> GetDependentPartModels(int id)
    {
      var incompleteRunOrderList = await incompleteRunOrderItemRepository.GetIncompleteRunOrderItemsByStatus(RunOrderItemStatus.New,
               RunOrderItemStatus.RunStarted, RunOrderItemStatus.Incomplete);

      var partIds = incompleteRunOrderList.Select(x => x.Id).ToArray();

      var dependentModels = mapper.Map<List<PartModel>, List<PartModelDto>>(await partModelsRepository.GetPartModelByPartIdsAndModelId(partIds, id));

      modelServiceApplicationLogger.LogInformation(Constant.classname + "ModelService"
       + Constant.methodname + "GetDependentPartModels" + Constant.message + "To get dependent part models.");

      return dependentModels;
    }

    /// <summary>
    /// Check model exist or not.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>bool</returns>
    private async Task<bool> ModelExists(int id)
    {
      var model = await modelRepository.GetModelById(id);

      modelServiceApplicationLogger.LogInformation(Constant.classname + "ModelService"
      + Constant.methodname + "ModelExists" + Constant.message + "To check model exist or not.");

      if (model != null && model.Id > 0)
      {
        return true;
      }

      return false;
    }
  }
}
