using CoilTracking.Business.Interfaces;
using CoilTracking.Business.TMMI;
using CoilTracking.Common;
using CoilTracking.Common.Constants;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.DataAccess.Interfaces;
using System.Collections.Generic;
using System.Linq;

namespace CoilTracking.Business.Implementation
{
  public class CoilFactory : ICoilFactory
  {
    private readonly IEnumerable<ICoilsFTZForTMMI> services;
    private readonly IUserHelper usersHelper;
    private readonly IPlantsRepository  plantsRepo;
    public CoilFactory(IEnumerable<ICoilsFTZForTMMI> services, IUserHelper usersHelper, IPlantsRepository plantsRepo)
    {
      this.services = services;
      this.usersHelper = usersHelper;
      this.plantsRepo = plantsRepo;
    }
    /// <summary>
    /// To create object in order to create required NAMC's Coils Service
    /// </summary>
    /// <returns>ICoilsService obj</returns>
    public ICoilsFTZForTMMI Create()
    {
      var NAMC = usersHelper.GetNAMCCode();
      var plant = plantsRepo.GetPlantName(NAMC);
      switch (plant)
      {
        case Constant.tmmiNAMC:
          return services.FirstOrDefault(x => x.GetType() == typeof(CoilsFTZForTMMI));
        default:
          return services.FirstOrDefault(x => x.GetType() == typeof(CoilsFTZ));
      }
    }
  }
}
