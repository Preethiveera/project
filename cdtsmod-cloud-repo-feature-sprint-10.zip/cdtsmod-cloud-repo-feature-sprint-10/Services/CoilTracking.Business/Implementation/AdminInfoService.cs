using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Logging;
using CoilTracking.DataAccess.Interfaces;

namespace CoilTracking.Business.Implementation
{
  public class AdminInfoService : IAdminInfoService
  {
    private readonly ICoilRepository coilsRepo;
    private readonly ILineRepository lineRepo;
    private readonly IBlankInfoesRepository dataRepo;
    private readonly ICoilTypeRepository coilTypeRepo;
    private readonly ICoilFieldRepository coilFieldRepo;
    private readonly ICoilFieldZoneRepository coilFieldZoneRepo;
    private readonly ICoilFieldLocationRepository coilFieldLocationRepo;
    private readonly IPartRepository partsRepo;
    private readonly IOPCConfigRepository kepServerRepo;
    private readonly IMillsRepository millRepo;
    private readonly IModelRepository modelRepo;
    private readonly IShiftRepository shiftRepo;

    private readonly IApplicationLogger<AdminInfoService> adminInfoServiceLogger;

    public AdminInfoService(ICoilRepository coilsRepo, ILineRepository lineRepo, IBlankInfoesRepository dataRepo, ICoilTypeRepository coilTypeRepo,
        ICoilFieldRepository coilFieldRepo, ICoilFieldZoneRepository coilFieldZoneRepo,
        ICoilFieldLocationRepository coilFieldLocationRepo, IPartRepository partsRepo, IOPCConfigRepository kepServerRepo,
      IMillsRepository millRepo, IModelRepository modelRepo, IShiftRepository shiftRepo, IApplicationLogger<AdminInfoService> adminInfoServiceLogger)
    {
      this.coilsRepo = coilsRepo;
      this.lineRepo = lineRepo;
      this.dataRepo = dataRepo;
      this.coilTypeRepo = coilTypeRepo;
      this.coilFieldRepo = coilFieldRepo;
      this.coilFieldZoneRepo = coilFieldZoneRepo;
      this.coilFieldLocationRepo = coilFieldLocationRepo;
      this.partsRepo = partsRepo;
      this.kepServerRepo = kepServerRepo;
      this.millRepo = millRepo;
      this.modelRepo = modelRepo;
      this.shiftRepo = shiftRepo;
      this.adminInfoServiceLogger = adminInfoServiceLogger;
      //this.userRepo=userRepo
    }
    public object GetDashboardCounts()
    {
      adminInfoServiceLogger.LogInformation(Constant.classname + "AdminInfoService" + Constant.methodname + "GetDashboardCounts" + Constant.message + "Get count of  List of all admin dashboards");

      return new
      {
        coilCount = coilsRepo.GetCountOfCoils(),
        blankCount = dataRepo.GetCountOfBlankInfoes(),
        lineCount = lineRepo.GetCountOfLines(),
        coilTypeCount = coilTypeRepo.GetCountIfCoilTypes(),
        coilFieldCount = coilFieldRepo.GetCountOfCoilField(),
        coilFieldZoneCount = coilFieldZoneRepo.GetCountOfCoilFieldZones(),
        coilFieldLocationCount = coilFieldLocationRepo.GetCountOfCoilFieldLocation(),
        partCount = partsRepo.GetCountOfparts(),
        kepServerCount = kepServerRepo.GetCountOfOPCConfigs(),
        millCount = millRepo.GetCountOfMills(),
        modelCount = modelRepo.GetCountOfModels(),
        shiftCount = shiftRepo.GetCountofShifts(),
        userCount = 0
      };
    }
  }
}
