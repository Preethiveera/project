using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CoilTracking.Business.Implementation
{
  public class PatternLetterService : IPatternLetterService
  {
    private readonly IPatternLetterRepository patternLetterRepo;
    private readonly IPatternCalendarRepository patternCallendarRepo;
    private readonly IApplicationLogger<PatternLetterService> patternLetterServiceLogger;

    public PatternLetterService(IPatternLetterRepository patternLetterRepo, IPatternCalendarRepository patternCallendarRepo, IApplicationLogger<PatternLetterService> patternLetterServiceLogger)
    {
      this.patternLetterRepo = patternLetterRepo;
      this.patternCallendarRepo = patternCallendarRepo;
      this.patternLetterServiceLogger = patternLetterServiceLogger;
    }


    /// <summary>
    /// Get Pattern Letter
    /// </summary>
    /// <returns></returns>
    public IQueryable<PatternLetterDto> GetPatternLetter()
    {
      var patternLetters = patternLetterRepo.GetPatternLetter();
      List<PatternLetterDto> patternLetterDtos = new List<PatternLetterDto>();
      PatternLetterDto patternLetterDto;
      patternLetterServiceLogger.LogInformation(Constant.classname + "PatternLetterService" + Constant.methodname + "GetPatternLetter");
      foreach (var patternLetter in patternLetters)
      {
        patternLetterDto = new PatternLetterDto();
        patternLetterDtos.Add(patternLetterDto);
        patternLetterDto.Id = patternLetter.Id;
        patternLetterDto.Name = patternLetter.Name;
        patternLetterDto.Desc = patternLetter.Desc;
        patternLetterDto.Disabled = patternLetter.Disabled;
        patternLetterDto.Plant_Id = patternLetter.Plant_Id;

      }
      return patternLetterDtos.AsQueryable();

    }

    /// <summary>
    /// Get PatternLetter by Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public PatternLetterDto GetPatternLetterById(int id)
    {
      var patternLetters = patternLetterRepo.GetPatternLetterById(id);

      PatternLetterDto patternLetterDto = null;
      if (patternLetters != null)
      {

        patternLetterDto = new PatternLetterDto
        {
          Id = patternLetters.Id,
          Name = patternLetters.Name,
          Desc = patternLetters.Desc,
          Disabled = patternLetters.Disabled
        };
      }
      patternLetterServiceLogger.LogInformation(Constant.classname + "PatternLetterService" + Constant.methodname + "GetPatternLetterById");

      return patternLetterDto;

    }

    /// <summary>
    /// To add new PatternLetters
    /// </summary>
    /// <param name="patternLetterDto"></param>
    /// <returns></returns>

    public PatternLetter PostPatternLetter(PatternLetterDto patternLetterDto)
    {
      PatternLetter patternLettersAdded = null;

      PatternLetter patternLetter = new PatternLetter
      {
        Name = patternLetterDto.Name,
        Desc = patternLetterDto.Desc,
        Disabled = patternLetterDto.Disabled
      };

      var getPatternLetterByName = patternLetterRepo.GetPatternLetterByName(patternLetter.Name);

      if (patternLetter.Name.Equals(Constant.defaultPatternLetter, StringComparison.OrdinalIgnoreCase))
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.defaultPatternExists };
      }
      else if (getPatternLetterByName != null && getPatternLetterByName.Name.ToUpper().Equals(patternLetter.Name.ToUpper()))
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.editingMessageForPatternLetter, HttpStatusCode = "BadRequest" };
      }
      else
      {
       patternLettersAdded = patternLetterRepo.PostPatternLetter(patternLetter);
      }

      return patternLettersAdded;

    }

    /// <summary>
    /// to edit existing PatternLetters
    /// </summary>
    /// <param name="id"></param>
    /// <param name="patternLetterDto"></param>
    /// <returns></returns>
    public bool PutPatternLetter(int id, PatternLetterDto patternLetterDto)
    {
      PatternLetter patternLetter = new PatternLetter
      {
        Id = patternLetterDto.Id,
        Name = patternLetterDto.Name,
        Desc = patternLetterDto.Desc,
        Disabled = patternLetterDto.Disabled
      };

      var patternLetterExists = patternLetterRepo.GetPatternLetterById(id);

      if (patternLetterExists == null)
      {
        return false;
      }
      patternLetter.Plant_Id =  patternLetterExists.Plant_Id;
      var editedPatternLetters = patternLetterRepo.PutPatternLetter(id, patternLetter);

      return true;

    }

    /// <summary>
    /// To delete a Pattern Letter
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public PatternLetterDto DeletePatternLetter(int id)
    {
      var patternLetterById = patternLetterRepo.GetPatternLetterById(id);
      var toDeletePatternLetters = patternLetterRepo.DeletePatternLetter(id);


      PatternLetterDto patternLetterDto = new PatternLetterDto
      {
        Id = patternLetterById.Id,
        Name = patternLetterById.Name,
        Desc = patternLetterById.Desc,
        Disabled = patternLetterById.Disabled
      };


      return patternLetterDto;
    }

    /// <summary>
    /// To disable Pattern Letter
    /// </summary>
    /// <param name="id"></param>
    /// <param name="disable"></param>
    /// <returns></returns>
    public bool DisablePatternLetter(int id, bool disable)
    {
      var patternLetterExists = patternLetterRepo.PatternLetterExists(id);
      if (!patternLetterExists)
      {
        return false;
      }
      var checkIfPatterLetterDisabled = patternLetterRepo.DisablePatternLetter(id, disable);

      return true;
    }

    /// <summary>
    /// To find associations of PatternLetter with PatternCallendar
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public List<string> CheckDependency(int id)
    {
      bool associatedItem = false;
      var patternLetterById = patternLetterRepo.GetPatternLetterById(id);

      if (patternLetterById != null)
      {
        associatedItem = patternCallendarRepo.GetPatternLetterAssociation(patternLetterById);

      }

      List<string> patternAssociationType = new List<string>();
      if (associatedItem)
      {
        patternAssociationType.Add("patterncalendar");
      }

      return patternAssociationType;

    }

    /// <summary>
    /// To check if the model is modified while performing delete operation
    /// </summary>
    /// <param name="id"></param>
    /// <param name="patternLetterDto"></param>
    /// <returns></returns>
    public bool CheckEdit(int id, PatternLetterDto patternLetterDto)
    {
      PatternLetter patternLetter = new PatternLetter
      {
        Name = patternLetterDto.Name,
        Desc = patternLetterDto.Desc,
        Disabled = patternLetterDto.Disabled
      };
      var patternLetterFromDB = patternLetterRepo.CheckEdit(id);
      List<string> checkIfEdited = new List<string>();
      if (patternLetterFromDB != null && (patternLetterFromDB.Name != patternLetterDto.Name || patternLetterFromDB.Desc != patternLetterDto.Desc || patternLetterFromDB.Disabled != patternLetterDto.Disabled))
      {
          checkIfEdited.Add("editing");
      }
      if (checkIfEdited.Any())
      {
        return false;

      }
      return true;
    }
  }
}
