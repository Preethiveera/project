using CoilTracking.Business.TMMI;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class CoilsFTZForTMMI : ICoilsFTZForTMMI
  {
    private readonly ICoilRepository coilRepo;
    private readonly IApplicationLogger<CoilsService> coilsServiceLogger;
    public CoilsFTZForTMMI(ICoilRepository coilRepo, IApplicationLogger<CoilsService> coilsServiceLogger)
    {
      this.coilRepo = coilRepo;
      this.coilsServiceLogger = coilsServiceLogger;
    }

    public async Task<Coil> GetCoilFTZByPrefix(string ftz)
    {
      //Added for TMMI
      string sPrefixFtz = 'S' + ftz;
      string tPrefixFtz = 'T' + ftz;
      var coil = await coilRepo.GetCoilsByPrefixFtz(sPrefixFtz, tPrefixFtz);
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "GetCoilByFTZ" + Constant.parameters + sPrefixFtz + tPrefixFtz);
      return coil;
    }
  }
}
