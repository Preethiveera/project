using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class ScheduleReportService : IScheduleReportService
  {
    private readonly IScheduleReportRepository scheduleReportRepo;
    private readonly IApplicationLogger<ScheduleReportService> scheduleReportServiceLogger;

    public ScheduleReportService(IScheduleReportRepository scheduleReportRepo, IApplicationLogger<ScheduleReportService> scheduleReportServiceLogger)
    {
      this.scheduleReportRepo = scheduleReportRepo;
      this.scheduleReportServiceLogger = scheduleReportServiceLogger;
    }


    /// <summary>
    /// Get Schedule Report
    /// </summary>
    /// <returns></returns>
    public IQueryable<ScheduleReportDto> GetScheduleReport()
    {
      var scheduleReports = scheduleReportRepo.Get();
      scheduleReportServiceLogger.LogInformation(Constant.classname + "ScheduleReportService" + Constant.methodname + "GetScheduleReport" + Constant.message + "Get List of all scheduleReports");
      List<ScheduleReportDto> scheduleReportDtos = new List<ScheduleReportDto>();
      ScheduleReportDto scheduleReportDto;

      foreach (var scheduleReport in scheduleReports)
      {
        scheduleReportDto = new ScheduleReportDto
        {
          Id = scheduleReport.Id,
          Email = scheduleReport.Email,
          CoilReport = scheduleReport.CoilReport,
          ScrapReport = scheduleReport.ScrapReport,
          RunReport = scheduleReport.RunReport
        };
        scheduleReportDtos.Add(scheduleReportDto);

      }
      return scheduleReportDtos.AsQueryable();

    }

    /// <summary>
    /// Get ScheduleReport by Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public ScheduleReportDto GetScheduleReportById(int id)
    {
      var scheduleReports = scheduleReportRepo.GetScheduleReportByID(id);

      ScheduleReportDto scheduleReportDto = null;
      if (scheduleReports != null)
      {

        scheduleReportDto = new ScheduleReportDto
        {
          Id = scheduleReports.Id,
          Email = scheduleReports.Email,
          CoilReport = scheduleReports.CoilReport,
          RunReport = scheduleReports.RunReport,
          ScrapReport = scheduleReports.ScrapReport
        };
      }

      return scheduleReportDto;

    }

    /// <summary>
    /// To add new ScheduleReport
    /// </summary>
    /// <param name="scheduleReportDto"></param>
    /// <returns></returns>

    public async Task<int> PostScheduleReport(ScheduleReportDto scheduleReportDto)
    {
      int scheduleReportAddedID = 0;

      ScheduledReportEmail scheduledReport = new ScheduledReportEmail
      {
        Email = scheduleReportDto.Email,
        CoilReport = scheduleReportDto.CoilReport,
        RunReport = scheduleReportDto.RunReport,
        ScrapReport = scheduleReportDto.ScrapReport
      };

      Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
      Match match = regex.Match(scheduledReport.Email);
      if (!match.Success)
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.invalidEmailAddress };
      }
      var getScheduleReportByEmail = scheduleReportRepo.GetScheduleReportByEmail(scheduledReport.Email);

      if (getScheduleReportByEmail != null && scheduledReport.Email.Equals(getScheduleReportByEmail.Email, StringComparison.OrdinalIgnoreCase))
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.scheduleReportExists, HttpStatusCode = "BadRequest" };
      }
      else
      {
        scheduleReportAddedID = await scheduleReportRepo.PostScheduleReport(scheduledReport);
      }

      return scheduleReportAddedID;

    }

    /// <summary>
    /// to edit existing ScheduleReport
    /// </summary>
    /// <param name="id"></param>
    /// <param name="scheduleReportDto"></param>
    /// <returns></returns>
    public bool PutScheduleReport(int id, ScheduleReportDto scheduleReportDto)
    {
      ScheduledReportEmail scheduledReport = new ScheduledReportEmail
      {
        Id = scheduleReportDto.Id,
        Email = scheduleReportDto.Email,
        CoilReport = scheduleReportDto.CoilReport,
        RunReport = scheduleReportDto.RunReport,
        ScrapReport = scheduleReportDto.ScrapReport
      };

      var scheduleReportExists = scheduleReportRepo.ScheduleReportExists(id);

      if (!scheduleReportExists)
      {
        return false;
      }
      var editedScheduleReport = scheduleReportRepo.PutScheduleReport(id, scheduledReport);

      return true;

    }

    /// <summary>
    /// To delete a Schedule Report
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public ScheduleReportDto DeleteScheduleReport(int id)
    {
      var scheduleReportById = scheduleReportRepo.GetScheduleReportByID(id);
      var toDeleteScheduleReport = scheduleReportRepo.DeleteScheduleReport(id);


      ScheduleReportDto scheduleReportDto = new ScheduleReportDto
      {
        Id = scheduleReportById.Id,
        Email = scheduleReportById.Email,
        CoilReport = scheduleReportById.CoilReport,
        RunReport = scheduleReportById.RunReport,
        ScrapReport = scheduleReportById.ScrapReport
      };


      return scheduleReportDto;
    }

  }
}
