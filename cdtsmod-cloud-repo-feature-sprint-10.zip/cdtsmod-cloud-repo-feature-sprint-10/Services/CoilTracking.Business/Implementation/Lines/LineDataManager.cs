using AutoMapper;
using CoilTracking.Business.Interfaces;
using CoilTracking.Business.Interfaces.Lines;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using Newtonsoft.Json;
using System;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation.Lines
{
  public class LineDataManager : ILineDataManager
  {
    private readonly ILineRepository lineRepository;
    private readonly IMapper mapper;
    private readonly IApplicationLogger<LineDataManager> logger;
    private readonly IWebSocketClientService webSocketClientService;

    public LineDataManager(ILineRepository lineRepository,
      IMapper mapper,
      IApplicationLogger<LineDataManager> logger,
      IWebSocketClientService webSocketClientService)
    {
      this.lineRepository = lineRepository;
      this.mapper = mapper;
      this.logger = logger;
      this.webSocketClientService = webSocketClientService;
    }
    public async Task<LineData> ProcessSavedData(LineData savedData, LineData lineData, Line line, string[] plcTags, DataUpdateDto currentValues)
    {
      DataUpdateDto savedValues = JsonConvert.DeserializeObject<DataUpdateDto>(savedData.DataUpdate);
      logger.LogInformation(Constant.classname + "LineDataManager" + Constant.methodname + "ProcessSavedData" + Constant.message + "Starting to process line data");
      if (currentValues.CoilODWarning != savedValues.CoilODWarning)
      {

        await webSocketClientService.CoilODWarning(line.Id);
      }

      //Downtime values from PLC needs to be tracked internally for each DataNumber
      int downTime = System.Convert.ToInt32((lineData.UpdateTime - savedData.UpdateTime).TotalSeconds);

      HandleDtFlags(ref currentValues, ref savedValues, downTime);

      UpdateDtDto updateDtDto = new UpdateDtDto
      {
        LineId = line.Id,
        DataNum = currentValues.Die,
#pragma warning disable S2184 // Results of integer division should not be assigned to floating point variables
        Adc = currentValues.DownTimeVals[plcTags[7]].Counter / 60,
        Maint = currentValues.DownTimeVals[plcTags[8]].Counter / 60,
        Tooldie = currentValues.DownTimeVals[plcTags[9]].Counter / 60,
        Prod = currentValues.DownTimeVals[plcTags[10]].Counter / 60,
        Kanban = currentValues.DownTimeVals[plcTags[11]].Counter / 60,
        Tryout = currentValues.DownTimeVals[plcTags[12]].Counter / 60,
#pragma warning restore S2184 // Results of integer division should not be assigned to floating point variables
        Schd = currentValues.DownTimeVals[plcTags[13]].Counter
      };

      await webSocketClientService.UpdateDt(updateDtDto);

      if (savedValues.Die == currentValues.Die)
      {
        HandleStackCounters(ref currentValues, ref savedValues);

        int stackerCount = (currentValues.StackerVals[plcTags[2]].CurVal + currentValues.StackerVals[plcTags[3]].CurVal +
            currentValues.StackerVals[plcTags[4]].CurVal + currentValues.StackerVals[plcTags[5]].CurVal);


        await webSocketClientService.UpdateStackerCount(line.Id, currentValues.Die, stackerCount);
        await webSocketClientService.UpdateStrokeCount(line.Id, currentValues.Die, currentValues.StackerVals[plcTags[1]].CurVal);

        currentValues.IsNew = false;
        savedData.DataUpdate = JsonConvert.SerializeObject(currentValues);
        savedData.UpdateTime = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.UtcNow, line.Plant.TimeZone.Name);
        lineRepository.UpdateLineData(savedData);
        logger.LogInformation(Constant.classname + "LineDataManager" + Constant.methodname + "ProcessSavedData" + Constant.message + "Updating the Values because the current values were old");
      }
      else //New Data Run set
      {
        if (currentValues.StackerVals[plcTags[1]].CurVal > 0) //ASSUMTION: New Run actually starts only when stroke > 0
        {
          currentValues.IsNew = false;

          lineData.DataUpdate = JsonConvert.SerializeObject(currentValues);
          await lineRepository.AddLineData(mapper.Map<LineData>(lineData));
          logger.LogInformation(Constant.classname + "LineDataManager" + Constant.methodname + "ProcessSavedData" + Constant.message + "Add line data because stroke > 0");
          await webSocketClientService.BlankingRunStarted(line.Id, currentValues.Die);
        }
        else if (currentValues.StackerVals[plcTags[1]].CurVal == 0) //ASSUMTION: Run ends when Data# changes && stroke == 0
        {
          if (!currentValues.IsNew)
          {
            SetupCountersAndFlags(ref currentValues);

            lineData.DataUpdate = JsonConvert.SerializeObject(currentValues);
            lineData.UpdateTime = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.UtcNow, line.Plant.TimeZone.Name);
            logger.LogInformation(Constant.classname + "LineDataManager" + Constant.methodname + "ProcessSavedData" + Constant.message + "Adding the line data when data changes and stroke == 0");
            await lineRepository.AddLineData(mapper.Map<LineData>(lineData));
          }
          await webSocketClientService.BlankingRunStopped(line.Id, savedValues.Die,
                            savedValues.StackerVals[plcTags[1]].CurVal);
        }
      }

      return lineData;
    }

    public async Task<LineData> CreateNewRun(LineData lineData, DataUpdateDto currentValues)
    {
      SetupCountersAndFlags(ref currentValues);
      await webSocketClientService.BlankingRunStarted(lineData.Id, currentValues.Die);

      lineData.DataUpdate = JsonConvert.SerializeObject(currentValues);
      await lineRepository.AddLineData(mapper.Map<LineData>(lineData));
      logger.LogInformation(Constant.classname + "LineDataManager" + Constant.methodname + "ProcessSavedData" + Constant.message + "Creating a new run for line data");
      return lineData;
    }

    private void HandleDtFlags(ref DataUpdateDto currentVals, ref DataUpdateDto savedVals, int downTime)
    {
      foreach (DownTimeContainer dtContainer in currentVals.DownTimeVals.Values)
      {
        if (dtContainer.Flag)
        {
          dtContainer.Counter = savedVals.DownTimeVals[dtContainer.Tag].Counter + downTime;
        }
        else
        {
          dtContainer.Counter = savedVals.DownTimeVals[dtContainer.Tag].Counter;
        }
      }
    }

    private void HandleStackCounters(ref DataUpdateDto currentVals, ref DataUpdateDto savedVals)
    {
      foreach (StackerContainer stContainer in currentVals.StackerVals.Values)
      {
        if (stContainer.CurVal == 0)
        {
          if (savedVals.StackerVals[stContainer.Tag].CurVal != 0)
          {
            int oldVal = savedVals.StackerVals[stContainer.Tag].CurVal -
                savedVals.StackerVals[stContainer.Tag].StartVal;
            oldVal = oldVal >= 0 ? oldVal : 0;
            stContainer.PrevVal = oldVal;
            stContainer.CurVal = oldVal;
          }
          stContainer.StartVal = 0;
        }
        else
        {
          stContainer.CurVal += savedVals.StackerVals[stContainer.Tag].PrevVal;
          stContainer.CurVal -= savedVals.StackerVals[stContainer.Tag].StartVal; //reduce the stacker starting value
          stContainer.CurVal = stContainer.CurVal >= 0 ? stContainer.CurVal : 0;
          stContainer.PrevVal = savedVals.StackerVals[stContainer.Tag].PrevVal;
          stContainer.StartVal = savedVals.StackerVals[stContainer.Tag].StartVal;
        }
      }
    }

    private void SetupCountersAndFlags(ref DataUpdateDto dto)
    {
      foreach (DownTimeContainer dtContainer in dto.DownTimeVals.Values)
      {
        dtContainer.Flag = false;
        dtContainer.Counter = 0;
      }

      foreach (StackerContainer stContainer in dto.StackerVals.Values)
      {
        stContainer.StartVal = stContainer.CurVal;
        stContainer.PrevVal = 0;
      }
      dto.IsNew = true;
    }
  }
}
