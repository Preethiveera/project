using AutoMapper;
using CoilTracking.Business.Interfaces;
using CoilTracking.Business.Interfaces.Lines;
using CoilTracking.Common;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class LineService : ILineService
  {
    private readonly ILineRepository lineRepo;
    private readonly IApplicationLogger<LineService> logger;
    private readonly IMapper mapper;
    private readonly IOPCClientServiceManager oPCClientServiceManager;
    private readonly IOPCConfigRepository oPCConfigRepository;
    private readonly IPlantsRepository plantsRepository;
    private readonly ILineDataManager lineDataManager;
    private readonly IPatternsRepository patternsRepository;
    private readonly IPatternCalendarRepository patternCalendarRepository;
    private readonly IUserHelper usersHelper;

    public LineService(ILineRepository lineRepo,
      IApplicationLogger<LineService> logger,
      IMapper mapper,
      IOPCClientServiceManager oPCClientServiceManager,
      IOPCConfigRepository oPCConfigRepository,
      IPlantsRepository plantsRepository,
      ILineDataManager lineDataManager,
      IPatternsRepository patternsRepository,
      IPatternCalendarRepository patternCalendarRepository, IUserHelper usersHelper)
    {
      this.lineRepo = lineRepo;
      this.logger = logger;
      this.mapper = mapper;
      this.oPCClientServiceManager = oPCClientServiceManager;
      this.oPCConfigRepository = oPCConfigRepository;
      this.plantsRepository = plantsRepository;
      this.lineDataManager = lineDataManager;
      this.patternsRepository = patternsRepository;
      this.patternCalendarRepository = patternCalendarRepository;
      this.usersHelper = usersHelper;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public List<AndonBlankingLinesDto> GetLinesForAndons()
    {

      var lines = lineRepo.GetLines();
      List<AndonBlankingLinesDto> lineDtos = new List<AndonBlankingLinesDto>();
      AndonBlankingLinesDto lineDto;

      foreach (var line in lines)
      {
        lineDto = new AndonBlankingLinesDto();
        lineDtos.Add(lineDto);

        lineDto.Name = line.LineName;
        lineDto.PartNumber = "???????-?????"; //TODO: Get this information from.... the PLC???
        lineDto.PartName = "?????????  ???? ???????? ?????";
        lineDto.Model = "???/?????/???";
        lineDto.Coil = "?-?-?";
        lineDto.PartsRequested = -111;
        lineDto.PartsProduced = -222;
      }

      return lineDtos;
    }

    /// <summary>
    /// Get list of line
    /// </summary>
    /// <returns></returns>
    public async Task<IQueryable<LineDto>> GetLines()
    {
      var lines = await lineRepo.GetLinesAsync();
      logger.LogInformation(Constant.classname + "LineService" + Constant.methodname + "GetLines" + Constant.message + "Get list of all lines.");

      return mapper.Map<List<LineDto>>(lines).AsQueryable();
    }

    /// <summary>
    /// Get line by ID
    /// </summary>
    /// <returns></returns>
    public async Task<LineDto> GetLineById(int id)
    {
      var line = await lineRepo.GetLineByIdAsync(id);
      logger.LogInformation(Constant.classname + "LineService" + Constant.methodname + "GetLineById" + Constant.message + "Get line by Id.");
      return mapper.Map<LineDto>(line);
    }

    /// <summary>
    /// Get line data to edit
    /// </summary>
    /// <returns></returns>
    public async Task<LineDto> GetLineForEdit(int id)
    {
      var line = await lineRepo.GetLineByIdAsync(id);
      if (line == null)
      {
        throw new CoilTrackingException { HttpStatusCode = "NotFound" };
      }

      var dto = mapper.Map<LineDto>(line);
      if (!string.IsNullOrWhiteSpace(line.Tags))
      {
        dto = ProcessTags(mapper.Map<LineDto>(line), line.Tags);
      }

      dto.Disabled = line.Disabled;
      logger.LogInformation(Constant.classname + "LineService" + Constant.methodname + "GetLineForEdit" + Constant.message + "Get line for Edit by Id.");
      return dto;
    }

    /// <summary>
    /// Update line subscription
    /// </summary>
    /// <returns></returns>
    public async Task<LineDto> UpdateLineSubscription(int id, bool subscribe, string token=null)
    {
      var line = await lineRepo.GetLineByIdAsync(id);
      if (line == null)
      {
        throw new CoilTrackingException { HttpStatusCode = "NotFound" };
      }
      logger.LogInformation( Constant.methodname + "UpdateLineSubscription" + Constant.message + "Before GetLineInfoData in Updating the line subscription");

      await oPCClientServiceManager.GetLineInfoData(line, subscribe, token);
      logger.LogInformation(Constant.classname + "LineService" + Constant.methodname + "UpdateLineSubscription" + Constant.message + "Updating the line subscription");
      return mapper.Map<LineDto>(line);
    }

    /// <summary>
    /// Get subscribed lines list
    /// </summary>
    /// <returns></returns>
    public async Task<List<LineInfo>> GetSubscribedLines(string namcCode)
    {
      var lineConfigs = await lineRepo.GetSubscribedLines(namcCode);
      var lineInfos =  oPCClientServiceManager.GetLineInfos(lineConfigs);
      logger.LogInformation(Constant.classname + "LineService" + Constant.methodname + "GetSubscribedLines" + Constant.message + "Get list of all subscribed lines.");
      return lineInfos;
    }

    /// <summary>
    /// Diable line
    /// </summary>
    /// <returns></returns>
    public async Task<bool> DisableLine(int id, bool disable)
    {
      var line = await lineRepo.GetLineByIdAsync(id);
      if (line == null)
      {
        throw new CoilTrackingException { HttpStatusCode = "NotFound" };
      }
      line.Disabled = disable;
      lineRepo.DisableLine(line);

      try
      {
        await lineRepo.SaveChanges(AuditActionType.ModifyEntity);
      }
      catch (DbUpdateConcurrencyException)
      {
        if (line == null)
        {
          throw new CoilTrackingException { HttpStatusCode = "NotFound" };
        }
        else
        {
          throw;
        }
      }

      logger.LogInformation(Constant.classname + "LineService" + Constant.methodname + "DisableLine" + Constant.message + "To disable a line");
      return true;
    }

    /// <summary>
    /// Update a line
    /// </summary>
    /// <returns></returns>
    public async Task<bool> PutLine(LineDto line)
    {
      var lineData = mapper.Map<Line>(line);
      try
      {
        await lineRepo.PutLine(lineData);
      }
      catch (DbUpdateConcurrencyException)
      {
        if (line == null)
        {
          throw new CoilTrackingException { HttpStatusCode = "NotFound" };
        }
        else
        {
          throw;
        }
      }

      logger.LogInformation(Constant.classname + "LineService" + Constant.methodname + "PutLine" + Constant.message + "To update a line");
      return true;
    }

    /// <summary>
    /// Update line
    /// </summary>
    /// <returns></returns>
    public async Task<LineDto> UpdateLine(int id, LineDto lineDto)
    {
      var line = await lineRepo.GetLineByLineIDAsync(id);
      line.LineName = lineDto.LineName;
      line.LinePath = lineDto.LinePath;
      line.OPCServer = await oPCConfigRepository.GetOPCConfigById(lineDto.OPCServer.Id);
      var NAMC = usersHelper.GetNAMCCode();
      var plant = plantsRepository.GetPlantName(NAMC);
      line.Plant = await plantsRepository.GetPlantByNAMCCode(plant);
      line.Tags = string.Concat(lineDto.DataNumberTag, ",",
          lineDto.DieStrokeTag, ",",
          lineDto.Stacker1FrontTag, ",",
          lineDto.Stacker1RearTag, ",",
          lineDto.Stacker2FrontTag, ",",
          lineDto.Stacker2RearTag, ",",
          lineDto.CoilODTag, ",",
          lineDto.AdcDt, ",",
          lineDto.MaintDt, ",",
          lineDto.ToolDt, ",",
          lineDto.ProdDt, ",",
          lineDto.KanbanDt, ",",
          lineDto.TryoutDt, ",",
          lineDto.SchdDt);
      line.Disabled = lineDto.Disabled;
      await lineRepo.UpdateLineSubscription(line);

      logger.LogInformation(Constant.classname + "LineService" + Constant.methodname + "UpdateLine" + Constant.message + "To update a line");
      return lineDto;
    }

    /// <summary>
    /// Add line
    /// </summary>
    /// <returns></returns>
    public async Task<int> AddLine(LineDto line)
    {
      var lineData = mapper.Map<Line>(line);
      var response = await lineRepo.AddLine(lineData);
      logger.LogInformation(Constant.classname + "LineService" + Constant.methodname + "AddLine" + Constant.message + "To add a line");
      return response.Id;
    }

    /// <summary>
    /// Save line
    /// </summary>
    /// <returns></returns>
    public async Task<LineDto> SaveLine(LineDto lineDto)
    {
      var line = new Line();
      line.LineName = lineDto.LineName;
      line.LinePath = lineDto.LinePath;
      line.OPCServer = await oPCConfigRepository.GetOPCConfigById(lineDto.OPCServer.Id);
      var NAMC = usersHelper.GetNAMCCode();
      var plant = plantsRepository.GetPlantName(NAMC);
      line.Plant = await plantsRepository.GetPlantByNAMCCode(plant);
      line.Tags = string.Concat(lineDto.DataNumberTag, ",", lineDto.DieStrokeTag);
      line.Disabled = lineDto.Disabled;

      lineRepo.AddPlantAndOPCServerData(line);
      await lineRepo.AddLine(line);
      lineDto.Id = line.Id;
      logger.LogInformation(Constant.classname + "LineService" + Constant.methodname + "SaveLine" + Constant.message + "To save a line");
      return lineDto;
    }

    /// <summary>
    /// Add line Data to a line
    /// </summary>
    /// <returns></returns>
    public async Task<LineDataDto> PostLineData(LineDataDto lineDataDto)
    {
      logger.LogInformation(Constant.methodname + "PostLineData" + "line data details=" + lineDataDto.Id + " " + lineDataDto.LineId + " " + lineDataDto.DataUpdate + " " + lineDataDto.UpdateTime);
      LineData lineData = new LineData();
      lineData.DataUpdate = lineDataDto.DataUpdate;
      lineData.LineId = lineDataDto.LineId;

      Line line = await lineRepo.GetLineWithPlantDetails(lineDataDto.LineId);
      lineData.UpdateTime = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.UtcNow, line.Plant.TimeZone.Name);

      LineData savedData = null;
      
      try
      {
        savedData = await lineRepo.GetLineDataByLineId(lineData);
        
      }
      catch (Exception)
      {
        logger.LogInformation(Constant.classname + "LineService" + Constant.methodname + "PostLineData" + Constant.message + "exception occured as savedData is null");
      }


      string[] plcTags = line.Tags.Split(',');
      var converter = new LineDataUpdateConverter(plcTags);

      DataUpdateDto currentValues = JsonConvert.DeserializeObject<DataUpdateDto>(lineData.DataUpdate, converter);

      if (savedData != null)
      {
        var response = await lineDataManager.ProcessSavedData(savedData, lineData, line, plcTags, currentValues);
        lineData = response;
      }
      else //New run for the day
      {
        var response = await lineDataManager.CreateNewRun(lineData, currentValues);
        lineData = response;
      }

      try
      {
        await lineRepo.SaveChanges(savedData != null ? AuditActionType.ModifyEntity : AuditActionType.CreateEntity, "OPCClient");
      }
      catch (Exception)
      {
        throw new CoilTrackingException { HttpStatusCode = "InternalServerError" };
      }

      logger.LogInformation(Constant.classname + "LineService" + Constant.methodname + "PostLineData" + Constant.message + "To post line data of a line");
      LineDataDto dto = new LineDataDto
      {
        Id = lineData.Id,
        LineId = lineData.LineId,
        DataUpdate = lineData.DataUpdate,
        UpdateTime =lineData.UpdateTime.Ticks
      };
      return dto;
    }

    /// <summary>
    /// Delete line
    /// </summary>
    /// <returns></returns>
    public async Task<LineDto> DeleteLine(int id)
    {
      var line = await lineRepo.GetLineByLineIDAsync(id);
      if (line == null)
      {
        throw new CoilTrackingException { HttpStatusCode = "NotFound" };
      }

      if (await patternCalendarRepository.PatternCalenderExistsByLineId(id))
      {
        await patternCalendarRepository.RemovePatternCalenderByLineId(id);
      }

      try
      {
        await lineRepo.DeleteLine(line);
      }
      catch(Exception e)
      {
        throw new CoilTrackingException {HttpStatusCode = "BadRequest", ErrorMessage = e.Message};
      }
      logger.LogInformation(Constant.classname + "LineService" + Constant.methodname + "DeleteLine" + Constant.message + "To delete a line");
      return mapper.Map<LineDto>(line);
    }

    /// <summary>
    /// Check Edit for line
    /// </summary>
    /// <returns></returns>
    public async Task<List<string>> CheckEdit(int id, LineDto line)
    {
      List<string> lineAssociation = new List<string>();
      if (line.Id != await lineRepo.CheckEdit(id))
      {
        lineAssociation.Add(Constant.Edited);
      }

      logger.LogInformation(Constant.classname + "LineService" + Constant.methodname + "CheckEdit" + Constant.message + "Check Edit Line");
      return lineAssociation;
    }

    /// <summary>
    /// Check Dependency line
    /// </summary>
    /// <returns></returns>
    public async Task<List<string>> CheckDependency(int id)
    {
      List<string> lineAssociation = new List<string>();
      var linesInIncompleteRunOrders = await lineRepo.GetIncompleteRunOrderItem(id);

      if (linesInIncompleteRunOrders.Any())
      {
        lineAssociation.Add(Constant.RunOrder);
      }
      if (await patternsRepository.PatternExists(id))
      {

        var patterns = await patternsRepository.GetPatternByLineId(id);
        foreach (var val in patterns)
        {
          if (val.PatternItems.Count != 0)
          {
            lineAssociation.Add(Constant.Pattern);
          }
        }
      }

      logger.LogInformation(Constant.classname + "LineService" + Constant.methodname + "CheckDependency" + Constant.message + "Check Dependency");
      return lineAssociation;
    }

    private LineDto ProcessTags(LineDto dto, string lineTags)
    {
      string[] tags = lineTags.Split(',');
      dto.DataNumberTag = tags[0];
      dto.DieStrokeTag = tags.Length > 1 ? tags[1] : "-";
      dto.Stacker1FrontTag = tags.Length > 2 ? tags[2] : "-";
      dto.Stacker1RearTag = tags.Length > 3 ? tags[3] : "-";
      dto.Stacker2FrontTag = tags.Length > 4 ? tags[4] : "-";
      dto.Stacker2RearTag = tags.Length > 5 ? tags[5] : "-";
      dto.CoilODTag = tags.Length > 6 ? tags[6] : "-";
      dto.AdcDt = tags.Length > 7 ? tags[7] : "-";
      dto.MaintDt = tags.Length > 8 ? tags[8] : "-";
      dto.ToolDt = tags.Length > 9 ? tags[9] : "-";
      dto.ProdDt = tags.Length > 10 ? tags[10] : "-";
      dto.KanbanDt = tags.Length > 11 ? tags[11] : "-";
      dto.TryoutDt = tags.Length > 12 ? tags[12] : "-";
      dto.SchdDt = tags.Length > 13 ? tags[13] : "-";

      return dto;
    }
   public string TestPLC()
    {
      var val =  oPCClientServiceManager.TestPLC();
      return val;
    }
   public async Task<LineData> GetLinesData(int lineId)
    {
      var lineData =await lineRepo.GetLinesData(lineId);
      return lineData;

    }

  }
}
