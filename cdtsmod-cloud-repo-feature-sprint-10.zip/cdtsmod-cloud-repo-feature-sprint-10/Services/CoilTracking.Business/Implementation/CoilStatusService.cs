using AutoMapper;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation.CoilMoveRequest
{
  public class CoilStatusService : ICoilStatusService
  {
    private readonly ICoilStatusRepository coilStatusRepo;
    private readonly IApplicationLogger<CoilStatusService> coilStatusServiceLogger;
    private readonly IMapper mapper;
    public CoilStatusService(IApplicationLogger<CoilStatusService> coilStatusServiceLogger, ICoilStatusRepository coilStatusRepo, IMapper mapper)
    {
      this.coilStatusServiceLogger = coilStatusServiceLogger;
      this.coilStatusRepo = coilStatusRepo;
      this.mapper = mapper;
    }

    /// <summary>
    /// Get coil status by Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>CoilStatusDto</returns>
    public async Task<CoilStatusDto> GetCoilStatusById(int id)
    {
      var coilStatus = await coilStatusRepo.GetCoilStatusByIdAsync(id);
      coilStatusServiceLogger.LogInformation(Constant.classname + "CoilStatusService" + Constant.methodname + "GetCoilStatusById" + Constant.message + "Get list of coil status by id");
      return mapper.Map<CoilStatusDto>(coilStatus);
    }

    /// <summary>
    /// Get list of coil status
    /// </summary>
    /// <returns>coil status dto</returns>
    public async Task<List<CoilStatusDto>> GetCoilStatuses()
    {
      var coilStatus = await coilStatusRepo.GetCoilStatuses();
      coilStatusServiceLogger.LogInformation(Constant.classname + "CoilStatusService" + Constant.methodname + "GetCoilStatuses" + Constant.message + "Get list of coil statuses");
      return mapper.Map<List<CoilStatusDto>>(coilStatus);
    }

    /// <summary>
    /// Save new CoilStatus
    /// </summary>
    /// <param name="coilStatusDto"></param>
    public void InsertCoilStatus(CoilStatusDto coilStatusDto)
    {
      var coilStatus = mapper.Map<CoilStatus>(coilStatusDto);
      coilStatusServiceLogger.LogInformation(Constant.classname + "CoilStatusService" + Constant.methodname + "SaveCoilStatus" + Constant.message + "Save New coil status");
      coilStatusRepo.InsertCoilStatus(coilStatus);
    }

    /// <summary>
    /// Update Coil Status
    /// </summary>
    /// <param name="id"></param>
    /// <param name="coilStatusDto"></param>
    public void UpdateCoilStatus(int id, CoilStatusDto coilStatusDto)
    {
      if (!CoilStatusExists(id))
      {
        throw new CoilTrackingException { HttpStatusCode = "NotFound" };
      }

      var coilStatus = mapper.Map<CoilStatus>(coilStatusDto);
      coilStatusServiceLogger.LogInformation(Constant.classname + "CoilStatusService" + Constant.methodname + "UpdateCoilStatus" + Constant.message + "Update New coil status");
      coilStatusRepo.UpdateCoilStatus(coilStatus);
    }

    /// <summary>
    /// Check if coil status exists
    /// </summary>
    /// <param name="id"></param>
    /// <returns>bool</returns>
    public bool CoilStatusExists(int id)
    {
      var coilStatus = coilStatusRepo.GetCoilStatusById(id);
      if (coilStatus == null)
      {
        return false;
      }
      return true;
    }

    /// <summary>
    /// Delete Coil Status ById
    /// </summary>
    /// <param name="id"></param>
    /// <returns>coil status dto</returns>
    public CoilStatusDto DeleteCoilStatus(int id)
    {
      var coilStatus = coilStatusRepo.DeleteCoilStatus(id);
      return mapper.Map<CoilStatusDto>(coilStatus);
    }
  }
}
