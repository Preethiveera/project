using CoilTracking.Business.Interfaces.EmailService;
using CoilTracking.DTO;
using System.Net.Mail;

namespace CoilTracking.Business.Implementation.EmailService
{
  public class EmailService : IEmailService
  {
    /// <summary>
    /// Creating SMTP client.
    /// </summary>
    /// <returns></returns>
    public SendEmailModel CreateSMTPClient(EmailModel request)
    {
      MailMessage message = new MailMessage();
      SmtpClient smtp = new SmtpClient();
      message.From = new MailAddress(request.From);
      message.Subject = request.Subject;
      message.IsBodyHtml = request.IsBodyHtml;
      message.Body = request.Body;
      smtp.Port = request.Port;
      smtp.Host = request.Host;
      smtp.EnableSsl = request.EnableSSL;
      smtp.DeliveryMethod = request.DeliveryMethod;

      return new SendEmailModel
      {
        MailMessage = message,
        SmtpClient = smtp
      };
    }

    /// <summary>
    /// Send Email.
    /// </summary>
    /// <returns></returns>
    public void SendEmail(MailMessage message, SmtpClient smtp)
    {
        smtp.Send(message);
        message.To.Clear();
        message.Attachments.Clear();
    }
  }
}
