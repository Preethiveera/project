using CoilTracking.Business.Implementation.Excel;
using CoilTracking.Business.Interfaces;
using CoilTracking.Business.Interfaces.EmailService;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mail;

namespace CoilTracking.Business.Implementation
{
  public class ScheduledReportBatchService : IScheduledReportBatchService
  {
    const string folderName = Email.FolderName;
    string location = "";
    const string runReport = Email.RunReport;
    const string scrapReport = Email.ScrapReport;
    const string coilInventoryReport = Email.CoilInventoryReport;
    readonly int NoOfDays = Email.Days;
    bool isSuccess = true;
    string AppLocation = "";

    private readonly ICoilTypeRepository coilTypeRepository;
    private readonly IScheduleReportRepository scheduleReportRepository;
    private readonly IPartModelsRepository partModelsRepository;
    private readonly IApplicationLogger<ScheduledReportBatchService> logger;
    private readonly IEmailService emailService;
    private readonly IRunResultService runResultService;
    private readonly ICoilsService coilsService;

    public ScheduledReportBatchService(ICoilTypeRepository coilTypeRepository,
      IScheduleReportRepository scheduleReportRepository,
      IPartModelsRepository partModelsRepository,
      IApplicationLogger<ScheduledReportBatchService> logger,
      IEmailService emailService,
      IRunResultService runResultService,
      ICoilsService coilsService)
    {
      this.coilTypeRepository = coilTypeRepository;
      this.scheduleReportRepository = scheduleReportRepository;
      this.partModelsRepository = partModelsRepository;
      this.logger = logger;
      this.emailService = emailService;
      this.runResultService = runResultService;
      this.coilsService = coilsService;
    }

    /// <summary>
    /// Get Batch Report that need to be sent as attachment in Emails.
    /// </summary>
    /// <returns></returns>
    public void GetReports()
    {
      try
      {
        logger.LogInformation(Constant.classname + "ScheduledReportBatchService" + Constant.methodname + "GetReports" + Constant.message + "Generate Report started");
        AppLocation = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase);
        logger.LogInformation(Constant.classname + "ScheduledReportBatchService" + Constant.methodname + "GetReports" + Constant.message + "Applocation is" + AppLocation);
        AppLocation = AppLocation.Replace("file:\\", "");
        logger.LogInformation(Constant.classname + "ScheduledReportBatchService" + Constant.methodname + "GetReports" + Constant.message + "Updated Applocation is" + AppLocation);
        location = AppLocation + "\\" + folderName;
        logger.LogInformation(Constant.classname + "ScheduledReportBatchService" + Constant.methodname + "GetReports" + Constant.message + "Location is" + location);

        GenerateRunResultReport();
        logger.LogInformation(Constant.classname + "ScheduledReportBatchService" + Constant.methodname + "GetReports" + Constant.message + "Generated Run Result Report");
        GenerateScrapResultReport();
        logger.LogInformation(Constant.classname + "ScheduledReportBatchService" + Constant.methodname + "GetReports" + Constant.message + "Generated Scrap Result Report");
        GenerateCoilInventoryReport();
        logger.LogInformation(Constant.classname + "ScheduledReportBatchService" + Constant.methodname + "GetReports" + Constant.message + "Generated Coil Inventory Report");
        SendEmail();
      }
      catch (Exception ex)
      {
        logger.LogInformation(Constant.classname + "ScheduledReportBatchService" + Constant.methodname + "GetReports" + Constant.message + "Error : " + ex.Message);
        logger.LogInformation(Constant.classname + "ScheduledReportBatchService" + Constant.methodname + "GetReports" + Constant.message + "Inner Exception : " + ex.InnerException );
        LogException(ex, null);
      }
    }

    /// <summary>
    /// Send Email using SMTP client.
    /// </summary>
    /// <returns></returns>
    private void SendEmail()
    {
      logger.LogInformation(Constant.classname + "ScheduledReportBatchService" + Constant.methodname + "SendEmail" + Constant.message + "Creating SMTP client");
      List<ScheduledReportEmail> reportEmails = GetScheduledReportEmails();

      var emailRequest = new EmailModel
      {
        From = Email.From,
        Subject = Email.Subject,
        IsBodyHtml = true,
        Body = Email.Body,
        Port = Email.Port,
        Host = Email.Host,
        EnableSSL = false,
        DeliveryMethod = SmtpDeliveryMethod.Network
      };

      var client = emailService.CreateSMTPClient(emailRequest);

      foreach (var reportEmail in reportEmails)
      {
        try
        {
          client.MailMessage.To.Add(reportEmail.Email.Trim());
          if (reportEmail.RunReport)
            client.MailMessage.Attachments.Add(new Attachment(location + "\\" + runReport));
          if (reportEmail.ScrapReport)
            client.MailMessage.Attachments.Add(new Attachment(location + "\\" + scrapReport));
          if (reportEmail.CoilReport)
            client.MailMessage.Attachments.Add(new Attachment(location + "\\" + coilInventoryReport));

          emailService.SendEmail(client.MailMessage, client.SmtpClient);
          logger.LogInformation(Constant.classname + "ScheduledReportBatchService" + Constant.methodname + "SendEmail" + Constant.message + "Email sent");
        }

        catch (Exception ex)
        {
          isSuccess = false;
          logger.LogInformation(Constant.classname + "ScheduledReportBatchService" + Constant.methodname + "SendEmail" + Constant.message + "Email failed" + ex.Message);

          logger.LogInformation(Constant.classname + "ScheduledReportBatchService" + Constant.methodname + "SendEmail" + Constant.message + "Email Exception" + ex.InnerException);
          LogException(ex, reportEmail.Email);
        }
      }
    }

    /// <summary>
    /// Generate Run Result Report Excel
    /// </summary>
    /// <returns></returns>
    private void GenerateRunResultReport()
    {
      try
      {
        var startDate = DateTime.Now.AddDays(-NoOfDays);
        var endDate = DateTime.Now;
        var results = runResultService.GetRunResultByDateAsync(startDate, endDate).Result;
        logger.LogInformation(Constant.classname + "ScheduledReportBatchService" + Constant.methodname + "GenerateRunResultReport" + Constant.message + "GetRunResultsByDate success");

        List<RunResultsReport> runResults = results.Select(rr => GetDto(rr)).ToList();


        if (!Directory.Exists(location))
          Directory.CreateDirectory(location);

        string excelSavingPath = location + "\\" + runReport;
        logger.LogInformation(Constant.classname + "ScheduledReportBatchService" + Constant.methodname + "GenerateRunResultReport" + Constant.message + "Excel saving path " + excelSavingPath);
        if (File.Exists(Path.Combine(location, runReport)))
        {
          File.Delete(Path.Combine(location, runReport));
        }
        ExcelExport.GenerateExcel(ExcelExport.ConvertToDataTable(runResults), excelSavingPath, "RunResults");
      }
      catch (Exception)
      {
        throw;
      }
    }

    /// <summary>
    /// Generate Scrap Result Report Excel
    /// </summary>
    /// <returns></returns>
    private void GenerateScrapResultReport()
    {
      try
      {
        var startDate = DateTime.Now.AddDays(-NoOfDays);
        var endDate = DateTime.Now;
        List<RunResult> runResultsWithPartials = runResultService.GetRunResultByDateAsync(startDate, endDate).Result;
        List<ScrapResultsReport> scrapEntries = new List<ScrapResultsReport>();
        foreach (RunResult runResult in runResultsWithPartials)
        {
          decimal weightUsed;
          ScrapResultsReport entry = new ScrapResultsReport
          {
            Date = runResult.RunStarted,
            Shift = runResult.RunOrderList.Shift.Name,
            DataNumber = runResult.DataNumber,
            PartNumber = runResult.PartNumber,
            CoilType = runResult.BlankCoilTypeName,
            FTZ = runResult.Coil.FTZ,
            YNANumber = runResult.Coil.YNA,
            BlanksRequested = runResult.BlanksRequested,
            PressCount = runResult.PressCount,
            BlanksProduced = runResult.BlanksProduced,
            BlankWeight = runResult.BlankWeight,
            WeightBefore = runResult.CoilWeightBefore,
            WeightAfter = runResult.CoilWeightBefore - runResult.WeightUsed
          };
          weightUsed = runResult.WeightUsed;

          decimal totalBlankWeight = runResult.BlankWeight * runResult.BlanksProduced;
          entry.TotalBlankWeight = totalBlankWeight;
          entry.TotalScrap = weightUsed - totalBlankWeight;
          entry.BlankScrap = (entry.PressCount - entry.BlanksProduced) * runResult.BlankWeight;
          entry.HeadAndTailScrap = entry.TotalScrap - entry.BlankScrap;
          entry.Yield = weightUsed > 0 ? (totalBlankWeight / weightUsed) * 100 : 0;
          scrapEntries.Add(entry);
        }

        if (!Directory.Exists(location))
          Directory.CreateDirectory(location);

        string excelSavingPath = location + "\\" + scrapReport;
        if (File.Exists(Path.Combine(location, scrapReport)))
        {
          File.Delete(Path.Combine(location, scrapReport));
        }
        ExcelExport.GenerateExcel(ExcelExport.ConvertToDataTable(scrapEntries), excelSavingPath, "ScrapResults");
      }
      catch (Exception)
      {
        throw;
      }
    }

    /// <summary>
    /// Generate Coil Inventory Report Excel
    /// </summary>
    /// <returns></returns>
    private void GenerateCoilInventoryReport()
    {
      try
      {
        //First get a listing of coil type Ids, and a listing of 5 digit parts that coil type is used for

        var allCoilTypesWithAllPartNums = coilTypeRepository.GetCoilTypesWithAllPartNums()
                                             .Select(x => new { CoilTypeId = x.CoilTypeId, PartNumber = x.PartNumber, Models = (x.Parts == null || x.PartNumber == null) ? string.Empty : partModelsRepository.GetModelList(x.Parts.PartNumber).ToString() })
                                             .ToList(); //Must do a .ToList() to materialize it so we don't try to do a string.join at the database level

        //Then group by the coilType ID, and join a distinct list of the (First 5 digit) part numbers into a single string
        var coilTypesWithDistinctPartNumsList = (from coilTypePart in allCoilTypesWithAllPartNums
                                                 group coilTypePart by coilTypePart.CoilTypeId into groupedByCoilTypeID
                                                 select new { CoilTypeId = groupedByCoilTypeID.Key, PartNumbers = string.Join(",", groupedByCoilTypeID.Select(d => d.PartNumber).Distinct()), Models = string.Join(",", groupedByCoilTypeID.Select(d => d.Models).Distinct()) }
                                            ).ToList(); //materialize the results into a list

        //Get a list of coils in inventory
        var coilsInInventory = coilsService.GetCoilsInInventoryAsync().Result;

        List<CoilInventoryReport> coilInventoryDtos = (from coil in coilsInInventory
                                                              join coilTypePartNum in coilTypesWithDistinctPartNumsList on coil.CoilType.Id equals coilTypePartNum.CoilTypeId into groupJoined
                                                              from coilTypePartNum in groupJoined.DefaultIfEmpty()
                                                              select new CoilInventoryReport
                                                              {
                                                                Type = coil.CoilType.Name,
                                                                YNA = coil.YNA,
                                                                Status = coil.CoilStatus.Name,
                                                                Location = (coil.CoilFieldLocation == null ? null : coil.CoilFieldLocation.Zone.Name + "-" + coil.CoilFieldLocation.Name),
                                                                FTZ = coil.FTZ,
                                                                Mill = coil.Mill.Name,
                                                                Serial = coil.SerialNum,
                                                                OriginalWeight = coil.OriginalWeight,
                                                                CurrentWeight = coil.CurrentWeight,
                                                                PartNumbers = (coilTypePartNum?.PartNumbers),
                                                                ModelList = (coilTypePartNum?.Models),
                                                                Received = coil.CheckInDate
                                                              }).ToList();
        if (!Directory.Exists(location))
          Directory.CreateDirectory(location);

        string excelSavingPath = location + "\\" + coilInventoryReport;
        if (File.Exists(Path.Combine(location, coilInventoryReport)))
        {
          File.Delete(Path.Combine(location, coilInventoryReport));
        }
        ExcelExport.GenerateExcel(ExcelExport.ConvertToDataTable(coilInventoryDtos), excelSavingPath, "CoilInventoryReport");
      }
      catch (Exception)
      {
        throw;
      }
    }

    /// <summary>
    /// Get list of email ids
    /// </summary>
    /// <returns></returns>
    private List<ScheduledReportEmail> GetScheduledReportEmails()
    {
      try
      {
        return scheduleReportRepository.Get().ToList();
      }
      catch (Exception)
      {
        throw;
      }
    }

    /// <summary>
    /// Generate Dto for Run Result Report
    /// </summary>
    /// <returns></returns>
    private RunResultsReport GetDto(RunResult runResult)
    {
      logger.LogInformation(Constant.classname + "ScheduledReportBatchService" + Constant.methodname + "GetDto" + Constant.message + "GetDto started");
      RunResultsReport dto = new RunResultsReport
      {
        RunStarted = runResult.RunStarted,
        DataNumber = runResult.DataNumber,
        PartNumber = runResult.PartNumber,
        BlanksRequested = runResult.BlanksRequested,
        CoilType = runResult.Coil.CoilType.Name,
        YNANumber = runResult.Coil.YNA,
        FTZ = runResult.Coil.FTZ,
        MeasuredWidth = runResult.MeasuredWidth,
        MeasuredThickness = runResult.MeasuredThickness,
        MeasuredPitch = runResult.MeasuredPitch,
        PressCount = runResult.PressCount,
        BlanksProduced = runResult.BlanksProduced,
        DownTime = runResult.DownTime,
        Comments = runResult.Comments,
        RunFinished = runResult.RunFinished,
        AdcDt = runResult.AdcDt,
        MaintDt = runResult.MaintDt,
        ToolDieDt = runResult.ToolDieDt,
        ProdDt = runResult.ProdDt,
        KanbanDt = runResult.KanbanDt,
        TryoutDt = runResult.TryoutDt,
        SchdDt = runResult.SchdDt
      };

      logger.LogInformation(Constant.classname + "ScheduledReportBatchService" + Constant.methodname + "GetDto" + Constant.message + "GetDto completed");
      return dto;
    }

    /// <summary>
    /// Logging Method
    /// </summary>
    /// <returns></returns>
    private void LogException(Exception ex, string mailInfo)
    {
      string exception = null;
      if (ex.InnerException != null)
        exception = ex.InnerException.ToString();
      else
        exception = ex.ToString();

      scheduleReportRepository.AddScheduleReportEmailLog(exception, mailInfo, isSuccess);
    }
  }
}
