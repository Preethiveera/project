using AutoMapper;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constant;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class RunResultService : IRunResultService
  {
    private readonly IApplicationLogger<RunResultService> runServiceLogger;
    private readonly IRunResultsRepository runResultsRepo;
    private readonly IBlankInfoesRepository blankInfoesRepo;
    private readonly ICoilRepository coilRepo;
    private readonly IRunOrderRepository runOrderRepo;
    private readonly IMapper mapper;
    private readonly ICoilRunHistoryRepository coilRunHistoryRepo;
    private readonly IPlantsRepository plantsRepo;
    private readonly IRunResultFactory runResultFactory;
    private readonly ICoilStatusRepository coilStatusRepo;
    private readonly IWebSocketClientService webSocketClientService;

    public RunResultService(IApplicationLogger<RunResultService> runServiceLogger, IRunResultsRepository runResultsRepo,
      IBlankInfoesRepository blankInfoesRepo, ICoilRepository coilRepo, IRunOrderRepository runOrderRepo,
      IMapper mapper, ICoilRunHistoryRepository coilRunHistoryRepo, IPlantsRepository plantsRepo,
      IRunResultFactory runResultFactory, ICoilStatusRepository coilStatusRepo, IWebSocketClientService webSocketClientService)
    {
      this.runServiceLogger = runServiceLogger;
      this.runResultsRepo = runResultsRepo;
      this.blankInfoesRepo = blankInfoesRepo;
      this.coilRepo = coilRepo;
      this.runOrderRepo = runOrderRepo;
      this.mapper = mapper;
      this.coilRunHistoryRepo = coilRunHistoryRepo;
      this.plantsRepo = plantsRepo;
      this.runResultFactory = runResultFactory;
      this.coilStatusRepo = coilStatusRepo;
      this.webSocketClientService = webSocketClientService;
    }
    /// <summary>
    /// Get Run Results 
    /// </summary>
    /// <returns></returns>
    public async Task<List<RunResultDto>> GetRunResults()
    {
      //Get Run Result Info
      var runResult = await runResultsRepo.GetRunResults();
      //logging the RunResult count info
      runServiceLogger.LogInformation(Constant.classname + "RunService" + Constant.methodname + "GetRunResults" + Constant.message + "Get List of all Runresult");
      var runResults = runResult.Select(rr => PopulateDto(rr)).ToList();
      return runResults;
    }

    /// <summary>
    /// Get Run Results 
    /// </summary>
    /// <returns></returns>
    public List<RunResultDto> GetRunOrderRunResult(int id)
    {
      int totalBlanksProduced = 0;
      //Get Run Result Info
      var runResult = runResultsRepo.GetRunOrderRunResultById(id);
      //logging the RunResult count info
      runServiceLogger.LogInformation(Constant.classname + "RunService" + Constant.methodname + "GetRunResults" + Constant.message + "Get List of all Runresult");
      if (runResult == null)
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.RunOrderRunResult, HttpStatusCode = "NotFound" };
      }
      foreach (var run in runResult)
      {
        totalBlanksProduced = totalBlanksProduced + run.BlanksProduced;
      }
      var runResults = mapper.Map<List<RunResult>, List<RunResultDto>>(runResult);
      return runResults;
    }

    /// <summary>
    /// Get Search results 
    /// </summary>
    /// <param name="startTime"></param>
    /// <param name="endTime"></param>
    /// <param name="partNum"></param>
    /// <param name="dataNum"></param>
    /// <param name="coilType"></param>
    /// <param name="lineId"></param>
    /// <param name="shiftId"></param>
    /// <param name="ftz"></param>
    /// <returns></returns>
    public List<RunResultDto> GetRunResultsSearch(DateTime? startTime = null, DateTime? endTime = null, string partNum = null, int? dataNum = null, string coilType = null, int? lineId = null, int? shiftId = null, string ftz = null)
    {
      //Get Run Results based on parameter 
      var results = runResultsRepo.GetRunResultsSearch(startTime, endTime, partNum, dataNum, coilType, lineId, shiftId, ftz);
      if (results == null)
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.RunResultsSearch, HttpStatusCode = "NotFound" };
      }
      runServiceLogger.LogInformation(Constant.classname + "RunService" + Constant.methodname + "GetSearch" + Constant.countoflines + results.Count);
      //Get Run results dto
      var resultDtos = results.Select(rr => PopulateDto(rr)).ToList();
      //logging
      runServiceLogger.LogInformation(Constant.classname + "RunService" + Constant.methodname + "GetSearch" + Constant.countoflines + resultDtos.Count);
      return resultDtos;
    }

    /// <summary>
    /// Get Latest Run Results
    /// </summary>
    /// <returns></returns>
    public async Task<RunResultDto> GetLatestRunResult()
    {
      //Get Latest Run Result
      var latestRunresult = await runResultsRepo.GetRunResults();
      var runResultsFinished = latestRunresult.OrderByDescending(r => r.RunFinished).FirstOrDefault();
      //logging
      runServiceLogger.LogInformation(Constant.classname + "RunService" + Constant.methodname + "GetLatestRunResult" + Constant.message + "Latest Run Results");
      var runResults = PopulateDto(runResultsFinished);
      return runResults;
    }

    /// <summary>
    /// Get CurrentStack For Size
    /// </summary>
    /// <param name="dataNum"></param>
    /// <returns></returns>
    public BlankInfoDto GetCurrentStackSize(int dataNum)
    {
      //Get List of blank info based on DataNumber
      var blankInfo = blankInfoesRepo.GetCurrentStackSize(dataNum);
      //logging
      runServiceLogger.LogInformation(Constant.classname + "RunService" + Constant.methodname + "GetCurrentStackForSize" + Constant.message + "CurrentStackForSize Based on DataNumber" + Constant.parameters + dataNum);
      var blankInfos = mapper.Map<BlankInfoDto>(blankInfo);
      return blankInfos;
    }

    /// <summary>
    /// GetRunResult Based n Id
    /// </summary>
    /// <param name="Id"></param>
    /// <returns></returns>
    public async Task<RunResultDto> GetRunResultById(int Id)
    {
      //Get RunResults based on Id
      var runResults = await runResultsRepo.GetRunResults();
      var runResultsId = runResults.FirstOrDefault(r => r.Id == Id);
      //logging
      runServiceLogger.LogInformation(Constant.classname + "RunService" + Constant.methodname + "GetRunResultById" + Constant.parameters + Id);
      var runResult = PopulateDto(runResultsId);
      return runResult;
    }

    /// <summary>
    /// Get RunResultForEdit Based on Id
    /// </summary>
    /// <param name="Id"></param>
    /// <returns></returns>
    public async Task<RunResultDto> GetRunResultForEditByID(int Id)
    {
      //Get RunResult info based on Id
      var runResults = await runResultsRepo.GetRunResults();
      var editRunResults = runResults.FirstOrDefault(r => r.Id == Id);
      //logging
      runServiceLogger.LogInformation(Constant.classname + "RunService" + Constant.methodname + "GetRunResultForEditByID" + Constant.parameters + Id);
      if (editRunResults == null)
      {
        throw new CoilTrackingException() { ErrorMessage = ApplicationMessages.editRunResults, HttpStatusCode = "NotFound" };
      }
      //Get RunResult dto
      var runResultdto = PopulateDto(editRunResults);
      return runResultdto;

    }

    /// <summary>
    /// Get RunCoils To Be Weighed
    /// </summary>
    /// <returns></returns>
    public List<CoilToBeWeighed> GetRunCoilsToBeWeighed()
    {
      // Get Run Results With Partials 
      var runResultsWithPartials = runResultsRepo.GetCoilsToBeWeighed();
      //logging
      runServiceLogger.LogInformation(Constant.classname + "RunService" + Constant.methodname + "GetRunCoilsToBeWeighed");
      //Get Coils partials
      var PartialsCoils = coilRepo.GetPartialsCoils();
      var partials = PartialsCoils.Where(c => c.CoilStatus.Name == CoilStatusName.PartialNeedsWeighed).ToList();
      //logging
      runServiceLogger.LogInformation(Constant.classname + "RunService" + Constant.methodname + "GetRunCoilsToBeWeighed");
      List<CoilToBeWeighed> coilsToBeWeighed = new List<CoilToBeWeighed>();
      foreach (RunResult runResult in runResultsWithPartials)
      {
        if (!coilsToBeWeighed.Any(p => p.CoilId == runResult.Coil.Id))
        //If the same coil was used in 2 runs, we don't want to show both runs to update the weight, only the newest RunResult for each coil that needs weighed
        {
          CoilToBeWeighed partial = new CoilToBeWeighed
          {
            RunResultId = runResult.Id,
            RunOrderListId = runResult.RunOrderList.Id,
            CoilId = runResult.Coil.Id,
            CoilType = runResult.Coil.CoilType.Name
          };
          if (runResult.Coil.CoilFieldLocation != null)
          {
            partial.CoilLocation = runResult.Coil.CoilFieldLocation.Name;
            partial.Zone = runResult.Coil.CoilFieldLocation.Zone.Name;
          }
          partial.OriginalWeight = runResult.Coil.OriginalWeight;
          partial.CurrentWeight = runResult.Coil.CurrentWeight;
          partial.FTZ = runResult.Coil.FTZ;
          partial.YNA = runResult.Coil.YNA;
          partial.NewWeight = runResult.Coil.CurrentWeight;
          partial.AttachedToRunResult = true;
          coilsToBeWeighed.Add(partial);
        }
      }
      foreach (Coil partialCoil in partials)
      {
        if (!coilsToBeWeighed.Any(p => p.CoilId == partialCoil.Id)) //only add each coil once
        {
          CoilToBeWeighed partial = new CoilToBeWeighed
          {
            RunResultId = -1,
            RunOrderListId = -1,
            CoilId = partialCoil.Id,
            CoilType = partialCoil.CoilType.Name
          };
          if (partialCoil.CoilFieldLocation != null)
          {
            partial.CoilLocation = partialCoil.CoilFieldLocation.Name;
            partial.Zone = partialCoil.CoilFieldLocation.Zone.Name;
          }
          coilsToBeWeighed = SetcoilsToBeWeighed(partial, partialCoil, coilsToBeWeighed);
        }

      }
      return coilsToBeWeighed;
    }

    /// <summary>
    /// Get RunCoils To Be Weighed
    /// </summary>
    /// <returns></returns>
    public async Task<List<CoilToBeWeighed>> GetCoilByFTZToBeWeighed(string ftz)
    {

      List<CoilToBeWeighed> coilsToBeWeighed = new List<CoilToBeWeighed>();
      var getObject = runResultFactory.Create();
      var partials = await getObject.GetRunResultCoilFTZByPrefix(ftz);  
      //logging
      runServiceLogger.LogInformation(Constant.classname + "RunService" + Constant.methodname + "GetRunCoilsToBeWeighed");
      foreach (Coil partialCoil in partials)
      {
        if (!coilsToBeWeighed.Any(p => p.CoilId == partialCoil.Id)) //only add each coil once
        {
          CoilToBeWeighed partial = new CoilToBeWeighed
          {
            RunResultId = -1,
            RunOrderListId = -1,
            CoilId = partialCoil.Id,
            CoilType = partialCoil.CoilType.Name
          };
          if (partialCoil.CoilFieldLocation != null)
          {
            partial.CoilLocation = partialCoil.CoilFieldLocation.Name;
            partial.Zone = partialCoil.CoilFieldLocation.Zone.Name;
            partial.CoilFieldLocationName = partialCoil.CoilFieldLocation.Name;
          }
          partial.CoilTypeName = partialCoil.CoilType.Name;
          if (partialCoil.Id == 2)
            partial.CoilStatusName = CoilStatusName.Partial;
          else
            partial.CoilStatusName = CoilStatusName.PartialNeedsWeighed;
          coilsToBeWeighed = SetcoilsToBeWeighed(partial, partialCoil, coilsToBeWeighed);
        }
      }
      return coilsToBeWeighed;
    }

    /// <summary>
    /// Set coils To Be Weighed
    /// </summary>
    /// <param name="partial"></param>
    /// <param name="partialCoil"></param>
    /// <param name="coilsToBeWeighed"></param>
    /// <returns></returns>
    public List<CoilToBeWeighed> SetcoilsToBeWeighed(CoilToBeWeighed partial, Coil partialCoil, List<CoilToBeWeighed> coilsToBeWeighed)
    {
      partial.OriginalWeight = partialCoil.OriginalWeight;
      partial.CurrentWeight = partialCoil.CurrentWeight;
      partial.FTZ = partialCoil.FTZ;
      partial.YNA = partialCoil.YNA;
      partial.NewWeight = partialCoil.CurrentWeight;
      partial.AttachedToRunResult = false;
      coilsToBeWeighed.Add(partial);
      return coilsToBeWeighed;
    }

    /// <summary>
    /// populate Run Results Dto 
    /// </summary>
    /// <param name="runResult"></param>
    /// <returns></returns>
    public RunResultDto PopulateDto(RunResult runResult)
    {
      RunResultDto dto = new RunResultDto
      {
        Id = runResult.Id,
        RunOrderListId = runResult.RunOrderList.Id,
        Line = runResult.RunOrderList.Line.LineName,
        Shift = runResult.RunOrderList.Shift.Name,
        RunStarted = runResult.RunStarted,
        DataNumber = runResult.DataNumber,
        PartNumber = runResult.PartNumber,
        BlanksRequested = runResult.BlanksRequested,
        CoilId = runResult.Coil.Id,
        CoilType = runResult.Coil.CoilType.Name,
        FTZ = runResult.Coil.FTZ,
        YNANumber = runResult.Coil.YNA,
        MeasuredWidth = runResult.MeasuredWidth,
        MeasuredThickness = runResult.MeasuredThickness,
        MeasuredPitch = runResult.MeasuredPitch,
        PressCount = runResult.PressCount,
        BlanksProduced = runResult.BlanksProduced,
        DownTime = runResult.DownTime,
        Comments = runResult.Comments,
        WeightUsed = runResult.WeightUsed,
        RunFinished = runResult.RunFinished,
        BlankWeight = runResult.BlankWeight,
        BlankPitch = runResult.BlankPitch,
        BlankWidth = runResult.BlankWidth,
        BlankStackSize = runResult.BlankStackSize,
        BlankDieNo = runResult.BlankDieNo,
        AdcDt = runResult.AdcDt,
        MaintDt = runResult.MaintDt,
        ToolDieDt = runResult.ToolDieDt,
        ProdDt = runResult.ProdDt,
        KanbanDt = runResult.KanbanDt,
        TryoutDt = runResult.TryoutDt,
        SchdDt = runResult.SchdDt,
        CoilCurrentWeight = runResult.Coil.CurrentWeight,
        ModifiedBy = runResult.ModifiedBy ?? "",
        BlankCoilTypeName = runResult.BlankCoilTypeName
      };
      return dto;
    }

    /// <summary>
    /// Get Scrap Results
    /// </summary>
    /// <param name="startTime"></param>
    /// <param name="endTime"></param>
    /// <param name="partNum"></param>
    /// <param name="dataNum"></param>
    /// <param name="coilType"></param>
    /// <param name="lineId"></param>
    /// <param name="shiftId"></param>
    /// <param name="ftz"></param>
    /// <returns></returns>
    public List<ScrapResultsDto> GetScrapResults(DateTime? startTime = null, DateTime? endTime = null, string partNum = null, int? dataNum = null, string coilType = null, int? lineId = null, int? shiftId = null, string ftz = null)
    {
      //Get Run Results based on parameter 
      var runResultsWithPartials = runResultsRepo.GetRunResultsSearch(startTime, endTime, partNum, dataNum, coilType, lineId, shiftId, ftz);
      runServiceLogger.LogInformation(Constant.classname + "RunService" + Constant.methodname + "GetSearch" + Constant.countoflines + runResultsWithPartials.Count);
      List<ScrapResultsDto> scrapEntries = new List<ScrapResultsDto>();
      foreach (RunResult runResult in runResultsWithPartials)
      {
        ScrapResultsDto entry = new ScrapResultsDto
        {
          RunResultId = runResult.Id,
          Date = runResult.RunStarted,
          LineId = runResult.RunOrderList.Line.Id,
          Line = runResult.RunOrderList.Line.LineName,
          ShiftId = runResult.RunOrderList.Shift.Id,
          Shift = runResult.RunOrderList.Shift.Name,
          DataNumber = runResult.DataNumber,
          PartNumber = runResult.PartNumber,
          CoilTypeId = runResult.Coil.CoilType.Id,
          CoilType = runResult.BlankCoilTypeName,
          FTZ = runResult.Coil.FTZ,
          YNANumber = runResult.Coil.YNA,
          BlanksRequested = runResult.BlanksRequested,
          PressCount = runResult.PressCount,
          BlanksProduced = runResult.BlanksProduced,
          BlankWeight = runResult.BlankWeight,
          WeightBefore = runResult.CoilWeightBefore,
          WeightAfter = runResult.CoilWeightBefore - runResult.WeightUsed,
          WeightUsed = runResult.WeightUsed
        };
        decimal totalBlankWeight = runResult.BlankWeight * runResult.BlanksProduced;
        entry.TotalBlankWeight = totalBlankWeight;
        entry.TotalScrap = entry.WeightUsed - totalBlankWeight;
        entry.BlankScrap = (entry.PressCount - entry.BlanksProduced) * runResult.BlankWeight;
        entry.HeadAndTailScrap = entry.TotalScrap - entry.BlankScrap;
        entry.Yield = entry.WeightUsed > 0 ? (totalBlankWeight / entry.WeightUsed) * 100 : 0;
        scrapEntries.Add(entry);
      }
      return scrapEntries;
    }
    /// <summary>
    /// Save Return Weight
    /// </summary>
    /// <param name="partials"></param>
    public bool SaveReturnWeight(List<CoilToBeWeighed> partials)
    {
      var runResult = runResultsRepo.GetRunResultIds(partials.Select(x => x.RunResultId).ToList());
      runServiceLogger.LogInformation(Constant.classname + "RunService" + Constant.methodname + "SaveReturnWeight" + Constant.countoflines + runResult.Count);
      List<Coil> runHistoryCoil = coilRepo.GetCoilRunHistoryByIds(partials.Select(x => x.RunResultId).ToList());
      List<RunOrderList> runHistoryRunOrder = runOrderRepo.GetRunOrderListByPartialIds(partials.Select(x => x.RunOrderListId).ToList());
      runServiceLogger.LogInformation(Constant.classname + "RunService" + Constant.methodname + "SaveReturnWeight" + Constant.countoflines + runHistoryRunOrder.Count);
      foreach (CoilToBeWeighed partial in partials)
      {
        var runResultId = runResult.FirstOrDefault(x => x.Id == partial.RunResultId);
        if (runResultId == null)
        {
          throw new CoilTrackingException() { ErrorMessage = ApplicationMessages.returnWeightRunResults, HttpStatusCode = "NotFound" };
        }
        runResultId.WeightUsed = partial.CurrentWeight - partial.NewWeight;

        CoilRunHistory runHistory = new CoilRunHistory
        {
          Coil = runHistoryCoil.FirstOrDefault(x => x.Id == partial.RunResultId),
          RunOrderList = runHistoryRunOrder.FirstOrDefault(x => x.Id == partial.RunOrderListId),
          WeightUsed = partial.CurrentWeight - partial.NewWeight
        };
        coilRunHistoryRepo.SaveCoilRunHistories(runHistory);
      }
      return true;
    }

    /// <summary>
    /// Update Current Weight
    /// </summary>
    /// <param name="partial"></param>
    public  async Task<bool> UpdateCurrentWeight(CoilToBeWeighed partial)
    {
      //Get the coils Based on CoilToBeWeighed CoilId
      Coil partialCoils = coilRepo.GetCoilsWithAllInfo(partial.CoilId);
      runServiceLogger.LogInformation(Constant.classname + "RunService" + Constant.methodname + "UpdateCurrentWeight" + Constant.parameters + partial.CoilId);
      if (partial.AttachedToRunResult)
      {
        //Getting the runresult info based on RunResultId
        RunResult runResult = runResultsRepo.GetRunResultId(partial.RunResultId);
        runServiceLogger.LogInformation(Constant.classname + "RunService" + Constant.methodname + "UpdateCurrentWeight" + Constant.parameters + partial.RunResultId);
        //Logging status of change
        runResultsRepo.ModifyRunResult(runResult);
        if (runResult == null)
        {
          throw new CoilTrackingException() { ErrorMessage = ApplicationMessages.returnWeightRunResults, HttpStatusCode = "NotFound" };
        }
        runResult.WeightUsed = partial.CurrentWeight - partial.NewWeight;
        CoilRunHistory runHistory = new CoilRunHistory
        {
          Coil = partialCoils,
          RunOrderList = runOrderRepo.GetRunOrderListId(partial.RunOrderListId),
          WeightUsed = partial.CurrentWeight - partial.NewWeight
        };
        if (partialCoils.CoilRunHistory == null)
          partialCoils.CoilRunHistory = new List<CoilRunHistory>();
        partialCoils.CoilRunHistory.Add(runHistory);
      }
      else
      {
        partialCoils.UnAccountedWeight = partialCoils.UnAccountedWeight + (partial.CurrentWeight - partial.NewWeight);
      }
      partialCoils.CoilStatus =  coilStatusRepo.GetCoilStatusName(CoilStatusName.Partial);    
      await coilRepo.UpdateCoils(partialCoils);
      await  webSocketClientService.CoilLocationsUpdated();
      return true;
    }

    /// <summary>
    /// RunResult Modified
    /// </summary>
    /// <param name="runResult"></param>
    /// <returns></returns>
    public async Task<bool> ModifyRunResult(RunResult runResult)
    {
      //Saving changes 
      bool result = await runResultsRepo.UpdateRunResultSaveChanges(runResult);
      return result;
    }

    /// <summary>
    /// RunResult Modified
    /// </summary>
    /// <param name="runResult"></param>
    /// <returns></returns>
    public async Task<bool> InsertRunResults(RunResult runResult)
    {
      //Saving changes 
      bool result = await runResultsRepo.RunResultSaveChanges(runResult);
      return result;
    }

    /// <summary>
    /// Get RunResult Exists Based on id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public bool IsRunResultExists(int id)
    {
      //validation of run result id
      bool resultId = runResultsRepo.IsRunResultExists(id);
      if (!(resultId))
      {
        throw new CoilTrackingException() { HttpStatusCode = "NotFound" };
      }
      return resultId;
    }

    /// <summary>
    /// Deletion of RunResult Based on Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<RunResult>  DeleteRunResult(int id)
    {
      //Get the RunResult Info based on Id
      var runResult = await runResultsRepo.GetRunResultsId(id);
      runServiceLogger.LogInformation(Constant.classname + "RunService" + Constant.methodname + "DeleteRunResult" + Constant.parameters + id);
      //Deletion of RunResult Info Based on Id
        await runResultsRepo.DeleteRunResult(runResult);
      return runResult;
    }

    /// <summary>
    /// Update RunResult Based on Id and runResultDto
    /// </summary>
    /// <param name="id"></param>
    /// <param name="runResultDto"></param>
    /// <returns></returns>
    public async Task<RunResult> UpdateRunResult(int id, RunResultDto runResultDto)
    {
      //Get the List of Runresult info Based on Coils and Runorderlist
      var runResult = await runResultsRepo.GetRunResultsById(runResultDto.Id);
      runServiceLogger.LogInformation(Constant.classname + "RunService" + Constant.methodname + "UpdateRunResult" + Constant.message + "runResult info");
      runResult.BlanksRequested = runResultDto.BlanksRequested;
      runResult.MeasuredWidth = runResultDto.MeasuredWidth;
      runResult.MeasuredPitch = runResultDto.MeasuredPitch;
      runResult.MeasuredThickness = runResultDto.MeasuredThickness;
      runResult.AdcDt = runResultDto.AdcDt;
      runResult.MaintDt = runResultDto.MaintDt;
      runResult.ToolDieDt = runResultDto.ToolDieDt;
      runResult.ProdDt = runResultDto.ProdDt;
      runResult.KanbanDt = runResultDto.KanbanDt;
      runResult.TryoutDt = runResultDto.TryoutDt;
      runResult.SchdDt = runResultDto.SchdDt;
      runResult.DownTime = runResultDto.AdcDt + runResultDto.MaintDt + runResultDto.ToolDieDt +
          runResultDto.ProdDt + runResultDto.KanbanDt + runResultDto.TryoutDt + runResultDto.SchdDt;
      runResult.Comments = runResultDto.Comments;
      runResult.PressCount = runResultDto.PressCount;
      runResult.BlanksProduced = runResultDto.BlanksProduced;
      //Saving changes 
     await runResultsRepo.UpdateRunResultSaveChanges(runResult);
      runServiceLogger.LogInformation(Constant.classname + "RunService" + Constant.methodname + "UpdateRunResult" + Constant.parameters + runResult);
      return runResult;
    }

    /// <summary>
    /// Save RunResult Based on runResultDto
    /// </summary>
    /// <param name="runResultDto"></param>
    /// <returns></returns>
    public async Task<RunResultDto> InsertRunResult(RunResultDto runResultDto)
    {
      RunResult runResult = new RunResult()
      {
        //Getting the RunOrderList Based on Id
        RunOrderList = runOrderRepo.GetRunOrderListId(runResultDto.RunOrderListId),
        RunStarted = runResultDto.RunStarted,
        DataNumber = runResultDto.DataNumber,
        PartNumber = runResultDto.PartNumber,
        BlanksRequested = runResultDto.BlanksRequested,
        Coil = await coilRepo.GetCoilId(runResultDto.CoilId),
        MeasuredThickness = runResultDto.MeasuredThickness,
        MeasuredWidth = runResultDto.MeasuredWidth,
        MeasuredPitch = runResultDto.MeasuredPitch,
        PressCount = runResultDto.PressCount,
        BlanksProduced = runResultDto.BlanksProduced,
        Comments = runResultDto.Comments,
        RunFinished = runResultDto.RunFinished,
        CoilWeightBefore = runResultDto.WeightBefore,
        WeightUsed = runResultDto.WeightBefore - runResultDto.WeightAfter,
        BlankCoilTypeName = runResultDto.CoilType,
        BlankWeight = runResultDto.BlankWeight,
        BlankPitch = runResultDto.BlankPitch,
        BlankWidth = runResultDto.BlankWidth,
        BlankStackSize = runResultDto.BlankStackSize,
        BlankDieNo = runResultDto.BlankDieNo,
        AdcDt = runResultDto.AdcDt,
        MaintDt = runResultDto.MaintDt,
        ToolDieDt = runResultDto.ToolDieDt,
        ProdDt = runResultDto.ProdDt,
        KanbanDt = runResultDto.KanbanDt,
        TryoutDt = runResultDto.TryoutDt,
        SchdDt = runResultDto.SchdDt,
        DownTime = runResultDto.AdcDt + runResultDto.MaintDt + runResultDto.ToolDieDt +
             runResultDto.ProdDt + runResultDto.KanbanDt + runResultDto.TryoutDt + runResultDto.SchdDt,
        ModifiedBy = runResultDto.ModifiedBy
      };
      //Saving changes 
    await  runResultsRepo.RunResultSaveChanges(runResult);
      runServiceLogger.LogInformation(Constant.classname + "RunService" + Constant.methodname + "SaveRunResult" + Constant.parameters + runResult);
      runResultDto.Id = runResult.Id;
      return runResultDto;
    }

    /// <summary>
    /// Get Plant Code
    /// </summary>
    /// <returns></returns>
    public async Task<string> GetPlantCode()
    {
      var plantCode = await plantsRepo.GetPlantNAMCCode();
      runServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "GetPlantCode" + Constant.countoflines + plantCode.Count());
      if (plantCode.Equals(Constant.tmmiNAMC, StringComparison.OrdinalIgnoreCase))
      {
        return Constant.OK;
      }
      else
      {
        return Constant.NA;
      }
    }

    /// <summary>
    /// Get Run Result By Date
    /// </summary>
    /// <returns></returns>
    public async Task<List<RunResult>> GetRunResultByDateAsync(DateTime startDate, DateTime endDate)
    {
      return await runResultsRepo.GetRunResultsByDate(startDate, endDate);
    }
  }
}

