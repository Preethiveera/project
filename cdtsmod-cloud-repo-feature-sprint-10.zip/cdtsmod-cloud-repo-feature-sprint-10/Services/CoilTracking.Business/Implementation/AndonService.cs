using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Logging;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CoilTracking.Business.Implementation
{
  public class AndonService : IAndonService
  {
    private readonly IApplicationLogger<AndonService> andonServiceLogger;
    private readonly IBlankInfoesRepository blankInfoesRepo;
    private readonly IPlantsRepository plantsRepo;
    private readonly ICoilFieldZoneRepository coilFieldZoneRepo;
    private readonly ICoilRepository coilRepo;
    private readonly ICoilTypeRepository coilTypeRepo;
    private readonly IUserHelper usersHelper;

    public AndonService(IApplicationLogger<AndonService> andonServiceLogger,
        IBlankInfoesRepository blankInfoesRepo, IPlantsRepository plantsRepo,
        ICoilFieldZoneRepository coilFieldZoneRepo, ICoilRepository coilRepo, ICoilTypeRepository coilTypeRepo, IUserHelper usersHelper)
    {
      this.andonServiceLogger = andonServiceLogger;
      this.blankInfoesRepo = blankInfoesRepo;
      this.plantsRepo = plantsRepo;
      this.coilFieldZoneRepo = coilFieldZoneRepo;
      this.coilRepo = coilRepo;
      this.coilTypeRepo = coilTypeRepo;
      this.usersHelper = usersHelper;
    }
    #region
    /// <summary>
    /// Get Andon CoilFieldZone information based on ZoneID  
    /// </summary>
    /// <param name="zoneId"></param>
    /// <returns></returns>
    public AndonCoilFieldZoneDisplayObject GetCoilsFeildsByZoneId(int? zoneId)
    {

      var zones = new AndonCoilFieldZoneDisplayObject
      {
        TotalZoneColumns = 0,
        Zones = new List<AndonCoilFieldZone>()
      };
      //Get the plant NAMC 
      string NAMC = usersHelper.GetNAMCCode();
      //logging the NAMC count info
      andonServiceLogger.LogInformation(Constant.classname + "AndonService" + Constant.methodname + "GetCoilsFeildsByZoneId" + Constant.message + "Current Plant Name"  + NAMC + Constant.countoflines);
      // Get the list of coilsInField 
      List<Coil> coilsInField = coilRepo.GetCoilsFeildsByZoneId(zoneId);
      //Get the List of DBZone
      var DBZones = coilFieldZoneRepo.GetCoilFieldZones(zoneId);
      andonServiceLogger.LogInformation(Constant.classname + "AndonService" + Constant.methodname + "GetCoilsFeildsByZoneId" + Constant.countoflines + DBZones.Count);
      foreach (var dbZone in DBZones)
      {
        var zone = new AndonCoilFieldZone
        {
          Locations = new List<AndonCoilFieldZoneLocation>(),
          Name = Constant.Zone + dbZone.Name,
          BackgroundColor = dbZone.Color,
          TextColor = dbZone.TextColor
        };
        SetCoilfieldZones(dbZone, zone);
        zones.TotalZoneColumns += zone.Columns;
        zones.Zones.Add(zone);
        andonServiceLogger.LogInformation(Constant.classname + "AndonService" + Constant.methodname + "GetCoilsFeildsByZoneId" + Constant.message + "coil at location");
        foreach (var dbLocation in dbZone.Locations)
        {
          var location = new AndonCoilFieldZoneLocation
          {
            Name = dbLocation.Name,
            Row = dbLocation.Row,
            Column = dbLocation.Column,
            IsEmpty = dbLocation.IsEmpty
          };

          Coil coilAtLocation = coilsInField.Where(c => c.CoilFieldLocation.Id == dbLocation.Id).FirstOrDefault();
          if (coilAtLocation != null)
          {           
            //Get the blankInfoesRepo die no
            List<BlankInfo> dieNo = blankInfoesRepo.GetdieNos(coilsInField);
            andonServiceLogger.LogInformation(Constant.classname + "AndonService" + Constant.methodname + "GetCoilsFeildsByZoneId" + Constant.message + "Get the die no" + Constant.countoflines + dieNo);
            string dienos = dieNo.Where(d => d.CoilType.Id == coilAtLocation.CoilType.Id).Select(d => d.DieNo.ToString()).FirstOrDefault();

            location.BackgroundColor = coilAtLocation.CoilStatus.Color;
            location.TextColor = coilAtLocation.CoilStatus.TextColor;
            CoilType dbCoilType = coilAtLocation.CoilType;
            SetCoilTypeDieNo(dbCoilType, location, NAMC, dienos);
            zone.Locations.Add(location);//always add the location if a coil is there
          }
          else if (!dbLocation.Disabled)
          {
            //If we don't have a coil at the location, only show it if it is not disabled.
            zone.Locations.Add(location);
          }
        }
      }
      return zones;
    }

    /// <summary>
    /// SetCoilfieldZones
    /// </summary>
    /// <param name="dbZone"></param>
    /// <param name="zone"></param>
    public void SetCoilfieldZones(CoilFieldZone dbZone, AndonCoilFieldZone zone)
    {
      if (dbZone.Locations.Any())
      {
        zone.Rows = dbZone.Locations.Max(l => l.Row);
        zone.Columns = dbZone.Locations.Max(l => l.Column);
      }
      else
      {
        zone.Columns = 1; //Minimum 1 column to show the title
      }
    }

    /// <summary>
    /// SetCoilTypeDieNo
    /// </summary>
    /// <param name="dbCoilType"></param>
    /// <param name="location"></param>
    /// <param name="NAMC"></param>
    /// <param name="dienos"></param>
    public void SetCoilTypeDieNo(CoilType dbCoilType, AndonCoilFieldZoneLocation location, string NAMC, string dienos)
    {
      if (dbCoilType != null)
      {
        location.CoilType = dbCoilType.Name;
        if (NAMC == Constant.TMMI && dienos != null)
        {
          location.CoilType = location.CoilType + Constant.FSlash + dienos;
        }
      }
    }
    /// <summary>
    /// Get Coil Locations
    /// </summary>
    /// <param name="coilAtLocation"></param>
    /// <returns></returns>
    public List<CoilFieldLocation> GetCoilFieldLocation(List<Coil> coilAtLocation)
    {
      List<CoilFieldLocation> CoilFieldLocation = new List<CoilFieldLocation>();
      foreach (var CoilFielddata in coilAtLocation)
      {
        CoilFieldLocation.Add(new CoilFieldLocation()
        {
          Id = CoilFielddata.CoilFieldLocation.Zone.Id,
          Name = CoilFielddata.CoilFieldLocation.Zone.Name,
          Zone = new CoilFieldZone { TextColor = CoilFielddata.CoilFieldLocation.Zone.TextColor }
        });
      }
      return CoilFieldLocation;
    }

    #endregion
    #region
    /// <summary>
    ///  Get Andon CoilTypesByZone information based on ZoneID    
    /// </summary>
    /// <param name="zoneId"></param>
    /// <returns></returns>
    public AndonCoilTypesByZoneDisplayObject GetCoilsTypesByZoneId(int? zoneId)
    {
        AndonCoilTypesByZoneDisplayObject andonDisplayObject = new AndonCoilTypesByZoneDisplayObject
        {
          Zones = new List<AndonZone>()
        };
        //Get Plants Name
        string NAMC = usersHelper.GetNAMCCode();
        //logging plants information  
        andonServiceLogger.LogInformation(Constant.classname + "AndonService" + Constant.methodname +
            "GetCoilsTypesByZoneId" + Constant.message + "Current Plant Name");
        //Get List of CoilTypes
        var numVals = coilTypeRepo.GetCoilTypes();
        andonServiceLogger.LogInformation(Constant.classname + "AndonService" + Constant.methodname +
           "GetCoilsTypesByZoneId" + Constant.countoflines + numVals.Count);
        //Get list of coils deatils based on zoneId
        List<Coil> coilsOnHand = coilRepo.GetCoilsFeildsByZoneId(zoneId);
        //logging
        andonServiceLogger.LogInformation(Constant.classname + "AndonService" + Constant.methodname +
            "GetCoilsTypesByZoneId" + Constant.countoflines + coilsOnHand.Count);
        DateTime now = DateTime.Now;
        List<BlankInfo> dieNo = blankInfoesRepo.GetdieNos(coilsOnHand);

        foreach (var coilinhand in coilsOnHand)
        {
          string dienos = dieNo.Where(d=>d.CoilType.Id == coilinhand.CoilType.Id).Select(d => d.DieNo.ToString()).FirstOrDefault();
          SetCoilStatusColors(coilinhand, dienos, NAMC);
        }
        var dbZones = coilFieldZoneRepo.GetCoilFieldZones(zoneId);
        //logging CoilFieldZones information 
        andonServiceLogger.LogInformation(Constant.classname + "AndonService" + Constant.methodname +
            "GetCoilsTypesByZoneId" + Constant.countoflines + dbZones.Count);
        var dbCoilsType = coilTypeRepo.GetdbCoilTypes(dbZones);
        //logging CoilTypes information
        andonServiceLogger.LogInformation(Constant.classname + "AndonService" + Constant.methodname +
            "GetCoilsTypesByZoneId" + Constant.countoflines + dbCoilsType.Count);
        foreach (var dbZone in dbZones)
        {
          //Get the andonzone list based on coilfeildzone 
          var andonZone = BuildAndonZoneOnCoilFieldZone(dbZone);
          andonDisplayObject.Zones.Add(andonZone);
        //Get the CoilTypes list based on coilfeildzoneID 
        var dbCoilTypes = dbCoilsType.Where(ct => ct.CoilFieldZone.Id == dbZone.Id && !ct.Disabled) //Get coilTypes in this zone, that are not disabled
                                              .OrderBy(ct => ct.Name).ToList();
        //its like zone 1 has  these coil types (dbCoilTypes- Like :1-1-A etc)            
        SetAndonZoneMaxCoilColumns(dbCoilTypes, andonZone);
          andonServiceLogger.LogInformation(Constant.classname + "AndonService" + Constant.methodname +
                  "GetCoilsTypesByZoneId");
          foreach (var dbCoilType in dbCoilTypes)
          {
            var andonCoilType = new AndonCoilType();
            andonZone.CoilTypes.Add(andonCoilType);
            andonCoilType.Name = dbCoilType.Name;
            andonCoilType.WrongZone = false;
            andonCoilType.NumCoils = dbCoilType.NumCoils;
          //Get the andonCoilType locations list based on coilfeildzone,coil,CoilType

          andonCoilType.CoilLocationsInOrder = coilsOnHand.Where(c => c.CoilFieldLocation != null
                                                                           && c.CoilFieldLocation.Zone.Id == dbZone.Id
                                                                           && c.CoilType.Id == dbCoilType.Id)
                                                                           .OrderBy(c => c.IsPriority) //First order by if it is priority coil or not, then by checkin date
                                                                           .ThenByDescending(c => c.CheckInDate) //Andon logic is backwards, we want newest first to the left, oldest to the right
                                                                           .Select(c => new AndonCoilTypeLocation()
                                                                           {
                                                                             Name = c.CoilFieldLocation.Name,
                                                                             CoilId = c.Id,
                                                                             BackgroundColor = c.CoilStatus.Color,
                                                                             TextColor = c.CoilStatus.TextColor
                                                                           }).ToList();


          var coilIdsAddedToZone = andonCoilType.CoilLocationsInOrder.Select(cl => cl.CoilId);
          coilsOnHand.RemoveAll(c => coilIdsAddedToZone.Contains(c.Id)); //Remove coils we already added from the list

            SetAndondbCoilType(andonCoilType, dbCoilType, andonZone);
          }
        }
        var coilsInWrongZone = coilsOnHand.GroupBy(c => c.CoilFieldLocation.Zone.Name).OrderBy(g => g.Key);
        //This will include any leftover coils, rather they are in the wrong zone or a disabled CoilType
        foreach (var coilsInWrongZoneGroup in coilsInWrongZone)
        {
          string zoneName = coilsInWrongZoneGroup.Key;
          var andonZone = andonDisplayObject.Zones.FirstOrDefault(ado => ado.Name == zoneName);
          if (andonZone == null)
          {
            var dbZone = coilsInWrongZoneGroup.First().CoilFieldLocation.Zone;
            andonZone = BuildAndonZoneOnCoilFieldZone(dbZone);
            if (dbZone.Disabled)
            {
              andonZone.Name += Constant.Disabled;
            }
            andonDisplayObject.Zones.Add(andonZone);
          }
          var coilsByTypeGroup = coilsInWrongZoneGroup.GroupBy(c => c.CoilType.Name).OrderBy(g => g.Key);

          andonServiceLogger.LogInformation(Constant.classname + "AndonService" + Constant.methodname +
              "GetCoilsTypesByZoneId" + Constant.countoflines + numVals.Count);

          foreach (var coilTypeGroup in coilsByTypeGroup)
          {
            string coilTypeName = coilTypeGroup.Key;
            var andonCoilType = new AndonCoilType();
            andonZone.CoilTypes.Add(andonCoilType);
            andonCoilType.Name = coilTypeName;
            andonCoilType.WrongZone = true;
          int numVal = numVals.Where(x => x.Name == coilTypeName.ToString()).Select(c => c.NumCoils).FirstOrDefault();
            andonCoilType.NumCoils = coilTypeGroup.First().CoilType.NumCoils;
            //Get the coiltype details from the first coil in the group (we're grouped by coiltype, so all in the group is the same) and we should be gaurenteed to have items since we have a group
            andonCoilType.CoilLocationsInOrder = coilTypeGroup.OrderBy(c => c.IsPriority)
                                                              //First order by if it is priority coil or not, then by checkin date
                                                              .OrderByDescending(c => c.CheckInDate)
                                                              //Andon logic is backwards, newest to left oldest to right
                                                              .Select(c => new AndonCoilTypeLocation()
                                                              {
                                                                Name = c.CoilFieldLocation.Name,
                                                                CoilId = c.Id,
                                                                BackgroundColor = c.CoilStatus.Color,
                                                                TextColor = c.CoilStatus.TextColor
                                                              }).ToList();
            var coilIdsAddedToZone = andonCoilType.CoilLocationsInOrder.Select(cl => cl.CoilId);
            coilsOnHand.RemoveAll(c => coilIdsAddedToZone.Contains(c.Id)); //Remove coils we already added from the list
            SetAndonCoilTypevalue(andonCoilType, numVal, andonZone);
          }
        }
        andonDisplayObject.TotalColumns = andonDisplayObject.Zones.Sum(z => z.MaxCoilColumns);
        return andonDisplayObject;
      
    }

    /// <summary>
    /// Set AndonZoneMaxCoilColumns
    /// </summary>
    /// <param name="dbCoilTypes"></param>
    /// <param name="andonZone"></param>
    public void SetAndonZoneMaxCoilColumns(List<CoilType> dbCoilTypes, AndonZone andonZone)
    {
      if (dbCoilTypes.Any())
      {
        andonZone.MaxCoilColumns = dbCoilTypes.Max(ct => ct.NumCoils);
        // andonZone has the open positions left in that Zone 
      }
      else
      {
        andonZone.MaxCoilColumns = 1; //Minimum 1 column to show the title
      }
    }

    /// <summary>
    /// Set AndonZone Based On CoilFieldZone
    /// </summary>
    /// <param name="dbZone"></param>
    /// <returns></returns>
    public AndonZone BuildAndonZoneOnCoilFieldZone(CoilFieldZone dbZone)
    {
      var andonZone = new AndonZone
      {
        CoilTypes = new List<AndonCoilType>(),
        Name = dbZone.Name,
        BackgroundColor = dbZone.Color,
        TextColor = dbZone.TextColor,
        LocationsCount = dbZone.Locations.Count,
        LocationsUsedCount = dbZone.Locations.Count(l => !l.IsEmpty),
        OpenPositions = dbZone.Locations.Where(l => l.IsEmpty).OrderBy(l => l.Column).ThenBy(l => l.Row).Select(l => l.Name).ToList()
      };
      return andonZone;
    }

    /// <summary>
    /// Set Coil Color Status 
    /// </summary>
    /// <param name="coilinhand"></param>
    /// <param name="dieNo"></param>
    /// <param name="NAMC"></param>
    public void SetCoilStatusColors(Coil coilinhand, string diesNo, string NAMC)
    {
      DateTime now = DateTime.Now;
      if ((coilinhand.CoilStatus.Name.Equals(Constant.New)) && ((now - coilinhand.CheckInDate).TotalHours <= 8))
      {
        coilinhand.CoilFieldLocation.Name = coilinhand.CoilFieldLocation.Name + Constant.EX;
        coilinhand.CoilStatus.Color = Constant.Green;
        coilinhand.CoilStatus.TextColor = Constant.White;
      }
      else if ((coilinhand.CoilStatus.Name.Equals(Constant.New)) && ((now - coilinhand.CheckInDate).TotalHours > 8) && ((now - coilinhand.CheckInDate).TotalDays <= 7))
      {
        coilinhand.CoilFieldLocation.Name = coilinhand.CoilFieldLocation.Name + Constant.exclamation;
        coilinhand.CoilStatus.Color = Constant.Green;
        coilinhand.CoilStatus.TextColor = Constant.White;
      }
      else if (coilinhand.CoilStatus.Name.Equals(Constant.New) && ((now - coilinhand.CheckInDate).TotalDays > 7))
      {
        coilinhand.CoilFieldLocation.Name = coilinhand.CoilFieldLocation.Name + Constant.WHY;
        coilinhand.CoilStatus.Color = Constant.Green;
        coilinhand.CoilStatus.TextColor = Constant.Red;
      }
      if (coilinhand.CoilStatus.Name.Equals(Constant.RejectedOnHand))
      {
        coilinhand.CoilStatus.Color = Constant.Red;
        coilinhand.CoilStatus.TextColor = Constant.Black;
      }
      if (coilinhand.CoilStatus.Name.Equals(Constant.TryoutCoils))
      {
        coilinhand.CoilStatus.Color = Constant.Violet;
        coilinhand.CoilStatus.TextColor = Constant.Black;
      }
      if (coilinhand.CurrentWeight < coilinhand.OriginalWeight && coilinhand.CoilStatus.Name.Equals(Constant.Partial))
      {
        coilinhand.CoilFieldLocation.Name = coilinhand.CoilFieldLocation.Name + Constant.MinusPR;
        coilinhand.CoilStatus.Color = Constant.Yellow;
        coilinhand.CoilStatus.TextColor = Constant.Black;
      }
      if (NAMC == Constant.TMMI && diesNo != null)
        coilinhand.CoilFieldLocation.Name = coilinhand.CoilFieldLocation.Name + Constant.FSlash + diesNo;
    }

    /// <summary>
    /// Set Andon CoilType On dbCoilType value
    /// </summary>
    /// <param name="andonCoilType"></param>
    /// <param name="dbCoilType"></param>
    public void SetAndondbCoilType(AndonCoilType andonCoilType, CoilType dbCoilType, AndonZone andonZone)
    {
      int count = 0;
      List<string> arr = new List<string>();
      if (andonCoilType.CoilLocationsInOrder.Count > dbCoilType.NumCoils)
      {
        var KanCoilStatus = coilRepo.GetKanCoils();
        andonServiceLogger.LogInformation(Constant.classname + "AndonService" + Constant.methodname +
           "SetAndondbCoilType" + Constant.countoflines + KanCoilStatus.Count);
        foreach (var kan in andonCoilType.CoilLocationsInOrder)
        {
          var coilData = KanCoilStatus.Where(c => c.Id == kan.CoilId);
          arr.Add(coilData.Select(x => x.CoilStatus.Name).FirstOrDefault());
        }
        for (int i = dbCoilType.NumCoils; i < arr.Count; i++)
        {
          if (arr[i] != Constant.Partial)
          {
            count = -1;
          }
        }
        if (count == -1)
        {
          andonCoilType.Kanban = true;
        }
        else
        {
          andonCoilType.Kanban = false;
        }
        //If we have more coils checked in than the max allowed/set, then increase the zone/coilType column counts
        if (andonCoilType.CoilLocationsInOrder.Count > andonZone.MaxCoilColumns)
        {
          andonZone.MaxCoilColumns = andonCoilType.CoilLocationsInOrder.Count;
        }
      }
    }

    /// <summary>
    /// Set Andon CoilType On numval value
    /// </summary>
    /// <param name="andonCoilType"></param>
    /// <param name="numVal"></param>
    public void SetAndonCoilTypevalue(AndonCoilType andonCoilType, int numVal, AndonZone andonZone)
    {
      int count1 = 0;
      List<string> array = new List<string>();
      if (andonCoilType.CoilLocationsInOrder.Count > numVal)
      {
        var KanCoilStatus = coilRepo.GetKanCoils();
        andonServiceLogger.LogInformation(Constant.classname + "AndonService" + Constant.methodname +
        "SetAndonCoilTypevalue" + Constant.countoflines + KanCoilStatus.Count);
        foreach (var kan in andonCoilType.CoilLocationsInOrder)
        {
          var coilData = KanCoilStatus.Where(c => c.Id == kan.CoilId);
          array.Add(coilData.Select(x => x.CoilStatus.Name).FirstOrDefault());
        }
        for (int i = numVal; i < array.Count; i++)
        {
          if (array[i] != Constant.Partial)
          {
            count1 = -1;
          }
        }
        if (count1 == -1)
        {
          andonCoilType.Kanban = true;
        }
        else
        {
          andonCoilType.Kanban = false;
        }
        //If we have more coils checked in than the max allowed/set, then increase the zone/coilType column counts
        if (andonCoilType.CoilLocationsInOrder.Count > andonZone.MaxCoilColumns)
        {
          andonZone.MaxCoilColumns = andonCoilType.CoilLocationsInOrder.Count;
        }
      }
    }
    #endregion
  }
}
