using CoilTracking.Business.Interfaces;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class ImportProdPlan : IImportProdPlan
  {
    private readonly IProdPlanRepository prodPlanRepository;
    private readonly IPartRepository partRepository;

    public ImportProdPlan(IProdPlanRepository prodPlanRepository,
      IPartRepository partRepository)
    {
      this.prodPlanRepository = prodPlanRepository;
      this.partRepository = partRepository;
    }
    private enum Columns
    {
      PartNo = 1,
      LotSize = 2,
    }

    public async Task<List<DataImportMessage>> Import(MemoryStream ms, string userName)
    {
      List<DataImportMessage> messages = new List<DataImportMessage>();

      using (var package = DataImportHelper.GetPackageFromMemoryStream(ms, messages))
      {
        if (package != null && package.Workbook != null && package.Workbook.Worksheets.Count > 0)
        {
          //Data expected only in first worksheet or a worksheet named Data
          ExcelWorksheet worksheet = package.Workbook.Worksheets.Where(ws => string.Equals(ws.Name, "ProdPlan", StringComparison.InvariantCultureIgnoreCase)).DefaultIfEmpty(package.Workbook.Worksheets.First()).FirstOrDefault();
          List<DataImportMessage> newMessages = await ImportData(worksheet, userName);
          messages.AddRange(newMessages);
        }
        else
        {
          messages.Add(new DataImportMessage(-1, "No valid worksheet found, make sure this is a valid XLSX (Excel 2007+) file", DataImportMessage.MsgType.Error));
        }
      }

      return messages;
    }

    public async Task<List<DataImportMessage>> ImportData(ExcelWorksheet worksheet, string userName)
    {
      List<DataImportMessage> errors = new List<DataImportMessage>();
      int maxRows = worksheet.Dimension.End.Row;

      //Columns where each blank property is expected are fixed
      for (int row = 2; row <= maxRows; row++)
      {
        int lotSize;
        try
        {
          lotSize = int.Parse(worksheet.Cells[row, (int)Columns.LotSize].Text);
        }
        catch (Exception)
        {
          errors.Add(new DataImportMessage(row, "Lot size missing/wrong format", DataImportMessage.MsgType.Error));
          continue;
        }

        string partNumber = worksheet.Cells[row, (int)Columns.PartNo].Text;
        var prodPlantEntry = await prodPlanRepository.GetProdPlanByPartBynumber(partNumber);

        if (prodPlantEntry == null)
        {
          Part part = partRepository.GetPartByName(partNumber);
          if (part == null)
          {
            errors.Add(new DataImportMessage(row, "Part Number " + partNumber + " is missing in system", DataImportMessage.MsgType.Error));
            continue;
          }
          prodPlantEntry = new ProdPlan();
          prodPlantEntry.Part = part;
          prodPlantEntry.LotSize = lotSize;
          try
          {
            await prodPlanRepository.AddProdPlantEntry(prodPlantEntry);
            errors.Add(new DataImportMessage(row,
                      "New Part number " + partNumber + " entry created", DataImportMessage.MsgType.Notification));
          }
          catch (Exception )
          {
            errors.Add(new DataImportMessage(row,
                    "Unidentified database error occured while creating new Part (" + partNumber + ") entry", DataImportMessage.MsgType.Error));
            prodPlanRepository.RemoveProdPlantEntry(prodPlantEntry);
          
          }
        }
        else
        {
          prodPlantEntry.LotSize = lotSize;
          try
          {
            await prodPlanRepository.UpdateProdPlantEntry(prodPlantEntry);
          }
          catch (Exception )
          {

            errors.Add(new DataImportMessage(row,
                    "Unidentified database error occured updating Part (" + partNumber + ") entry", DataImportMessage.MsgType.Error));
            prodPlanRepository.UpdateProdPlantState(prodPlantEntry);
          
          }
        }
      }


      return errors;
    }

  }
}
