using AutoMapper;
using CoilTracking.Business.Interfaces;
using CoilTracking.Business.Interfaces.BlockingDiagrams;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{

  public class BlockingDiagramService : IBlockingDiagramService
  {
    private readonly IAWSS3BucketHelper aWSS3BucketHelper;
    private readonly IBlockingDiagramRepository blockingDiagramRepo;
    private readonly IMapper mapper;
    private readonly IApplicationLogger<BlockingDiagramService> logger;

    public BlockingDiagramService(IAWSS3BucketHelper aWSS3BucketHelper, IBlockingDiagramRepository blockingDiagramRepo, IMapper mapper, IApplicationLogger<BlockingDiagramService> logger)
    {
      this.aWSS3BucketHelper = aWSS3BucketHelper;
      this.blockingDiagramRepo = blockingDiagramRepo;
      this.mapper = mapper;
      this.logger = logger;
    }

    /// <summary>
    /// Get blocking diagrams
    /// </summary>
    /// <returns>blockingDiagram</returns>
    public async Task<List<BlockingDiagramDto>> GetBlockingDiagrams()
    {
      var blockingDiagrams = await blockingDiagramRepo.GetBlockingDiagrams();
      var list = MapBlockingDiagram(blockingDiagrams);
      logger.LogInformation(Constant.classname + "AWSS3FileService" + Constant.methodname + "GetBlockingDiagrams" + Constant.message + "Get  all blocking diagrams");

      return list;
    }
    /// <summary>
    /// To get blocking diagram by Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<BlockingDiagramDto> GetBlockingDiagramById(int id)
    {
      var blockingDiagram = await blockingDiagramRepo.GetBlockingDiagramById(id);
      logger.LogInformation(Constant.classname + "AWSS3FileService" + Constant.methodname + "GetBlockingDiagramById" + Constant.message + "Get  all blocking diagrams by Id");
      return mapper.Map<BlockingDiagramDto>(blockingDiagram);
    }

    /// <summary>
    /// To map list of blocking diagram list to dto list
    /// </summary>
    /// <param name="blockingDiagrams"></param>
    /// <returns></returns>
    public List<BlockingDiagramDto> MapBlockingDiagram(List<BlockingDiagrams> blockingDiagrams)
    {
      List<BlockingDiagramDto> blockingDiagramDtoList = new List<BlockingDiagramDto>();
      foreach (var dto in blockingDiagrams)
      {
        BlockingDiagramDto blockingDiagramDto = new BlockingDiagramDto
        {
          Id = dto.Id,
          DataNumber = dto.DataNumber,
          ImagePath = dto.ImagePath
        };
        blockingDiagramDtoList.Add(blockingDiagramDto);
      }
      return blockingDiagramDtoList;
    }
   
    /// <summary>
    /// Get File by Id
    /// </summary>
    /// <param name="key"></param>
    /// <returns>Stream</returns>
    public async Task<Stream> GetFile(int dataNum)
    {
      
        string defaultImg = "DEFAULT.JPG";
      if (dataNum == 0)
      {
        logger.LogInformation(Constant.classname + "BlockingDiagramService" + Constant.methodname + "GetFile" + Constant.message + "Before aWSS3BucketHelper.GetFile for default");

        Stream fileStreamDefault = await aWSS3BucketHelper.GetFile(defaultImg);
        logger.LogInformation(Constant.classname + "BlockingDiagramService" + Constant.methodname + "GetFile" + Constant.message + "After aWSS3BucketHelper.GetFile for default");

        return fileStreamDefault;
      }
      logger.LogInformation(Constant.classname + "BlockingDiagramService" + Constant.methodname + "GetFile" + Constant.message + "Before aWSS3BucketHelper.GetFile for dataNum");

      var key = await blockingDiagramRepo.GetBlockingDiagramByDataNum(dataNum);

      Stream fileStream = await aWSS3BucketHelper.GetFile(key.ImagePath);
      if (fileStream == null)
      {
         
        logger.LogInformation(Constant.classname + "AWSS3FileService" + Constant.methodname + "GetFile" + Constant.message + "Get  image from S3 bucket");
        throw new CoilTrackingException { ErrorMessage = "File Not Found", HttpStatusCode = StatusCodes.Status400BadRequest.ToString() };
      }
        else
        {
          return fileStream;
        }
      
    }
    /// <summary>
    /// Delete a blocking diagram
    /// </summary>
    /// <param name="id"></param>
    /// <returns>blockingDiagramDto</returns>
    public async Task<BlockingDiagramDto> DeleteBlockingDiagram(int id)
    {
      var blockingDiagram = await blockingDiagramRepo.GetBlockingDiagramById(id);
      if (blockingDiagram == null)
      {
        throw new CoilTrackingException { ErrorMessage = "NotFound", HttpStatusCode = "NotFound" };
      }
      var blockingDiagramDto = mapper.Map<BlockingDiagramDto>(blockingDiagram);
      logger.LogInformation(Constant.classname + "BlockingDiagramService" + Constant.methodname + "DeleteFile" + Constant.message + "Before aWSS3BucketHelper.DeleteFile");

      var result = await aWSS3BucketHelper.DeleteFile(blockingDiagram.ImagePath);
      logger.LogInformation(Constant.classname + "BlockingDiagramService" + Constant.methodname + "DeleteFile" + Constant.message + "After aWSS3BucketHelper.DeleteFile");

      if (result)
      {
        logger.LogInformation(Constant.classname + "BlockingDiagramService" + Constant.methodname + "DeleteFile" + Constant.message + "Before repo.DeleteFile");

        await blockingDiagramRepo.DeleteBlockingDiagram(id);
        logger.LogInformation(Constant.classname + "BlockingDiagramService" + Constant.methodname + "DeleteFile" + Constant.message + "After aWSS3BucketHelper.DeleteFile");

      }
      else
      {
        throw new CoilTrackingException { ErrorMessage = "Some error occured for Id"+ id, HttpStatusCode = "Internal Server Error" };
      }
      logger.LogInformation(Constant.classname + "AWSS3FileService" + Constant.methodname + "DeleteBlockingDiagram" + Constant.message + "Delete blocking diagrams by Id");

      return blockingDiagramDto;
    }

    /// <summary>
    /// Update blocking diagram
    /// </summary>
    /// <param name="uploadFileName"></param>
    /// <param name="dataNum"></param>
    /// <param name="id"></param>
    /// <returns>bool</returns>
    public async Task<bool> UpdateBlockingDiagram(IFormFile uploadFileName, int dataNum, int id)
    {
      var blockingDiagram =await blockingDiagramRepo.GetBlockingDiagramById(id);
      BlockingDiagramDto blockingDiagramDto = new BlockingDiagramDto();
      if (blockingDiagram.DataNumber != dataNum)
      {
          throw new CoilTrackingException { ErrorMessage = ApplicationMessages.blockingUpdateErr, HttpStatusCode = StatusCodes.Status400BadRequest.ToString() };
      }
      logger.LogInformation(Constant.classname + "AWSS3FileService" + Constant.methodname + "UpdateBlockingDiagram" + Constant.message + "Update blocking diagrams by Id");

      blockingDiagramDto.Id = id;
      blockingDiagramDto.DataNumber = dataNum;
      blockingDiagramDto.ImagePath = dataNum.ToString()+ Path.GetExtension(uploadFileName.FileName);
      var updatedBlockingDiagram = mapper.Map<BlockingDiagrams>(blockingDiagramDto);
      
      if (uploadFileName.Length > 0)
      {
        var deleteExistingImage = await aWSS3BucketHelper.DeleteFile(blockingDiagram.ImagePath);
        if (deleteExistingImage)
        {
            string fileName = string.Empty;
            fileName = dataNum.ToString() + Path.GetExtension(uploadFileName.FileName);
            var check = await aWSS3BucketHelper.UploadFileAsyncTransferUtility(uploadFileName, fileName);
            if (check)
            {
              await blockingDiagramRepo.UpdateBlockingDiagram(updatedBlockingDiagram);
            }
            return check;
          
        }
      }
      return true;
    }
    /// <summary>
    /// To import images to blocking diagram
    /// </summary>
    /// <param name="selectedFiles"></param>
    /// <returns></returns>
    public async Task<List<DataImportMessage>> ImportBlockingDiagram(IFormFileCollection selectedFiles)
    {
      var xsn = Constant.jpg;
      var xsnpng = Constant.png;
      int dataNum = 0;
      List<DataImportMessage> errors = new List<DataImportMessage>();
      List<BlockingDiagrams> blockingDiagramsToAdd = new List<BlockingDiagrams>();
      logger.LogInformation(Constant.classname + "AWSS3FileService" + Constant.methodname + "ImportBlockingDiagram" + Constant.message + "Import blocking diagrams");
    
      for (int i = 0; i < selectedFiles.Count; i++)
      {
        
          var postedFile = selectedFiles[i];
        string filename = Path.GetFileNameWithoutExtension(postedFile.FileName);
        string ext = Path.GetExtension(postedFile.FileName);
        if (!String.Equals(ext, xsn, StringComparison.OrdinalIgnoreCase))
        {
          if (!String.Equals(ext, xsnpng, StringComparison.OrdinalIgnoreCase))
            errors.Add(new DataImportMessage(-1, "The file: " + filename + "" + ext + " is in wrong format", 0));
          continue;
        }

        try
        {
          dataNum = Int32.Parse(filename);
        }
        catch (FormatException)
        {
          errors.Add(new DataImportMessage(-1, filename + ApplicationMessages.invalidMsus, 0));
          continue;
        }
        // Get this list outside loop
        var blockingDiagramByDataNum =await blockingDiagramRepo.GetBlockingDiagramByDataNum(dataNum);
        if (blockingDiagramByDataNum!=null)
        {
          errors.Add(new DataImportMessage(dataNum, ApplicationMessages.blockingDiagramExist, 0));
          continue;
        }

        BlockingDiagramDto blockingDiagramDto = new BlockingDiagramDto
        {
          DataNumber = dataNum,
          ImagePath = postedFile.FileName.ToString() + Path.GetExtension(postedFile.FileName)
         
        };

        BlockingDiagrams blockingDiagram = new BlockingDiagrams
        {
          DataNumber = dataNum,
          ImagePath = blockingDiagramDto.ImagePath
        };

        
          string fileName = string.Empty;
          fileName = postedFile.FileName.ToString() + Path.GetExtension(postedFile.FileName);

          bool check = await aWSS3BucketHelper.UploadFileAsyncTransferUtility(postedFile, fileName);
          if (check)
          {
            blockingDiagramsToAdd.Add(blockingDiagram);
          }
          
        
        errors.Add(new DataImportMessage(dataNum, ApplicationMessages.newBlockingDiagram, DataImportMessage.MsgType.Notification));
      }
      await blockingDiagramRepo.InsertBlockingDiagramList(blockingDiagramsToAdd);

      return errors;
    }


    /// <summary>
    /// To upload image to s3 bucket 
    /// </summary>
    /// <param name="uploadFileName"></param>
    /// <param name="dataNum"></param>
    /// <returns></returns>
    public async Task<bool> UploadFile(IFormFile uploadFileName, int dataNum)
    {
      var blockingDiagramByDataNum = await blockingDiagramRepo.GetBlockingDiagramByDataNum(dataNum);
      if (blockingDiagramByDataNum != null)
      {
        throw new CoilTrackingException { HttpStatusCode = "BadRequest", ErrorMessage = ApplicationMessages.defaultMsgForBlockingDiagram };
      }
      BlockingDiagrams blockingDiagram = new Data.Models.BlockingDiagrams
      {
        DataNumber = dataNum,
        ImagePath = dataNum.ToString() + Path.GetExtension(uploadFileName.FileName)

    };
      
        if (uploadFileName.Length > 0)
        {
        string fileName= dataNum.ToString()+ Path.GetExtension(uploadFileName.FileName);
            

        logger.LogInformation(Constant.classname + "BlockingDiagramService" + Constant.methodname + "UploadFile" + Constant.message + "Before aWSS3BucketHelper.UploadFile");
        
        var check = await aWSS3BucketHelper.UploadFileAsyncTransferUtility(uploadFileName, fileName);
        logger.LogInformation(Constant.classname + "BlockingDiagramService" + Constant.methodname + "UploadFile" + Constant.message + "After aWSS3BucketHelper.UploadFile");

        if (check)
            {
          logger.LogInformation(Constant.classname + "BlockingDiagramService" + Constant.methodname + "UploadFile" + Constant.message + "Before Insert blocking diagram");

          await blockingDiagramRepo.InsertBlockingDiagram(blockingDiagram);
            }
            return check;
        }
        return true;
    }
  }
}
