using Amazon.S3;
using Amazon.S3.Model;
using Amazon.S3.Transfer;
using CoilTracking.Business.Interfaces.BlockingDiagrams;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using System;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  [ExcludeFromCodeCoverage]
  public class AWSS3BucketHelper : IAWSS3BucketHelper
  {
    private readonly IConfiguration config;
    private readonly IAmazonS3 amazonS3;
    private readonly IApplicationLogger<AWSS3BucketHelper> logger;
    public AWSS3BucketHelper(IAmazonS3 s3Client,  IApplicationLogger<AWSS3BucketHelper> logger, IConfiguration config)
    {
      this.amazonS3 = s3Client;
      this.logger = logger;
      this.config = config;
    }

   

    public async Task<bool> UploadFileAsyncTransferUtility(IFormFile file, string keyName)
    {

      await using var newMemoryStream = new MemoryStream();
      file.CopyTo(newMemoryStream);

      var uploadRequest = new TransferUtilityUploadRequest
      {
        InputStream = newMemoryStream,
        Key = keyName,
        BucketName = config["s3:diagram-bucket"],
        ContentType = file.ContentType
      };

      var fileTransferUtility = new TransferUtility(amazonS3);
      await fileTransferUtility.UploadAsync(uploadRequest);
      return true;
    }

    /// <summary>
    /// Upload images to S3 bucket
    /// </summary>
    /// <param name="inputStream"></param>
    /// <param name="fileName"></param>
    /// <returns></returns>
    public async Task<bool> UploadFile(System.IO.Stream inputStream, string fileName)
    {
      logger.LogInformation(Constant.classname + "BucketHelper" + Constant.methodname + "UploadFile" + Constant.message + "before stream" + inputStream.Length);

      inputStream.Position = 0;
      logger.LogInformation(Constant.classname + "BucketHelper" + Constant.methodname + "UploadFile" + Constant.message +"after stream"+ inputStream.Length);

      var region = amazonS3.Config.RegionEndpoint;
      logger.LogInformation(Constant.classname + "BucketHelper" + Constant.methodname + "UploadFile" + Constant.message + "Get  all blocking diagrams in "+ region+ "bucket name"+ config["s3:diagram-bucket"]);
        PutObjectRequest request = new PutObjectRequest()
        {
          InputStream = inputStream,
          BucketName = config["s3:diagram-bucket"],
          Key = fileName
        };

        PutObjectResponse response = await amazonS3.PutObjectAsync(request);
        if (response.HttpStatusCode == System.Net.HttpStatusCode.OK)
          return true;
        else
          return false;
      
    }

    /// <summary>
    /// Get File by Data Num
    /// </summary>
    /// <param name="key"></param>
    /// <returns>Stream</returns>
    public async Task<Stream> GetFile(string key)
    {
      using (var client = new AmazonS3Client(amazonS3.Config.RegionEndpoint))
      {
        logger.LogInformation(Constant.classname + "BucketHelper" + Constant.methodname + "GetFile" + Constant.message + "Get  blocking diagrams in " + amazonS3.Config.RegionEndpoint + "bucket name" + config["s3:diagram-bucket"]);

        var request = new GetObjectRequest
        {
          BucketName = config["s3:diagram-bucket"],
          Key = key
        };

        using (var getObjectResponse = await client.GetObjectAsync(request))
        {
          using (var responseStream = getObjectResponse.ResponseStream)
          {
            var stream = new MemoryStream();
            await responseStream.CopyToAsync(stream);
            stream.Position = 0;
            return stream;
          }
        }
      }
      ///GetObjectResponse response = await amazonS3.GetObjectAsync(config["s3:diagram-bucket"], key);
      ///if (response.HttpStatusCode == System.Net.HttpStatusCode.OK)
      ///  return response.ResponseStream;
      ///else
      ///  return null;
    }

    /// <summary>
    /// Delete file from s3 bucket
    /// </summary>
    /// <param name="dataNum"></param>
    /// <returns>bool</returns>
    public async Task<bool> DeleteFile(string dataNum)
    {
      logger.LogInformation(Constant.classname + "BucketHelper" + Constant.methodname + "DeleteFile" + Constant.message + "delete   blocking diagrams in " + amazonS3.Config.RegionEndpoint);
      var deleteFile = await amazonS3.DeleteObjectAsync(config["s3:diagram-bucket"], dataNum);
      if (deleteFile.HttpStatusCode == System.Net.HttpStatusCode.NoContent)
      {
        return true;
      }
      return false;
    }

  }
}
