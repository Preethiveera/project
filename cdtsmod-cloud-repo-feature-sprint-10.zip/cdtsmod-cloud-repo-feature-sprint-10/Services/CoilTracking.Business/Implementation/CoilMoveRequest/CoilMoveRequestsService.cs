using AutoMapper;
using CoilTracking.Business.Interfaces;
using CoilTracking.Business.Interfaces.CoilMoveRequest;
using CoilTracking.Common.Constant;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TimeZoneConverter;

namespace CoilTracking.Business.Implementation
{
  public class CoilMoveRequestsService : ICoilMoveRequestService
  {
    private readonly ICoilMoveRequestsRepository coilMoveRequestsRepository;
    private readonly IMapper mapper;
    private readonly IApplicationLogger<CoilMoveRequestsService> logger;
    private readonly ICoilStatusRepository coilStatusRepository;
    private readonly ILineRepository lineRepository;
    private readonly ICoilTypeRepository coilTypeRepository;
    private readonly ICoilMoveRequestFactory coilMoveRequestFactory;
    private readonly IWebSocketClientService webSocketClientService;

    public CoilMoveRequestsService(ICoilMoveRequestsRepository coilMoveRequestsRepository,
      IMapper mapper,
      IApplicationLogger<CoilMoveRequestsService> logger,
      ICoilStatusRepository coilStatusRepository,
      ILineRepository lineRepository,
      ICoilTypeRepository coilTypeRepository,
      ICoilMoveRequestFactory coilMoveRequestFactory,
      IWebSocketClientService webSocketClientService)
    {
      this.coilMoveRequestsRepository = coilMoveRequestsRepository;
      this.mapper = mapper;
      this.logger = logger;
      this.coilStatusRepository = coilStatusRepository;
      this.lineRepository = lineRepository;
      this.coilTypeRepository = coilTypeRepository;
      this.coilMoveRequestFactory = coilMoveRequestFactory;
      this.webSocketClientService = webSocketClientService;
    }

    /// <summary>
    /// To Get all the coil move requests
    /// </summary>

    public async Task<IQueryable<CoilMoveRequestDto>> GetCoilMoveRequests()
    {
      var requests = await coilMoveRequestsRepository.GetAllCoilMoveRequest();
      logger.LogInformation(Constant.classname + "CoilMoveRequestsService" + Constant.methodname + "GetCoilMoveRequests" + Constant.message + "Get list of all coil move requests.");
      return mapper.Map<List<CoilMoveRequestDto>>(requests).AsQueryable();
    }

    /// <summary>
    /// To Get all the pending move requests by line
    /// </summary>

    public async Task<IQueryable<CoilMoveRequestDto>> GetPendingRequestsByLine(int lineId, DateTime? startTime = null, DateTime? endTime = null)
    {
      var requests = await coilMoveRequestsRepository.GetPendingRequestByLine(lineId, startTime, endTime);
      logger.LogInformation(Constant.classname + "CoilMoveRequestsService" + Constant.methodname + "GetPendingRequestsByLine" + Constant.message + "Get list of pending coil move requests by lineid.");
      return mapper.Map<List<CoilMoveRequestDto>>(requests).AsQueryable();
    }

    /// <summary>
    /// To Get all the unfulfilled coil move requests.
    /// </summary>

    public async Task<List<CoilMoveRequestDto>> GetUnfulfilledCoilMoveRequests()
    {
      var requests = await coilMoveRequestsRepository.GetUnfulfilledCoilMoveRequests();
      logger.LogInformation(Constant.classname + "CoilMoveRequestsService" + Constant.methodname + "GetUnfulfilledCoilMoveRequests" + Constant.message + "Get list of unfulfilled coil move requests.");
      return mapper.Map<List<CoilMoveRequestDto>>(requests);
    }

    /// <summary>
    /// To cancel a coil move request.
    /// </summary>

    public async Task<bool> CancelCoilMove(int id)
    {
      var moveRequest = await coilMoveRequestsRepository.GetMoveRequestById(id);

      if (moveRequest == null)
      {
        throw new CoilTrackingException { HttpStatusCode = "BadRequest", ErrorMessage = ApplicationMessages.moveRequestNotFound + id };
      }

      moveRequest.IsCancelled = true;

      //Prasanna 20180302 : Added Arun/David's cmts from 2016 mails for context and understanding.
      //•	Enable the cancel button for coil returns
      //• If a coil return is cancelled, it changes the coil status to Completely Used and updates weight to 0
      //•	The coil setter can then do a Coil Move to change the status to partial/ new/partial needs weighed if needed.
      //  Or if they need to move I back to the line, they can do that with Coil Move as well.
      if (moveRequest.RequestType == CoilMoveRequestType.CoilReturn && moveRequest.Coil.CoilStatus.Name == CoilStatusName.LoadedAtLine)
      {

        var coilStatus = await coilStatusRepository.GetCoilStatusByName(CoilStatusName.CompletelyUsed);
        moveRequest.Coil.CoilStatus = coilStatus.FirstOrDefault();
      }

      //CCDTS-15 : Added new option 'CancelCoilMoveRequest' to track coil cancel requests
      await coilMoveRequestsRepository.SaveChanges(AuditActionType.CancelCoilMoveRequest);
      logger.LogInformation(Constant.classname + "CoilMoveRequestsService" + Constant.methodname + "CancelCoilMove" + Constant.message + "Cancel coil move request");

      //Update the SignalR clients with the new notification count
      await UpdateNotificationCount();
      return true;
    }

    /// <summary>
    /// To request as coil movement.
    /// </summary>

    public async Task<CoilMoveRequestDto> RequestCoilMove(int lineId, int coilTypeId, CoilMoveRequestType requestType, int? coilId = null)
    {
      Line line = await lineRepository.GetLineWithPlantDetails(lineId);
      CoilType coilType = coilTypeRepository.GetCoilTypeById(coilTypeId);
      if (coilType == null)
      {
        throw new CoilTrackingException { HttpStatusCode = "BadRequest", ErrorMessage = ApplicationMessages.coilTypeNotFound + coilTypeId };
      }

      AuditActionType actionType = AuditActionType.ModifyEntity;

      Coil coilToMove = null;

      var getObject = coilMoveRequestFactory.Create(requestType);
      var result = await getObject.RequestCoilMove(coilType, requestType, coilId);
      coilToMove = result.CoilsToMove;
      actionType = result.ActionType;

      var timeZone = TZConvert.GetTimeZoneInfo(line.Plant.TimeZone.Name).Id;
      Data.Models.CoilMoveRequest coilMoveRequest = new Data.Models.CoilMoveRequest
      {
        Coil = coilToMove,
        Line = line,
        RequestType = requestType,
        Requested = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.UtcNow, timeZone)
      };

      await coilMoveRequestsRepository.AddCoilMoveRequest(coilMoveRequest);
      await coilMoveRequestsRepository.SaveChanges(actionType);

      var response = mapper.Map<CoilMoveRequestDto>(coilMoveRequest);
      logger.LogInformation(Constant.classname + "CoilMoveRequestsService" + Constant.methodname + "RequestCoilMove" + Constant.message + "Request a coil move request");

      //Update the SignalR clients with the new notification
      await UpdateNotificationCount();
      return response;
    }

    /// <summary>
    /// To fulfill a coil move requests.
    /// </summary>

    public async Task<CoilMoveRequestDto> FulfillCoilMoveRequest(int id, string newLocation, string newWeight)
    {
      var coilMoveRequest = await coilMoveRequestsRepository.GetCoilMoveRequestWithCoilData(id);
      if (coilMoveRequest == null)
      {
        throw new CoilTrackingException { HttpStatusCode = "NotFound" };
      }

      var getObject = coilMoveRequestFactory.Create(coilMoveRequest.RequestType);
      coilMoveRequest = await getObject.FullFillCoilMove(coilMoveRequest, newWeight, newLocation);

      //Finally, Mark the request fulfilled
      coilMoveRequest.Fulfilled = DateTime.Now;
      await coilMoveRequestsRepository.SaveChanges(AuditActionType.FulFillRequest);

      var response = mapper.Map<CoilMoveRequestDto>(coilMoveRequest);
      logger.LogInformation(Constant.classname + "CoilMoveRequestsService" + Constant.methodname + "FulfillCoilMoveRequest" + Constant.message + "Fulfill Coil Move Request");
      if (coilMoveRequest.RequestType == CoilMoveRequestType.CoilRequest)
      {
        //If this was a coil load request, update the signalR clients with the line Id the coil Id is now loaded at
        await webSocketClientService.CoilLoaded(coilMoveRequest.Line.Id, coilMoveRequest.Coil.Id);
      }
      //Update the SignalR clients with the new notification count
      await UpdateNotificationCount();

      //Tell the signalR (andon) clients the coil locations have been updated
      await webSocketClientService.CoilLocationsUpdated();
      return response;
    }

    /// <summary>
    /// To Get coil move request by ids.
    /// </summary>

    public async Task<CoilMoveRequestDto> GetCoilMoveRequestAsync(int id)
    {
      var coilMoveRequest = await coilMoveRequestsRepository.GetMoveRequestById(id);

      var coilMoveRequestData = mapper.Map<CoilMoveRequestDto>(coilMoveRequest);
      logger.LogInformation(Constant.classname + "CoilMoveRequestsService" + Constant.methodname + "GetCoilMoveRequestAsync" + Constant.message + "Get Coil Move request by Id");
      return coilMoveRequestData;
    }

    /// <summary>
    /// To post a coil move requests.
    /// </summary>

    public async Task<CoilMoveRequestDto> PostCoilMoveRequestAsync(CoilMoveRequestDto coilMoveRequest)
    {
      var moveRequest = mapper.Map<Data.Models.CoilMoveRequest>(coilMoveRequest);
      await coilMoveRequestsRepository.AddCoilMoveRequest(moveRequest);
      await coilMoveRequestsRepository.SaveChanges(AuditActionType.CoilMoveRequest);

      logger.LogInformation(Constant.classname + "CoilMoveRequestsService" + Constant.methodname + "PostCoilMoveRequestAsync" + Constant.message + "Create a new Coil Move Request");

      //Update the SignalR clients with the new notification
      await UpdateNotificationCount();
      return mapper.Map<CoilMoveRequestDto>(moveRequest);
    }

    /// <summary>
    /// To delete a coil move requests.
    /// </summary>

    public async Task<CoilMoveRequestDto> DeleteCoilMoveRequest(int id)
    {
      var coilMoveRequest = await coilMoveRequestsRepository.FindCoilMoveRequestAsync(id);
      if (coilMoveRequest == null)
      {
        throw new CoilTrackingException { HttpStatusCode = "NotFound" };
      }

      await coilMoveRequestsRepository.DeleteCoilMoveRequest(coilMoveRequest);
      logger.LogInformation(Constant.classname + "CoilMoveRequestsService" + Constant.methodname + "DeleteCoilMoveRequest" + Constant.message + "Delete a coil move request");

      //Update the SignalR clients with the new notification
      await UpdateNotificationCount();
      return mapper.Map<CoilMoveRequestDto>(coilMoveRequest);
    }

    /// <summary>
    /// To Get loaded coils from coil move requests.
    /// </summary>

    public async Task<List<CoilDto>> GetLoadedCoils(int lineId, int shiftId)
    {
      List<CoilDto> coilDto = new List<CoilDto>();
      List<Coil> coilsLoaded = await coilMoveRequestsRepository.GetCoilsLoadedByCoilStatusName(CoilStatusName.LoadedAtLine);
      List<Data.Models.CoilMoveRequest> returnRequests = await coilMoveRequestsRepository.GetReturnRequests();

      foreach (Coil coilLoaded in coilsLoaded)
      {
        if (returnRequests.Any(r => r.Coil.Id == coilLoaded.Id))
          continue;

        CoilDto dto = new CoilDto()
        {
          Id = coilLoaded.Id,
          CoilStatusId = coilLoaded.CoilStatus.Id,
          OrderNo = coilLoaded.OrderNo,
          CoilTypeId = coilLoaded.CoilType.Id,
          MillId = coilLoaded.Mill.Id,
          SerialNum = coilLoaded.SerialNum,
          OriginalWeight = coilLoaded.OriginalWeight,
          FTZ = coilLoaded.FTZ,
          YNA = coilLoaded.YNA,
          CurrentWeight = coilLoaded.CurrentWeight,
          CheckInDate = coilLoaded.CheckInDate
        };
        coilDto.Add(dto);
      }

      logger.LogInformation(Constant.classname + "CoilMoveRequestsService" + Constant.methodname + "GetLoadedCoils" + Constant.message + "Get list of loaded coils");

      return coilDto;
    }

    private async Task UpdateNotificationCount()
    {
      var count = await coilMoveRequestsRepository.GetUnfulfilledCoilMoveRequestsCount();
      logger.LogInformation(Constant.classname + "CoilMoveRequestsService" + Constant.methodname + "UpdateNotificationCount" + Constant.message + "Update notification count");
      await webSocketClientService.UpdateNotificationCount(count);
    }
  }
}
