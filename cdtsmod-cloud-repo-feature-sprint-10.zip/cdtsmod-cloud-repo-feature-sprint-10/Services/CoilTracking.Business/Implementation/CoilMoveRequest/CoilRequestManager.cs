using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constant;
using CoilTracking.Common.Exception;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class CoilRequestManager : ICoilMoveRequestManager
  {
    private readonly ICoilRepository coilRepository;
    private readonly ICoilMoveRequestsRepository coilMoveRequestsRepository;
    private readonly IRunResultsRepository runResultsRepository;
    private readonly ICoilRunHistoryRepository coilRunHistoryRepository;
    private readonly ICoilStatusRepository coilStatusRepository;

    public CoilRequestManager(ICoilRepository coilRepository,
      ICoilMoveRequestsRepository coilMoveRequestsRepository,
      IRunResultsRepository runResultsRepository,
      ICoilRunHistoryRepository coilRunHistoryRepository,
      ICoilStatusRepository coilStatusRepository)
    {
      this.coilRepository = coilRepository;
      this.coilMoveRequestsRepository = coilMoveRequestsRepository;
      this.runResultsRepository = runResultsRepository;
      this.coilRunHistoryRepository = coilRunHistoryRepository;
      this.coilStatusRepository = coilStatusRepository;

    }

    /// <summary>
    /// Request Coil Move for CoilRequest
    /// </summary>

    public async Task<CoilMoveRequestModel> RequestCoilMove(CoilType coilType, CoilMoveRequestType requestType, int? coilId = null)
    {
      List<int> unfulfilledCoilIds = await coilMoveRequestsRepository.GetUnfulfilledCoilIds();
      var coils = await coilRepository.GetCoilsToMove(coilType.Id, unfulfilledCoilIds); //FIFO assumes even if there is partial it is the one with earliest check-in
      var coilToMove = coils.FirstOrDefault();
      if (coilToMove == null)
      {
        //No coil found, either 0 in stock or the last one is already at a line?
        throw new CoilTrackingException { HttpStatusCode = "BadRequest", ErrorMessage = ApplicationMessages.unableToUseCoil + coilType.Name };
      }
      var actionType = AuditActionType.CoilRequest;

      return new CoilMoveRequestModel
      {
        CoilsToMove = coilToMove,
        ActionType = actionType
      };
    }

    /// <summary>
    /// FulFill Coil Move for CoilRequest
    /// </summary>

    public async Task<Data.Models.CoilMoveRequest> FullFillCoilMove(Data.Models.CoilMoveRequest coilMoveRequest, string newWeight = null, string newLocation = null)
    {
      if (coilMoveRequest.Coil.CoilStatus.Name == CoilStatusName.PartialNeedsWeighed)
      {
        int newWeightInt = -1;
        int.TryParse(newWeight, out newWeightInt);
        if (newWeightInt <= 0)
        {
          throw new CoilTrackingException { HttpStatusCode = "BadRequest", ErrorMessage = ApplicationMessages.invalidWeight };
        }
        int weightUsed = coilMoveRequest.Coil.CurrentWeight - newWeightInt;

        //Get the newest run Result to add a weight for
        var newestRunResultForCoil = await runResultsRepository.GetNewestRunResultForCoil(coilMoveRequest.Coil.Id);

        var newRunHistoryWeightUsed = new CoilRunHistory()
        {
          Coil = coilMoveRequest.Coil,
          WeightUsed = weightUsed
        };

        if (newestRunResultForCoil != null)
        {
          newestRunResultForCoil.WeightUsed = weightUsed;
          newRunHistoryWeightUsed.RunOrderList = newestRunResultForCoil.RunOrderList; //It allows null for run order list, or should we put it in coilMoveRequest.Coil.UnAccountedWeight?
        }

        coilRunHistoryRepository.SaveCoilRunHistories(newRunHistoryWeightUsed);
      }
      if (coilMoveRequest.Coil.CoilFieldLocation != null)
      {
        //Mark the location empty+Null the CoilFieldLocation on the coil (if CoilRequest)
        coilMoveRequest.Coil.CoilFieldLocation.IsEmpty = true;
        coilMoveRequest.Coil.CoilFieldLocation = null;
      }
      coilMoveRequest.Coil.CoilStatus = coilStatusRepository.GetCoilStatusByName(CoilStatusName.LoadedAtLine).Result.FirstOrDefault();

      return coilMoveRequest;
    }
  }
}
