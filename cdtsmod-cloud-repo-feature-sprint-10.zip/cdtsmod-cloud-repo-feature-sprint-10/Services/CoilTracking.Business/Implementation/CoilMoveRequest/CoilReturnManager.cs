using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constant;
using CoilTracking.Common.Exception;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class CoilReturnManager : ICoilMoveRequestManager
  {
    private readonly ICoilRepository coilRepository;
    private readonly ICoilFieldZoneRepository coilFieldZoneRepository;
    private readonly ICoilStatusRepository coilStatusRepository;

    public CoilReturnManager(ICoilRepository coilRepository,
      ICoilFieldZoneRepository coilFieldZoneRepository,
      ICoilStatusRepository coilStatusRepository)
    {
      this.coilRepository = coilRepository;
      this.coilFieldZoneRepository = coilFieldZoneRepository;
      this.coilStatusRepository = coilStatusRepository;
    }

    /// <summary>
    /// Request Coil Move for Coil Return/Reject
    /// </summary>

    public async Task<CoilMoveRequestModel> RequestCoilMove(CoilType coilType, CoilMoveRequestType requestType, int? coilId = null)
    {
      if (!coilId.HasValue)
      {
        throw new CoilTrackingException { HttpStatusCode = "BadRequest", ErrorMessage = ApplicationMessages.CoilIdNotFound };
      }
      var coilToMove = await coilRepository.GetCoilToMoveByCoilId(coilId.Value);

      if (coilToMove == null)
      {
        //No coil found, either 0 in stock or the last one is already at a line?
        throw new CoilTrackingException { HttpStatusCode = "BadRequest", ErrorMessage = "Unable to find a coil to move of type: " + coilType.Name + " with coilId=" + coilId.Value };
      }

      var actionType = (requestType == CoilMoveRequestType.CoilReturn) ? AuditActionType.CoilReturn : AuditActionType.CoilReject;

      return new CoilMoveRequestModel
      {
        CoilsToMove = coilToMove,
        ActionType = actionType
      };
    }

    /// <summary>
    /// FulFill Coil Move for Coil return/reject
    /// </summary>

    public async Task<Data.Models.CoilMoveRequest> FullFillCoilMove(Data.Models.CoilMoveRequest coilMoveRequest, string newWeight = null, string newLocation = null)
    {
      if (string.IsNullOrWhiteSpace(newLocation) || !newLocation.Contains("-"))
      {
        throw new CoilTrackingException { HttpStatusCode = "BadRequest", ErrorMessage = ApplicationMessages.validLocationNotFound };
      }
      //Mark the location not empty and set the coilfield location (if CoilReturn)
      string[] zoneLocation = newLocation.Split('-');
      string zone = zoneLocation[0];
      string location = zoneLocation[1];

      CoilFieldZone dbZone = await coilFieldZoneRepository.GetCoilFieldZoneByNameWithLocation(zone);

      if (dbZone == null)
      {
        throw new CoilTrackingException { HttpStatusCode = "BadRequest", ErrorMessage = ApplicationMessages.specifyValidZoneName };
      }
      CoilFieldLocation dbLocation = dbZone.Locations.FirstOrDefault(l => l.Name == location);
      if (dbLocation == null)
      {
        throw new CoilTrackingException { HttpStatusCode = "BadRequest", ErrorMessage = ApplicationMessages.specifyValidLocation };
      }
      else if (!dbLocation.IsEmpty)
      {
        throw new CoilTrackingException { HttpStatusCode = "BadRequest", ErrorMessage = ApplicationMessages.locationNotEmpty };
      }

      dbLocation.IsEmpty = false;
      coilMoveRequest.Coil.CoilFieldLocation = dbLocation;
      coilMoveRequest.Coil.ReturnedToField = DateTime.Now;
      if (coilMoveRequest.RequestType == CoilMoveRequestType.CoilReturn)
      {
        //TODO: Maybe add logic here if returned without being used instead of partial, reset back to new?
        //because coil loaded at line will have a coil run history created, 
        //we may not set this status again as it will require the coilsetter to enter weight again 
        //instead set the status to partial

        coilMoveRequest.Coil.CoilStatus = coilStatusRepository.GetCoilStatusByName(CoilStatusName.Partial).Result.FirstOrDefault();
      }
      else if (coilMoveRequest.RequestType == CoilMoveRequestType.CoilReject)
      {
        coilMoveRequest.Coil.CoilStatus = coilStatusRepository.GetCoilStatusByName(CoilStatusName.RejectedOnHand).Result.FirstOrDefault();
      }

      return coilMoveRequest;
    }
  }
}
