using CoilTracking.Business.Interfaces;
using CoilTracking.Business.Interfaces.CoilMoveRequest;
using CoilTracking.Data.Models;
using System.Collections.Generic;
using System.Linq;

namespace CoilTracking.Business.Implementation.CoilMoveRequest
{
  public class CoilMoveRequestFactory : ICoilMoveRequestFactory
  {
    private readonly IEnumerable<ICoilMoveRequestManager> services;

    public CoilMoveRequestFactory(IEnumerable<ICoilMoveRequestManager> services)
    {
      this.services = services;
    }

    /// <summary>
    /// To create object in order to create required CoilMoveRequestManager
    /// </summary>
    /// <returns>ICoilMoveRequestManager obj</returns>
    public ICoilMoveRequestManager Create(CoilMoveRequestType requestType)
    {
      switch (requestType)
      {
        case CoilMoveRequestType.CoilRequest:
          return services.FirstOrDefault(x => x.GetType() == typeof(CoilRequestManager));

        default:
          return services.FirstOrDefault(x => x.GetType() == typeof(CoilReturnManager));

      }


    }
  }
}
