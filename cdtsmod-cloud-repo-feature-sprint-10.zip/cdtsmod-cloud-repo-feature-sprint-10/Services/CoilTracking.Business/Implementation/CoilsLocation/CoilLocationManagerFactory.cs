
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using System.Collections.Generic;
using System.Linq;

namespace CoilTracking.Business.Implementation
{
  public class CoilLocationManagerFactory : ICoilLocationManagerFactory
  {

    private readonly IEnumerable<ICoilLocationManager> services;

    public CoilLocationManagerFactory(IEnumerable<ICoilLocationManager> services)
    {
      this.services = services;
    }

    /// <summary>
    /// Create
    /// </summary>
    /// <param name="location"></param>
    /// <returns></returns>
    public ICoilLocationManager Create(string location)
    {
      switch (location)
      {
        case (Constant.supplier):
          return services.FirstOrDefault(x => x.GetType() == typeof(CoilLocationManagerSupplier));

        case Constant.other:
          return services.FirstOrDefault(x => x.GetType() == typeof(CoilLocationManagerOther));

        default:
          return services.FirstOrDefault(x => x.GetType() == typeof(CoilLocationManager));

      }


    }
  }
}
