using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constant;
using CoilTracking.Data.Models;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class CoilLocationManagerOther : ICoilLocationManager
  {
    public CoilLocationManagerOther()
    {
    }
    /// <summary>
    /// CoilLocation
    /// </summary>
    /// <param name="newStatus"></param>
    /// <param name="coil"></param>
    /// <param name="lineId"></param>
    /// <param name="newLocation"></param>
    /// <returns></returns>
    public async Task<Coil> AssignCoilLocation(CoilStatus newStatus, Coil coil, int? lineId, string newLocation)
    {
      //location is other, if new status is not usable, mark old location empty
      //We marked the coil as completely used, and removed it's location. We may not have a RunResult for this coil since it was moved manually (system offline/inventory recovery/etc)
      if (!newStatus.IsUsable || newStatus.Name == CoilStatusName.CompletelyUsed)
      {
        SetCoilFieldLocation(coil);
      }
      return coil;

    }
    /// <summary>
    /// Set CoilFieldLocation
    /// </summary>
    /// <param name="coil"></param>
    public void SetCoilFieldLocation(Coil coil)
    {
      if (coil.CoilFieldLocation != null)
      {
        //Mark old location as empty
        coil.CoilFieldLocation.IsEmpty = true;
        coil.CoilFieldLocation = null;
      }
    }
  }
}
