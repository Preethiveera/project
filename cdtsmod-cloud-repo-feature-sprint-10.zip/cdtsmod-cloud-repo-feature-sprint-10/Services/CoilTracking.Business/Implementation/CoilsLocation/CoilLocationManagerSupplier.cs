using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Data.Models;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class CoilLocationManagerSupplier : ICoilLocationManager
  {
    public CoilLocationManagerSupplier()
    {

    }
    /// <summary>
    /// CoilLocation
    /// </summary>
    /// <param name="newStatus"></param>
    /// <param name="coil"></param>
    /// <param name="lineId"></param>
    /// <param name="newLocation"></param>
    /// <returns></returns>
    public async Task<Coil> AssignCoilLocation(CoilStatus newStatus, Coil coil, int? lineId, string newLocation)
    {
      //location is back to supplier, status must be returned or rejected returned
      if (newStatus.IsUsable)
      {
        throw new CoilTrackingException { HttpStatusCode = Constant.badRequest, ErrorMessage = ApplicationMessages.newlocation + newStatus.Name + ApplicationMessages.returntosupplier };
      }
      SetCoilFieldLocation(coil);
      return coil;

    }
    /// <summary>
    /// Set CoilFieldLocation
    /// </summary>
    /// <param name="coil"></param>
    public void SetCoilFieldLocation(Coil coil)
    {
      if (coil.CoilFieldLocation != null)
      {
        //Mark old location as empty
        coil.CoilFieldLocation.IsEmpty = true;
        coil.CoilFieldLocation = null;
      }
    }
  }
}
