using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class CoilLocationManager : ICoilLocationManager
  {
    private readonly ICoilFieldLocationRepository coilFieldLocationRepo;
    public CoilLocationManager(ICoilFieldLocationRepository coilFieldLocationRepo)
    {
      this.coilFieldLocationRepo = coilFieldLocationRepo;
    }

    /// <summary>
    /// CoilLocation
    /// </summary>
    /// <param name="newStatus"></param>
    /// <param name="coil"></param>
    /// <param name="lineId"></param>
    /// <param name="newLocation"></param>
    /// <returns></returns>
    public async Task<Coil> AssignCoilLocation(CoilStatus newStatus, Coil coil, int? lineId, string newLocation)
    {
      //Split out the coil location 
      CoilFieldLocation location = await ValidateLocation(newLocation, coil);
      //update coil location, update new location to not empty
      coil.CoilFieldLocation = location;
      location.IsEmpty = false;
      return coil;
    }
    /// <summary>
    /// Get CoilFieldLocationByName
    /// </summary>
    /// <param name="newLocation"></param>
    ///  <param name="coil"></param>
    /// <returns></returns>
    public async Task<CoilFieldLocation> ValidateLocation(string location, Coil coil)
    {
      if (string.IsNullOrWhiteSpace(location) || !location.Contains('-') || location.Length < 4)
      {
        throw new CoilTrackingException { HttpStatusCode = Constant.badRequest, ErrorMessage = ApplicationMessages.newlocation + location + ApplicationMessages.coillocationnotcorrectformat };
      }
      //Split out the coil location 
      string[] locationSplit = location.Split('-');
      string zone = locationSplit[0];
      string locationName = locationSplit[1];
      CoilFieldLocation locations = await coilFieldLocationRepo.GetCoilFieldLocationByName(zone, locationName);
      if (locations == null)
      { //A valid existing CoilFieldLocation is required
        throw new CoilTrackingException { HttpStatusCode = Constant.badRequest, ErrorMessage = ApplicationMessages.couldnotfindacoillocation + location };
      }
      if (!locations.IsEmpty && !(coil.CoilFieldLocation != null && coil.CoilFieldLocation.Id == locations.Id)) //Must be empty, unless this coil is already in the same spot
      {
        //An empty location is required. They moved a coil without telling the system?  Or should we set the coil at the new location to "Missing" status and put this coil there anyway?
        throw new CoilTrackingException { HttpStatusCode = Constant.badRequest, ErrorMessage = ApplicationMessages.location + location + ApplicationMessages.isnotempty };
      }
      if (coil.CoilFieldLocation != null)
      {
        //Mark old location as empty
        coil.CoilFieldLocation.IsEmpty = true;
      }
      return locations;
    }
  }
}
