using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class ImportPartData : IImportPartData
  {
    public readonly IModelRepository modelRepo;
    public readonly IPartModelsRepository partModelsRepo;
    public readonly IPartRepository partRepo;
    public readonly IPartsService partsService;
    public ImportPartData(IModelRepository modelRepo, IPartModelsRepository partModelsRepo, IPartRepository partRepo, IPartsService partsService)
    {
      this.modelRepo = modelRepo;
      this.partModelsRepo = partModelsRepo;
      this.partRepo = partRepo;
      this.partsService = partsService;
    }
    /// <summary>
    /// enum
    /// </summary>
    private enum Columns
    {
      PartNo = 1,
      BlankingPartNo = 2,
      PartName = 3,
      Model = 4,
      Disabled = 5,
      SCount = 6,
    }
    /// <summary>
    /// Import
    /// </summary>
    /// <param name="ms"></param>
    /// <param name="userName"></param>
    /// <returns></returns>
    public async Task<List<DataImportMessage>> Import(MemoryStream ms, string userName)
    {
      List<DataImportMessage> messages = new List<DataImportMessage>();

      using (var package = DataImportHelper.GetPackageFromMemoryStream(ms, messages))
      {
        if (package != null && package.Workbook != null && package.Workbook.Worksheets.Count > 0)
        {
          //Data expected only in first worksheet or a worksheet named Data
          ExcelWorksheet worksheet = package.Workbook.Worksheets.Where(ws => string.Equals(ws.Name, Constant.PartNo, StringComparison.InvariantCultureIgnoreCase)).DefaultIfEmpty(package.Workbook.Worksheets.First()).FirstOrDefault();
          List<DataImportMessage> newMessages = await ImportData(worksheet, userName);
          messages.AddRange(newMessages);
        }
        else
        {
          messages.Add(new DataImportMessage(-1, "No valid worksheet found, make sure this is a valid XLSX (Excel 2007+) file", DataImportMessage.MsgType.Error));
        }
      }

      return messages;
    }
    /// <summary>
    /// Import Data
    /// </summary>
    /// <param name="worksheet"></param>
    /// <param name="userName"></param>
    /// <returns></returns>
    public async Task<List<DataImportMessage>> ImportData(ExcelWorksheet worksheet, string userName)
    {
      List<DataImportMessage> errors = new List<DataImportMessage>();
      int maxRows = worksheet.Dimension.End.Row;

      //Columns where each blank property is expected are fixed
      for (int row = 2; row <= maxRows; row++)
      {
        string partNumber = "";
        string blankingPartNumber = "";
        string partName = "";
        string modelsListString = "";
        bool disabled = false;
        int StrokeCount = 1;

        errors.AddRange(DataImportHelper.GetString(worksheet, row, (int)Columns.PartNo, Columns.PartNo.ToString(), out partNumber));
        errors.AddRange(DataImportHelper.GetString(worksheet, row, (int)Columns.BlankingPartNo, Columns.BlankingPartNo.ToString(), out blankingPartNumber));
        errors.AddRange(DataImportHelper.GetString(worksheet, row, (int)Columns.PartName, Columns.PartName.ToString(), out partName));
        errors.AddRange(DataImportHelper.GetString(worksheet, row, (int)Columns.Model, Columns.Model.ToString(), out modelsListString));
        errors.AddRange(DataImportHelper.GetBool(worksheet, row, (int)Columns.Disabled, Columns.Disabled.ToString(), out disabled));
        errors.AddRange(DataImportHelper.GetInt(worksheet, row, (int)Columns.SCount, Columns.SCount.ToString(), out StrokeCount)); //hari added code on 08/31/2018

        string[] modelsList = modelsListString.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries); //If the model list has a leading/trailing comma or repeating commas this would give issues with blank model numbers
        var modelList = modelsList.ToList();
        //handle if blanking part# is different from stamping part#
        if (!string.IsNullOrWhiteSpace(blankingPartNumber))
        {
          partNumber = blankingPartNumber;
          partName = await GetRHLHPartName(partName);
          row += 1;  //skip the next row since the next row is going to be the duplicate of the current row (RH row and LH row)
        }
        List<Model> models = new List<Model>();
        var modelResponse = await ProcessModels(modelList, errors, models, row);
        models = modelResponse.Models;
        errors = modelResponse.Errors;

        Part partEntry =  partRepo.GetPartByName(partNumber);
        var updatedErrors = await ProcessPartEntry(partEntry, partNumber, errors, partName, disabled, StrokeCount, models, row);
        errors = updatedErrors;
      }
      return errors;
    }

    /// <summary>
    /// Gets the RightHand and LeftHand part name for this part
    /// </summary>
    /// <param name="partName">The full part name</param>
    /// <returns>Part name with R/L or RH/LH appended to the end</returns>
    public async Task<string>  GetRHLHPartName(string partName)
    {
      string partSuffix = "";
      if (partName.EndsWith(")"))
      {
        int suffixBegin = partName.LastIndexOf("(");
        partSuffix = " " + partName.Substring(suffixBegin).Trim(); //add the beginning space here but trim any other existing spacing
        partName = partName.Substring(0, suffixBegin).Trim();
      }

      if (partName.EndsWith(" R"))
      {
        partName = partName.Substring(0, partName.LastIndexOf(" R")) + " R/L";
      }
      else if (partName.EndsWith(" L"))
      {
        partName = partName.Substring(0, partName.LastIndexOf(" L")) + " R/L";
      }
      else if (partName.EndsWith(".R"))
      {
        partName = partName.Substring(0, partName.LastIndexOf(".R")) + " R/L";
      }
      else if (partName.EndsWith(".L"))
      {
        partName = partName.Substring(0, partName.LastIndexOf(".L")) + " R/L";
      }
      else if (partName.EndsWith(" RH"))
      {
        partName = partName.Substring(0, partName.LastIndexOf(" RH")) + " RH/LH";
      }
      else if (partName.EndsWith(" LH"))
      {
        partName = partName.Substring(0, partName.LastIndexOf(" LH")) + " RH/LH";
      }
      else if (partName.EndsWith("-RH"))
      {
        partName = partName.Substring(0, partName.LastIndexOf("-RH")) + "-RH/LH";
      }
      else if (partName.EndsWith("-LH"))
      {
        partName = partName.Substring(0, partName.LastIndexOf("-LH")) + " RH/LH";
      }
      else if (partName.EndsWith(",RH"))
      {
        partName = partName.Substring(0, partName.LastIndexOf(",RH")) + " RH/LH";
      }
      else if (partName.EndsWith(",LH"))
      {
        partName = partName.Substring(0, partName.LastIndexOf(",LH")) + " RH/LH";
      }
      else if (partName.EndsWith(".RH"))
      {
        partName = partName.Substring(0, partName.LastIndexOf(".RH")) + " RH/LH";
      }
      else if (partName.EndsWith(".LH"))
      {
        partName = partName.Substring(0, partName.LastIndexOf(".LH")) + " RH/LH";
      }

      return partName + partSuffix;
    }
    /// <summary>
    /// Process Models
    /// </summary>
    /// <param name="modelsList"></param>
    /// <param name="errors"></param>
    /// <param name="models"></param>
    /// <param name="row"></param>
    /// <returns></returns>
    private async Task<ModelResponse>   ProcessModels(List<string> modelsList, List<DataImportMessage> errors, List<Model> models, int row)
    {
      var modelInfo = modelRepo.GetAllModelByModelNo(modelsList);
      foreach (string modelNumber in modelsList)
      {
        if (string.IsNullOrWhiteSpace(modelNumber))
        {
          continue; //Skip models that are null/empty/spaces
        }
        string modelNumberTrimmed = modelNumber.Trim();
        var modelNumbers = modelInfo.Where(x => x.ModelNumber == modelNumberTrimmed);
        Model model = modelNumbers.FirstOrDefault();
        if (model == null)
        {
          model = new Model
          {
            ModelNumber = modelNumberTrimmed
          };
          try
          {//save changes 
          await  modelRepo.AddModel(model);
            errors.Add(new DataImportMessage(row, "New model (" + modelNumberTrimmed + ") added.", DataImportMessage.MsgType.Notification));
            models.Add(model); //only add the model to the list if it saved successfully
          }
          catch (Exception)
          {
            errors.Add(new DataImportMessage(row, "Error while creating new model (" + modelNumberTrimmed + ").", DataImportMessage.MsgType.Error));
            modelRepo.RemoveModel(model);
          }
        }
        else
        {
          models.Add(model); //Add existing models to the list
        }
      
      }
     

      return new ModelResponse
      {
        Errors = errors,
        Models = models
      };
    }
    /// <summary>
    /// Process Part Entry
    /// </summary>
    /// <param name="partEntry"></param>
    /// <param name="partNumber"></param>
    /// <param name="errors"></param>
    /// <param name="partName"></param>
    /// <param name="disabled"></param>
    /// <param name="StrokeCount"></param>
    /// <param name="models"></param>
    /// <param name="row"></param>
    /// <returns></returns>
    private async Task<List<DataImportMessage>>  ProcessPartEntry(Part partEntry, string partNumber, List<DataImportMessage> errors, string partName, bool disabled, int StrokeCount, List<Model> models, int row)
    {
      if (partEntry == null)
      {
        partEntry = new Part
        {
          PartNumber = partNumber,
          PartName = partName,
          Disabled = disabled,
          StrokeCount = StrokeCount
        };

        try
        {
       var partEnt =   await partRepo.InsertPart(partEntry);   
           await partsService.ChangeModelNopart(models, partEnt);
            errors.Add(new DataImportMessage(row, "New Part " + partNumber + " entry created", DataImportMessage.MsgType.Notification));
        }
        catch (Exception )
        {
          
          errors.Add(new DataImportMessage(row, "Unidentified database error occured while creating new Part (" + partNumber + ") entry", DataImportMessage.MsgType.Error));     
          partRepo.RemovePart(partEntry);
        }
      }
      else
      {
       await partsService.ChangeModels(models, partEntry.Id);
        partEntry.Disabled = disabled;
        partEntry.StrokeCount = StrokeCount;
        try
        {
         await partRepo.PartSavechanges();
        }
        catch (Exception)
        {
          if (partEntry.PartNumber.Count() == 0)
          {
            errors.Add(new DataImportMessage(row, "Unidentified database error occured updating Part (" + partNumber + ") entry", DataImportMessage.MsgType.Error));
          }
          partRepo.UnchangedPart(partEntry);
        }
      }

      return errors;
    }
  }
  /// <summary>
  /// ModelResponse
  /// </summary>
  public class ModelResponse
  {
    public List<DataImportMessage> Errors { get; set; }

    public List<Model> Models { get; set; }
  }
}
