using CoilTracking.Business.Interfaces;
using CoilTracking.Common;
using CoilTracking.Common.Constants;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.DataAccess.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CoilTracking.Business.Implementation
{
 public class RunResultFactory : IRunResultFactory
  {
    private readonly IEnumerable<IRunResultftzManager> services;
    private readonly IUserHelper usersHelper;
    private readonly IPlantsRepository plantsRepo;
    public RunResultFactory(IEnumerable<IRunResultftzManager> services ,IUserHelper usersHelper, IPlantsRepository plantsRepo)
    {
      this.services = services;
      this.usersHelper = usersHelper;
      this.plantsRepo = plantsRepo;
    }

    /// <summary>
    /// To create object in order to create required NAMC's RunResult Service
    /// </summary>
    /// <returns>ICoilsService obj</returns>
    public IRunResultftzManager Create()
    {
      var NAMC = usersHelper.GetNAMCCode();
      var plant = plantsRepo.GetPlantName(NAMC);
      switch (plant)
      {
        case Constant.tmmiNAMC:
          return services.FirstOrDefault(x => x.GetType() == typeof(RunResultftzTMMIManager));
        default:
          return services.FirstOrDefault(x => x.GetType() == typeof(RunResultftzManager));

      }


    }
  }
}
