using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
 public class RunResultftzManager : IRunResultftzManager
  {
    private readonly ICoilRepository coilRepo;
    private readonly IApplicationLogger<RunResultService> runResultsServiceLogger;
    public RunResultftzManager(ICoilRepository coilRepo, IApplicationLogger<RunResultService> runResultsServiceLogger)
    {
      this.coilRepo = coilRepo;
      this.runResultsServiceLogger = runResultsServiceLogger;
    }
    /// <summary>
    /// Get RunResult Coil FTZ By Prefix
    /// </summary>
    /// <param name="ftz"></param>
    /// <returns></returns>
    public async Task<List<Coil>> GetRunResultCoilFTZByPrefix(string ftz)
    {
      var coil = await coilRepo.GetRunResultCoilsByFtz(ftz);
      runResultsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "GetCoilByFTZ" + Constant.parameters + ftz);
      return coil;
    }
  }
}
