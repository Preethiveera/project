using CoilTracking.Common.Logging;
using CoilTracking.DataAccess.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using CoilTracking.Data.Models;
using CoilTracking.Common.Constants;
using CoilTracking.Business.Interfaces;

namespace CoilTracking.Business.Implementation
{
 public class RunResultftzTMMIManager : IRunResultftzManager
  {

    private readonly ICoilRepository coilsRepo;
    private readonly IApplicationLogger<RunResultService> runResultsServiceLogger;
    public RunResultftzTMMIManager(ICoilRepository coilsRepo, IApplicationLogger<RunResultService> runResultsServiceLogger)
    {
      this.coilsRepo = coilsRepo;
      this.runResultsServiceLogger = runResultsServiceLogger;
    }
    /// <summary>
    /// Get RunResult Coil FTZ By Prefix
    /// </summary>
    /// <param name="ftz"></param>
    /// <returns></returns>
    public async Task<List<Coil>> GetRunResultCoilFTZByPrefix(string ftz)
    {
      //Added for TMMI
      string sPrefixFtz = 'S' + ftz;
      string tPrefixFtz = 'T' + ftz;
      var coil = await coilsRepo.GetRunResultCoilsByPrefixFtz(sPrefixFtz, tPrefixFtz);
      runResultsServiceLogger.LogInformation(Constant.classname + "RunResultftzTMMIManager" + Constant.methodname + "GetRunResultCoilFTZByPrefix" + Constant.parameters + sPrefixFtz + tPrefixFtz);
      return coil;
    }
  }
}
