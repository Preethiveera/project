using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.IO;
using System.Reflection;

namespace CoilTracking.Business.Implementation.Excel
{
  public static class ExcelExport
  {
    public static void GenerateExcel(DataTable dataTable, string path, string sheetName)
    {
      using (ExcelPackage objExcelPackage = new ExcelPackage())
      {
        DataSet dataSet = new DataSet();
        dataSet.Tables.Add(dataTable);

        foreach (DataTable table in dataSet.Tables)
        {
          //Create the worksheet    
          ExcelWorksheet objWorksheet = objExcelPackage.Workbook.Worksheets.Add(table.TableName);
          objWorksheet.Name = sheetName;
          //Load the datatable into the sheet, starting from cell A1. Print the column names on row 1    
          objWorksheet.Cells["A1"].LoadFromDataTable(table, true);
          objWorksheet.Cells.AutoFitColumns();
          using (ExcelRange objRange = objWorksheet.Cells["A1:XFD1"])
          {
            objRange.Style.Font.Bold = true;
            objRange.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
            objRange.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
          }
        }
        //Write it back to the client    
        if (File.Exists(path))
          File.Delete(path);

        //Create excel file on physical disk    
        FileStream objFileStrm = File.Create(path);
        objFileStrm.Close();

        //Write content to excel file    
        File.WriteAllBytes(path, objExcelPackage.GetAsByteArray());

      }
    }

    // T : Generic Class
    public static DataTable ConvertToDataTable<T>(List<T> models)
    {
      DataTable dataTable = new DataTable(typeof(T).Name);

      //Get all the properties
      PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);

      // Loop through all the properties            
      // Adding Column to our datatable
      foreach (PropertyInfo prop in Props)
      {
        var dd = prop.GetCustomAttribute(typeof(DisplayAttribute)) as DisplayAttribute;
        string name;
        if (dd != null)
        {
          name = dd.Name;
        }
        else
        {
          name = prop.Name;
        }
        //Setting column names as Property names  
        dataTable.Columns.Add(name);
      }
      // Adding Row
      foreach (T item in models)
      {
        var values = new object[Props.Length];
        for (int i = 0; i < Props.Length; i++)
        {
          //inserting property values to datatable rows  
          values[i] = Props[i].GetValue(item, null);
        }
        // Finally add value to datatable  
        dataTable.Rows.Add(values);
      }
      return dataTable;
    }
  }
}
