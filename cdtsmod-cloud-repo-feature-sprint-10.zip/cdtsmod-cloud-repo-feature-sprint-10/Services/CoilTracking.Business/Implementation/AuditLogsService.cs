using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class AuditLogsService : IAuditLogsService
  {

    private readonly IAuditLogsRepository auditLogsRepo;
    private readonly IApplicationLogger<AuditLogsService> auditlogsServiceLogger;

    public AuditLogsService(IAuditLogsRepository auditLogsRepo, IApplicationLogger<AuditLogsService> auditlogsServiceLogger)
    {
      this.auditLogsRepo = auditLogsRepo;
      this.auditlogsServiceLogger = auditlogsServiceLogger;
    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="Id"></param>
    /// <returns></returns>
    public AuditLog IsAuditLogExists(int Id)
    {
      auditlogsServiceLogger.LogInformation(Constant.classname + "AuditLogService" + Constant.methodname + "IsAuditLogExists" + Constant.message + "Check if Audit logs exist");

      var audit = new AuditLogsDto();
      var Ids = auditLogsRepo.AuditLogExist(Id);
      return Ids;
    }

    /// <summary>
    /// Get the records of events and changes
    /// </summary>
    /// <returns></returns>
    public IQueryable<AuditLogsDto> GetAuditLogs()
    {
      var logsList = auditLogsRepo.GetAuditLogs();
      List<AuditLogsDto> auditLogsDto = new List<AuditLogsDto>();
      AuditLogsDto logsDto;

      foreach (var logs in logsList)
      {

        logsDto = new AuditLogsDto();
        auditLogsDto.Add(logsDto);
        logsDto.Id = logs.Id;
        logsDto.Log = logs.Log;
        logsDto.UserName = logs.UserName;
        logsDto.ActionTime = logs.ActionTime;

      }
      return auditLogsDto.AsQueryable();
    }
    /// <summary>
    /// Get search values for Audit logs
    /// </summary>
    /// <param name="startTime"></param>
    /// <param name="endTime"></param>
    /// <param name="username"></param>
    /// <param name="actionType"></param>
    /// <param name="className"></param>
    /// <returns>a record of events and changes</returns>
    public List<AuditLog> Search(DateTime? startTime = null, DateTime? endTime = null, string username = null, int? actionType = null, string className = null)
    {
      var auditLogsList = auditLogsRepo.Search(startTime, endTime, username, actionType, className);
      auditlogsServiceLogger.LogInformation(Constant.classname + "AuditLogService" + Constant.methodname + "Search" + Constant.message + "Get list of Audit logs");

      return auditLogsList;
    }
    /// <summary>
    /// Get User names
    /// </summary>
    /// <returns></returns>
    public List<string> GetUserAuditLogs()
    {
      var username =  auditLogsRepo.GetUserNameAudits();
      return username;
    }
  }
}
