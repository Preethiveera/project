using AutoMapper;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class PatternService : IPatternService
  {
    private readonly IPatternsRepository patternsRepository;
    private readonly IPatternItemRepository patternItemRepository;
    private readonly ILineRepository lineRepository;
    private readonly IBlankInfoesRepository blankInfosRepository;
    private readonly IApplicationLogger<PatternService> patternServiceLogger;

    private readonly IMapper mapper;

    public PatternService(IPatternsRepository patternsRepository, IBlankInfoesRepository blankInfosRepository
      , IPatternItemRepository patternItemRepository, ILineRepository lineRepository, IApplicationLogger<PatternService> patternServiceLogger, IMapper mapper)
    {
      this.mapper = mapper;
      this.patternsRepository = patternsRepository;
      this.patternItemRepository = patternItemRepository;
      this.lineRepository = lineRepository;
      this.blankInfosRepository = blankInfosRepository;
      this.patternServiceLogger = patternServiceLogger;
    }

    /// <summary>
    /// Get patterns for export
    /// </summary>
    /// <returns>List of PatternForExportDto</returns>
    public async Task<List<PatternForExportDto>> GetPatternsForExport()
    {
      int month = DateTime.Today.Month;
      int year = DateTime.Today.Year;
      int monthPre = month > 1 ? month - 1 : 12;
      int yearPre = month > 1 ? year : year - 1;

      var pattern = await patternsRepository.GetPatternByMonthAndYear(monthPre, yearPre);

      var exportList = pattern.Where(p => p.CreateDate.Month == monthPre && p.CreateDate.Year == yearPre)
          .GroupBy(p => p.Line).OrderBy(g => g.Key.LineName)
          .Select(g => new PatternForExportDto
          {
            LineName = g.Key.LineName,
            Patterns = g.OrderBy(p => p.Name).Select(p => new PatternExportDto()
            {
              PatternLetter = p.Name,
              Items = mapper.Map<List<PatternItemDto>>(p.PatternItems)
            }).ToList(),
            PatternLetters = g.OrderBy(p => p.Name).Select(p => p.Name).ToList()
          }).ToList();

      patternServiceLogger.LogInformation(Constant.classname + "PatternService" + Constant.methodname + "GetPatternsForExport"
        + Constant.message + "To get the pattern for export.");

      return exportList;
    }

    /// <summary>
    /// Get patterns
    /// </summary>
    /// <returns>List of pattern dto</returns>
    public async Task<List<PatternDto>> GetPatterns()
    {
      patternServiceLogger.LogInformation(Constant.classname + "PatternService" + Constant.methodname + "GetPatterns"
       + Constant.message + "To get the patterns.");

      return mapper.Map<List<PatternDto>>(await patternsRepository.GetPatterns());
    }

    /// <summary>
    /// Get pattern by id.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>PatternDto</returns>
    public async Task<PatternDto> GetPattern(int id)
    {
      var pattern = await patternsRepository.GetPatternById(id);

      patternServiceLogger.LogInformation(Constant.classname + "PatternService" + Constant.methodname + "GetPattern"
        + Constant.message + "To get the pattern by id.");

      return mapper.Map<PatternDto>(pattern);
    }

    /// <summary>
    /// Get pattern by lineId ,patternLetter, year and month
    /// </summary>
    /// <param name="lineId"></param>
    /// <param name="patternLetter"></param>
    /// <param name="year"></param>
    /// <param name="month"></param>
    /// <returns>PatternDto</returns>
    public async Task<PatternDto> GetPattern(int lineId, string patternLetter, int year, int month)
    {
      var pattern = await patternsRepository.GetPatternByLineId_PatternLetter_Year_Month(lineId, patternLetter, year, month);

      if (pattern == null)
      {
        throw new CoilTrackingException
        {
          ErrorMessage = ApplicationMessages.patternNotFound,
          HttpStatusCode = "NotFound"
        };
      }

      var partNumbers = pattern.PatternItems.Select(x => x.PartNumber).ToList();
      var blankInfo = await blankInfosRepository.GetBlankInfoByLineIdAndPartNumber(lineId, partNumbers);
      pattern.PatternItems.ForEach(item =>
     {
       if (string.IsNullOrEmpty(item.DataNumber))
       {
         item.DataNumber = blankInfo.FirstOrDefault(x => x.Part.PartNumber == item.PartNumber)?.DataNumber.ToString();
         if (string.IsNullOrEmpty(item.DataNumber))
           item.DataNumber = "-";
       }
     });


      var patternDto = mapper.Map<PatternDto>(pattern);

      patternServiceLogger.LogInformation(Constant.classname + "PatternService" + Constant.methodname + "GetPattern"
        + Constant.message + "To get the pattern by lineId ,patternLetter, year and month.");

      return patternDto;
    }


    /// <summary>
    /// Put pattern
    /// </summary>
    /// <param name="id"></param>
    /// <param name="patternDto"></param>
    /// <returns>bool</returns>
    public async Task<bool> PutPattern(int id, PatternDto patternDto)
    {
      var pattern = await patternsRepository.GetPatternById(id);

      if (pattern?.PatternItems.Count > 0)
      {
        var patternItem = pattern?.PatternItems?.First();

        if (patternItem != null)
          patternItemRepository.RemovePatternItem(patternItem);
        pattern.PatternItems.Clear();
      }


      Pattern originalPattern = pattern;

      if (originalPattern == null)
      {
        throw new CoilTrackingException
        {
          ErrorMessage = ApplicationMessages.patternCalendarNotFound,
          HttpStatusCode = "NotFound"
        };
      }

      originalPattern.Name = patternDto.Name;
      patternDto.PatternItems.ForEach(p => p.DataNumber = p.DataNumber == "-" ? null : p.DataNumber);
      originalPattern.PatternItems = mapper.Map<List<PatternItem>>(patternDto.PatternItems);
      originalPattern.CreateDate = patternDto.CreateDate;

      patternsRepository.UpdatePattern(originalPattern);
      await patternsRepository.SaveChangesAsync(AuditActionType.ModifyPattern);

      patternServiceLogger.LogInformation(Constant.classname + "PatternService" + Constant.methodname + "GetPattern"
        + Constant.message + "To get the pattern by lineId ,patternLetter, year and month.");

      return true;
    }

    /// <summary>
    /// Post pattern
    /// </summary>
    /// <param name="patternDto"></param>
    /// <returns>PatternDto</returns>
    public async Task<PatternDto> PostPattern(PatternDto patternDto)
    {

      Pattern patternTemp = new Pattern();
      Line line = await lineRepository.GetLineByLineIDAsync(patternDto.Line.Id);
      patternTemp.Line = line;
      patternTemp.Line.Plant = mapper.Map<Plant>(patternDto.Line.Plant);
      patternTemp.Line.Plant.TimeZone = mapper.Map<PlantTimeZone>(patternDto.Line.Plant.TimeZone);
      patternTemp.Line.OPCServer = mapper.Map<OPCConfig>(patternDto.Line.OPCServer);
      patternTemp.Name = patternDto.Name;
      patternDto.PatternItems.ForEach(p => p.DataNumber = p.DataNumber == "-" ? null : p.DataNumber);
      patternTemp.PatternItems = mapper.Map<List<PatternItem>>(patternDto.PatternItems);
      patternTemp.CreateDate = patternDto.CreateDate;
      patternTemp.Plant = new Plant { };
      var pattern = await patternsRepository.AddPattern(patternTemp);

      patternServiceLogger.LogInformation(Constant.classname + "PatternService" + Constant.methodname + "PostPattern"
        + Constant.message + "To post the pattern.");

      return mapper.Map<PatternDto>(pattern);
    }

    /// <summary>
    /// Delete pattern
    /// </summary>
    /// <param name="id"></param>
    /// <returns>PatternDto</returns>
    public async Task<PatternDto> DeletePattern(int id)
    {
      var pattern = await patternsRepository.GetPatternById(id);
      if (pattern == null)
      {
        throw new CoilTrackingException
        {
          ErrorMessage = ApplicationMessages.patternCalendarNotFound,
          HttpStatusCode = "NotFound"
        };
      }

      await patternsRepository.RemovePattern(pattern);

      patternServiceLogger.LogInformation(Constant.classname + "PatternService" + Constant.methodname + "DeletePattern"
        + Constant.message + "To delete the pattern.");

      return mapper.Map<PatternDto>(pattern);
    }
  }
}
