using AutoMapper;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using System.Collections.Generic;
using System.Linq;

namespace CoilTracking.Business.Implementation
{
  public class CoilFieldsService : ICoilFieldsService
  {

    private readonly ICoilFieldRepository coilFieldRepo;
    private readonly ICoilFieldZoneRepository coilFieldZoneRepo;
    private readonly ICoilRepository coilRepo;
    private readonly IApplicationLogger<CoilFieldsService> coilFieldServiceLogger;
    private readonly IWebSocketClientService webSocketClientService;

    private readonly IMapper mapper;

    public CoilFieldsService(ICoilFieldRepository coilFieldRepo, ICoilRepository coilRepo,
      IApplicationLogger<CoilFieldsService> coilFieldServiceLogger, IMapper mapper,
      ICoilFieldZoneRepository coilFieldZoneRepo, IWebSocketClientService webSocketClientService)
    {
      this.coilFieldRepo = coilFieldRepo;
      this.coilRepo = coilRepo;
      this.coilFieldServiceLogger = coilFieldServiceLogger;
      this.mapper = mapper;
      this.coilFieldZoneRepo = coilFieldZoneRepo;
      this.webSocketClientService = webSocketClientService;
    }

    /// <summary>
    /// To get the List of CoilFields.Includes both zones and locations with the coil fields
    /// </summary>
    /// <returns>coilFieldsDto</returns>
    public List<CoilFieldDto> GetCoilFields()
    {
      var coilFields = coilFieldRepo.GetCoilFields();
      var coilFieldList = mapper.Map<List<CoilField>, List<CoilFieldDto>>(coilFields);
      coilFieldServiceLogger.LogInformation(Constant.classname + "CoilFieldsService" + Constant.methodname + "GetCoilFields" + Constant.message + "To get the List of CoilFields.Includes both zones and locations with the coil fields");

      return coilFieldList;

    }

    /// <summary>
    /// To get the List of CoilFields by Id.Includes both zones and locations with the coil fields
    /// </summary>
    /// <param name="id"></param>
    /// <returns>coilFieldDto</returns>
    public CoilFieldDto GetCoilFieldById(int id)
    {
      var coilFields = coilFieldRepo.GetCoilFieldWithZonesById(id);
      var coilFieldDto = mapper.Map<CoilFieldDto>(coilFields);
      coilFieldServiceLogger.LogInformation(Constant.classname + "CoilFieldsService" + Constant.methodname + "GetCoilFieldById" + Constant.message + "To get the List of CoilFields.Includes both zones and locations with the coil fields By Id");

      return coilFieldDto;
    }

    /// <summary>
    /// To get the List of CoilFields by Id.Includes both zones and locations with the coil fields
    /// </summary>
    /// <param name="id"></param>
    /// <returns>coilField</returns>
    public CoilFieldDto GetCoilFieldForEdit(int id)
    {
      var coilFields = coilFieldRepo.GetCoilFieldWithZonesById(id);
      var coilFieldDto = mapper.Map<CoilFieldDto>(coilFields);
      coilFieldServiceLogger.LogInformation(Constant.classname + "CoilFieldsService" + Constant.methodname + "GetCoilFieldForEdit" + Constant.message + "To get the List of CoilFields.Includes both zones and locations with the coil fields By Id for editing");

      return coilFieldDto;
    }

    /// <summary>
    /// Check if entity is edited 
    /// </summary>
    /// <param name="id"></param>
    /// <param name="dto"></param>
    /// <returns>string</returns>
    public string CheckIfEdited(int id, CoilFieldDto dto)
    {
      string editing = null;
      var coilFields = coilFieldRepo.GetCoilFieldWithZonesById(id);
      if (dto.Id != coilFields.Id
              || dto.Name != coilFields.Name || dto.Disabled != coilFields.Disabled)

      {
        editing = Constant.edited;

      }
      coilFieldServiceLogger.LogInformation(Constant.classname + "CoilFieldsService" + Constant.methodname + "CheckIfEdited" + Constant.message + "Check if entity is edited ");

      return editing;
    }

    /// <summary>
    /// To get the  associated coil field zones with the CoilField
    /// </summary>
    /// <param name="id"></param>
    /// <returns>List of coil field zones</returns>
    public List<CoilFieldZoneDto> GetCoilFieldsZoneByCoilFieldId(int id)
    {
      var coilFieldzonelist = coilFieldZoneRepo.GetCoilFieldsZoneByCoilFieldId(id);
      var coilFieldZoneDtoList = mapper.Map<List<CoilFieldZone>, List<CoilFieldZoneDto>>(coilFieldzonelist);
      coilFieldServiceLogger.LogInformation(Constant.classname + "CoilFieldsService" + Constant.methodname + "GetAssociatedItemsCoilFielsZone" + Constant.message + "To get the  associated coil field zones with the CoilField ");
      webSocketClientService.CoilLocationsUpdated();
      return coilFieldZoneDtoList;
    }

    /// <summary>
    /// To get the list of coils by coilField Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns>Id</returns>
    public List<CoilDto> GetCoilsByCoilField(int id)
    {
      var coils = coilRepo.GetCoilsByCoilField(id);
      var coilsDto = mapper.Map<List<Coil>, List<CoilDto>>(coils);
      coilFieldServiceLogger.LogInformation(Constant.classname + "CoilFieldsService" + Constant.methodname + "GetCoilsByCoilField" + Constant.message + "To get the list of coils by coilField Id ");

      return coilsDto;

    }

    /// <summary>
    /// Get the coil field association type
    /// </summary>
    /// <param name="id"></param>
    /// <returns>List of String</returns>
    public List<string> GetCoilsFieldAssociationType(int id)
    {
      var coils = coilRepo.GetCoilsByCoilField(id);
      List<string> fieldAssociation = new List<string>();

      if (coils.Any())
      {
        fieldAssociation.Add(Constant.coilzone);
      }
      coilFieldServiceLogger.LogInformation(Constant.classname + "CoilFieldsService" + Constant.methodname + "GetCoilsFieldAssociationType" + Constant.message + "Get the coil field association type ");

      return fieldAssociation;
    }



    /// <summary>
    /// Disable a coil field
    /// </summary>
    /// <param name="id"></param>
    /// <param name="disable"></param>
    /// <returns>bool</returns>
    public bool DisableCoilField(int id, bool disable)
    {
      var coils = coilRepo.GetCoilsByCoilField(id);
      if (disable && coils.Any())
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.disableCoilFieldMsg, HttpStatusCode = "BadRequest" };

      }
      if (!CoilFieldExists(id))
      {
        return false;
      }
      var disableCoilField = coilFieldRepo.DisableCoilField(id, disable);
      coilFieldServiceLogger.LogInformation(Constant.classname + "CoilFieldsService" + Constant.methodname + "DisableCoilField" + Constant.message + "Disable a coil field ");
      webSocketClientService.CoilLocationsUpdated();
      return disableCoilField;
    }

    /// <summary>
    /// Check if CoilField Exists
    /// </summary>
    /// <param name="id"></param>
    /// <returns>bool</returns>
    public bool CoilFieldExists(int id)
    {
      var coilField = coilFieldRepo.GetCoilFieldById(id);
      coilFieldServiceLogger.LogInformation(Constant.classname + "CoilFieldsService" + Constant.methodname + "CoilFieldExists" + Constant.message + "Check if  a coil field exists");

      if (coilField != null)
        return true;
      return false;

    }
    /// <summary>
    /// To update an existing Coil Field
    /// </summary>
    /// <param name="id"></param>
    /// <param name="dto"></param>
    /// <returns>bool</returns>
    public bool UpdateCoilFieldDto(int id, CoilFieldDto dto)
    {
      var coils = coilRepo.GetCoilsByCoilField(id);
      if (dto.Disabled && coils.Count > 0)
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.disableCoilFieldMsg, HttpStatusCode = "BadRequest" };

      }
      if (!CoilFieldExists(id))
      {
        return false;
      }
      var coilField = mapper.Map<CoilField>(dto);

      var updateCoilField = coilFieldRepo.UpdateCoilField(id, coilField);
      coilFieldServiceLogger.LogInformation(Constant.classname + "CoilFieldsService" + Constant.methodname + "UpdateCoilFieldDto" + Constant.message + "To update an existing Coil Field ");
      webSocketClientService.CoilLocationsUpdated();
      return updateCoilField;
    }

    /// <summary>
    /// To add new coil field
    /// </summary>
    /// <param name="dto"></param>
    /// <returns>bool</returns>
    public bool SaveCoilFieldDto(CoilFieldDto dto)
    {
      var coilField = mapper.Map<CoilField>(dto);
      var saveNewCoilField = coilFieldRepo.SaveCoilField(coilField);
      webSocketClientService.CoilLocationsUpdated();
      return saveNewCoilField;
    }

    /// <summary>
    /// Delete a coil field
    /// </summary>
    /// <param name="id"></param>
    /// <returns>coilfieldDto</returns>
    public CoilFieldDto DeleteCoilField(int id)
    {
      var coilField = coilFieldRepo.DeleteCoilField(id);
      var coilFieldDto = mapper.Map<CoilFieldDto>(coilField);
      webSocketClientService.CoilLocationsUpdated();
      return coilFieldDto;
    }
  }
}
