using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Helpers;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.DTO;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  [ExcludeFromCodeCoverage]
  public class WebSocketClientService : IWebSocketClientService
  {
    private readonly string[] UserGroups;
    private readonly IWebsocketService websocketService;

    public WebSocketClientService(IWebsocketService websocketService, IUserHelper usersHelper)
    {
      this.websocketService = websocketService;
      var namc = usersHelper.GetNAMCCode();
      this.UserGroups = HubHelper.GetGroups(namc);
    }


    /// <summary>
    /// Updates CoilSetter and Andon clients with the new unfulfilled request count
    /// </summary>
    /// <param name="unfulfilledRequestCount"></param>
    public async Task UpdateNotificationCount(int unfulfilledRequestCount)
    {
      await this.websocketService.SendMessageToGroup(this.UserGroups, "UpdateNotificationCount", unfulfilledRequestCount);
    }

    /// <summary>
    /// Updates Blanking Operators when a run starts
    /// </summary>
    /// <param name="lineId">Line where run has started</param>
    /// <param name="dataNum">The data# of run</param>
    public async Task BlankingRunStarted(int lineId, int dataNum)
    {
      await this.websocketService.SendMessageToGroup(this.UserGroups, "BlankingRunStarted", new { lineId, dataNum });
    }

    /// <summary>
    /// Updates Blanking Operators when a run starts
    /// </summary>
    /// <param name="lineId">Line where the run stopped</param>
    /// <param name="dataNum">Data Number of the run the stopped</param>
    /// <param name="pressCount">The stroke count from PLC</param>
    public async Task BlankingRunStopped(int lineId, int dataNum, int pressCount)
    {
      await this.websocketService.SendMessageToGroup(this.UserGroups, "BlankingRunStopped", new { lineId, dataNum, pressCount });
    }

    /// <summary>
    /// Updates Blanking Operators when a coil is loaded
    /// </summary>
    /// <param name="lineId">Line where run has started</param>
    /// <param name="coilId">Coil identification</param>
    public async Task CoilLoaded(int lineId, int coilId)
    {
      await this.websocketService.SendMessageToGroup(this.UserGroups, "CoilLoaded", new { lineId, coilId });
    }

    /// <summary>
    /// Coil locations has been changed, notify clients.
    /// </summary>
    public async Task CoilLocationsUpdated()
    {
      await this.websocketService.SendMessageToGroup(this.UserGroups, "CoilLocationsUpdated", new { });
    }

    /// <summary>
    /// run order list has been changed , notify clients
    /// </summary>
    /// <param name="lineId">The line the runOrder is for</param>
    /// <param name="runOrderListId">The specific run order list updated</param>
    public async Task RunOrderListUpdated(int lineId, int runOrderListId)
    {
      await this.websocketService.SendMessageToGroup(this.UserGroups, "RunOrderListUpdated", new { lineId, runOrderListId });
    }

    public async Task UpdateStrokeCount(int lineId, int dataNumber, int strokeCount)
    {
      await this.websocketService.SendMessageToGroup(this.UserGroups, "UpdateStrokeCount", new { lineId, dataNumber, strokeCount });
    }

    public async Task UpdateStackerCount(int lineId, int dataNumber, int stackerCount)
    {
      await this.websocketService.SendMessageToGroup(this.UserGroups, "UpdateStackerCount", new { lineId, dataNumber, stackerCount });
    }

    public async Task UpdateDt(UpdateDtDto updateDtDto)
    {
      await this.websocketService.SendMessageToGroup(this.UserGroups, "UpdateDt", new {
        lineId = updateDtDto.LineId,
        dataNum =updateDtDto.DataNum,
        adc = updateDtDto.Adc,
        maint = updateDtDto.Maint,
        tooldie = updateDtDto.Tooldie,
        prod = updateDtDto.Prod,
        kanban = updateDtDto.Kanban,
        tryoutupdate = updateDtDto.Tryout,
        schd = updateDtDto.Schd });
    }

    public async Task CoilODWarning(int lineId)
    {
      await this.websocketService.SendMessageToGroup(this.UserGroups, "CoilODWarning", new { lineId });
    }
  }
}
