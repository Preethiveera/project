using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class RunOrderListQuantityService : IRunOrderListQuantityService
  {
    private readonly ICoilRepository coilRepo;
    private readonly IRunOrderListQuantityRepository runOrderListQuantityRepo;
    private readonly IPartRepository partRepo;
    private readonly IBlankInfoesRepository blankInfoesRepo;
    private readonly IProdPlanRepository prodPlanRepo;
    private readonly IApplicationLogger<RunOrderListQuantityService> runOrderListQuantityServiceLogger;
    private readonly IWebSocketClientService webSocketClientService;
    public RunOrderListQuantityService(ICoilRepository coilRepo, IRunOrderListQuantityRepository runOrderListQuantityRepo,
      IPartRepository partRepo, IBlankInfoesRepository blankInfoesRepo, IProdPlanRepository prodPlanRepo,
      IApplicationLogger<RunOrderListQuantityService> runOrderListQuantityServiceLogger, IWebSocketClientService webSocketClientService)
    {
      this.coilRepo = coilRepo;
      this.runOrderListQuantityRepo = runOrderListQuantityRepo;
      this.partRepo = partRepo;
      this.blankInfoesRepo = blankInfoesRepo;
      this.prodPlanRepo = prodPlanRepo;
      this.runOrderListQuantityServiceLogger = runOrderListQuantityServiceLogger;
      this.webSocketClientService = webSocketClientService;
    }
    /// <summary>
    /// Get RunOrderListQuantities
    /// </summary>
    /// <returns></returns>
    public async Task<List<RunOrderListQuantity>> GetRunOrderListQuantities()
    {
      var runorder = await runOrderListQuantityRepo.GetRunOrderListQuantities();
      return runorder;
    }
    /// <summary>
    ///  Get RunOrderListQuantities Based on Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public RunOrderListQuantity GetRunOrderListQuantity(int id)
    {
      //Get RunOrderListQuantity Based on ID
      var runOrderListQuantity = runOrderListQuantityRepo.GetRunOrderListQuantityById(id);
      runOrderListQuantityServiceLogger.LogInformation(Constant.classname + "RunOrderListQuantityService" + Constant.methodname + "GetRunOrderListQuantity" + Constant.message + "runOrderListQuantity Info Based on Id" + Constant.parameters + id);
      return runOrderListQuantity;
    }

    /// <summary>
    /// Get RunOrderItem Based on  LineId,partNumber,sortOrder
    /// </summary>
    /// <param name="lineId"></param>
    /// <param name="partNumber"></param>
    /// <param name="sortOrder"></param>
    /// <returns></returns>
    public RunOrderItemForCreate GetRunOrderItem(int lineId, string partNumber, int sortOrder)
    {
      RunOrderItemForCreate runOrderEntry = new RunOrderItemForCreate();
      //Get the Part Info Based on Partnumber
      Part part = partRepo.GetPartByName(partNumber);
       if (part == null)
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.Partnumbervalid, HttpStatusCode = "NotFound" };
      }
      runOrderListQuantityServiceLogger.LogInformation(Constant.classname + "RunOrderListQuantityService" + Constant.methodname + "GetRunOrderItem" + Constant.message + "part Info Based on partNumber");
      runOrderEntry.PartNumber = part.PartNumber;
      //20180302 : Prasanna : autocomplete part name not filled.
      runOrderEntry.PartName = part.PartName;
      runOrderEntry.ModelList = partRepo.GetModelList(partNumber);
      runOrderEntry.Blanks = new List<DataNumberDto>();
      //Get BlankInfo Based on Partnumber and LineID
      List<BlankInfo> blanks = blankInfoesRepo.GetBlankInfoByPartnumberLineIds(partNumber, lineId);
      runOrderListQuantityServiceLogger.LogInformation(Constant.classname + "RunOrderListQuantityService" + Constant.methodname + "GetRunOrderItem" + Constant.countoflines + blanks.Count + Constant.parameters + partNumber + lineId);
      //Get the CoilTypes
      List<Coil> Coils = coilRepo.GetCoilTypeByBlanks(blanks);
      runOrderListQuantityServiceLogger.LogInformation(Constant.classname + "RunOrderListQuantityService" + Constant.methodname + "GetRunOrderItem" + Constant.countoflines + Coils.Count);
      foreach (BlankInfo blank in blanks)
      {
        DataNumberDto dataNumberDto = new DataNumberDto
        {
          Id = blank.Id,
          DataNumber = blank.DataNumber,
          CoilTypeId = blank.CoilType.Id,
          CoilType = blank.CoilType.Name
        };
        List<int> coilsWeight = new List<int>();
        List<Coil> coils = Coils.Where(c => c.CoilType.Id == blank.CoilType.Id).ToList();
        dataNumberDto.CoilRemaining = coils.Sum(x => x.CurrentWeight);
        dataNumberDto.BlankWeight = blank.Weight;
        dataNumberDto.RewindWeight = blank.RewindWeight;
        dataNumberDto.StackSize = blank.StackSize;
        runOrderEntry.Blanks.Add(dataNumberDto);
      }
      var RequestQuantity = prodPlanRepo.GetProdPlanByPartnumber(partNumber);
      runOrderEntry.RequestQuantity = RequestQuantity.Select(l => l.LotSize).FirstOrDefault();
      runOrderEntry.SortOrder = sortOrder;
      runOrderEntry.OverrideQuantity = runOrderEntry.RequestQuantity;
      return runOrderEntry;
    }
    /// <summary>
    /// Insertion of Record to  RunOrderListQuantities
    /// </summary>
    /// <param name="runOrderListQuantity"></param>
    /// <returns></returns>
    public void InsertRunOrderListQuantity(RunOrderListQuantity runOrderListQuantity)
    {
      runOrderListQuantityRepo.InsertRunOrderListQuantity(runOrderListQuantity);
      runOrderListQuantityRepo.RunOrderListQuantitySaveChanges();
      webSocketClientService.RunOrderListUpdated(0, 0);
    }
    /// <summary>
    /// Update  Record to  RunOrderListQuantities Based on Id
    /// </summary>
    /// <param name="id"></param>
    /// <param name="runOrderListQuantity"></param>
    /// <returns></returns>
    public void UpdateRunOrderListQuantity(int id, RunOrderListQuantity runOrderListQuantity)
    {
      runOrderListQuantityRepo.ModifyRunOrderListQuantity(runOrderListQuantity);
      runOrderListQuantityRepo.RunOrderListQuantitySaveChanges();
      webSocketClientService.RunOrderListUpdated(0, 0);
    }
    /// <summary>
    /// Deletion of Record to  RunOrderListQuantities Based on Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public void DeleteRunOrderListQuantity(int id)
    {
      //Get RunOrderListQuantity Based on ID
      RunOrderListQuantity runOrderListQuantity = runOrderListQuantityRepo.GetRunOrderListQuantityById(id);
      runOrderListQuantityServiceLogger.LogInformation(Constant.classname + "RunOrderListQuantityService" + Constant.methodname + "DeleteRunOrderListQuantity" + Constant.message + "runOrderListQuantity Info Based on Id" + Constant.parameters + id);
      if (runOrderListQuantity == null)
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.RunOrderListQuantityNotFound, HttpStatusCode = "NotFound" };
      }
      runOrderListQuantityRepo.DeleteRunOrderListQuantityById(runOrderListQuantity);
      runOrderListQuantityRepo.RunOrderListQuantitySaveChanges();
      webSocketClientService.RunOrderListUpdated(0, 0);
    }
  }
}
