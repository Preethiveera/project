using AutoMapper;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class ProdPlanService : IProdPlanService
  {
    private readonly IApplicationLogger<ProdPlanService> logger;
    private readonly IProdPlanRepository prodPlanRepository;
    private readonly IMapper mapper;

    public ProdPlanService(IApplicationLogger<ProdPlanService> logger,
      IProdPlanRepository prodPlanRepository,
      IMapper mapper)
    {
      this.logger = logger;
      this.prodPlanRepository = prodPlanRepository;
      this.mapper = mapper;
    }

    /// <summary>
    /// Get list of ProdPlans.
    /// </summary>
    /// <returns></returns>
    public async Task<IQueryable<ProdPlanDto>> GetProdPlans()
    {
      var prodPlans = await prodPlanRepository.GetProdPlans();
      logger.LogInformation(Constant.classname + "ProdPlanService" + Constant.methodname + "GetProdPlans" + Constant.message + "Get list of all ProdPlans.");
      return mapper.Map<List<ProdPlanDto>>(prodPlans).AsQueryable();
    }

    /// <summary>
    /// Get ProdPlan by id.
    /// </summary>
    /// <returns></returns>
    public async Task<ProdPlanDto> GetProdPlanById(int id)
    {
      var prodPlan = await prodPlanRepository.GetProdPlanById(id);
      if (prodPlan == null)
      {
        throw new CoilTrackingException { HttpStatusCode = "NotFound" };
      }

      logger.LogInformation(Constant.classname + "ProdPlanService" + Constant.methodname + "GetProdPlanById" + Constant.message + "Get ProdPlan by Id.");
      return mapper.Map<ProdPlanDto>(prodPlan);
    }

    /// <summary>
    /// Update ProdPlan.
    /// </summary>
    /// <returns></returns>
    public async Task<bool> PutProdPlan(int id, ProdPlanDto prodPlan)
    {

      try
      {
        await prodPlanRepository.PutProdPlan(mapper.Map<ProdPlan>(prodPlan));
      }
      catch (DbUpdateConcurrencyException)
      {
        if (await prodPlanRepository.GetProdPlanById(id) == null)
        {
          throw new CoilTrackingException { HttpStatusCode = "NotFound" };
        }
        else
        {
          throw;
        }
      }

      logger.LogInformation(Constant.classname + "ProdPlanService" + Constant.methodname + "PutProdPlan" + Constant.message + "Update ProdPlan");
      return true;
    }

    /// <summary>
    /// Add ProdPlan.
    /// </summary>
    /// <returns></returns>
    public async Task<ProdPlanDto> PostProdPlan(ProdPlanDto prodPlan)
    {
      var prodPlanData = await prodPlanRepository.AddProdPlan(mapper.Map<ProdPlan>(prodPlan));
      logger.LogInformation(Constant.classname + "ProdPlanService" + Constant.methodname + "PostProdPlan" + Constant.message + "Add ProdPlan");
      return mapper.Map<ProdPlanDto>(prodPlanData);
    }

    /// <summary>
    /// Delete ProdPlan.
    /// </summary>
    /// <returns></returns>
    public async Task<ProdPlanDto> DeleteProdPlan(int id)
    {
      var prodPlan = await prodPlanRepository.GetProdPlanById(id);
      if (prodPlan == null)
      {
        throw new CoilTrackingException { HttpStatusCode = "NotFound" };
      }

      await prodPlanRepository.RemoveProdPlan(prodPlan);
      logger.LogInformation(Constant.classname + "ProdPlanService" + Constant.methodname + "DeleteProdPlan" + Constant.message + "Delete ProdPlan");
      return mapper.Map<ProdPlanDto>(prodPlan);
    }
  }
}
