using CoilTracking.Business.TMMI;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class CoilsFTZ : ICoilsFTZForTMMI
  {
    private readonly ICoilRepository coilRepo;
    private readonly IApplicationLogger<CoilsService> coilsServiceLogger;
    public CoilsFTZ(ICoilRepository coilRepo, IApplicationLogger<CoilsService> coilsServiceLogger)
    {
      this.coilRepo = coilRepo;
      this.coilsServiceLogger = coilsServiceLogger;
    }
    public async Task<Coil> GetCoilFTZByPrefix(string ftz)
    {
      var coil = await coilRepo.GetCoilsByFTZ(ftz);
      coilsServiceLogger.LogInformation(Constant.classname + "CoilsService" + Constant.methodname + "GetCoilByFTZ" + Constant.parameters + ftz);
      return coil;
    }
  }
}
