using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Logging;
using CoilTracking.Common.UsersHelperUtility;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class PrintTagService : IPrintTagService
  {
    private readonly IIncompleteRunOrderItemsRepository incompleteRunOrderItemsRepository;
    private readonly IRunResultsRepository runResultsRepository;
    private readonly IBlankInfoesRepository blankInfoesRepository;
    private readonly IPrintFunctions printFunctions;
    private readonly IPlantsRepository plantsRepository;
    private readonly IPartRepository partRepository;
    private readonly IHostingEnvironment hostingEnvironment;
    private readonly IApplicationLogger<PrintTagService> logger;
    private readonly IUserHelper userHelper;
    public PrintTagService(IIncompleteRunOrderItemsRepository incompleteRunOrderItemsRepository,
      IRunResultsRepository runResultsRepository,
      IBlankInfoesRepository blankInfoesRepository,
      IPrintFunctions printFunctions,
      IPlantsRepository plantsRepository,
      IPartRepository partRepository,
      IHostingEnvironment hostingEnvironment,
      IApplicationLogger<PrintTagService> logger, IUserHelper userHelper)
    {
      this.incompleteRunOrderItemsRepository = incompleteRunOrderItemsRepository;
      this.runResultsRepository = runResultsRepository;
      this.blankInfoesRepository = blankInfoesRepository;
      this.printFunctions = printFunctions;
      this.plantsRepository = plantsRepository;
      this.partRepository = partRepository;
      this.hostingEnvironment = hostingEnvironment;
      this.logger = logger;
      this.userHelper = userHelper;
    }

    /// <summary>
    /// Get list of CurrentRun List.
    /// </summary>
    /// <returns></returns>
    public async Task<CurrentRunListForGet> GetCurrentRunListAsync(int id)
    {
      List<IncompleteRunOrderItem> incompleteRunOrderItems = new List<IncompleteRunOrderItem>();
       CurrentRunListForGet runOrderListDto = new CurrentRunListForGet
      {
        RunOrderItems = new List<CurrentRunItemForGet>()
      };

      if (id == 0)
      {
        incompleteRunOrderItems = await incompleteRunOrderItemsRepository.GetIncompleteRunOrderItemsByStatus(RunOrderItemStatus.RunStarted);
        var updatedIncompleteRunOrderItems = ProcessIncompleteRunOrderItems(incompleteRunOrderItems);
        incompleteRunOrderItems = updatedIncompleteRunOrderItems;
      }
      else
      {
        incompleteRunOrderItems = await incompleteRunOrderItemsRepository.GetIncompleteRunOrderItemsById(id);
      }

      logger.LogInformation(Constant.classname + "PrintTagService" + Constant.methodname + "GetCurrentRunListAsync" + Constant.message + "Get list of all current run");
      return ProcessRunOrderItems(incompleteRunOrderItems, runOrderListDto);
    }

    /// <summary>
    /// Print Blank tags
    /// </summary>
    /// <returns></returns>
    public async Task<PrintResultDto> PrintBlankTagAsync(string printType, JObject data, DateTime? heatTreatDate = null, string partNumber = null, string stackSize = null, string lineName = null)
    {
      string printerName = null;
      CurrentRunItemForGet currentRun;
      PrintResultDto printResult = new PrintResultDto();
      PrinterConfigDto printerConfig = new PrinterConfigDto();
      string ZPLString = string.Empty;
      printResult.Printstatus = false;
      printResult.PalletID = null;

      
      string NAMCCode = userHelper.GetNAMCCode();
      ZPLParametersDto ZPLParameters = new ZPLParametersDto();
      PalletTag palletTag = new PalletTag();

      ZPLParameters.NamcCode = NAMCCode;

      int tagCount = 0;

      if (printType == PrintType.LostTag)
      {
        var printerDetails = await incompleteRunOrderItemsRepository.GetPrinterConfigAsync(lineName);
        if (printerDetails != null)
          printerName = printerDetails.PrinterName;

        tagCount = 1;
        ZPLParameters.Line = lineName;
        ZPLParameters.RunOrderItemId = 0;
        ZPLParameters.CustomerPartNumber = partNumber;
        ZPLParameters.FTZ = "";
        ZPLParameters.Quantity = stackSize;
        ZPLParameters.PartName = await partRepository.GetPartName(partNumber);
      }
      else if (printType == PrintType.Manual || printType == PrintType.Automatic)
      {
        currentRun = data["runOrderItem"].ToObject<CurrentRunItemForGet>();

        ZPLParameters.RunOrderItemId = currentRun.Id;
        ZPLParameters.Line = currentRun.LineName;
        ZPLParameters.FTZ = currentRun.FTZ;
        ZPLParameters.Quantity = currentRun.StackSize.ToString();
        ZPLParameters.CustomerPartNumber = currentRun.PartNumber;
        ZPLParameters.PartName = await partRepository.GetPartName(currentRun.PartNumber);

        if (printType == PrintType.Automatic)
        {
          tagCount = currentRun.tagsCount;
        }
        else
        {
          tagCount = 1;
          if (!IsTagsPrintedfromAutoPrint(ZPLParameters))
          {
            printResult.Printstatus = false;
            printResult.Printinfo = PrintTag.CoilNotLoaded;
            printResult.Errormessage = PrintTag.CoilNotLoadedError;
            return printResult;
          }
        }
      }

      ZPLParameters = ProcessZPL(heatTreatDate, ZPLParameters);
      var updatedPrintResult = ProcessZPLParamter(ZPLParameters, tagCount, NAMCCode, printResult, ZPLString, printerName, printerConfig, palletTag);
      logger.LogInformation(Constant.classname + "PrintTagService" + Constant.methodname + "PrintBlankTagAsync" + Constant.message + "Print Blank Tag async completed");
      return updatedPrintResult;
    }

    /// <summary>
    /// Test method for Print Blank tag.
    /// </summary>
    /// <returns></returns>
    public string PrintBlankTagTest()
    {
      string NAMCCode = "02"; // TODO: get NAMCCode from plant table
      string ZPLString = string.Empty;
      ZPLParametersDto ZPLParameters = new ZPLParametersDto();
      PalletTag palletTag = new PalletTag();
      ZPLParameters.PalletId = "B" + NAMCCode + GenerateBlankPalletID();
      ZPLParameters.NamcCode = NAMCCode;
      ZPLParameters.Line = "BL1";
      ZPLParameters.CustomerPartNumber = "53321-0R030";
      ZPLParameters.PartName = "PANEL, HOOD INNER";
      ZPLParameters.HeatTreatDate = ""; //heatTreatDate.ToString("MM-dd-yyyy");
                                        //TODO check server path in test env
                                        //ZPLParameters.TemplatesLocation = _hostingEnvironment.ContprintResult.printinfoentRootPath + "\\Templates\\";
      ZPLParameters.TemplatesLocation = @"D:\";

      ZPLParameters.Quantity = "150";
      ZPLParameters.TagSerialNumber = GenerateTagSerialNumber(NAMCCode, ZPLParameters.Line, ZPLParameters.CustomerPartNumber);
      ZPLParameters.palletSequence = GenerateTagSerialID(NAMCCode, ZPLParameters.Line, ZPLParameters.CustomerPartNumber);

      ZPLString = printFunctions.GetZPLTemplateString(ZPLParameters);// TODO: get materaial type from DB

      palletTag.PalletID = ZPLParameters.PalletId;
      palletTag.NAMCCode = ZPLParameters.NamcCode;
      palletTag.LineName = ZPLParameters.Line;
      palletTag.PartNumber = ZPLParameters.CustomerPartNumber;
      palletTag.PalletSequence = Convert.ToInt32(ZPLParameters.palletSequence);
      palletTag.SerialNumber = ZPLParameters.TagSerialNumber;
      palletTag.BlanksQuantity = Convert.ToInt32(ZPLParameters.Quantity);
      palletTag.Created = DateTime.Now;

      InsertBlankPalletInfo(palletTag);

      return ZPLString;
    }

    /// <summary>
    /// Process Incomplete Run Order Items.
    /// </summary>
    /// <returns></returns>
    private List<IncompleteRunOrderItem> ProcessIncompleteRunOrderItems(List<IncompleteRunOrderItem> incompleteRunOrderItems)
    {
      IQueryable<int> runResults = runResultsRepository.GetRunResultForIncompleteOrderItem();
      var completedRunOrderItems = incompleteRunOrderItemsRepository.GetCompletedRunOrderItemsByIdAndStatus(runResults.ToList(), RunOrderItemStatus.Completed).Result;

      if (runResults != null && runResults.Count() > 0)
      {
        foreach (int lastRun in runResults)
        {
          IncompleteRunOrderItem completedRunOrderItem = completedRunOrderItems.Where(x => x.RunOrderList.Id == lastRun).FirstOrDefault();
          if (completedRunOrderItem != null)
            incompleteRunOrderItems.Add(completedRunOrderItem);
        }
      }

      return incompleteRunOrderItems;
    }

    /// <summary>
    /// Process Run Order Items
    /// </summary>
    /// <returns></returns>
    private CurrentRunListForGet ProcessRunOrderItems(List<IncompleteRunOrderItem> incompleteRunOrderItems, CurrentRunListForGet runOrderListDto)
    {
      var dataNumbers = incompleteRunOrderItems.Select(x => x.DataNumber).ToList();
      var blankInfoes = blankInfoesRepository.GetBlankInfoByDataNumbers(dataNumbers).Result;
      foreach (IncompleteRunOrderItem incompleteRunOrderItem in incompleteRunOrderItems)
      {
        var blankInfo = blankInfoes.Where(x => x.DataNumber == incompleteRunOrderItem.DataNumber && x.Line.Id == incompleteRunOrderItem.Line.Id).FirstOrDefault();
        CurrentRunItemForGet runOrderItem = new CurrentRunItemForGet();
        runOrderItem.Id = incompleteRunOrderItem.Id;
        runOrderItem.SortOrder = incompleteRunOrderItem.SortOrder;
        runOrderItem.LineName = incompleteRunOrderItem.Line.LineName;
        runOrderItem.DataNumber = incompleteRunOrderItem.DataNumber;
        runOrderItem.PartNumber = incompleteRunOrderItem.Part.PartNumber;
        runOrderItem.StackSize = blankInfo?.StackSize;
        runOrderItem.FTZs = incompleteRunOrderItemsRepository.GetFTZAsync(incompleteRunOrderItem.Id).Result;

        runOrderListDto.RunOrderItems.Add(runOrderItem);
      }

      return runOrderListDto;
    }

    /// <summary>
    /// Check if Tags are printed of Autoprint.
    /// </summary>
    /// <returns></returns>
    private bool IsTagsPrintedfromAutoPrint(ZPLParametersDto ZplParams)
    {
      return incompleteRunOrderItemsRepository.IsTagsPrintedfromAutoPrint(ZplParams.RunOrderItemId).Result;
    }

    /// <summary>
    /// Generates a blank pallet id.
    /// </summary>
    /// <returns></returns>
    private string GenerateBlankPalletID()
    {
      string NxtPalletSeqNo = "1";
      NxtPalletSeqNo = NxtPalletSeqNo.ToString().PadLeft(5, '0');
      string palletSeqNo = string.Empty;
      try
      {
        var LstPallet = incompleteRunOrderItemsRepository.GetMaxBkankPalet(); //max blank pallet id record
        if (LstPallet != null)
        {
          string palletId = LstPallet.PalletID;
          palletSeqNo = palletId.Substring(4).ToString();

          NxtPalletSeqNo = IncrementPalletID(palletSeqNo);
        }
        else
        {
          NxtPalletSeqNo = NxtPalletSeqNo.ToString().PadLeft(5, '0');
        }
      }
      catch (Exception ex)
      {
        throw ex;
      }
      return NxtPalletSeqNo.ToString().PadLeft(5, '0');
    }

    /// <summary>
    /// Increments Pallet Id.
    /// </summary>
    /// <returns></returns>
    private string IncrementPalletID(string palletid)
    {
      var palletArr = palletid.ToCharArray();

      // Add legal characters
      var characters = new List<char>() {
'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'
            };

      for (int i = palletArr.Length - 1; i >= 0; i--)
      {
        if (palletArr[i] == characters.Last())
        {
          palletArr[i] = characters.First();
        }
        else
        {
          palletArr[i] = characters[characters.IndexOf(palletArr[i]) + 1];
          break;
        }
      }
      return new string(palletArr);
    }

    /// <summary>
    /// Generates Tag Serial id.
    /// </summary>
    /// <returns></returns>
    private string GenerateTagSerialID(string namcCode, string Line, string CustomerPartNumber)
    {
      string NxtProdIDSeqNo = "1";
      try
      {
        //get last production id from db
        var palletList = incompleteRunOrderItemsRepository.GetSerialNumbers(namcCode, Line, CustomerPartNumber);

        if (!string.IsNullOrEmpty(palletList))
        {

          int last4Digits = int.Parse(palletList.Substring(palletList.Length - 4));
          NxtProdIDSeqNo = (last4Digits + 1).ToString();

        }
      }
      catch (Exception ex)
      {
        logger.LogInformation(Constant.classname + "PrintTagService" + Constant.methodname + "GenerateTagSerialID" + Constant.message + "Exception " + ex.Message);
        throw ex;
      }
      return NxtProdIDSeqNo.ToString();
    }

    /// <summary>
    /// Generates Tag Serial Number.
    /// </summary>
    /// <returns></returns>
    private string GenerateTagSerialNumber(string namcCode, string Line, string CustomerPartNumber)
    {
      //generate tag serial number
      //TagSerialNmber format: Line + Date (mmMMddyyyy) + 4 digit Sequence (Example: BL1 04062020 0001)
      var TagSequence = Line + DateTime.Now.ToString("MMddyyyy");
      var TagSerialNumber = TagSequence + GenerateTagSerialID(namcCode, Line, CustomerPartNumber).PadLeft(4, '0');
      return TagSerialNumber;
    }

    /// <summary>
    /// Insert Blank Pallet Infp.
    /// </summary>
    /// <returns></returns>
    private bool InsertBlankPalletInfo(PalletTag pallettag)
    {
      bool success = false;
      try
      {
        incompleteRunOrderItemsRepository.AddPallet(pallettag);
        success = true;
      }
      catch (Exception)
      {
        throw;
      }
      return success;
    }

    private ZPLParametersDto ProcessZPL(DateTime? heatTreatDate, ZPLParametersDto ZPLParameters)
    {
      if (heatTreatDate != null)
      {
        ZPLParameters.HTDText = "HTD";
        ZPLParameters.HeatTreatDate = heatTreatDate.Value.ToString("MM-dd-yyyy");
      }
      else
      {
        ZPLParameters.HTDText = "";
        ZPLParameters.HeatTreatDate = "";
      }
      ZPLParameters.TemplatesLocation = hostingEnvironment.ContentRootPath + ("/Templates/");

      return ZPLParameters;
    }

    private PrintResultDto ProcessZPLParamter(ZPLParametersDto ZPLParameters, int tagCount, string NAMCCode, PrintResultDto printResult, string ZPLString, string printerName, PrinterConfigDto printerConfig, PalletTag palletTag)
    {
      for (int i = 0; i < tagCount; i++)
      {
        ZPLParameters.PalletId = "BI" + NAMCCode + GenerateBlankPalletID();
        printResult.PalletID = ZPLParameters.PalletId;

        ZPLParameters.TagSerialNumber = GenerateTagSerialNumber(NAMCCode, ZPLParameters.Line, ZPLParameters.CustomerPartNumber);
        ZPLParameters.palletSequence = GenerateTagSerialID(NAMCCode, ZPLParameters.Line, ZPLParameters.CustomerPartNumber);

        ZPLString = printFunctions.GetZPLTemplateString(ZPLParameters);// TODO: get materaial type from DB
                                                                       //TODO check server path in test env
                                                                       //ZPLParameters.TemplatesLocation = _hostingEnvironment.ContprintResult.printinfoentRootPath + "\\Templates\\";

        var result = ProcessPrintResult(ZPLParameters, printResult, ZPLString, printerName, printerConfig, NAMCCode);
        printerConfig = result.PrinterConfig;
        printResult = result.PrintResult;

        try
        {
          if ((NAMCCode != null) && (printResult.PalletID != null))
          {
            printResult = ProcessPallet(ZPLParameters, printResult, printerConfig, palletTag, ZPLString, tagCount);
          }
          else
          {
            printResult.Printinfo = PrintTag.PrintUnsuccessful;
            printResult.Errormessage = PrintTag.NAMCPalletError;
          }
        }
        catch (Exception ex)
        {
          printResult.Printinfo = PrintTag.PrintUnsuccessful;
          printResult.Errormessage = PrintTag.NetworkPrinterError;
          printResult.Errormessage = "Error : " + ex.Message.ToString();
        }
      }
      return printResult;
    }

    private PrintResultModel ProcessPrintResult(ZPLParametersDto ZPLParameters, PrintResultDto printResult, string ZPLString, string printerName, PrinterConfigDto printerConfig, string NAMCCode)
    {
      if (string.IsNullOrEmpty(ZPLString))
      {
        printResult.Printinfo = PrintTag.PrintUnsuccessful;
        printResult.Errormessage = PrintTag.BlankPalletTemplateNullError;
      }

      //Assign printer name to 
      if (printerName != null)
      {
        //write trhe code for below method
        printerConfig = printFunctions.GetPrinterConfigValuesByPrinterName(NAMCCode, printerName);
      }
      else
      {
        printerConfig = printFunctions.GetPrinterConfigValues(NAMCCode, ZPLParameters.Line);
      }

      return new PrintResultModel
      {
        PrinterConfig = printerConfig,
        PrintResult = printResult
      };
    }

    private PrintResultDto ProcessPallet(ZPLParametersDto ZPLParameters, PrintResultDto printResult, PrinterConfigDto printerConfig, PalletTag palletTag, string ZPLString, int tagCount)
    {
      printResult.TagCount = tagCount;
      if (ZPLString != string.Empty && (printerConfig.IPAddress != null) && (printerConfig.PortNumber > 0))
      {
        try
        {
          //print pallet tag here 
          printResult.Printstatus = printFunctions.PrintFunction(ZPLString, printerConfig.IPAddress, printerConfig.PortNumber);

          if (printResult.Printstatus)
          {
            palletTag.PalletID = ZPLParameters.PalletId;
            palletTag.NAMCCode = ZPLParameters.NamcCode;
            palletTag.LineName = ZPLParameters.Line;
            palletTag.PartNumber = ZPLParameters.CustomerPartNumber;
            palletTag.PalletSequence = Convert.ToInt32(ZPLParameters.palletSequence);
            palletTag.SerialNumber = ZPLParameters.TagSerialNumber;
            palletTag.BlanksQuantity = Convert.ToInt32(ZPLParameters.Quantity);
            palletTag.FTZ = ZPLParameters.FTZ;
            palletTag.RunOrderItemId = ZPLParameters.RunOrderItemId;
            palletTag.Created = DateTime.Now;

            InsertBlankPalletInfo(palletTag);
          }
          printResult.Printinfo = PrintTag.PrintSuccessfull;
          printResult.Errormessage = PrintTag.Success;
        }
        catch (Exception ex1)
        {
          printResult.Printinfo = PrintTag.PrintUnsuccessful;
          printResult.Errormessage = PrintTag.NetworkPrinterError;
          printResult.Errormessage = "Error : " + ex1.Message.ToString();
          throw ex1;
        }
      }
      else
      {
        printResult.Printinfo = PrintTag.PrintUnsuccessful;
        printResult.Errormessage = "Error : " + printerConfig.ErrorMessage;
      }

      return printResult;
    }

    public class PrintResultModel
    {
      public PrintResultDto PrintResult { get; set; }

      public PrinterConfigDto PrinterConfig { get; set; }
    }
  }
}
