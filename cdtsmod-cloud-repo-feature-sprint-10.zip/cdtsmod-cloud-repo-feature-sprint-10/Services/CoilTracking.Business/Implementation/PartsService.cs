using AutoMapper;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class PartsService : IPartsService
  {
    public readonly IPartModelsRepository partModelsRepo;
    public readonly IPartRepository partRepo;
    public readonly IBlankInfoesRepository blankInfoesRepo;
    public readonly IModelRepository modelRepo;
    private readonly IBlankInfoService blankInfoservice;
    public PartsService(IPartRepository partRepo, IPartModelsRepository partModelsRepo, IBlankInfoesRepository blankInfoesRepo, IModelRepository modelRepo,  IBlankInfoService blankInfoservice)
    {
      this.partRepo = partRepo;
      this.partModelsRepo = partModelsRepo;
      this.blankInfoesRepo = blankInfoesRepo;
      this.modelRepo = modelRepo;
      this.blankInfoservice = blankInfoservice;
    }

    public async Task<List<PartDto>> GetParts()
    {
      var parts = await partRepo.GetPartsAsync();
      var partDtos = parts.Select(p => GetDtoFromPart(p)).OrderBy(part => part.PartNumber).ToList();
      return partDtos;

    }
    /// <summary>
    /// Gets a DTO from the Part
    /// </summary>
    /// <param name="part"></param>
    /// <returns></returns>
    private PartDto GetDtoFromPart(Part part)
    {
      return new PartDto()
      {
        Id = part.Id,
        PartName = part.PartName,
        PartNumber = part.PartNumber,
        Disabled = part.Disabled,
        ModelList = partRepo.GetModelList(part.PartNumber),
        StrokeCount = part.StrokeCount,
        Plant_Id = part.Plant_Id
      };
    }
    /// <summary>
    /// Get Part Based On Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<PartDto> GetPartById(int id)
    {
      var part = await partRepo.GetPartByIdAsync(id);
      var partDtos = GetDtoFromPart(part);
      return partDtos;
    }
    /// <summary>
    /// Get PartModel Based On Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<List<int>> GetPartModelsById(int id)
    {
      var part = await partRepo.GetPartByIdAsync(id);
      if (part == null)
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.noPartInfo, HttpStatusCode = Constant.notfound };
      }
      var partModels = partModelsRepo.GetPartModelByPartId(part.Id);
      var Parts = partModels.Select(m => m.Id).ToList();
      return Parts;
    }

    /// <summary>
    /// Get AutoComplete Info Based on PartNumber and LineId
    /// </summary>
    /// <param name="partNumber"></param>
    /// <param name="lineId"></param>
    /// <returns></returns>
    public async Task<List<string>> GetAutoCompleteInfo(string partNumber, int lineId)
    {
      var partModels = await partModelsRepo.GetPartmodelsByPartnumber(partNumber);
      var partModelsGroupings = partModels.Select(pm =>
      new PartModelGroup
      {
        PartNumber = pm.Part.PartNumber,
        ModelNumber = pm.Model.ModelNumber,
        PartName = pm.Part.PartName
      }).GroupBy(pm => pm.PartNumber).ToList();
      var partModelGroups = partModelsGroupings.Select(pmg => new PartModelGroup()
      {
        PartNumber = pmg.Key,
        PartName = pmg.FirstOrDefault().PartName,
        ModelNumber = string.Join(",", pmg.Select(pm => pm.ModelNumber))
      }).ToList();

      var partNumberlist = partModelGroups.Select(p => p.PartNumber).ToList();

      var lstDatas = await blankInfoesRepo.GetBlankInfoByLineIdAndPartNumber(lineId, partNumberlist);

      partModelGroups.ForEach(pmg => pmg.DataNumber = lstDatas.Any(x => x.Part.PartNumber == pmg.PartNumber) ? lstDatas.FirstOrDefault(x => x.Part.PartNumber == pmg.PartNumber).DataNumber.ToString() : "-");

      List<string> partsList = partModelGroups.Select(pmg => pmg.PartNumber + " : " + pmg.DataNumber + " : " + pmg.ModelNumber + " : " + pmg.PartName).OrderBy(item => item).ToList();

      return partsList;

    }
    /// <summary>
    /// Updation Of Part Based On Id and Part
    /// </summary>
    /// <param name="id"></param>
    /// <param name="part"></param>
    /// <returns></returns>
    public async Task UpdatePart(int id, Part part)
    {
      var parts = await partRepo.GetPartByIdAsync(id);
      if (parts == null)
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.noPartInfo, HttpStatusCode = Constant.notfound };
      }
      part.Plant_Id = parts.Plant_Id;
      await partRepo.UpdatePartSaveChanges(part);
    }

    /// <summary>
    /// Disable Part
    /// </summary>
    /// <param name="id"></param>
    /// <param name="disable"></param>
    /// <returns></returns>
    public async Task DisablePart(int id, bool disable)
    {
      var part = await partRepo.GetPartByIdAsync(id);
      if (part == null)
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.noPartInfo, HttpStatusCode = Constant.notfound };
      }
      part.Disabled = disable;
      await partRepo.DisablePartSaveChanges(part);
    }

    /// <summary>
    ///Change Models
    /// </summary>
    /// <param name="models"></param>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<int> ChangeModels(List<Model> models, int id)
    {
      var part = await partRepo.GetPartByIdAsync(id);
      //GetPartModels first then you get Models 
      List<PartModel> partModelsExisting = await partModelsRepo.GetPartmodelsByPartIdwithOut(id);
      List<Model> modelsExisting = partModelsExisting.Select(x=>x.Model).ToList();

      if (partModelsExisting != null && partModelsExisting.Any() && partModelsExisting.Count >0)
      {
        foreach (PartModel partModel in partModelsExisting)
        {
          if (!models.Exists(m => m.Id == partModel.Model.Id))
          {
            partModelsRepo.RemovePartModel(partModel);
          }
        }
        await partModelsRepo.PartModelsSavechanges();
      }
      List<PartModel> partModels = new List<PartModel>();
      foreach (Model model in models)
      {
        if (!modelsExisting.Exists(m => m.Id == model.Id))
        {
          PartModel partModel = new PartModel();
          partModel.Part = part;
          partModel.Model = model;
          partModels.Add(partModel);
        }
      }
     var res =  await partModelsRepo.InsertPartModelsSavechanges(partModels);
      return res;
    }



    /// <summary>
    ///Change Models
    /// </summary>
    /// <param name="models"></param>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<int> ChangeModelNopart(List<Model> models, Part part)
    {
      //GetPartModels first then you get Models 
      List<PartModel> partModelsExisting = await partModelsRepo.GetPartmodelsByPartIdwithOut(part.Id);
      List<Model> modelsExisting = partModelsExisting.Select(x => x.Model).ToList();

      if (partModelsExisting != null && partModelsExisting.Any() && partModelsExisting.Count > 0)
      {
        foreach (PartModel partModel in partModelsExisting)
        {
          if (!models.Exists(m => m.Id == partModel.Model.Id))
          {
            partModelsRepo.RemovePartModel(partModel);
          }
        }
        await partModelsRepo.PartModelsSavechanges();
      }
      List<PartModel> partModels = new List<PartModel>();
      foreach (Model model in models)
      {
        if (!modelsExisting.Exists(m => m.Id == model.Id))
        {
          PartModel partModel = new PartModel();
          partModel.Part = part;
          partModel.Model = model;
          partModels.Add(partModel);
        }
      }
      var res = await partModelsRepo.InsertPartModelsSavechanges(partModels);
      return res;
    }

    /// <summary>
    /// Insertion Part Based on Info
    /// </summary>
    /// <param name="part"></param>
    /// <returns></returns>
    public async Task<Part> InsertPart(Part part)
    {
      Part partInfo = partRepo.GetPartByName(part.PartNumber);
      if (partInfo != null)
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.partsalreadyexsit, HttpStatusCode = Constant.notfound };
      }
      await partRepo.InsertParts(part);

      return part;
    }
    /// <summary>
    /// Delete Part
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<Part> DeletePart(int id)
    {
      Part parts = await partRepo.GetPartByIdAsync(id);
      if (parts == null)
      {
        throw new CoilTrackingException { ErrorMessage = ApplicationMessages.noPartInfo, HttpStatusCode = Constant.notfound };
      }
      await partRepo.DeletePart(parts);
      return parts;
    }
    /// <summary>
    /// Part CheckEdit
    /// </summary>
    /// <param name="id"></param>
    /// <param name="part"></param>
    /// <returns></returns>
    public async Task PartCheckEdit(int id, Part part)
    {
      List<PartModel> partModels = await partModelsRepo.GetPartmodelsByPartId(id);
      Part parts = await partRepo.GetPartByIdAsync(id);
      if (parts.PartName != part.PartName || parts.PartNumber != part.PartNumber || part.StrokeCount != parts.StrokeCount || parts.Disabled != part.Disabled)
        throw new CoilTrackingException { HttpStatusCode = Constant.badRequest };
      else
        throw new CoilTrackingException { HttpStatusCode = Constant.notfound };
    }
    /// <summary>
    /// Get Part ProdPlan Association
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<List<string>> GetPartProdPlanAssociation(int id)
    {
      List<string> partAssociation = new List<string>();
      bool partInRunOrder = false;
      var part = await partRepo.GetPartByIdAsync(id);
      string partNumber = part.PartNumber;
      var blankinfoPart = await blankInfoesRepo.GetBlankInfoByPartId(id);
      if (blankinfoPart != null)
      {
        List<BlankInfo> blanks = blankinfoPart;
        List<IncompleteRunOrderItem> blanksData = new List<IncompleteRunOrderItem>();
        var blankinfo = await blankInfoservice.GetBlankInfoRunOrder(blanks);
        blanksData.AddRange(blankinfo);
        if (blanksData.Count != 0)
        {
          partInRunOrder = true;
        }
      }
      if (partInRunOrder)
        partAssociation.Add("Runorder");


      return partAssociation;
    }


  }
}
