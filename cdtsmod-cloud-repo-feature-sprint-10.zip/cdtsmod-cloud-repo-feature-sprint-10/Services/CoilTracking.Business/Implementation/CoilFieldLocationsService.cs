using AutoMapper;
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class CoilFieldLocationsService : ICoilFieldLocationsService
  {
    private readonly ICoilFieldLocationRepository coilFieldLocationRepository;
    private readonly IMapper mapper;
    private readonly IApplicationLogger<CoilFieldLocationsService> logger;
    private readonly ICoilFieldZoneRepository coilFieldZoneRepository;
    private readonly ICoilRepository coilRepository;
    private readonly IWebSocketClientService webSocketClientService;

    public CoilFieldLocationsService(ICoilFieldLocationRepository coilFieldLocationRepository,
      IMapper mapper,
      IApplicationLogger<CoilFieldLocationsService> logger,
      ICoilFieldZoneRepository coilFieldZoneRepository,
      ICoilRepository coilRepository,
      IWebSocketClientService webSocketClientService)
    {
      this.coilFieldLocationRepository = coilFieldLocationRepository;
      this.mapper = mapper;
      this.logger = logger;
      this.coilFieldZoneRepository = coilFieldZoneRepository;
      this.coilRepository = coilRepository;
      this.webSocketClientService = webSocketClientService;
    }

    /// <summary>
    /// To Get all the coil Field Location
    /// </summary>

    public IQueryable<CoilFieldLocationDto> GetCoilFieldLocations()
    {
      var data = coilFieldLocationRepository.GetAllCoilFieldLocations();
      var coilFieldLocations = mapper.Map<List<CoilFieldLocationDto>>(data);

      logger.LogInformation(Constant.classname + "CoilFieldLocationsService" + Constant.methodname + "GetCoilFieldLocations" + Constant.message + "Get List of all Coil Field Locations");

      return coilFieldLocations.AsQueryable();
    }

    /// <summary>
    /// To Get the coil Field Location by Id
    /// </summary>

    public CoilFieldLocationDto GetCoilFieldLocationById(int id)
    {
      var data = coilFieldLocationRepository.GetCoilFieldLocationById(id);
      var coilFieldLocation = mapper.Map<CoilFieldLocationDto>(data);

      logger.LogInformation(Constant.classname + "CoilFieldLocationsService" + Constant.methodname + "FindCoilFieldLocation" + Constant.message + "Find Coil Field Location by Id");

      return coilFieldLocation;
    }

    /// <summary>
    /// To Get the coil Field Location including zone
    /// </summary>

    public Task<CoilFieldLocationDto> GetCoilFieldLocationWithZone(int id)
    {
      var data = coilFieldLocationRepository.GetCoilFieldLocationWithZone(id);
      var coilFieldLocation = mapper.Map<CoilFieldLocationDto>(data);

      logger.LogInformation(Constant.classname + "CoilFieldLocationsService" + Constant.methodname + "FindCoilFieldLocationForEdit" + Constant.message + "Find Coil Field Location for Edit by Id");

      return Task.FromResult(coilFieldLocation);
    }

    /// <summary>
    /// To Get the coil Field Location by coilID
    /// </summary>

    public List<CoilFieldLocationDto> GetCoilFieldLocationByCoilId(int coilId)
    {
      // Get list of Empty Locations
      List<CoilFieldLocation> freeLocs = coilFieldLocationRepository.GetFreeLocations();

      // Get Coil using Coil Id
      Coil coil = coilRepository.GetCoilWithCoilField(coilId);

      if (coil.CoilFieldLocation != null)
      {
        CoilFieldLocation coilLoc = coilFieldLocationRepository.GetCoilFieldLocationWithZone(coil.CoilFieldLocation.Id);
        freeLocs.Add(coilLoc);
      }

      logger.LogInformation(Constant.classname + "CoilFieldLocationsService" + Constant.methodname + "FindCoilFieldLocationByCoilId" + Constant.message + "Find Coil Field Location by CoilId");
      var coilFieldLocation = mapper.Map<List<CoilFieldLocationDto>>(freeLocs);
      return coilFieldLocation;
    }

    /// <summary>
    /// To Get the coil Field Location by ZoneId
    /// </summary>

    public List<CoilFieldLocationDto> GetCoilFieldLocationByZoneId(int zoneId)
    {
      var data = coilFieldLocationRepository.GetCoilFieldLocationByZoneId(zoneId);
      var coilFieldLocation = mapper.Map<List<CoilFieldLocationDto>>(data);

      logger.LogInformation(Constant.classname + "CoilFieldLocationsService" + Constant.methodname + "FindCoilFieldLocationByZoneId" + Constant.message + "Find Coil Field Location by ZoneId");

      return coilFieldLocation;
    }

    /// <summary>
    /// To Update the coil Field Location
    /// </summary>

    public void UpdateCoilFieldLocation(int id, CoilFieldLocationDto coilFieldLocation)
    {
      var coilFieldLocationData = mapper.Map<CoilFieldLocation>(coilFieldLocation);

      try
      {
        coilFieldLocationRepository.UpdateCoilFieldLocation(id, coilFieldLocationData);
      }

      catch (DbUpdateConcurrencyException)
      {
        if (coilFieldLocationRepository.GetCoilFieldLocationById(id) == null)
        {
          throw new CoilTrackingException { HttpStatusCode = "NotFound" };
        }
        else
        {
          throw;
        }
      }

      logger.LogInformation(Constant.classname + "CoilFieldLocationsService" + Constant.methodname + "UpdateCoilFieldLocation" + Constant.message + "Updating Coil Field Location");
      webSocketClientService.CoilLocationsUpdated();
    }

    /// <summary>
    /// To Disable the coil Field Location
    /// </summary>

    public Task<string> DisableCoilFieldLocation(int id, bool disable)
    {
      var coilFieldLocation = coilFieldLocationRepository.GetCoilFieldLocationById(id);
      if (coilFieldLocation == null)
      {
        throw new CoilTrackingException { HttpStatusCode = "NotFound" };
      }

      // Checking if any coil exist at that particular location
      if (disable && coilRepository.GetCoilByLocationId(id).Count > 0)
      {
        throw new CoilTrackingException { ErrorNumber = "400", HttpStatusCode = "BadRequest", ErrorMessage = ApplicationMessages.coilExistAtCoilLocation };
      }
      coilFieldLocation.Disabled = disable;

      try
      {
        coilFieldLocationRepository.SaveChanges(AuditActionType.EnableDisable);
      }
      catch (DbUpdateConcurrencyException)
      {
        if (coilFieldLocation == null)
        {
          throw new CoilTrackingException { HttpStatusCode = "NotFound" };
        }
        else
        {
          throw;
        }
      }

      logger.LogInformation(Constant.classname + "CoilFieldLocationsService" + Constant.methodname + "DisableCoilFieldLocation" + Constant.message + "Disable Coil Field Location");
      webSocketClientService.CoilLocationsUpdated();
      return Task.FromResult(ApplicationMessages.completed);
    }

    /// <summary>
    /// To update the coil Field Location
    /// </summary>

    public Task<string> UpdateCoilFieldLocationDto(int id, CoilFieldLocationDto coilFieldLocation)
    {
      try
      {
        var coilFieldLocationData = coilFieldLocationRepository.GetCoilFieldLocationById(id);

        // fetching zone for that particular location
        var coilFieldZone = coilFieldZoneRepository.GetCoilFieldZones(coilFieldLocation.ZoneId).FirstOrDefault();
        if (coilFieldLocation.Disabled && coilRepository.GetCoilByLocationId(id).Count > 0)
        {
          return Task.FromResult(ApplicationMessages.coilExistAtCoilLocation);
        }

        coilFieldLocationData.Column = coilFieldLocation.Column;
        coilFieldLocationData.Disabled = coilFieldLocation.Disabled;
        coilFieldLocationData.IsEmpty = coilFieldLocation.IsEmpty;
        coilFieldLocationData.Name = coilFieldLocation.Name;
        coilFieldLocationData.Row = coilFieldLocation.Row;
        coilFieldLocationData.Zone = coilFieldZone;
        coilFieldLocationRepository.SaveChanges(AuditActionType.ModifyEntity);
      }
      catch (DbUpdateConcurrencyException)
      {
        if (coilFieldLocationRepository.GetCoilFieldLocationById(id) == null)
        {
          throw new CoilTrackingException { HttpStatusCode = "NotFound" };
        }
        else
        {
          throw;
        }
      }

      logger.LogInformation(Constant.classname + "CoilFieldLocationsService" + Constant.methodname + "UpdateCoilFieldLocationDto" + Constant.message + "Updating Coil Field Location");
      webSocketClientService.CoilLocationsUpdated();
      return Task.FromResult(ApplicationMessages.completed);
    }

    /// <summary>
    /// To add the coil Field Location
    /// </summary>

    public async Task<CoilFieldLocationDto> AddCoilFieldLocation(CoilFieldLocationDto coilFieldLocation)
    {
      // fetching zone for that particular location
      var zones = coilFieldZoneRepository.GetCoilFieldZones(coilFieldLocation.ZoneId);
      var coilFieldLocationData = mapper.Map<CoilFieldLocation>(coilFieldLocation);
      if (zones.Count > 0)
      {
        coilFieldLocationData.Zone = zones.FirstOrDefault();
      }

    var CoilFieldLocation =  await  coilFieldLocationRepository.AddCoilFieldLocation(coilFieldLocationData);
      var coilFieldLocations =  mapper.Map<CoilFieldLocationDto>(CoilFieldLocation);
      logger.LogInformation(Constant.classname + "CoilFieldLocationsService" + Constant.methodname + "SaveCoilFieldLocation" + Constant.message + "Save new Coil Field Location");
     await webSocketClientService.CoilLocationsUpdated();
      return coilFieldLocations;
    }

    /// <summary>
    /// To delete the coil Field Location
    /// </summary>

    public CoilFieldLocationDto DeleteCoilFieldLocation(int id)
    {
      var coilFieldLocation = coilFieldLocationRepository.GetCoilFieldLocationById(id);
      if (coilFieldLocation == null)
      {
        throw new CoilTrackingException { HttpStatusCode = "NotFound" };
      }

      var coilFieldLocationData = mapper.Map<CoilFieldLocationDto>(coilFieldLocation);
      coilFieldLocationRepository.DeleteCoilFieldLocation(coilFieldLocation);

      logger.LogInformation(Constant.classname + "CoilFieldLocationsService" + Constant.methodname + "DeleteCoilFieldLocation" + Constant.message + "Delete Coil Field Location");
      webSocketClientService.CoilLocationsUpdated();
      return coilFieldLocationData;
    }

    public async Task<List<string>> CheckEditAsync(int id, CoilFieldLocationDto dto)
    {
      return await coilFieldLocationRepository.CheckEdit(id, dto);
    }
  }
}
