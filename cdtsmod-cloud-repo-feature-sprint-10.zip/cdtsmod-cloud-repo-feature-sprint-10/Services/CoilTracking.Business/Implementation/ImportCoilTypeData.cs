using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using CoilTracking.DTO;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class ImportCoilTypeData : IImportCoilTypeData
  {
    private readonly IMaterialTypesRepository materialTypesRepo;
    private readonly IApplicationLogger<ImportCoilTypeData> ServiceLogger;
    private readonly ICoilTypeRepository coilTypeRepo;
    private readonly ICoilFieldZoneRepository coilFieldZoneRepo;
    private readonly ICoilTypeYNARepository coilTypeYNARepo;
    public ImportCoilTypeData(ICoilTypeRepository coilTypeRepo, IMaterialTypesRepository materialTypesRepo, IApplicationLogger<ImportCoilTypeData> ServiceLogger, ICoilFieldZoneRepository coilFieldZoneRepo, ICoilTypeYNARepository coilTypeYNARepo)
    {
      this.coilTypeRepo = coilTypeRepo;
      this.materialTypesRepo = materialTypesRepo;
      this.ServiceLogger = ServiceLogger;
      this.coilFieldZoneRepo = coilFieldZoneRepo;
      this.coilTypeYNARepo = coilTypeYNARepo;
    }

    /// <summary>
    /// Enum for Excel sheet columns
    /// </summary>
    private enum Columns
    {
      YNumber = 1,
      CoilTypeName = 2,
      Zone = 3,
      Thickness = 4,
      Width = 5,
      Specification = 6,
      NumOfCoils = 7,
      Disabled = 8,
      NAMC = 9, //Unused column not really needed since one database will be for each NAMC any way?
      YieldPercent = 10,
      MinThickness = 11,
      MaxThickness = 12,
      MinWidth = 13,
      MaxWidth = 14,
      YNumberDisabled = 15,
      MaterialType = 16
    }
    /// <summary>
    /// CoilType data structure
    /// </summary>
    public struct CoilTypeRecord
    {
      public decimal thickness;
      public int width;
      public int numCoils;
      public decimal yield;
      public string zone;
      public string yNumber;
      public string coilTypeName;
      public string spec;
      public bool disabled;
      public decimal minThickness;
      public decimal maxThickness;
      public decimal minWidth;
      public decimal maxWidth;
      public bool yNumberDisabled;
      public int materialType;
    }

    /// <summary>
    /// To import the CoilType to excel
    /// </summary>
    /// <param name="ms"></param>
    /// <param name="userName"></param>
    /// <returns></returns>
    public async Task<List<DataImportMessage>> Import(MemoryStream ms, string userName)
    {
      List<DataImportMessage> messages = new List<DataImportMessage>();

      using (var package = DataImportHelper.GetPackageFromMemoryStream(ms, messages))
      {
        if (package != null && package.Workbook != null && package.Workbook.Worksheets.Count > 0)
        {
          //Data expected only in first worksheet or a worksheet named CoilType
          ExcelWorksheet worksheet = package.Workbook.Worksheets.Where(ws => string.Equals(ws.Name, "CoilType", StringComparison.InvariantCultureIgnoreCase)).DefaultIfEmpty(package.Workbook.Worksheets.First()).FirstOrDefault();
          List<DataImportMessage> newMessages = await ImportData(worksheet, userName);
          messages.AddRange(newMessages);
          ServiceLogger.LogInformation(Constant.classname + "ImportCoilTypeData" + Constant.methodname + "Import" + Constant.message + "To import the memory stream ");
        }
        else
        {
          messages.Add(new DataImportMessage(-1, "No valid worksheet found, make sure this is a valid XLSX (Excel 2007+) file", DataImportMessage.MsgType.Error));
        }
      }

      return messages;
    }
    /// <summary>
    /// Imports data
    /// </summary>
    /// <param name="worksheet"></param>
    /// <param name="userName"></param>
    /// <returns></returns>
    public async Task<List<DataImportMessage>> ImportData(ExcelWorksheet worksheet, string userName)
    {
      List<DataImportMessage> errors = new List<DataImportMessage>();
      int maxRows = worksheet.Dimension.End.Row;
      //Columns where each blank property is expected are fixed
      for (int row = 2; row <= maxRows; row++)
      {
        int originalErrorCount = errors.Count;
        CoilTypeRecord record = GetRecordFromRow(worksheet, errors, row);

        if (errors.Count > originalErrorCount)
        {
          //Errors on required fields, skip to next row
          continue;
        }
        CoilFieldZone coilFieldZone = coilFieldZoneRepo.GetCoilFieldZoneByName(record.zone);
        if (coilFieldZone == null)
        {
          errors.Add(new DataImportMessage(row, "Zone " + record.zone + " is missing in system", DataImportMessage.MsgType.Error));
          continue;
        }

        CoilType coilTypeEntry = null;
        //Check to make sure the Y# doesnt exist for a different coil type (that isn't disabled)

        var coilTypeYNAAlreadyExistsDiffCoilType = coilTypeYNARepo.GetcoilTypeYNAAlreadyExistsDiffCoilType(record.coilTypeName, record.yNumber);
        if (coilTypeYNAAlreadyExistsDiffCoilType != null)
        {
          errors.Add(new DataImportMessage(row, "Y # " + record.yNumber + " exists for a different Coil Type " + coilTypeYNAAlreadyExistsDiffCoilType.CoilType.Name, DataImportMessage.MsgType.Error));
          continue;
        }
        SetcoilTypeEntry(coilTypeEntry, record, row, errors);
        AuditActionType actionType = AuditActionType.ModifyEntity;
        coilTypeEntry = GetCoilTypeEntry(coilTypeEntry, record.yNumber);
        MaterialType materialType = materialTypesRepo.GetMaterialTypesById(record.materialType);
        if (materialType == null)
        {
          errors.Add(new DataImportMessage(row, "MaterialType " + record.zone + " is missing in system", DataImportMessage.MsgType.Error));
          continue;
        }
       
        try
        {
          actionType = await InsertCoilType(coilTypeEntry, record, materialType, actionType, coilFieldZone, row, errors);
          if (actionType == AuditActionType.CreateEntity)
          {
            errors.Add(new DataImportMessage(row, "New Coil Type " + record.coilTypeName + " entry created", DataImportMessage.MsgType.Notification));
          }
        }
        catch (Exception ex)
        {
          IsUpdateCoilType(actionType, coilTypeEntry, record, row, errors, ex);
        }

      }

      return errors;

    }
    /// <summary>
    /// Is UpdateCoilType
    /// </summary>
    /// <param name="actionType"></param>
    /// <param name="coilTypeEntry"></param>
    /// <param name="record"></param>
    /// <param name="row"></param>
    /// <param name="errors"></param>
    /// <param name="ex"></param>
    public void IsUpdateCoilType(AuditActionType actionType, CoilType coilTypeEntry, CoilTypeRecord record, int row, List<DataImportMessage> errors, Exception ex)
    {
      if (actionType == AuditActionType.CreateEntity)
      {
        errors.Add(new DataImportMessage(row, "Unidentified database error occured while creating new Coil Type (" + record.coilTypeName + ") entry", DataImportMessage.MsgType.Error));
        coilTypeRepo.RemoveCoilType(coilTypeEntry);
      }
      else
      {
        errors.Add(new DataImportMessage(row, "Unidentified database error occured updating Coil Type (" + record.coilTypeName + ") entry", DataImportMessage.MsgType.Error));
        coilTypeRepo.UnchangedCoilType(coilTypeEntry);
      }
      errors.Add(new DataImportMessage(row, ex.ToString(), DataImportMessage.MsgType.ErrorDetails));
    }


    /// <summary>
    /// Set coilTypeEntry
    /// </summary>
    /// <param name="coilTypeEntry"></param>
    /// <param name="record"></param>
    /// <param name="row"></param>
    /// <param name="errors"></param>
    public void SetcoilTypeEntry(CoilType coilTypeEntry, CoilTypeRecord record, int row, List<DataImportMessage> errors)
    {
      try
      {
        if (coilTypeRepo.IsCoilTypeByName(record.coilTypeName))
        {
          //We have a coil type with the same name, check to see if the Y# exists for that coil type, if not add it
          var existingYNum = coilTypeYNARepo.GetCoilTypeYNAByNumberWithcoilTypeName(record.coilTypeName, record.yNumber);
          if (existingYNum != null)
          {
            ValidateExistingYNum(existingYNum, record, row, errors);
          }
          else
          {
            //It's possible we have an existing CoilType with existing YNA #'s, but we are adding a new YNA # to the list
            coilTypeEntry = coilTypeRepo.GetCoilTypeByName(record.coilTypeName);
            coilTypeEntry.CoilTypeYNAs.Add(new CoilTypeYNA()
            {
              YNA = record.yNumber,
              DateAdded = DateTime.Now,
              Disabled = record.yNumberDisabled
            });
            errors.Add(new DataImportMessage(row, "New Y # " + record.yNumber + " added to existing Coil Type " + record.coilTypeName, DataImportMessage.MsgType.Notification));
          }
        }
      }
      catch(Exception ex)
      {
        IsUpdateCoilType(AuditActionType.EnableDisable, coilTypeEntry, record, row, errors, ex);
      }
    }

    /// <summary>
    /// Validate ExistingYNum
    /// </summary>
    /// <param name="existingYNum"></param>
    /// <param name="record"></param>
    /// <param name="row"></param>
    /// <param name="errors"></param>
    public void ValidateExistingYNum(CoilTypeYNA existingYNum, CoilTypeRecord record, int row, List<DataImportMessage> errors)
    {
      if (existingYNum.Disabled != record.yNumberDisabled)
      {
        existingYNum.Disabled = record.yNumberDisabled; //Allow disabling existing Y#'s
        errors.Add(new DataImportMessage(row, "Y # " + record.yNumber + " Disabled changed to: " + record.yNumberDisabled, DataImportMessage.MsgType.Notification));

        //Check if all Y#'s are disabled, if so, then disable the CoilType 
        if (existingYNum.Disabled && existingYNum.CoilType.CoilTypeYNAs.All(cty => cty.Disabled))
        {
          existingYNum.CoilType.Disabled = true;
          errors.Add(new DataImportMessage(row, "Coil Type " + existingYNum.CoilType.Name + " Disabled since we have no Y# that are enabled.", DataImportMessage.MsgType.Notification));
        }

        if (existingYNum.CoilType.Disabled //if the coil type is currently disabled
          && existingYNum.CoilType.CoilTypeYNAs.Any(cty => !cty.Disabled)) //Check if any Y#'s are enabled, if so, then enable the CoilType
        {
          existingYNum.CoilType.Disabled = false;
          errors.Add(new DataImportMessage(row, "Coil Type " + existingYNum.CoilType.Name + " Enabled since we have a Y# that's not disabled.", DataImportMessage.MsgType.Notification));
        }
      }

    }

    /// <summary>
    /// Insert CoilType
    /// </summary>
    /// <param name="coilTypeEntry"></param>
    /// <param name="record"></param>
    /// <param name="materialType"></param>
    /// <param name="actionType"></param>
    /// <param name="coilFieldZone"></param>
    /// <returns></returns>
    public async Task<AuditActionType> InsertCoilType(CoilType coilTypeEntry, CoilTypeRecord record, MaterialType materialType, AuditActionType actionType, CoilFieldZone coilFieldZone, int row, List<DataImportMessage> errors)
    {
        if (coilTypeEntry == null)
        {
          coilTypeEntry = new CoilType();
        try
        {
          coilTypeEntry.CoilTypeYNAs = new List<CoilTypeYNA>()
                        {
                            new CoilTypeYNA()
                            {
                                YNA = record.yNumber,
                                DateAdded = DateTime.Now,
                                Disabled = record.yNumberDisabled,
                                MaterialType = materialType
                            }
                        };
          coilTypeEntry.CoilFieldZone = coilFieldZone;
          coilTypeEntry.Name = record.coilTypeName;
          coilTypeEntry.Thickness = record.thickness;
          coilTypeEntry.Width = record.width;
          coilTypeEntry.Spec = record.spec;
          coilTypeEntry.NumCoils = record.numCoils;
          coilTypeEntry.Yield = record.yield;
          coilTypeEntry.Disabled = record.disabled;
          coilTypeEntry.MinThickness = record.minThickness;
          coilTypeEntry.MaxThickness = record.maxThickness;
          coilTypeEntry.MinWidth = record.minWidth;
          coilTypeEntry.MaxWidth = record.maxWidth;
        }
        catch (Exception ex)
        {
          IsUpdateCoilType(actionType, coilTypeEntry, record, row, errors, ex);
        }
          actionType = AuditActionType.CreateEntity;
          coilTypeRepo.AddCoilType(coilTypeEntry);
          try
          {
            await coilTypeRepo.SaveChangesAsync();
            return actionType;
          }
          catch (Exception ex)
          {
            IsUpdateCoilType(actionType, coilTypeEntry, record, row, errors, ex);
          }
        }
        else
        {
          coilTypeEntry.CoilFieldZone = coilFieldZone;
          coilTypeEntry.Name = record.coilTypeName;
          coilTypeEntry.Thickness = record.thickness;
          coilTypeEntry.Width = record.width;
          coilTypeEntry.Spec = record.spec;
          coilTypeEntry.NumCoils = record.numCoils;
          coilTypeEntry.Yield = record.yield;
          coilTypeEntry.Disabled = record.disabled;
          coilTypeEntry.MinThickness = record.minThickness;
          coilTypeEntry.MaxThickness = record.maxThickness;
          coilTypeEntry.MinWidth = record.minWidth;
          coilTypeEntry.MaxWidth = record.maxWidth;
         
          try
          {

            await coilTypeRepo.ModifyCoilTypes(coilTypeEntry);
          actionType = AuditActionType.ModifyEntity;
          return actionType;
          }
          catch (Exception ex)
          {
            IsUpdateCoilType(actionType, coilTypeEntry, record, row, errors, ex);
          }
        }
      return AuditActionType.EnableDisable;

    }
    /// <summary>
    /// Get CoilTypeEntry
    /// </summary>
    /// <param name="coilTypeEntry"></param>
    /// <param name="yNumber"></param>
    /// <returns></returns>
    public CoilType GetCoilTypeEntry(CoilType coilTypeEntry, string yNumber)
    {
      if (coilTypeEntry == null)
      {
        coilTypeEntry = coilTypeYNARepo.GetCoilTypeByRecordNumber(yNumber);
      }
      return coilTypeEntry;
    }

    /// <summary>
    /// Get Record From Row
    /// </summary>
    /// <param name="worksheet"></param>
    /// <param name="errors"></param>
    /// <param name="row"></param>
    /// <returns></returns>
    private static CoilTypeRecord GetRecordFromRow(ExcelWorksheet worksheet, List<DataImportMessage> errors, int row)
    {
      CoilTypeRecord record = new CoilTypeRecord();

      errors.AddRange(DataImportHelper.GetDecimal(worksheet, row, (int)Columns.Thickness, Columns.Thickness.ToString(), out record.thickness));
      errors.AddRange(DataImportHelper.GetInt(worksheet, row, (int)Columns.Width, Columns.Width.ToString(), out record.width));
      errors.AddRange(DataImportHelper.GetInt(worksheet, row, (int)Columns.NumOfCoils, Columns.NumOfCoils.ToString(), out record.numCoils));
      errors.AddRange(DataImportHelper.GetDecimal(worksheet, row, (int)Columns.YieldPercent, Columns.YieldPercent.ToString(), out record.yield));
      errors.AddRange(DataImportHelper.GetString(worksheet, row, (int)Columns.Zone, Columns.Zone.ToString(), out record.zone));
      errors.AddRange(DataImportHelper.GetString(worksheet, row, (int)Columns.YNumber, Columns.YNumber.ToString(), out record.yNumber));
      errors.AddRange(DataImportHelper.GetString(worksheet, row, (int)Columns.CoilTypeName, Columns.CoilTypeName.ToString(), out record.coilTypeName));
      errors.AddRange(DataImportHelper.GetString(worksheet, row, (int)Columns.Specification, Columns.Specification.ToString(), out record.spec));
      errors.AddRange(DataImportHelper.GetBool(worksheet, row, (int)Columns.Disabled, Columns.Disabled.ToString(), out record.disabled));
      errors.AddRange(DataImportHelper.GetDecimal(worksheet, row, (int)Columns.MinThickness, Columns.MinThickness.ToString(), out record.minThickness, true));
      errors.AddRange(DataImportHelper.GetDecimal(worksheet, row, (int)Columns.MaxThickness, Columns.MaxThickness.ToString(), out record.maxThickness, true));
      errors.AddRange(DataImportHelper.GetDecimal(worksheet, row, (int)Columns.MinWidth, Columns.MinWidth.ToString(), out record.minWidth, true));
      errors.AddRange(DataImportHelper.GetDecimal(worksheet, row, (int)Columns.MaxWidth, Columns.MaxWidth.ToString(), out record.maxWidth, true));
      errors.AddRange(DataImportHelper.GetBool(worksheet, row, (int)Columns.YNumberDisabled, Columns.YNumberDisabled.ToString(), out record.yNumberDisabled, true));
      errors.AddRange(DataImportHelper.GetInt(worksheet, row, (int)Columns.MaterialType, Columns.MaterialType.ToString(), out record.materialType));

      return record;
    }

  }
}
