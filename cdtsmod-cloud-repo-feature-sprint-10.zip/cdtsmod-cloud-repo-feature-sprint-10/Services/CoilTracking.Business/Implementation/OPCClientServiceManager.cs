
using CoilTracking.Business.Interfaces;
using CoilTracking.Common.Constants;
using CoilTracking.Common.Exception;
using CoilTracking.Common.Logging;
using CoilTracking.Data.Models;
using CoilTracking.DataAccess.Interfaces;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.Business.Implementation
{
  public class OPCClientServiceManager : IOPCClientServiceManager
  {
    private readonly ILineRepository lineRepo;
    private readonly IHttpContextAccessor httpContextAccessor;
    private readonly IPLCIntegrationService plcService;

    private readonly IApplicationLogger<OPCClientServiceManager> logger;
    public OPCClientServiceManager(ILineRepository lineRepo,
      IHttpContextAccessor httpContextAccessor, IPLCIntegrationService plcService, IApplicationLogger<OPCClientServiceManager> logger)
    {
      this.lineRepo = lineRepo;
      this.httpContextAccessor = httpContextAccessor;
      this.plcService = plcService;
      this.logger = logger;
    }


    public async Task GetLineInfoData(Line line, bool subscribe, string token=null)
    {
      LineInfo lineInfo = new LineInfo
      {
        lineId = line.Id,
        kepHostName = line.OPCServer.ServerName,
        kepServerInstance = line.OPCServer.InstanceName,
        linePath = line.LinePath,
        plcTags = line.Tags.Split(','),
        responseUrl = GetLineInfoResponseUrl()
      };
      logger.LogInformation(Constant.methodname + "GetLineInfoData" + Constant.message + "Before calling PLC service ");

      try
      {

        int responseResult =subscribe? plcService.SubscribeLineData(lineInfo, token): plcService.UnSubscribeLineData(lineInfo, token);
        logger.LogInformation(Constant.methodname + "GetLineInfoData" + Constant.message + "After calling PLC service  = " + responseResult);

        if (responseResult!=0)
        {
          throw new CoilTrackingException { HttpStatusCode = "InternalServerError" };
        }
        line.Subscribed = subscribe;
        await lineRepo.UpdateLineSubscription(line);
      }
      catch (Exception e )
      {
        logger.LogError("PLC exception" + e.Message + " Inner Exception=" + e.InnerException + "stackTrace=" + e.StackTrace);
        throw new CoilTrackingException { HttpStatusCode = "InternalServerError" , ErrorMessage="PLC exception"+e.Message+" Inner Exception="+ e.InnerException+"stackTrace="+e.StackTrace};
      }
    }

    public string TestPLC()
    {
      var val = plcService.TestPLC();
      return val;
    }

    public List<LineInfo> GetLineInfos(List<Line> lineConfigs)
    {
      List<LineInfo> lineInfos = new List<LineInfo>();
      foreach (var lineConfig in lineConfigs)
      {
        LineInfo lineInfo = new LineInfo();
        lineInfo.lineId = lineConfig.Id;
        lineInfo.kepHostName = lineConfig.OPCServer.ServerName;
        lineInfo.kepServerInstance = lineConfig.OPCServer.InstanceName;
        lineInfo.linePath = lineConfig.LinePath;
        lineInfo.plcTags = lineConfig.Tags.Split(',');
        lineInfo.responseUrl = GetLineInfoResponseUrl();

        lineInfos.Add(lineInfo);
      }

      return lineInfos;
    }

    /// <summary>
    /// Get the absolute uri of request
    /// </summary>
    /// <returns></returns>
    private string GetLineInfoResponseUrl()
    {
      var request = httpContextAccessor.HttpContext.Request;
      UriBuilder uriBuilder = new UriBuilder();
      uriBuilder.Scheme = request.Scheme;
      uriBuilder.Host = request.Host.Host;
      uriBuilder.Path = request.Path.ToString();
      uriBuilder.Query = request.QueryString.ToString();
      var uri = uriBuilder.Uri.AbsoluteUri;
      uri = uri.Substring(0, uri.IndexOf("Lines")) + "Lines/PostLineData";
      return uri;
    }
  }
  



}
