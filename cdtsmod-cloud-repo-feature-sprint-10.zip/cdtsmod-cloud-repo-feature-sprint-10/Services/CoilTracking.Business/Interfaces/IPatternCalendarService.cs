using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface IPatternCalendarService
  {
    public List<CalendarItemDto> GetPatternCalendars();

    public Task<PatternCalendarExportDto> GetPatternCalendarsForExport();

    public Task<PatternCalendarDto> GetPatternCalendar(int id);

    public Task<List<CalendarItemDto>> GetPatternCalendar(DateTime localDate, int lineId, int shiftId);

    public Task<bool> ChangePattern(int id, string patternLetter);

    public Task<bool> PutPatternCalendar(PatternCalendarDto patternCalendarDto);

    public Task<PatternCalendarDto> PostPatternCalendar(PatternCalendarDto patternCalendarDto);

    public Task<PatternCalendarDto> DeletePatternCalendar(int id);
  }
}
