using CoilTracking.Business.TMMI;

namespace CoilTracking.Business.Interfaces
{
  public interface ICoilFactory
  {
    ICoilsFTZForTMMI Create();
  }
}
