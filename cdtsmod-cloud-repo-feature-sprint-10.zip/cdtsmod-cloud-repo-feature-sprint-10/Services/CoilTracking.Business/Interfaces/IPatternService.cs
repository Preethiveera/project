using CoilTracking.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface IPatternService
  {
    public Task<List<PatternForExportDto>> GetPatternsForExport();

    public Task<List<PatternDto>> GetPatterns();

    public Task<PatternDto> GetPattern(int id);

    public Task<PatternDto> GetPattern(int lineId, string patternLetter, int year, int month);

    public Task<bool> PutPattern(int id, PatternDto patternDto);

    public Task<PatternDto> PostPattern(PatternDto patternDto);

    public Task<PatternDto> DeletePattern(int id);    
  }
}
