using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface IRunOrderListService
  {
    Task<List<RunOrderListForGet>> GetRunOrderLists();
    Task<RunOrderListForGet> GetRunOrderListById(int id);
    public Task MarkRunOrderItemsIncomplete(List<IncompleteRunOrderItemDto> incompleteItems);
    public Task MarkRunOrderItemStatus(int runOrderItemId, RunOrderItemStatusDto status);
    public Task<RunOrderListForCreate> CreateRunOrderList(DateTime date, int lineId, int shiftId);
    public Task<RunOrderListForGet> GetRunOrderItemForGet(DateTime date, int lineId, int shiftId);

    public Task<bool> DeleteRunOrderList(int id);
    public Task<RunOrderListForCreate> SaveRunOrderList(RunOrderListForUpdate runOrderList);

    public Task UpdateRunOrderList(int id, RunOrderListForUpdate runOrderList);
  }

}
