using CoilTracking.DTO;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface IShiftService
  {
    Task<IQueryable<ShiftDto>> GetShifts();

    Task<ShiftDto> GetShiftById(int id);

    Task<ShiftDto> GetCurrentShift(int lineId);

    Task<ShiftDto> GetNextShift(int lineId);

    Task PutShift(int id, ShiftDto shift);

    Task DisableShift(int id, bool disable);

    Task<ShiftDto> AddShift(ShiftDto shift);

    Task<ShiftDto> DeleteShift(int id);

    Task<List<string>> CheckEdit(int id, ShiftDto shift);

    Task<List<string>> CheckDependency(int id);
  }
}
