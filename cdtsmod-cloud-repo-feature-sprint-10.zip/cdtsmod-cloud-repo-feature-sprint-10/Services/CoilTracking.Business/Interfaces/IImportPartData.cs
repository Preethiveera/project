using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
 public interface IImportPartData
  {
    Task<List<DataImportMessage>> Import(MemoryStream ms, string userName);
  }
}
