namespace CoilTracking.Business.Interfaces
{
  public interface IScheduledReportBatchService
  {
    void GetReports();
  }
}
