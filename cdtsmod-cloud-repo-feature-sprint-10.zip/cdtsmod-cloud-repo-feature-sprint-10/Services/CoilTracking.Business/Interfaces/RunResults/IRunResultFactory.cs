using System;
using System.Collections.Generic;
using System.Text;

namespace CoilTracking.Business.Interfaces
{
 public interface IRunResultFactory
  {
    IRunResultftzManager Create();
  }
}
