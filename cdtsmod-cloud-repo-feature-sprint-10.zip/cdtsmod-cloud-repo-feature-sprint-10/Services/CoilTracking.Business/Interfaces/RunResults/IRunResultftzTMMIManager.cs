using CoilTracking.Data.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
 public interface IRunResultftzTMMIManager
  {
    Task<List<Coil>> GetRunResultCoilFTZByPrefix(string ftz);
  }
}
