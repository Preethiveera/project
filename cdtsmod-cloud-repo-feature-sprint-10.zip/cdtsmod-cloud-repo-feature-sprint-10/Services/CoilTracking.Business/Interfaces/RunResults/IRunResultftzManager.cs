using CoilTracking.Data.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
 public interface IRunResultftzManager
  {
    Task<List<Coil>> GetRunResultCoilFTZByPrefix(string ftz);
  }
}
