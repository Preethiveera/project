using CoilTracking.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface IModelService
  {
    Task<List<string>> CheckDependency(int id);
    Task<bool> CheckEdit(int id, ModelDto modelDto);
    Task<ModelDto> DeleteModel(int id);
    Task<bool> DisableModel(int id, bool disable);
    Task<ModelDto> GetModel(int id);
    Task<List<ModelDto>> GetModels();
    Task<List<PartModelDto>> GetPartsInRunOrderByModelId(int id);
    Task<List<PartDto>> GetPartsRelatedToModels(int id);
    Task<ModelDto> PostModel(ModelDto modelDto);
    Task<bool> PutModel(ModelDto modelDto);
  }
}
