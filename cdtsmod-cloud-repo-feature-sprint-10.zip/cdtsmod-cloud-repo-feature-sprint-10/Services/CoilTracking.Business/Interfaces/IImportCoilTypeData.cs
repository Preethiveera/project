using CoilTracking.DTO;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface IImportCoilTypeData
  {
    Task<List<DataImportMessage>> Import(MemoryStream ms, string userName);
  }
}
