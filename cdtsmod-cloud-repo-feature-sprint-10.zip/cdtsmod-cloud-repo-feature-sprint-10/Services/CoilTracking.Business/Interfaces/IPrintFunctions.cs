using CoilTracking.DTO;

namespace CoilTracking.Business.Interfaces
{
  public interface IPrintFunctions
  {
    string GetZPLTemplateString(ZPLParametersDto ZPLParameters);

    string GetTemplate(string filename, string fileLocation);

    PrinterConfigDto GetPrinterConfigValuesByPrinterName(string strNAMC, string PrinterName);

    PrinterConfigDto GetPrinterConfigValues(string strNAMC, string lineName);

    bool PrintFunction(string ZPLprintTemplate, string PrinterIPAddress, int port);
  }
}
