using CoilTracking.DTO;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface IProdPlanService
  {
    Task<IQueryable<ProdPlanDto>> GetProdPlans();

    Task<ProdPlanDto> GetProdPlanById(int id);

    Task<bool> PutProdPlan(int id, ProdPlanDto prodPlan);

    Task<ProdPlanDto> PostProdPlan(ProdPlanDto prodPlan);

    Task<ProdPlanDto> DeleteProdPlan(int id);
  }
}
