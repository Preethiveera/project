﻿using CoilTracking.DTO;
using System.Collections.Generic;
using System.IO;

namespace CoilTracking.Business.Interfaces
{
  public interface IImportBlankData
  {
    public List<DataImportMessage> Import(MemoryStream ms, string userName);
  }
}
