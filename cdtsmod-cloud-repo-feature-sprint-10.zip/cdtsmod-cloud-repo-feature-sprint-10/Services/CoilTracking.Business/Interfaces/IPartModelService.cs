using CoilTracking.DTO;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface IPartModelService
  {
    Task<IQueryable<PartModelDto>> GetPartModels();

    Task<PartModelDto> GetPartModelById(int id);

    Task PutPartModel(int id, PartModelDto partModel);

    Task<PartModelDto> AddPartModel(PartModelDto partModel);

    Task<PartModelDto> DeletePartModel(int id);
  }
}
