using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface IWebSocketClientService
  {
    Task BlankingRunStarted(int lineId, int dataNum);
    Task BlankingRunStopped(int lineId, int dataNum, int pressCount);
    Task CoilLoaded(int lineId, int coilId);
    Task CoilLocationsUpdated();
    Task CoilODWarning(int lineId);
    Task RunOrderListUpdated(int lineId, int runOrderListId);
    Task UpdateDt(UpdateDtDto updateDtDto);
    Task UpdateNotificationCount(int unfulfilledRequestCount);
    Task UpdateStackerCount(int lineId, int dataNumber, int stackerCount);
    Task UpdateStrokeCount(int lineId, int dataNumber, int strokeCount);
  }
}
