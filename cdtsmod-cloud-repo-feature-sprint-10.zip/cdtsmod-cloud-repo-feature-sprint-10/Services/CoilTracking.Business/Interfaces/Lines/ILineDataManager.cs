using CoilTracking.Data.Models;
using CoilTracking.DTO;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces.Lines
{
  public interface ILineDataManager
  {
    Task<LineData> ProcessSavedData(LineData savedData, LineData lineData, Line line, string[] plcTags, DataUpdateDto currentValues);

    Task<LineData> CreateNewRun(LineData lineData, DataUpdateDto currentValues);
  }
}
