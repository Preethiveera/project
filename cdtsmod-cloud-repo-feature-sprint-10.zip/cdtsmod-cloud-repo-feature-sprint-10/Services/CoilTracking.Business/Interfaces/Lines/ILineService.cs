
using CoilTracking.Data.Models;
using CoilTracking.DTO;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface ILineService
  {
    List<AndonBlankingLinesDto> GetLinesForAndons();

    Task<IQueryable<LineDto>> GetLines();

    Task<LineDto> GetLineById(int id);

    Task<LineDto> GetLineForEdit(int id);

    Task<LineDto> UpdateLineSubscription(int id, bool subscribe, string token=null);

    Task<List<LineInfo>> GetSubscribedLines(string namcCode);

    Task<bool> DisableLine(int id, bool disable);

    Task<bool> PutLine(LineDto line);

    Task<LineDto> UpdateLine(int id, LineDto lineDto);

    Task<int> AddLine(LineDto line);

    Task<LineDto> SaveLine(LineDto lineDto);

    Task<LineDataDto> PostLineData(LineDataDto lineDataDto);

    Task<LineDto> DeleteLine(int id);

    Task<List<string>> CheckEdit(int id, LineDto line);

    Task<List<string>> CheckDependency(int id);
    public string TestPLC();
    Task<LineData> GetLinesData(int lineId);
  }
}
