﻿namespace CoilTracking.Business.Interfaces
{
  public interface IAdminInfoService
  {

    public object GetDashboardCounts();

  }
}
