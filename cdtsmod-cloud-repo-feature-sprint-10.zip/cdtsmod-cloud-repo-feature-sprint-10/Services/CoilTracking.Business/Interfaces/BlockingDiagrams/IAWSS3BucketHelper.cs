using Microsoft.AspNetCore.Http;
using System.IO;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces.BlockingDiagrams
{
  public interface IAWSS3BucketHelper
  {
    Task<bool> UploadFile(System.IO.Stream inputStream, string fileName);

    Task<Stream> GetFile(string key);
    Task<bool> DeleteFile(string dataNum);
    Task<bool> UploadFileAsyncTransferUtility(IFormFile file, string keyName);

  }
}
