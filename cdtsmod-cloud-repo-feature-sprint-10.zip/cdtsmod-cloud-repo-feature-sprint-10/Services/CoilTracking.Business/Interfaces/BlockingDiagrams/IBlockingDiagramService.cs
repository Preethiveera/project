using CoilTracking.DTO;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface IBlockingDiagramService
  {
    Task<List<BlockingDiagramDto>> GetBlockingDiagrams();
    Task<BlockingDiagramDto> GetBlockingDiagramById(int id);
    Task<Stream> GetFile(int dataNum);
    Task<BlockingDiagramDto> DeleteBlockingDiagram(int id);
    Task<bool> UpdateBlockingDiagram(IFormFile uploadFileName, int dataNum, int id);
    Task<List<DataImportMessage>> ImportBlockingDiagram(IFormFileCollection selectedFiles);

    Task<bool> UploadFile(IFormFile uploadFileName, int dataNum);
  }
}
