using CoilTracking.DTO;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface IScheduleReportService
  {
    IQueryable<ScheduleReportDto> GetScheduleReport();
    ScheduleReportDto GetScheduleReportById(int id);
    Task<int> PostScheduleReport(ScheduleReportDto scheduleReportDto);
    bool PutScheduleReport(int id, ScheduleReportDto scheduleReportDto);
    ScheduleReportDto DeleteScheduleReport(int id);

  }
}
