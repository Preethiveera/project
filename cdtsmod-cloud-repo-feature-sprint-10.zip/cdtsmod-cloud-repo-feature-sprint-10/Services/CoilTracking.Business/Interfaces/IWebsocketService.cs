using CoilTracking.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface IWebsocketService
  {
    Task Connect(ConnectionModelDto connection);
    Task Disconnect(ConnectionModelDto connection);
    Task SendMessageToGroup(string[] groups, string action, object payload);
  }
}
