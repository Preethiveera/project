﻿namespace CoilTracking.Business.Interfaces
{
  public interface IScheuledReportBatchService
  {
  }
}
