﻿using CoilTracking.Business.Interfaces;

namespace CoilTracking.Business.Kentucky
{
  public interface IImportBlankInfoFactory
  {
    IImportBlank Create();
  }
}
