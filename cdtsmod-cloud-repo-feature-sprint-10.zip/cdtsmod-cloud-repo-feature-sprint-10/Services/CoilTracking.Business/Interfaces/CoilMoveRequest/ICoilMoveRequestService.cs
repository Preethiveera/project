using CoilTracking.Data.Models;
using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface ICoilMoveRequestService
  {
    Task<IQueryable<CoilMoveRequestDto>> GetCoilMoveRequests();

    Task<IQueryable<CoilMoveRequestDto>> GetPendingRequestsByLine(int lineId, DateTime? startTime = null, DateTime? endTime = null);

    Task<List<CoilMoveRequestDto>> GetUnfulfilledCoilMoveRequests();

    Task<bool> CancelCoilMove(int id);

    Task<CoilMoveRequestDto> RequestCoilMove(int lineId, int coilTypeId, CoilMoveRequestType requestType, int? coilId = null);

    Task<CoilMoveRequestDto> FulfillCoilMoveRequest(int id, string newLocation, string newWeight);

    Task<CoilMoveRequestDto> GetCoilMoveRequestAsync(int id);

    Task<CoilMoveRequestDto> PostCoilMoveRequestAsync(CoilMoveRequestDto coilMoveRequest);

    Task<CoilMoveRequestDto> DeleteCoilMoveRequest(int id);

    Task<List<CoilDto>> GetLoadedCoils(int lineId, int shiftId);
  }
}
