using CoilTracking.Data.Models;

namespace CoilTracking.Business.Interfaces.CoilMoveRequest
{
  public interface ICoilMoveRequestFactory
  {
    ICoilMoveRequestManager Create(CoilMoveRequestType requestType);
  }
}
