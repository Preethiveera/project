using CoilTracking.Data.Models;
using CoilTracking.DTO;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface ICoilMoveRequestManager
  {
    Task<CoilMoveRequestModel> RequestCoilMove(CoilType coilType, CoilMoveRequestType requestType, int? coilId = null);

    Task<Data.Models.CoilMoveRequest> FullFillCoilMove(Data.Models.CoilMoveRequest coilMoveRequest, string newWeight = null, string newLocation = null);
  }
}
