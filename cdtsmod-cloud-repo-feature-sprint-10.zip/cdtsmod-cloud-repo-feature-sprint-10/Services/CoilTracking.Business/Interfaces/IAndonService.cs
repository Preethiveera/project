﻿using CoilTracking.DTO;

namespace CoilTracking.Business.Interfaces
{
  public interface IAndonService
  {

    /// <summary>
    /// 
    /// </summary>
    /// <param name="zoneId"></param>
    /// <returns></returns>
    AndonCoilFieldZoneDisplayObject GetCoilsFeildsByZoneId(int? zoneId);
    /// <summary>
    /// 
    /// </summary>
    /// <param name="zoneId"></param>
    /// <returns></returns>
    AndonCoilTypesByZoneDisplayObject GetCoilsTypesByZoneId(int? zoneId);
  }
}
