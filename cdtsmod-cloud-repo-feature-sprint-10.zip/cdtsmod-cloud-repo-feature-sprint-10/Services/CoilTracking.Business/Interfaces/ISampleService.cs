﻿namespace CoilTracking.Business.Interfaces
{
  public interface ISampleService
  {
  }
}
