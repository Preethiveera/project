﻿using CoilTracking.DTO;
using OfficeOpenXml;
using System.Collections.Generic;
using static CoilTracking.Business.Implementation.ImportBlankData;

namespace CoilTracking.Business.Interfaces
{
  public interface IImportBlank
  {
    public abstract BlankDataRecord GetRecordFromRow(ExcelWorksheet worksheet, List<DataImportMessage> errors, int row);


  }
}
