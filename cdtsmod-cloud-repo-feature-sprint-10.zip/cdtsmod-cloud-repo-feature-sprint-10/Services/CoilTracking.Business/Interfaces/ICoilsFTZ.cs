using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface ICoilsFTZ
  {
    Task<Data.Models.Coil> GetCoilFTZByPrefix(string ftz);
  }
}
