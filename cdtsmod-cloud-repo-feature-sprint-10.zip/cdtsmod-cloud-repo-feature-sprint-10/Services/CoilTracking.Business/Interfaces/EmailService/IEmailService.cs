using CoilTracking.DTO;
using System.Net.Mail;

namespace CoilTracking.Business.Interfaces.EmailService
{
  public interface IEmailService
  {
    SendEmailModel CreateSMTPClient(EmailModel request);

    void SendEmail(MailMessage message, SmtpClient smtp);
  }
}
