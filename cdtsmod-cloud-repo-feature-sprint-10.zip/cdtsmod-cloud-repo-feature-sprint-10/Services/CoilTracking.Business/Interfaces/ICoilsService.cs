using CoilTracking.Data.Models;
using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface ICoilsService
  {
    string GetModelListFromPart(Part part, List<PartModel> partModels);
    Task<List<CoilDto>> GetCoils();
    Task<string> GetPlantCode();
    Task<List<CoilDto>> SearchForCoils(DateTime? startTime = null, DateTime? endTime = null, string coilType = null,
      int? coilStatusId = null, int? zoneId = null, string FilterByBornOnDate = "0");

    Task<List<CoilInventoryDto>> GetCoilInventory();
    Task<CoilDto> GetCoilsById(int id);


    Task<CoilDto> GetCoilByFTZ(string ftz);

    Task<CoilDto> GetCoilsLocationName(string coilFieldLocationFullName);

    Task<CoilDto> GetCoilsByLocationId(int id);

    Task<CoilDto> GetCoilForModify(int CoilId);

    Task<List<CoilDto>> GetCoilsToBeWeighed();
    Task<decimal> GetRemainingCoilWeightById(int id);
    Task<string> GetMaterialTypeByYNA(string yna);

    Task<List<string>> CheckDependency(int id);

    Task<CoilDto> InsertCoil(Coil coil);
    Task<CoilDto> DeleteCoilById(int id);

    Task<List<string>> CoilCheckEdit(int id, CoilDto dto);

    Task<int> UpdateCoil(int id, Coil coil);
    Task<string> UpdateUnAccountedWeight(int id, int unAccountedWeight);

    Task<CoilDto> CoilsCheckIn(CoilCheckIn coilCheckIn);

    Task<string> UpdateCoilRunHistory(int coilId, int runOrderListId, int weightUsed);

    Task<string> UpdateMoveCoilsByIds(int coilId, string newLocation, int newStatusId, bool isPriorityCoil = false, int? lineId = null);

    Task<List<Coil>> GetCoilsInInventoryAsync();

    Task<string> UpdateCoilsByIdDto(int id, CoilDto dto);

  }
}
