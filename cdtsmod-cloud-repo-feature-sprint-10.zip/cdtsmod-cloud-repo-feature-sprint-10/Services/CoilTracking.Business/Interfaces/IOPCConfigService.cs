using CoilTracking.DTO;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface IOPCConfigService
  {
    Task<IQueryable<OPCConfigDTO>> GetOPCConfigs();
    Task<OPCConfigDTO> GetOPCConfigById(int id);

    Task<List<LineDto>> GetDependencyForKep(int id);

    public void UpdateOPCConfig(int id, OPCConfigDTO oPCConfig);

    public Task DisableOPCConfig(int id, bool disable);

    public Task<OPCConfigDTO> InsertOPCConfig(OPCConfigDTO opcconfig);

    public Task<OPCConfigDTO> DeleteOPCConfig(int id);

    public Task<List<LineDto>> GetLinesInRunOrderById(int id);
    public Task<bool> CheckIfEdited(int id, OPCConfigDTO oPCConfig);
  }
}
