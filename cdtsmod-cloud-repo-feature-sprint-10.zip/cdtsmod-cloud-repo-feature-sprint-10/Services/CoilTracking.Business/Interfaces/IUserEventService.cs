using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface IUserEventService
  {
    public Task<List<UserEventDto>> GetUserEvents();
    public Task<List<UserEventDto>> GetUserEventsBetween(DateTime? startTime = null, DateTime? endTime = null, string username = null);
    public Task<UserEventDto> GetUserEventById(int id);
    public void UpdateUserEvent(int id, UserEventDto userEvent);

    public Task<UserEventDto> InsertUserEvent(UserEventDto userEvent);
    public Task<UserEventDto> DeleteUserEvent(int id);
  }
}
