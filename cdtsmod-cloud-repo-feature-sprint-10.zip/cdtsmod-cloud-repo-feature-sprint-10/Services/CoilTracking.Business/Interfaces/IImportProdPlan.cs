using CoilTracking.DTO;
using OfficeOpenXml;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface IImportProdPlan
  {
   Task<List<DataImportMessage>> Import(MemoryStream ms, string userName);

    Task<List<DataImportMessage>> ImportData(ExcelWorksheet worksheet, string userName);
  }
}
