using CoilTracking.DTO;
using Newtonsoft.Json.Linq;
using System;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface IPrintTagService
  {
    Task<CurrentRunListForGet> GetCurrentRunListAsync(int id);

    Task<PrintResultDto> PrintBlankTagAsync(string printType, JObject data, DateTime? heatTreatDate = null, string partNumber = null, string stackSize = null, string lineName = null);

    string PrintBlankTagTest();
  }
}
