using CoilTracking.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface ICoilTypeService
  {

    Task<List<CoilTypeDto>> GetCoilTypes();
    Task<List<CoilTypeDto>> GetCoilsTypes();
    Task<CoilTypeDto> GetCoilTypesById(int id);
    Task<List<MaterialTypeDto>> GetMaterialTypes();
    Task<List<CoilDto>> GetCoilsByCoilTypeId(int id);
    Task<string> CheckEdit(int id, CoilTypeDto dto);
    Task<List<CoilDto>> GetCoilsLoadedForCoilType(int id);
    Task<List<string>> CheckDependency(int id);
    Task<CoilTypeDto> DeleteCoilTypeById(int id);
    Task<CoilTypeDto> DisableCoilType(int id, bool disable);
    Task<string> UpdateCoilType(int id, CoilTypeDto coilType);
    Task<CoilTypeDto> InsertCoilType(CoilTypeDto coilType);
  }
}
