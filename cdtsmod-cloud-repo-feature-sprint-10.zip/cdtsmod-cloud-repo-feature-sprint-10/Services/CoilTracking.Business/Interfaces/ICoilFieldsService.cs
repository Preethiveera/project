using CoilTracking.DTO;
using System.Collections.Generic;

namespace CoilTracking.Business.Interfaces
{
  public interface ICoilFieldsService
  {
    public List<CoilFieldDto> GetCoilFields();

    public CoilFieldDto GetCoilFieldById(int id);
    public CoilFieldDto GetCoilFieldForEdit(int id);

    public string CheckIfEdited(int id, CoilFieldDto dto);

    public List<CoilFieldZoneDto> GetCoilFieldsZoneByCoilFieldId(int id);
    public List<CoilDto> GetCoilsByCoilField(int id);

    public List<string> GetCoilsFieldAssociationType(int id);

    public bool DisableCoilField(int id, bool disable);
    public bool UpdateCoilFieldDto(int id, CoilFieldDto dto);
    public bool SaveCoilFieldDto(CoilFieldDto dto);

    public CoilFieldDto DeleteCoilField(int id);
  }
}
