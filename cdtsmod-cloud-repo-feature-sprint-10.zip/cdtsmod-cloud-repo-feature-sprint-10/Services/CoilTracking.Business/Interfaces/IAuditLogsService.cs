using CoilTracking.Data.Models;
using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface IAuditLogsService
  {
    /// <summary>
    /// 
    /// </summary>
    /// <param name="Id"></param>
    /// <returns></returns>
    AuditLog IsAuditLogExists(int Id);
    public IQueryable<AuditLogsDto> GetAuditLogs();

    public List<string> GetUserAuditLogs();

    public List<AuditLog> Search(DateTime? startTime = null, DateTime? endTime = null, string username = null, int? actionType = null, string className = null);


  }
}
