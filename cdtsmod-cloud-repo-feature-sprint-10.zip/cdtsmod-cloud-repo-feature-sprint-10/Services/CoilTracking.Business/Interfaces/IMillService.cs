using CoilTracking.DTO;
using System.Collections.Generic;
using System.Linq;

namespace CoilTracking.Business.Interfaces
{
  public interface IMillService
  {
    public IQueryable<MillDto> GetMills();
    public MillDto GetMillById(int id);

    public List<CoilDto> GetAssociatedItemsMills(int id);

    public List<CoilDto> GetLoadedCoilsById(int id);

    public string CheckIfEdited(int id, MillDto mill);

    public List<string> CheckDependencyType(int id);
    public bool DisableMill(int id, bool disable);

    public bool InsertMill(MillDto milldto);
    public MillDto DeleteMill(int id);

    public bool UpdateMill(int id, MillDto mill);
  }
}
