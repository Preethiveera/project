using CoilTracking.Data.Models;
using CoilTracking.DTO;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface IRunOrderListQuantityService
  {
    Task<List<RunOrderListQuantity>> GetRunOrderListQuantities();
    RunOrderListQuantity GetRunOrderListQuantity(int id);

    RunOrderItemForCreate GetRunOrderItem(int lineId, string partNumber, int sortOrder);
    void InsertRunOrderListQuantity(RunOrderListQuantity runOrderListQuantity);
    void UpdateRunOrderListQuantity(int id, RunOrderListQuantity runOrderListQuantity);
    void DeleteRunOrderListQuantity(int id);
  }
}
