using CoilTracking.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface ICoilStatusService
  {
    public Task<List<CoilStatusDto>> GetCoilStatuses();
    public Task<CoilStatusDto> GetCoilStatusById(int id);
    public void InsertCoilStatus(CoilStatusDto coilStatusDto);
    public void UpdateCoilStatus(int id, CoilStatusDto coilStatusDto);
    public CoilStatusDto DeleteCoilStatus(int id);
  }
}
