using CoilTracking.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface ICoilFieldZonesService
  {
    public Task<List<CoilFieldZoneDto>> GetCoilFieldZones();

    public Task<CoilFieldZoneDto> GetCoilFieldZone(int id);

    public Task<CoilFieldZoneDto> GetCoilFieldZoneForEdit(int id);

    public Task<List<CoilTypeDto>> GetAssociatedItemsCoilFieldsZone(int zoneId);

    public Task<List<CoilDto>> GetCoilsByZoneId(int zoneId);

    public Task<List<string>> CheckDependencyByZoneId(int zoneId);

    public Task<bool> DisableCoilFieldZone(int zoneId, bool disable);

    public Task<string> CheckIfEdited(CoilFieldZoneDto coilFeildZoneDto);

    public Task UpdateCoilFieldZone(CoilFieldZoneDto coilFeildZoneDto);

    public Task<CoilFieldZoneDto> SaveCoilFieldZone(CoilFieldZoneDto coilFeildZoneDto);

    public Task<CoilFieldZoneDto> DeleteCoilFieldZone(int zoneId);
  }
}
