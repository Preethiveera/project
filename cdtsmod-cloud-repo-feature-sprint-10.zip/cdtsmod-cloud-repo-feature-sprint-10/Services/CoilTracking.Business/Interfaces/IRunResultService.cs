using CoilTracking.Data.Models;
using CoilTracking.DTO;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface IRunResultService
  {
    /// <summary>
    /// Get Run Results
    /// </summary>
    /// <returns></returns>
    Task<List<RunResultDto>> GetRunResults();

    List<RunResultDto> GetRunOrderRunResult(int id);

    /// <summary>
    /// Get Search Result
    /// </summary>
    /// <param name="startTime"></param>
    /// <param name="endTime"></param>
    /// <param name="partNum"></param>
    /// <param name="dataNum"></param>
    /// <param name="coilType"></param>
    /// <param name="lineId"></param>
    /// <param name="shiftId"></param>
    /// <param name="ftz"></param>
    /// <returns></returns>
    List<RunResultDto> GetRunResultsSearch(DateTime? startTime = null, DateTime? endTime = null, string partNum = null, int? dataNum = null, string coilType = null, int? lineId = null, int? shiftId = null, string ftz = null);

    /// <summary>
    /// Get Latest Run Results
    /// </summary>
    /// <returns></returns>
    Task<RunResultDto> GetLatestRunResult();

    /// <summary>
    /// Get CurrentStack For Size
    /// </summary>
    /// <returns></returns>
    BlankInfoDto GetCurrentStackSize(int dataNum);

    /// <summary>
    /// Get RunResult Based on Id
    /// </summary>
    /// <param name="Id"></param>
    /// <returns></returns>
    Task<RunResultDto> GetRunResultById(int Id);

    /// <summary>
    /// Get RunResult For Edit Based on ID
    /// </summary>
    /// <param name="Id"></param>
    /// <returns></returns>
    Task<RunResultDto> GetRunResultForEditByID(int Id);

    /// <summary>
    /// Ge tRunCoils To Be Weighed
    /// </summary>
    /// <returns></returns>
    List<CoilToBeWeighed> GetRunCoilsToBeWeighed();
    /// <summary>
    /// Get Coil By FTZ ToBeWeighed
    /// </summary>
    /// <param name="ftz"></param>
    /// <returns></returns>
   Task<List<CoilToBeWeighed>> GetCoilByFTZToBeWeighed(string ftz);
    /// <summary>
    /// Get Scrap Results
    /// </summary>
    /// <param name="startTime"></param>
    /// <param name="endTime"></param>
    /// <param name="partNum"></param>
    /// <param name="dataNum"></param>
    /// <param name="coilType"></param>
    /// <param name="lineId"></param>
    /// <param name="shiftId"></param>
    /// <param name="ftz"></param>
    /// <returns></returns>
    List<ScrapResultsDto> GetScrapResults(DateTime? startTime = null, DateTime? endTime = null, string partNum = null, int? dataNum = null, string coilType = null, int? lineId = null, int? shiftId = null, string ftz = null);

    /// <summary>
    /// Save ReturnWeight
    /// </summary>
    /// <param name="partials"></param>
    /// <returns></returns>
    bool SaveReturnWeight(List<CoilToBeWeighed> partials);
    /// <summary>
    /// Update CurrentWeight
    /// </summary>
    /// <param name="data"></param>
    Task<bool> UpdateCurrentWeight(CoilToBeWeighed partial);

    Task<bool> ModifyRunResult(RunResult runResult);

    bool IsRunResultExists(int id);

    Task<RunResult> DeleteRunResult(int id);

    Task<RunResult> UpdateRunResult(int id, RunResultDto runResultDto);

    Task<RunResultDto> InsertRunResult(RunResultDto runResultDto);

    Task<string> GetPlantCode();

    Task<List<RunResult>> GetRunResultByDateAsync(DateTime startDate, DateTime endDate);

    Task<bool> InsertRunResults(RunResult runResult);

  }
}
