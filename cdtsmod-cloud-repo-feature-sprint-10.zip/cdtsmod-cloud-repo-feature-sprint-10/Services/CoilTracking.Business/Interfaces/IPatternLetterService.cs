using CoilTracking.Data.Models;
using CoilTracking.DTO;
using System.Collections.Generic;
using System.Linq;

namespace CoilTracking.Business.Interfaces
{
  public interface IPatternLetterService
  {
    IQueryable<PatternLetterDto> GetPatternLetter();
    PatternLetterDto GetPatternLetterById(int id);
    PatternLetter PostPatternLetter(PatternLetterDto patternLetterDto);
    bool PutPatternLetter(int id, PatternLetterDto patternLetterDto);
    PatternLetterDto DeletePatternLetter(int id);
    bool DisablePatternLetter(int id, bool disable);
    List<string> CheckDependency(int id);

    bool CheckEdit(int id, PatternLetterDto patternLetterDto);

  }
}
