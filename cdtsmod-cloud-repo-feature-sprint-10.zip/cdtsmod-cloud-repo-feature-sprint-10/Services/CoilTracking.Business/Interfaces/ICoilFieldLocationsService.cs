using CoilTracking.Data.Models;
using CoilTracking.DTO;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface ICoilFieldLocationsService
  {
    IQueryable<CoilFieldLocationDto> GetCoilFieldLocations();

    CoilFieldLocationDto GetCoilFieldLocationById(int id);

    Task<CoilFieldLocationDto> GetCoilFieldLocationWithZone(int id);

    List<CoilFieldLocationDto> GetCoilFieldLocationByCoilId(int coilId);

    List<CoilFieldLocationDto> GetCoilFieldLocationByZoneId(int zoneId);

    void UpdateCoilFieldLocation(int id, CoilFieldLocationDto coilFieldLocation);

    Task<string> DisableCoilFieldLocation(int id, bool disable);

    Task<string> UpdateCoilFieldLocationDto(int id, CoilFieldLocationDto coilFieldLocation);

    Task<CoilFieldLocationDto> AddCoilFieldLocation(CoilFieldLocationDto coilFieldLocation);

    CoilFieldLocationDto DeleteCoilFieldLocation(int id);

    Task<List<string>> CheckEditAsync(int id, CoilFieldLocationDto dto);
  }
}
