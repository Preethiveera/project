using CoilTracking.Data.Models;


namespace CoilTracking.Business.Interfaces
{
  public interface IPLCIntegrationService
  {
    public int SubscribeLineData(LineInfo lineInfo, string token=null);
    public int UnSubscribeLineData(LineInfo lineInfo, string token=null);
    public  string TestPLC();
  }
}
