using CoilTracking.Data.Models;
using CoilTracking.DTO;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface IBlankInfoService
  {
    public IQueryable<BlankInfo> GetAllBlankInfo();

    public BlankInfoDto GetBlankInfoById(int id);

    public string GetNAMCinfo();

    public BlankInfo GetBlankInfoByDataNumAndLineId(int dataNum, int lineId);
    public bool IsBlankInfoDependent(int id);
    public Task<bool> AddNewBlankInfo(BlankInfoDto blankInfoDto);

    public Task<bool> CheckEdit(int id, BlankInfoDto blankInfoDto);

    void UpdateBlankInfo(int id, BlankInfoDto blankInfoDto);

    void DisableBlankInfo(int id, bool disable);

    BlankInfoDto DeleteBlankInfo(int id);

    Task<List<BlankInfoDto>> GetBlankInfoByPartId(int id);

    Task<List<BlankInfoDto>> GetBlankInfoPartsInRunOrder(int id);

    Task<List<IncompleteRunOrderItem>> GetBlankInfoRunOrder(List<BlankInfo> blanks);
  }
}
