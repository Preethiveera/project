
using CoilTracking.Data.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface IOPCClientServiceManager
  {
    Task GetLineInfoData(Line line, bool subscribe, string token=null);

    List<LineInfo> GetLineInfos(List<Line> lineConfigs);
    public  string TestPLC();
  }
}
