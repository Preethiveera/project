using CoilTracking.Data.Models;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface ICoilLocationManager
  {
    Task<Coil> AssignCoilLocation(CoilStatus newStatus, Coil coil, int? lineId, string newLocation);
  }
}
