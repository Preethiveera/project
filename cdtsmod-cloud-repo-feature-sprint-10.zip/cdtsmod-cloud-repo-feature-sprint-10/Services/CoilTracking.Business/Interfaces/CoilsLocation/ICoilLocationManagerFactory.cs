namespace CoilTracking.Business.Interfaces
{
  public interface ICoilLocationManagerFactory
  {
    ICoilLocationManager Create(string location);
  }
}
