using CoilTracking.Data.Models;
using CoilTracking.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoilTracking.Business.Interfaces
{
  public interface IPartsService
  {
    Task<List<PartDto>> GetParts();
    Task<PartDto> GetPartById(int id);
    Task<List<int>> GetPartModelsById(int id);

    Task<List<string>> GetAutoCompleteInfo(string partNumber, int lineId);

    Task UpdatePart(int id, Part part);

    Task DisablePart(int id, bool disable);

    Task<int> ChangeModels(List<Model> models, int id);

    Task<int> ChangeModelNopart(List<Model> models, Part part);

    Task<Part> InsertPart(Part part);
    Task<Part> DeletePart(int id);

    Task PartCheckEdit(int id, Part part);

    Task<List<string>> GetPartProdPlanAssociation(int id);



  }
}
