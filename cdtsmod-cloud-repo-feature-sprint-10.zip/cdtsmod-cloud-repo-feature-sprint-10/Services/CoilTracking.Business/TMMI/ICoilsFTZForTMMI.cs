using System.Threading.Tasks;

namespace CoilTracking.Business.TMMI
{
  public interface ICoilsFTZForTMMI
  {
    Task<Data.Models.Coil> GetCoilFTZByPrefix(string ftz);


  }
}
