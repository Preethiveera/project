using CoilTracking.DTO;
using OfficeOpenXml;
using System.Collections.Generic;
using static CoilTracking.Business.Implementation.ImportBlankData;

namespace CoilTracking.Business.Implementation
{
  public class ImportBlankForTMMI : ImportBlankBase
  {
    /// <summary>
    /// Get the BlankDataRecord from the row index specified for Tmmi plant
    /// </summary>
    /// <param name="worksheet"></param>
    /// <param name="errors"></param>
    /// <param name="row"></param>
    /// <returns>records</returns>
    public override ImportBlankData.BlankDataRecord GetRecordFromRow(ExcelWorksheet worksheet, List<DataImportMessage> errors, int row)
    {
      var record = base.GetRecordFromRow(worksheet, errors, row);
      errors.AddRange(DataImportHelper.GetDecimal(worksheet, row, (int)Columns.RewindWeight, Columns.RewindWeight.ToString(), out record.RewindWeight));

      return record;
    }
  }
}
