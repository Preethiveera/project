---
name: Import repository
about: Import repository from Bitbucket to Github
title: Import repository from Bitbucket to Github
labels: ''
assignees: ''

---

**List down bitbucket repositories below the line (seperated by comma/semi-colon/new line).** <br> 

**Note**: 
1. Repos migrated into github will have team name prefixed if not already. Example: Repos belonging to `tmna` team - `samples-java` will become `tmna-samples-java` & `tmna-samples-npm` will remain `tmna-samples-npm`. 

2. Issue will be updated post completion. Progress can be viewed under [`Actions`]
__________________________________________________________________________________
